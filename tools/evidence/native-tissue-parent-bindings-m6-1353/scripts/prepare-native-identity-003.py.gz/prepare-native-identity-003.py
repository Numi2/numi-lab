from pathlib import Path
import json,hashlib,sys,shutil,argparse,importlib.util
A=Path('/Users/n/numi-human-retained-delivery-20261009/anatomy-completion-1276')
P=A/'temporalis163-native-m6-001';O=A/'parent-bindings-native-identity-1353-003'
W=Path('/Users/n/numi-lab-parent-bindings-1353');B=Path('/Users/n/numi-lab-parent-bindings-build-1353-002')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for name in ('lib','matter','shaders'):
 target=Path('/Users/n/numi-lab-resting-mtp-anatomy-build-1330')/name
 
 if not (B/name).exists():(B/name).symlink_to(target)
O.mkdir(exist_ok=False);(O/'baseline').mkdir()
sys.path.insert(0,'/Users/n/numi-human-complete-reference-inventory-1335/src')
from numilab_human import resting_run as rr,passive_attachment_composition as pc
T=P/'assets/bodyparts3d-myosim-fullbody-muscle-surfaces.nhtissue'
t=pc._read_nhtiss4(T);row=next(r for r in t['records'] if int(r[6])==163)
receipt=json.loads((P/'resting-anatomy-receipt.json').read_text())
for filename in ('common-cardiac-map-f32.bin','common-cardiac-domains-f32.bin','common-cardiac-volumes-f32.bin'):
 shutil.copyfile(P/filename,O/filename)
receipt['passive_tissue_parent_bindings']=dict(child_payload_sha256=sha(T),source_payloads=[dict(path=str(T),sha256=sha(T))],surfaces=[dict(stable_id=163,vertices=[[[0,163,v,1.0]] for v in range(int(row[3]))])])
rp=O/'resting-anatomy-receipt.json';rp.write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
base=json.loads((P/'baseline/run-declaration.json').read_text());idx=base['argv'].index('numilab_human.resting_run');av=base['argv'][idx+1:]
for flag,value in [('--output',str(O/'baseline/native-run')),('--anatomy-receipt',str(rp)),('--build',str(B)),('--lab',str(W))]:
 if flag in av:av[av.index(flag)+1]=value
 else:av.extend([flag,value])
parser=argparse.ArgumentParser();rr.add_arguments(parser);args=parser.parse_args(av);native,assets=rr.command(args)
env=dict(x.split('=',1) for x in base['argv'][2:idx-2])
env['NUMI_HUMAN_RESTING_COMMON_FAILURE_RECEIPT']=str(args.output/'common-field-failure.json')
env['NUMI_LAB_ROOT']=str(W);env['NUMI_BUILD_DIR']=str(B)
env['DYLD_LIBRARY_PATH']=':'.join(str((B/p).resolve()) for p in ('lib','matter'))
argv=['/usr/bin/env','-i']+[k+'='+v for k,v in sorted(env.items())]+['/Users/n/numi-human-prep-venv-20261005/bin/python3.13','-m','numilab_human.resting_run']+av
launch=O/'launch_arm.py';shutil.copyfile(P/'launch_arm.py',launch)
pins={**assets,**{str(p):sha(p) for p in [Path(__file__),rp,T,W/'apps/NumiHumanRestingTissueParents.hpp',W/'apps/NumiHumanRestingVisual.hpp',W/'apps/numilab_human_myosim_visual_probe.mm',B/'build-report.json',launch]}}
decl=dict(schema='numi.human.native-smoke.run-declaration.v1',seconds=16.,accepted_steps=8000,immutable_assets=pins,argv=argv,launch_adapter=dict(path=str(launch),sha256=sha(launch)),owner_cli_preview=dict(native_argv=native,asset_sha256=assets,recorded_invocation_environment=rr.invocation_environment(env)),execution_host='numi',qualification='Existing tissue163 identity parent-reference native regression; no new anatomy qualification.')
dp=O/'baseline/run-declaration.json';dp.write_text(json.dumps(decl,indent=2,sort_keys=True)+'\n')
(O/'launch-guard.json').write_text(json.dumps(dict(launcher_sha256=sha(launch),arms=dict(baseline=dict(run_declaration_sha256=sha(dp),native_output=str(args.output)))),indent=2)+'\n')
print(O,flush=True)

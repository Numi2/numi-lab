#!/usr/bin/env python3
from __future__ import annotations
import argparse,hashlib,importlib.util,json,sys,time
from pathlib import Path
import numpy as np
A=Path('/Users/numi/numi-human-retained-delivery-20261009/anatomy-completion-1276')
SRC=A/'forearm054-native-diagnostic-009-refined085'
C=A/'forearm-shared-field-native-compensated-011'
RUN=C/'baseline/native-run'
FIELD=Path('/Users/numi/numi-human-fds132-m6-1350/attempt-088-registered-route-field-refined-2mm-001/result-001/route-anchor-reference-field-001.npz')
H=A/'neck-back-retained-pose-audit-002/forward_all_positive_weights.py'
PUB=Path('/Users/numi/numi-human-left-pq-publication-1344/src')
STEPS=[0,4767,5023,5599,6207,7423,8000]
ALL_STEPS=[3807]+STEPS
TARGETS=(132,134)
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(4*1024*1024),b''):h.update(b)
 return h.hexdigest()
def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
def jd(x):
 if isinstance(x,np.generic):return x.item()
 if isinstance(x,np.ndarray):return x.tolist()
 if isinstance(x,Path):return str(x)
 raise TypeError(type(x).__name__)
def parity(t):
 inv=sum(int(t[i]>t[j]) for i in range(3) for j in range(i+1,3))
 return -1 if inv%2 else 1
def signs(v):return ['positive' if x>0 else 'negative' if x<0 else 'zero' for x in v]
def volume_signs(xyz,faces,components):
 x=np.asarray(xyz,dtype=np.float64);out=[]
 for comp in components:
  fc=faces[np.asarray(comp,dtype=np.int64)];used=np.unique(fc);tri=x[fc]-x[used].mean(axis=0,dtype=np.float64)
  out.append(float(np.einsum('ij,ij->i',tri[:,0],np.cross(tri[:,1],tri[:,2])).sum()/6.))
 return out
def build_union(surfaces,gids,coords):
 occ={};allf=[];lookup={sid:{g:i for i,g in enumerate(gids[sid])} for sid in TARGETS}
 for sid in TARGETS:
  for fi,face in enumerate(np.asarray(surfaces[sid]['faces'],dtype=np.int64)):
   trip=tuple(int(gids[sid][int(v)]) for v in face);key=tuple(sorted(trip));occ.setdefault(key,[]).append((sid,fi,trip));allf.append((sid,fi,trip,key))
 removed=set();shared=[];errors=[]
 for key,items in occ.items():
  if len(items)==1:continue
  if len(items)==2 and {items[0][0],items[1][0]}==set(TARGETS) and parity(items[0][2])==-parity(items[1][2]):
   shared.append(key);removed.update(((items[0][0],items[0][1]),(items[1][0],items[1][1])))
  elif len(items)==2 and {items[0][0],items[1][0]}==set(TARGETS):
   errors.append({'global_face_ids':list(key),'reason':'shared_orientation_not_opposite'})
  else:errors.append({'global_face_ids':list(key),'reason':'duplicate_or_unpaired_face','occurrences':[[s,f] for s,f,_ in items]})
 remaining=[x for x in allf if (x[0],x[1]) not in removed]
 used=sorted({g for _,_,trip,_ in remaining for g in trip});ix={g:i for i,g in enumerate(used)};xyz=[]
 for gid in used:
  qs=[]
  for sid in TARGETS:
   i=lookup[sid].get(gid)
   if i is not None:qs.append(np.asarray(coords[sid][i],dtype='<f4'))
  if not qs:errors.append({'global_vertex_id':gid,'reason':'missing_coordinates'});xyz.append(np.zeros(3,dtype='<f4'))
  else:
   if any(q.tobytes()!=qs[0].tobytes() for q in qs[1:]):errors.append({'global_vertex_id':gid,'reason':'shared_xyz_not_bitwise_equal'})
   xyz.append(qs[0])
 faces=np.asarray([[ix[g] for g in trip] for _,_,trip,_ in remaining],dtype=np.int64)
 src=[(sid,fi) for sid,fi,_,_ in remaining]
 return np.asarray(xyz,dtype='<f4'),faces,src,{'shared_face_pairs':len(shared),'removed_face_count':len(removed),'remaining_face_count':len(faces),'remaining_vertex_count':len(used),'shared_vertex_count':len(set(gids[132])&set(gids[134])),'interface_errors':errors}
def topo_summary(t):
 return {k:t.get(k) for k in ('closed_oriented_manifold_candidate','vertex_count','face_count','edge_count','face_component_count','boundary_edge_count','boundary_loop_count','euler_characteristic')}
def exact_self(h,xyz,faces,ci):
 rec,dg=h.exact_rows(np.asarray(xyz,dtype='<f4'),np.asarray(faces,dtype=np.int64),ci)
 if rec is None or dg:return None,dg,[]
 a=ci._audit_pair(rec,rec,same_surface=True);return int(a['count']),dg,a.get('triangle_pairs',[])
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--max-rss-gib',type=float,default=2.5);args=ap.parse_args()
 try:
  import resource
  limit=int(args.max_rss_gib*1024**3);resource.setrlimit(resource.RLIMIT_AS,(limit,limit))
 except Exception:pass
 out=C/'native-audit-002';out.mkdir(exist_ok=False);rp=out/'report.json'
 report={'schema':'numi.human.forearm-shared-field-native-011-kahan-target-geometry-audit.v1',
 'scope':'Experimental target-geometry-only audit of Kahan-accumulated shared-field native011. Exact child self/topology and joined-union self/topology/winding are checked on actual native captures. Start at the prior step3807 witness, then cover the remaining capture grid only if step3807 passes. Whole-scene unchanged-surface/pose/physiology comparison is reported separately by the owning root audit. No anatomy admission claim.',
 'status':'running','complete':False,'checks':{},'captures':{},'failures':[],'pins':{}}
 def save():rp.write_text(json.dumps(report,indent=2,sort_keys=True,default=jd)+'\n')
 def check(n,ok,**f):
  report['checks'][n]={'passed':bool(ok),**f}
  if not ok:report['failures'].append(n)
  save()
 prior_path=C/'native-audit-001/report.json'
 prior=json.loads(prior_path.read_text())
 prior_check=prior.get('checks',{}).get('capture_3807_native_children_and_union',{})
 report['captures'].update(prior.get('captures',{}))
 if prior_check:report['checks']['capture_3807_native_children_and_union']=prior_check
 if not prior_check.get('passed',False):
  report['failures'].append('capture_3807_native_children_and_union')
  report['status']='step3807_native_target_geometry_failed';report['complete']=True
  save();print(json.dumps({'report':str(rp),'status':report['status'],'failed_checks':report['failures']},indent=2),flush=True);return
 sys.path.insert(0,str(PUB))
 from numilab_human import cardiac_cavity_intersections as ci,common_atlas_skin_clearance as ca
 from numilab_human.cardiac_cavity_geometry import analyze_topology
 h=module('forearm054_011_audit_forward',H)
 prep=json.loads((SRC/'preparation.json').read_text());decl=json.loads((C/'baseline/run-declaration.json').read_text())
 ex=json.loads((C/'baseline/execution.json').read_text());inv=json.loads((RUN/'invocation.json').read_text());meta=json.loads((RUN/'run-metadata.json').read_text())
 check('execution_and_invocation_pins',ex.get('returncode')==0 and ex.get('timed_out') is False and meta.get('exit_code')==0 and ex.get('native_argv_matches_prepared_cli_preview') is True and ex.get('native_environment_matches_prepared_cli_preview') is True and not ex.get('changed_inputs') and not meta.get('source_files_changed_during_run'),
  returncode=ex.get('returncode'),timed_out=ex.get('timed_out'),native_exit_code=meta.get('exit_code'),wall_seconds=ex.get('wall_seconds'),argv_match=ex.get('native_argv_matches_prepared_cli_preview'),environment_match=ex.get('native_environment_matches_prepared_cli_preview'),changed_input_count=len(ex.get('changed_inputs',[])),capture_steps=decl.get('capture_steps'))
 # 011 intentionally reuses 009's exact target source geometry and field definition.
 target_pins={SRC/'preparation.json':None,SRC/'baseline/run-declaration.json':prep.get('run_declaration_sha256'),
  SRC/'assets/bodyparts3d-myosim-fullbody-muscle-surfaces.nhtissue':prep.get('child_payload_sha256'),
  SRC/'assets/shared-field-carriers.nhtissue':prep.get('carrier_payload_sha256'),
  SRC/'passive-tissue-parent-bindings.json':prep.get('parent_extension_sha256'),
  FIELD:prep.get('route_field_sha256'),Path(prep.get('candidate_path','')):prep.get('candidate_sha256')}
 bad=[]
 for p,expected in target_pins.items():
  actual=sha(p) if p.is_file() else None
  if expected and expected!=actual:bad.append({'path':str(p),'expected':expected,'actual':actual})
 check('shared_target_geometry_source_pinned',not bad and prep.get('anatomical_admission_claimed') is False,
  source_preparation_status=prep.get('status'),pin_count=len(target_pins),mismatches=bad)
 with np.load(FIELD,allow_pickle=False) as z:field={k:z[k].copy() for k in z.files}
 src={};gids={};faces={};rest={};child_top={};child_vol={}
 for sid in TARGETS:
  src[sid]={'faces':field[f'stable{sid}_faces']}
  gids[sid]=list(map(int,field[f'stable{sid}_global_vertex_ids']))
  faces[sid]=np.asarray(field[f'stable{sid}_faces'],dtype=np.int64)
  rest[sid]=np.asarray(field[f'stable{sid}_rest_positions_m'],dtype='<f4')
  child_top[sid]=analyze_topology(rest[sid].astype(float).tolist(),faces[sid].tolist())
  child_vol[sid]=volume_signs(rest[sid],faces[sid],child_top[sid].get('face_components',[]))
 shared=sorted(set(gids[132])&set(gids[134]));gix={sid:{g:i for i,g in enumerate(gids[sid])} for sid in TARGETS}
 refxyz,reffaces,refsources,refmeta=build_union(src,gids,rest)
 reftop=analyze_topology(refxyz.astype(float).tolist(),reffaces.tolist());refvol=volume_signs(refxyz,reffaces,reftop.get('face_components',[]))
 refok=not refmeta['interface_errors'] and refmeta['shared_face_pairs']==7010 and refmeta['removed_face_count']==14020 and refmeta['remaining_face_count']==40624 and refmeta['remaining_vertex_count']==20208 and reftop.get('closed_oriented_manifold_candidate') is True and len(reftop.get('face_components',[]))==12 and 'zero' not in signs(refvol)
 check('source085_union_reference_closed_and_wound',refok,construction={k:v for k,v in refmeta.items() if k!='interface_errors'},interface_error_count=len(refmeta['interface_errors']),topology=topo_summary(reftop),component_signs=signs(refvol))
 request_keys,*_=ca._load_target_inventory(h.INV);request_keys=set(request_keys)|{(51005,s) for s in (151,152,159,160,161,162,163,164)}
 expected_inventory=request_keys|{(51007,1)}
 # 3807 is the known precision-sensitive witness. Stop here if any local geometry gate fails.
 for step in STEPS:
  start=time.monotonic();pack=RUN/'accepted-geometry'/f'step-{step}.mrvpack';rp0=pack.with_suffix('.receipt.json')
  if not pack.is_file() or not rp0.is_file():
   check(f'capture_{step}_available',False,pack_exists=pack.is_file(),receipt_exists=rp0.is_file());report['captures'][str(step)]={'available':False};continue
  receipt=json.loads(rp0.read_text());pos,surf,_=ca._pack_surfaces(pack,request_keys)
  inventory_ok=set(surf)==expected_inventory and len(surf)==868
  receipt_ok=receipt.get('physical_endpoint')=='accepted' and receipt.get('pack_file_sha256')==sha(pack)
  rows={};world={}
  for sid in TARGETS:
   nf=np.asarray(surf[(51005,sid)]['faces'],dtype=np.int64);delta=nf-faces[sid]
   layout=nf.shape==faces[sid].shape and delta.size>0 and bool(np.all(delta==delta.flat[0]))
   if not layout:
    rows[str(sid)]={'face_layout_matches_candidate':False,'geometry_pass':False};continue
   offset=int(delta.flat[0]);x=pos[offset:offset+len(gids[sid])].astype('<f4',copy=True);world[sid]=x
   top=analyze_topology(x.astype(float).tolist(),faces[sid].tolist());selfcount,dg,pairs=exact_self(h,x,faces[sid],ci)
   vols=volume_signs(x,faces[sid],top.get('face_components',[]));s=signs(vols);sr=signs(child_vol[sid])
   winding=s==sr and 'zero' not in s
   topok=top.get('closed_oriented_manifold_candidate') is True and len(top.get('face_components',[]))==len(child_top[sid].get('face_components',[]))
   ok=topok and selfcount==0 and len(dg)==0 and winding
   rows[str(sid)]={'vertex_count':len(x),'face_count':len(faces[sid]),'face_layout_matches_candidate':True,'closed_oriented_manifold':topok,'topology':topo_summary(top),
    'component_signed_volumes_m3':vols,'component_signs':s,'source_component_signs':sr,'winding_matches_source':winding,
    'degenerate_face_count':len(dg),'degenerate_face_ids':[int(v) for v in dg[:20]],'exact_self_pair_count':selfcount,'exact_self_pairs':[list(map(int,v)) for v in pairs[:20]],'geometry_pass':ok}
  seam_count=0;seam_ok=False;max_gap=None
  if set(world)==set(TARGETS):
   a=world[132][[gix[132][g] for g in shared]];b=world[134][[gix[134][g] for g in shared]]
   seam_count=int(np.count_nonzero(np.all(a==b,axis=1)));gaps=np.linalg.norm(a.astype(np.float64)-b.astype(np.float64),axis=1)*1e6;max_gap=float(gaps.max()) if len(gaps) else None
   seam_ok=seam_count==len(shared)
  unionok=False;union={}
  if set(world)==set(TARGETS):
   ux,uf,usrc,um=build_union(src,gids,world);top=analyze_topology(ux.astype(float).tolist(),uf.tolist());selfcount,dg,pairs=exact_self(h,ux,uf,ci)
   vols=volume_signs(ux,uf,top.get('face_components',[]));sg=signs(vols);winding=sg==signs(refvol) and 'zero' not in sg
   topok=top.get('closed_oriented_manifold_candidate') is True and len(top.get('face_components',[]))==12 and top.get('vertex_count')==20208 and top.get('face_count')==40624
   details=[]
   for pair in pairs[:20]:
    detail=[]
    for fi in pair:
     if 0<=int(fi)<len(usrc):detail.append({'union_face':int(fi),'stable_id':int(usrc[int(fi)][0]),'source_face':int(usrc[int(fi)][1])})
    details.append(detail)
   unionok=not um['interface_errors'] and um['shared_face_pairs']==7010 and um['removed_face_count']==14020 and um['remaining_face_count']==40624 and um['remaining_vertex_count']==20208 and seam_ok and len(dg)==0 and selfcount==0 and topok and winding
   union={'construction':{k:v for k,v in um.items() if k!='interface_errors'},'interface_error_count':len(um['interface_errors']),'topology':topo_summary(top),
    'component_signed_volumes_m3':vols,'component_signs':sg,'source_component_signs':signs(refvol),'winding_matches_source':winding,
    'degenerate_face_count':len(dg),'degenerate_face_ids':[int(v) for v in dg[:20]],'exact_self_pair_count':selfcount,'exact_self_pairs':details,'union_pass':unionok}
  else:union={'union_pass':False,'reason':'one or both child surfaces missing'}
  local_ok=all(v.get('geometry_pass') is True for v in rows.values())
  entry={'capture_sha256':sha(pack),'receipt_sha256':sha(rp0),'capture_receipt_valid':receipt_ok,'native_inventory_count':len(surf),'inventory_868_exact':inventory_ok,
   'accepted_body_pose_count':len(receipt.get('accepted_body_poses',[])),'shared_seam_vertices':len(shared),'shared_seam_bitwise_equal_count':seam_count,'shared_seam_max_gap_um':max_gap,'shared_seam_pass':seam_ok,
   'children':rows,'joined_union':union,'audit_wall_seconds':time.monotonic()-start}
  report['captures'][str(step)]=entry
  capturepass=receipt_ok and inventory_ok and local_ok and seam_ok and unionok
  check(f'capture_{step}_native_children_and_union',capturepass,step=step,capture_receipt_valid=receipt_ok,inventory_868_exact=inventory_ok,
   seam_bitwise_equal=seam_ok,children={k:{q:v for q,v in r.items() if q in ('geometry_pass','exact_self_pair_count','degenerate_face_count','component_signs','source_component_signs')} for k,r in rows.items()},
   union={k:v for k,v in union.items() if k in ('union_pass','exact_self_pair_count','degenerate_face_count','component_signs','source_component_signs','topology')},audit_wall_seconds=entry['audit_wall_seconds'])
  print(json.dumps({'step':step,'seconds':entry['audit_wall_seconds'],'children':{k:{q:v for q,v in r.items() if q in ('geometry_pass','exact_self_pair_count','degenerate_face_count')} for k,r in rows.items()},'union':{k:v for k,v in union.items() if k in ('union_pass','exact_self_pair_count','degenerate_face_count','component_signs')}}),flush=True)
  if step==3807 and not capturepass:
   report['status']='step3807_native_target_geometry_failed';report['complete']=True;break
 report['pins']={str(p):sha(p) for p in [SRC/'preparation.json',SRC/'assets/bodyparts3d-myosim-fullbody-muscle-surfaces.nhtissue',SRC/'assets/shared-field-carriers.nhtissue',SRC/'passive-tissue-parent-bindings.json',FIELD,C/'baseline/run-declaration.json',C/'baseline/execution.json',C/'native-audit-001/report.json',RUN/'invocation.json',RUN/'run-metadata.json',RUN/'native.log'] if p.is_file()}
 if not report['complete']:
  report['complete']=set(map(int,report['captures']))==set(ALL_STEPS)
  report['status']='experimental_native011_target_geometry_all8_clear_not_admitted' if report['complete'] and not report['failures'] else ('experimental_native011_target_geometry_failed' if report['complete'] else 'native011_target_audit_incomplete')
 save()
 print(json.dumps({'report':str(rp),'status':report['status'],'failed_checks':report['failures'],'steps':sorted(map(int,report['captures']))},indent=2),flush=True)
if __name__=='__main__':main()


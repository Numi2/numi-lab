#pragma once

#include "numi/matter/shared.h"
#include "numi/matter/partitioned_reduction_projection.h"
#ifndef __METAL_VERSION__
#include "numi/matter/partitioned_reduction_sparse_support.hpp"
#endif

#define NM_PARTITIONED_REDUCTION_FEM_TANGENT_TILE_WIDTH 256u

typedef struct NM_ALIGN16 NMPartitionedReductionFEMTangentDispatchGPU {
    nm_u32 globalNodeCount, basisNodeCount, modeCount, tetrahedronCount;
    nm_u32 environmentCount, regionCount, blockModeCount, tileCount;
    nm_u32 objectIndex, supportTetrahedronCount, reserved0, reserved1;
} NMPartitionedReductionFEMTangentDispatchGPU;

// Per-(environment, regional-support-tet, local mode) element action. The
// diagonal pieces let the regional matrix add only FEM off-diagonal coupling;
// the already assembled nodal blocks retain FEM diagonal, inertia, and contact.
typedef struct NM_ALIGN16 NMPartitionedReductionFEMTangentActionGPU {
    NMFEMElementVectorGPU full;
    nm_float4 selfDiagonal[4];
} NMPartitionedReductionFEMTangentActionGPU;

#ifndef __METAL_VERSION__
#include <algorithm>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <span>
#include <string>
#include <vector>

namespace numi::matter {
static_assert(sizeof(NMPartitionedReductionFEMTangentDispatchGPU) == 48u);
static_assert(sizeof(NMPartitionedReductionFEMTangentActionGPU) == 128u);

struct PartitionedReductionFEMTangentSupport {
    std::vector<NMPartitionedReductionSparseRangeGPU> regionTetrahedronRanges;
    std::vector<std::uint32_t> regionTetrahedronIndices;
    std::vector<std::uint32_t> tetrahedronBasisNodeRows;
    std::uint32_t maximumRegionTetrahedronCount = 0u;
    std::uint32_t tileCount = 0u;
    std::string error;
    [[nodiscard]] bool valid() const noexcept { return error.empty(); }
};

// Exact union of tetrahedra touched by each regional twelve-mode block.
// Selected source-object tets must map all four corners into the exact global
// row map; dormant and unrelated-object capacity slots are omitted.
// Build all regional tet lists in one source traversal. Map node ancestry
// once, then gather the exact region union at each tet from compact support.
[[nodiscard]] inline PartitionedReductionFEMTangentSupport
buildPartitionedReductionFEMTangentSupport(
    const PartitionedReductionSparseSupport& support,
    std::span<const std::uint32_t> globalNodes,
    std::uint32_t basisNodeCount, std::uint32_t regionCount,
    std::span<const NMTetrahedronGPU> tetrahedra, std::uint32_t objectIndex
) {
    PartitionedReductionFEMTangentSupport out;
    const auto reject=[&](const char* message) {
        PartitionedReductionFEMTangentSupport failed;failed.error=message;return failed;
    };
    if (!support.valid()||globalNodes.size()!=basisNodeCount||!basisNodeCount||
        support.regionSupportRanges.size()!=regionCount||!regionCount||tetrahedra.empty()||
        tetrahedra.size()>std::numeric_limits<std::uint32_t>::max())
        return reject("sparse FEM tangent support dimensions mismatch");
    for (std::uint32_t row=1;row<basisNodeCount;++row)
        if (globalNodes[row-1u]>=globalNodes[row]) return reject("FEM tangent source rows are not ordered unique");
    // Use only the represented global range, never unrelated world capacity.
    const auto globalFirst=globalNodes.front();
    const std::uint64_t span=std::uint64_t(globalNodes.back())-globalFirst+1u;
    if (span>std::numeric_limits<std::uint32_t>::max())
        return reject("FEM tangent source row span exceeds uint32");
    std::vector<std::uint32_t> localRows(span,NM_INVALID_INDEX);
    for (std::uint32_t row=0;row<basisNodeCount;++row) localRows[globalNodes[row]-globalFirst]=row;
    std::vector<std::vector<std::uint32_t>> rowRegions(basisNodeCount),regionTets(regionCount);
    for (std::uint32_t region=0;region<regionCount;++region) {
        const auto range=support.regionSupportRanges[region];
        if (std::uint64_t(range.first)+range.count>support.regionSupportRows.size())
            return reject("FEM tangent sparse support range is invalid");
        for (auto i=range.first;i<range.first+range.count;++i) {
            const auto row=support.regionSupportRows[i];
            if (row>=basisNodeCount) return reject("FEM tangent sparse support row is invalid");
            rowRegions[row].push_back(region);
        }
    }
    out.tetrahedronBasisNodeRows.assign(tetrahedra.size()*4u,NM_INVALID_INDEX);
    std::vector<std::uint32_t> touched;
    for (std::uint32_t index=0;index<tetrahedra.size();++index) {
        const auto& tet=tetrahedra[index];
        if ((tet.identity.w&NM_OBJECT_ACTIVE)==0u||
            (objectIndex!=NM_INVALID_INDEX&&tet.identity.y!=objectIndex)) continue;
        const std::uint32_t nodes[4]={tet.nodes.x,tet.nodes.y,tet.nodes.z,tet.nodes.w};
        std::uint32_t mapped[4],count=0u;
        for (std::uint32_t k=0;k<4u;++k) {
            const auto node=nodes[k];
            mapped[k]=node>=globalFirst&&std::uint64_t(node)-globalFirst<span
                ?localRows[node-globalFirst]:NM_INVALID_INDEX;
            if (mapped[k]!=NM_INVALID_INDEX) ++count;
        }
        if (!count) continue;
        if (count!=4u) return reject("selected-source tet is only partially represented in the exact basis row map");
        touched.clear();
        for (std::uint32_t k=0;k<4u;++k) {
            out.tetrahedronBasisNodeRows[std::size_t(index)*4u+k]=mapped[k];
            touched.insert(touched.end(),rowRegions[mapped[k]].begin(),rowRegions[mapped[k]].end());
        }
        std::sort(touched.begin(),touched.end());touched.erase(std::unique(touched.begin(),touched.end()),touched.end());
        for (auto region:touched) regionTets[region].push_back(index);
    }
    for (const auto& tets:regionTets) {
        if (tets.empty()||out.regionTetrahedronIndices.size()+tets.size()>std::numeric_limits<std::uint32_t>::max())
            return reject("FEM tangent sparse regional tet range is empty or oversized");
        out.regionTetrahedronRanges.push_back({std::uint32_t(out.regionTetrahedronIndices.size()),std::uint32_t(tets.size())});
        out.regionTetrahedronIndices.insert(out.regionTetrahedronIndices.end(),tets.begin(),tets.end());
        out.maximumRegionTetrahedronCount=std::max(out.maximumRegionTetrahedronCount,std::uint32_t(tets.size()));
    }
    out.tileCount=(out.maximumRegionTetrahedronCount+NM_PARTITIONED_REDUCTION_FEM_TANGENT_TILE_WIDTH-1u)/
        NM_PARTITIONED_REDUCTION_FEM_TANGENT_TILE_WIDTH;
    return out;
}

[[nodiscard]] inline PartitionedReductionFEMTangentSupport
buildPartitionedReductionFEMTangentSupport(
    std::span<const nm_float4> basisValues,
    std::span<const std::uint32_t> globalFEMNodeIndices,
    std::uint32_t basisNodeCount, std::uint32_t modeCount,
    std::span<const std::uint32_t> blockModeIndices,
    std::uint32_t regionCount, std::uint32_t blockModeCount,
    std::span<const NMTetrahedronGPU> tetrahedra,
    std::uint32_t objectIndex) {
    PartitionedReductionFEMTangentSupport out;
    auto fail = [&](const char* message) {
        out.error = message;
        out.regionTetrahedronRanges.clear();
        out.regionTetrahedronIndices.clear();
        out.tetrahedronBasisNodeRows.clear();
        out.maximumRegionTetrahedronCount = out.tileCount = 0u;
        return out;
    };
    if (!basisNodeCount || !modeCount || !regionCount ||
        !blockModeCount || blockModeCount > 32u ||
        globalFEMNodeIndices.size() != basisNodeCount ||
        basisValues.size() != std::size_t(basisNodeCount) * modeCount ||
        blockModeIndices.size() != std::size_t(regionCount) * blockModeCount ||
        tetrahedra.empty() ||
        tetrahedra.size() > std::numeric_limits<std::uint32_t>::max())
        return fail("FEM tangent support dimensions mismatch");
    for (std::uint32_t row = 1u; row < basisNodeCount; ++row)
        if (globalFEMNodeIndices[row - 1u] >= globalFEMNodeIndices[row])
            return fail("FEM tangent support row map is not strictly ascending");
    std::vector<std::uint8_t> seen(modeCount, 0u);
    for (const auto mode : blockModeIndices)
        if (mode >= modeCount || seen[mode]++)
            return fail("FEM tangent support mode map is invalid or duplicated");
    std::vector<std::vector<std::uint8_t>> supported(
        regionCount, std::vector<std::uint8_t>(basisNodeCount, 0u));
    for (std::uint32_t region = 0u; region < regionCount; ++region)
        for (std::uint32_t row = 0u; row < basisNodeCount; ++row)
            for (std::uint32_t local = 0u; local < blockModeCount; ++local) {
                const auto mode = blockModeIndices[
                    std::size_t(region) * blockModeCount + local];
                const auto value = basisValues[
                    std::size_t(mode) * basisNodeCount + row];
                if (!std::isfinite(value.x) || !std::isfinite(value.y) ||
                    !std::isfinite(value.z))
                    return fail("FEM tangent support basis has non-finite xyz");
                supported[region][row] |= value.x != 0.0f ||
                    value.y != 0.0f || value.z != 0.0f;
            }
    if (tetrahedra.size() > std::numeric_limits<std::size_t>::max() / 4u)
        return fail("FEM tangent support row map overflows size_t");
    out.tetrahedronBasisNodeRows.assign(tetrahedra.size() * 4u,
                                         NM_INVALID_INDEX);
    out.regionTetrahedronRanges.resize(regionCount);
    for (std::uint32_t region = 0u; region < regionCount; ++region) {
        auto& range = out.regionTetrahedronRanges[region];
        if (out.regionTetrahedronIndices.size() >
            std::numeric_limits<std::uint32_t>::max())
            return fail("FEM tangent support offset exceeds uint32");
        range.first = static_cast<std::uint32_t>(
            out.regionTetrahedronIndices.size());
        for (std::uint32_t tetIndex = 0u;
             tetIndex < tetrahedra.size(); ++tetIndex) {
            const auto& tet = tetrahedra[tetIndex];
            if ((tet.identity.w & NM_OBJECT_ACTIVE) == 0u ||
                (objectIndex != NM_INVALID_INDEX &&
                 tet.identity.y != objectIndex)) continue;
            const std::uint32_t nodes[4]{
                tet.nodes.x, tet.nodes.y, tet.nodes.z, tet.nodes.w};
            std::array<std::uint32_t, 4u> mappedRows{};
            std::uint32_t mappedCount = 0u;
            for (std::uint32_t slot = 0u; slot < 4u; ++slot) {
                const auto found = std::lower_bound(
                    globalFEMNodeIndices.begin(), globalFEMNodeIndices.end(),
                    nodes[slot]);
                if (found == globalFEMNodeIndices.end() ||
                    *found != nodes[slot]) continue;
                mappedRows[slot] = static_cast<std::uint32_t>(
                    found - globalFEMNodeIndices.begin());
                ++mappedCount;
            }
            if (mappedCount == 0u) continue;
            if (mappedCount != 4u)
                return fail("selected-source tet is only partially represented in the exact basis row map");
            bool touches = false;
            for (std::uint32_t slot = 0u; slot < 4u; ++slot) {
                const auto row = mappedRows[slot];
                out.tetrahedronBasisNodeRows[
                    std::size_t(tetIndex) * 4u + slot] = row;
                touches |= supported[region][row] != 0u;
            }
            if (touches) out.regionTetrahedronIndices.push_back(tetIndex);
        }
        const std::size_t count = out.regionTetrahedronIndices.size() -
            range.first;
        if (!count || count > std::numeric_limits<std::uint32_t>::max())
            return fail("FEM tangent support has empty/oversized regional tet range");
        range.count = static_cast<std::uint32_t>(count);
        out.maximumRegionTetrahedronCount = std::max(
            out.maximumRegionTetrahedronCount, range.count);
    }
    if (out.regionTetrahedronIndices.size() >
        std::numeric_limits<std::uint32_t>::max())
        return fail("FEM tangent support flat list exceeds uint32");
    const std::uint64_t tiles =
        (std::uint64_t(out.maximumRegionTetrahedronCount) +
         NM_PARTITIONED_REDUCTION_FEM_TANGENT_TILE_WIDTH - 1u) /
        NM_PARTITIONED_REDUCTION_FEM_TANGENT_TILE_WIDTH;
    if (!tiles || tiles > std::numeric_limits<std::uint32_t>::max())
        return fail("FEM tangent support tile count invalid");
    out.tileCount = static_cast<std::uint32_t>(tiles);
    return out;
}
} // namespace numi::matter
#endif


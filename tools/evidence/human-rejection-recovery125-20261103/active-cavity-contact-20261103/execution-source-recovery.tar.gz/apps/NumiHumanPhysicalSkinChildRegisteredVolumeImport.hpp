#pragma once

// Narrow bridge from existing combined TetGen node rows and registered O/I/D
// sidecars into the child mass-mapping bundle. Source ancestry remains separate
// from current-parent registration.
#include "NumiHumanPhysicalSkinChildRegisteredSurfaceSidecars.hpp"

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <limits>
#include <set>
#include <span>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

namespace metalrobo::human::coarse_tissue {

enum class PhysicalSkinRegisteredVolumeNodeRole : std::uint8_t {
    interior=0, outerO=1, innerI=2, deepD=3
};

struct PhysicalSkinRegisteredVolumeNodeRow {
    std::uint32_t volumeNodeRow=NM_INVALID_INDEX;
    PhysicalSkinRegisteredVolumeNodeRole role=PhysicalSkinRegisteredVolumeNodeRole::interior;
    std::uint32_t surfaceVertexRow=NM_INVALID_INDEX;
    V3 currentWorldPoint{};
    std::uint32_t donorBody=NM_INVALID_INDEX;
    std::uint32_t donorBinding=NM_INVALID_INDEX;
    V3 donorLocalPoint{};
    std::uint32_t incidentMaterialMask=0u;
    std::uint32_t geometricDonorBody=NM_INVALID_INDEX;
    std::uint32_t anatomicalRegion=NM_INVALID_INDEX;
    std::string sourceMappingKind;

    // Source ancestry is typed by domain and is not a parent-tet ID or mass donor.
    std::string sourceDomain,frameMethod;
    std::uint32_t sourceVertex=NM_INVALID_INDEX,sourceFace=NM_INVALID_INDEX;
    std::array<double,3> sourceBarycentric{};
    V3 sourceResidualWorldM{};

    // Current-frame parent registration. The reference residual is computed
    // at the same world target from this exact tet and barycentric tuple.
    std::string parentRegistrationKind;
    std::uint32_t parentTet=NM_INVALID_INDEX,parentTieCount=0;
    std::array<double,4> parentBarycentric{};
    V3 parentCurrentResidualWorldM{};
    double parentRegistrationDistanceM=0.0;

    // Opt-in split: sourceParentNodeRow preserves exact one-to-one node identity
    // into the immutable source-mass packet; operationalReference* maps the
    // node into the hash-pinned repaired support mesh. They are never aliases.
    std::uint32_t sourceParentNodeRow=NM_INVALID_INDEX;
    std::uint32_t operationalReferenceTet=NM_INVALID_INDEX;
    std::array<double,4> operationalReferenceBarycentric{};
    V3 operationalReferenceResidualWorldM{};
    double operationalReferenceDistanceM=0.0;
    std::uint32_t sourceParentGeometricDonorBody=NM_INVALID_INDEX;
    std::uint32_t sourceParentAnatomicalRegion=NM_INVALID_INDEX;
};

struct PhysicalSkinStableDeepAttachmentRequest {
    std::uint64_t stableAttachmentID=0;
    std::uint32_t donorBody=NM_INVALID_INDEX;
    std::uint32_t stableSourceVertex=NM_INVALID_INDEX;
    std::string sourceDomain;
};
struct PhysicalSkinStableDeepAttachmentMapRow {
    std::uint64_t stableAttachmentID=0;
    std::uint32_t donorBody=NM_INVALID_INDEX;
    std::uint32_t stableSourceVertex=NM_INVALID_INDEX;
    std::uint32_t deepSurfaceVertexRow=NM_INVALID_INDEX;
    std::uint32_t volumeNodeRow=NM_INVALID_INDEX;
};
struct PhysicalSkinRegisteredBodyPose {
    std::uint32_t bodyIndex=NM_INVALID_INDEX;
    std::uint32_t binding=NM_INVALID_INDEX;
    bool available=false;
    PhysicalSkinPoseArithmetic arithmetic=PhysicalSkinPoseArithmetic::strictDouble;
    V3 currentOrigin{},restOrigin{};
    std::array<double,9> currentLocalToWorld{},restLocalToWorld{};
};
enum class PhysicalSkinRegisteredVolumeRegistrationDomain : std::uint8_t {
    sourceMassParent=0,
    candidateOperationalReference=1,
    currentFractionalReference=2
};

struct PhysicalSkinRegisteredVolumeImportReport {
    std::size_t volumeNodeCount=0;
    std::array<std::size_t,3> mappedBoundaryNodes{};
    std::size_t registeredParentRows=0,inferredCurrentParentRows=0,sourceIdentityRows=0;
    bool oneSourceDomain=false,canonicalDetailedSourceMapPopulated=false;
    bool typedSourceDomainMapPopulated=false;
    std::size_t sourceDomainCount=0u;
    double maximumCurrentParentReconstructionErrorM=0.0;
    double maximumReferenceParentReconstructionErrorM=0.0;
    double maximumReferenceResidualDifferenceM=0.0;
    bool separatedOperationalReference=false;
    std::size_t sourceParentNodeIdentityRows=0u;
    double maximumHistoricalSourceParentDistanceM=0.0;
    double maximumOperationalReferenceDistanceM=0.0;
    double maximumOperationalReferenceReconstructionErrorM=0.0;
};
struct PhysicalSkinRegisteredVolumeImportSidecars {
    // Retain exact source semantics even when rows span multiple source domains.
    std::vector<PhysicalSkinNodeSourceRow> sourceAncestryRows;
    std::vector<PhysicalSkinParentRegistrationRow> currentParentRows;
    std::vector<std::string> sourceDomains;
    std::vector<PhysicalSkinStableDeepAttachmentMapRow> deepAttachments;
};


// Operational-reference O/I/D distance measurements are intentionally separate
// from the inherited source-330 thickness fields. The fields retain their
// existing hard bounds; geometric depth and field-parity are reported for
// fitted candidates, but do not rewrite or silently reinterpret source mass or
// thickness lineage.
struct PhysicalSkinRegisteredLayerDepthAudit {
    std::size_t rowCount=0;
    double minimumSkinDepthM=0.0,maximumSkinDepthM=0.0;
    double minimumFatDepthM=0.0,maximumFatDepthM=0.0;
    double maximumSkinDepthFieldErrorM=0.0,maximumFatDepthFieldErrorM=0.0;
    std::vector<std::uint32_t> skinDepthOutsideBoundsRows,fatDepthOutsideBoundsRows;
    std::vector<std::uint32_t> skinDepthFieldMismatchRows,fatDepthFieldMismatchRows;
    bool skinActualDepthWithinBounds=false,fatActualDepthWithinBounds=false;
    bool skinDepthMatchesInheritedField=false,fatDepthMatchesInheritedField=false;
};

// Measures the physical O-I and I-D Euclidean depths in one candidate row
// domain. Declared source fields must remain finite and within the existing
// bounds. Geometric depth excursions and differences from inherited source
// fields are recorded as diagnostics so a caller can use them during fitting;
// this function does not mark a registered-volume candidate physically
// admitted. The immutable source-330 mass/geometry lineage is verified by the
// separate parent-mapping proof and is not substituted by these measurements.
inline bool auditPhysicalSkinRegisteredLayerDepths(
        std::span<const V3> outerO,std::span<const V3> innerI,std::span<const V3> deepD,
        std::span<const double> inheritedSkinThicknessM,
        std::span<const double> inheritedFatThicknessM,
        double minSkinThicknessM,double maxSkinThicknessM,
        double minFatThicknessM,double maxFatThicknessM,
        PhysicalSkinRegisteredLayerDepthAudit& output,std::string& error) {
    auto fail=[&](std::string message){error=std::move(message);return false;};
    const std::size_t n=outerO.size();
    if(n==0u||n>std::numeric_limits<std::uint32_t>::max()||innerI.size()!=n||deepD.size()!=n||
       inheritedSkinThicknessM.size()!=n||inheritedFatThicknessM.size()!=n)
        return fail("registered O/I/D thickness audit arrays must have one identical nonzero row domain");
    if(!std::isfinite(minSkinThicknessM)||!std::isfinite(maxSkinThicknessM)||
       minSkinThicknessM<=0.0||maxSkinThicknessM<minSkinThicknessM||
       !std::isfinite(minFatThicknessM)||!std::isfinite(maxFatThicknessM)||
       minFatThicknessM<=0.0||maxFatThicknessM<minFatThicknessM)
        return fail("registered O/I/D thickness audit bounds must be finite, positive, and ordered");
    const auto finitePoint=[](const V3& point){
        return std::all_of(point.begin(),point.end(),[](double value){return std::isfinite(value);});
    };
    const auto pointDistance=[](const V3& a,const V3& b){
        const double x=a[0]-b[0],y=a[1]-b[1],z=a[2]-b[2];
        return std::sqrt(x*x+y*y+z*z);
    };
    PhysicalSkinRegisteredLayerDepthAudit measured;
    measured.rowCount=n;
    measured.minimumSkinDepthM=std::numeric_limits<double>::infinity();
    measured.minimumFatDepthM=std::numeric_limits<double>::infinity();
    for(std::size_t row=0;row<n;++row) {
        const double declaredSkin=inheritedSkinThicknessM[row];
        const double declaredFat=inheritedFatThicknessM[row];
        if(!finitePoint(outerO[row])||!finitePoint(innerI[row])||!finitePoint(deepD[row])||
           !std::isfinite(declaredSkin)||!std::isfinite(declaredFat)||
           declaredSkin<minSkinThicknessM||declaredSkin>maxSkinThicknessM||
           declaredFat<minFatThicknessM||declaredFat>maxFatThicknessM)
            return fail("registered O/I/D thickness audit has a nonfinite point or inherited field outside its declared bounds at row "+
                        std::to_string(row));
        const double skinDepth=pointDistance(outerO[row],innerI[row]);
        const double fatDepth=pointDistance(innerI[row],deepD[row]);
        if(!std::isfinite(skinDepth)||!std::isfinite(fatDepth))
            return fail("registered O/I/D thickness audit produced a nonfinite geometric depth at row "+
                        std::to_string(row));
        measured.minimumSkinDepthM=std::min(measured.minimumSkinDepthM,skinDepth);
        measured.maximumSkinDepthM=std::max(measured.maximumSkinDepthM,skinDepth);
        measured.minimumFatDepthM=std::min(measured.minimumFatDepthM,fatDepth);
        measured.maximumFatDepthM=std::max(measured.maximumFatDepthM,fatDepth);
        if(skinDepth<minSkinThicknessM||skinDepth>maxSkinThicknessM)
            measured.skinDepthOutsideBoundsRows.push_back(static_cast<std::uint32_t>(row));
        if(fatDepth<minFatThicknessM||fatDepth>maxFatThicknessM)
            measured.fatDepthOutsideBoundsRows.push_back(static_cast<std::uint32_t>(row));
        const double skinError=std::abs(skinDepth-declaredSkin);
        const double fatError=std::abs(fatDepth-declaredFat);
        measured.maximumSkinDepthFieldErrorM=std::max(measured.maximumSkinDepthFieldErrorM,skinError);
        measured.maximumFatDepthFieldErrorM=std::max(measured.maximumFatDepthFieldErrorM,fatError);
        if(skinError>std::max(1.0e-10,declaredSkin*1.0e-5))
            measured.skinDepthFieldMismatchRows.push_back(static_cast<std::uint32_t>(row));
        if(fatError>std::max(1.0e-10,declaredFat*1.0e-5))
            measured.fatDepthFieldMismatchRows.push_back(static_cast<std::uint32_t>(row));
    }
    measured.skinActualDepthWithinBounds=measured.skinDepthOutsideBoundsRows.empty();
    measured.fatActualDepthWithinBounds=measured.fatDepthOutsideBoundsRows.empty();
    measured.skinDepthMatchesInheritedField=measured.skinDepthFieldMismatchRows.empty();
    measured.fatDepthMatchesInheritedField=measured.fatDepthFieldMismatchRows.empty();
    output=std::move(measured);
    error.clear();
    return true;
}

namespace physical_skin_registered_volume_import_detail {

inline bool finitePoint(const V3& p) {
    return std::all_of(p.begin(),p.end(),[](double x){return std::isfinite(x);});
}
inline bool finiteBary(const std::array<double,4>& p) {
    return std::all_of(p.begin(),p.end(),[](double x){return std::isfinite(x);});
}
inline bool closePoint(const V3& a,const V3& b,double tolerance) {
    return norm(sub(a,b))<=tolerance;
}
inline V3 baryPoint(const std::vector<V3>& points,const std::array<std::uint32_t,4>& tet,
                    const std::array<double,4>& bary) {
    V3 out{};
    for(unsigned c=0;c<4;++c)for(unsigned a=0;a<3;++a)out[a]+=bary[c]*points[tet[c]][a];
    return out;
}
inline double signedSixVolume(const std::vector<V3>& points,const std::array<std::uint32_t,4>& tet) {
    return dot(sub(points[tet[1]],points[tet[0]]),
               cross(sub(points[tet[2]],points[tet[0]]),sub(points[tet[3]],points[tet[0]])));
}
inline unsigned roleIndex(PhysicalSkinRegisteredVolumeNodeRole role) {
    switch(role){
        case PhysicalSkinRegisteredVolumeNodeRole::outerO:return 0u;
        case PhysicalSkinRegisteredVolumeNodeRole::innerI:return 1u;
        case PhysicalSkinRegisteredVolumeNodeRole::deepD:return 2u;
        case PhysicalSkinRegisteredVolumeNodeRole::interior:return 3u;
    }
    return 4u;
}
inline bool validSourceIdentity(const PhysicalSkinRegisteredVolumeNodeRow& row,std::string& error) {
    if(!finitePoint(row.sourceResidualWorldM)||
       !std::all_of(row.sourceBarycentric.begin(),row.sourceBarycentric.end(),
                    [](double value){return std::isfinite(value);})){
        error="volume node source barycentric or residual is nonfinite";return false;
    }
    const bool direct=row.sourceVertex!=NM_INVALID_INDEX;
    const bool embedded=row.sourceFace!=NM_INVALID_INDEX;
    if(row.sourceDomain=="derived_volume_interior_no_surface_ancestry"){
        if(row.role!=PhysicalSkinRegisteredVolumeNodeRole::interior||direct||embedded||
           row.sourceMappingKind!="none"||row.frameMethod!="derived_full_all_bodies_geometric_donor_pose"||
           row.sourceBarycentric!=std::array<double,3>{}||row.sourceResidualWorldM!=V3{}){
            error="derived interior source absence has an invalid role, identity, or explicit method";return false;
        }
        return true;
    }
    if(row.sourceDomain.empty()){
        error="volume node lacks a typed source domain or explicit no-surface-ancestry state";return false;
    }
    if(direct==embedded){error="volume node needs exactly one direct source vertex or embedded source face";return false;}
    if((direct&&row.sourceMappingKind!="vertex")||(embedded&&row.sourceMappingKind!="face")){
        error="volume node source mapping kind differs from its explicit vertex/face identity";return false;
    }
    if(embedded){
        double sum=0.0;
        for(double x:row.sourceBarycentric){
            if(!std::isfinite(x)||x< -1.0e-8||x>1.0+1.0e-8){
                error="volume node source-face barycentric is outside its declared source face";return false;
            }
            sum+=x;
        }
        if(std::abs(sum-1.0)>1.0e-8){error="volume node source-face barycentric does not sum to one";return false;}
    }
    if(row.frameMethod.empty()){error="volume node source/frame method is missing";return false;}
    return true;
}
inline bool validParentRegistration(const PhysicalSkinRegisteredVolumeNodeRow& row,
        const PhysicalSkinParentMassPacket& parent,const double maximumDistance,
        const V3& referenceTarget,V3& referenceResidual,double& currentError,
        double& referenceError,std::string& error,const bool enforceDistance=true,
        const std::uint32_t sourceParentDonor=NM_INVALID_INDEX,
        const std::uint32_t sourceParentRegion=NM_INVALID_INDEX) {
    if(row.parentRegistrationKind!="source_parent_tet_reference_registration"&&
       row.parentRegistrationKind!="inferred_current_parent_tet_same_material_donor_region"){
        error="volume node has an absent or unsupported current-parent registration method";return false;
    }
    if(row.parentTet>=parent.tetrahedra.size()||
       parent.materialIndices.size()!=parent.tetrahedra.size()||
       parent.donorBodyIndices.size()!=parent.tetrahedra.size()||
       parent.anatomicalRegionIndices.size()!=parent.tetrahedra.size()){
        error="volume node current-parent registration has an invalid parent label domain";return false;
    }
    const auto expectedDonor=sourceParentDonor==NM_INVALID_INDEX?row.geometricDonorBody:sourceParentDonor;
    const auto expectedRegion=sourceParentRegion==NM_INVALID_INDEX?row.anatomicalRegion:sourceParentRegion;
    if(parent.donorBodyIndices[row.parentTet]!=expectedDonor||
       parent.anatomicalRegionIndices[row.parentTet]!=expectedRegion){
        error="volume node current-parent cell donor/region differs from its declared semantic tuple";return false;
    }
    if(!finiteBary(row.parentBarycentric)||!finitePoint(row.parentCurrentResidualWorldM)||
       !std::isfinite(row.parentRegistrationDistanceM)||row.parentRegistrationDistanceM<0.0||
       (enforceDistance&&row.parentRegistrationDistanceM>maximumDistance)){
        error="volume node current-parent registration has an invalid tet, barycentric, residual, or bound";return false;
    }
    double sum=0.0;
    for(double b:row.parentBarycentric){
        if(b< -1.0e-8||b>1.0+1.0e-8){error="volume node current-parent barycentric is outside its tet";return false;}
        sum+=b;
    }
    if(std::abs(sum-1.0)>1.0e-8||
       std::abs(norm(row.parentCurrentResidualWorldM)-row.parentRegistrationDistanceM)>2.0e-10){
        error="volume node current-parent residual does not match its recorded distance or barycentric sum";return false;
    }
    const auto tet=parent.tetrahedra[row.parentTet];
    for(const auto node:tet)if(node>=parent.currentWorldPoints.size()||
                                  node>=parent.referenceWorldPoints.size()){
        error="volume node current-parent tet references a missing parent point";return false;
    }
    const double currentSixVolume=signedSixVolume(parent.currentWorldPoints,tet);
    const double referenceSixVolume=signedSixVolume(parent.referenceWorldPoints,tet);
    if(!std::isfinite(currentSixVolume)||!std::isfinite(referenceSixVolume)||
       currentSixVolume<=1.0e-24||referenceSixVolume<=1.0e-24){
        error="volume node parent current/reference tet is nonpositive, singular, or inverted";return false;
    }
    const auto currentBase=baryPoint(parent.currentWorldPoints,tet,row.parentBarycentric);
    currentError=norm(sub(add(currentBase,row.parentCurrentResidualWorldM),row.currentWorldPoint));
    if(!std::isfinite(currentError)||currentError>2.0e-8){
        error="volume node current-parent registration does not reconstruct its current world point";return false;
    }

    // Current and child TetGen reference rows use the same initialization-world
    // target. Preserve beta, then move the anchor from parent-current to
    // parent-reference: r_ref = r_cur + sum(beta * (parent_current-parent_ref)).
    referenceResidual=row.parentCurrentResidualWorldM;
    for(unsigned c=0;c<4;++c)for(unsigned a=0;a<3;++a)
        referenceResidual[a]+=row.parentBarycentric[c]*
            (parent.currentWorldPoints[tet[c]][a]-parent.referenceWorldPoints[tet[c]][a]);
    if(!finitePoint(referenceResidual)){
        error="same-target reference parent residual is nonfinite";return false;
    }
    const auto referenceBase=baryPoint(parent.referenceWorldPoints,tet,row.parentBarycentric);
    referenceError=norm(sub(add(referenceBase,referenceResidual),referenceTarget));
    if(!std::isfinite(referenceError)||referenceError>1.0e-8){
        error="same-target converted parent residual does not reconstruct the TetGen reference point";return false;
    }
    return true;
}
inline bool validOperationalReferenceRegistration(
        const PhysicalSkinRegisteredVolumeNodeRow& row,
        const PhysicalSkinChildMassMappingBundle& bundle,const double maximumDistance,
        V3& referenceResidual,double& reconstructionError,std::string& error) {
    if(row.operationalReferenceTet>=bundle.childTetrahedra.size()||
       bundle.childMaterialIndices.size()!=bundle.childTetrahedra.size()||
       bundle.childDonorBodyIndices.size()!=bundle.childTetrahedra.size()||
       bundle.childAnatomicalRegionIndices.size()!=bundle.childTetrahedra.size()||
       (!bundle.currentWorldPoints.empty()&&bundle.currentWorldPoints.size()!=bundle.referenceWorldPoints.size())||
       row.volumeNodeRow>=bundle.referenceWorldPoints.size()){
        error="operational-reference registration has an invalid candidate-cell domain";return false;
    }
    if(!finiteBary(row.operationalReferenceBarycentric)||
       !finitePoint(row.operationalReferenceResidualWorldM)||
       !std::isfinite(row.operationalReferenceDistanceM)||row.operationalReferenceDistanceM<0.0||
       row.operationalReferenceDistanceM>maximumDistance){
        error="operational-reference registration exceeds its pinned distance or finite-value bound";return false;
    }
    double sum=0.0;
    for(const auto weight:row.operationalReferenceBarycentric){
        if(weight< -1.0e-8||weight>1.0+1.0e-8){
            error="operational-reference barycentric is outside its candidate tetrahedron";return false;
        }
        sum+=weight;
    }
    if(std::abs(sum-1.0)>1.0e-8||
       std::abs(norm(row.operationalReferenceResidualWorldM)-row.operationalReferenceDistanceM)>2.0e-10){
        error="operational-reference residual does not match its bounded distance or barycentric sum";return false;
    }
    const auto tet=bundle.childTetrahedra[row.operationalReferenceTet];
    const auto& target=bundle.currentWorldPoints.empty()?bundle.referenceWorldPoints:bundle.currentWorldPoints;
    for(const auto node:tet)if(node>=target.size()||node>=bundle.referenceWorldPoints.size()){
        error="operational-reference cell references an absent candidate node";return false;
    }
    const double currentVolume=signedSixVolume(target,tet);
    const double referenceVolume=signedSixVolume(bundle.referenceWorldPoints,tet);
    if(!std::isfinite(currentVolume)||!std::isfinite(referenceVolume)||
       currentVolume<=1.0e-24||referenceVolume<=1.0e-24){
        error="operational-reference candidate cell is nonpositive, singular, or inverted";return false;
    }
    const auto currentBase=baryPoint(target,tet,row.operationalReferenceBarycentric);
    const auto currentError=norm(sub(add(currentBase,row.operationalReferenceResidualWorldM),row.currentWorldPoint));
    if(!std::isfinite(currentError)||currentError>2.0e-8){
        error="operational-reference current map does not reconstruct its exact candidate node";return false;
    }
    referenceResidual=row.operationalReferenceResidualWorldM;
    for(unsigned corner=0;corner<4;++corner)for(unsigned axis=0;axis<3;++axis)
        referenceResidual[axis]+=row.operationalReferenceBarycentric[corner]*
            (target[tet[corner]][axis]-bundle.referenceWorldPoints[tet[corner]][axis]);
    const auto referenceBase=baryPoint(bundle.referenceWorldPoints,tet,row.operationalReferenceBarycentric);
    reconstructionError=norm(sub(add(referenceBase,referenceResidual),bundle.referenceWorldPoints[row.volumeNodeRow]));
    if(!std::isfinite(reconstructionError)||reconstructionError>1.0e-8){
        error="operational-reference converted residual does not reconstruct the exact candidate reference node";return false;
    }
    error.clear();return true;
}
inline bool compareSource(const PhysicalSkinRegisteredVolumeNodeRow& row,
                          const PhysicalSkinNodeSourceRow& source,std::string& error) {
    const std::string expectedMapping=source.vertex>=0?"vertex":(source.face>=0?"face":"none");
    if(row.sourceMappingKind!=expectedMapping||row.sourceDomain!=source.domain||row.frameMethod!=source.frameMethod||
       row.sourceResidualWorldM!=source.residual||
       (source.vertex<0?row.sourceVertex!=NM_INVALID_INDEX:
          row.sourceVertex!=static_cast<std::uint32_t>(source.vertex))||
       (source.face<0?row.sourceFace!=NM_INVALID_INDEX:
          row.sourceFace!=static_cast<std::uint32_t>(source.face))||
       row.sourceBarycentric!=source.bary){
        error="volume-node source ancestry differs from its exact registered O/I/D sidecar row";return false;
    }
    return true;
}
} // namespace physical_skin_registered_volume_import_detail

[[nodiscard]] inline bool mapPhysicalSkinStableDeepAttachments(
        const std::span<const PhysicalSkinStableDeepAttachmentRequest> requests,
        const RegisteredSurface& deepSurface,
        const std::vector<PhysicalSkinNodeSourceRow>& deepSourceRows,
        const numi::human::SkinBoundaryNodeMap& boundaryMap,
        std::vector<PhysicalSkinStableDeepAttachmentMapRow>& output,
        std::string& error) {
    using namespace physical_skin_registered_volume_import_detail;
    const auto fail=[&](std::string message){error=std::move(message);return false;};
    if(deepSurface.worldPoints.empty()||deepSurface.donorBodyIndices.size()!=deepSurface.worldPoints.size()||
       deepSurface.sourceVertexIndices.size()!=deepSurface.worldPoints.size()||
       deepSourceRows.size()!=deepSurface.worldPoints.size()||
       boundaryMap.fatDeep.size()!=deepSurface.worldPoints.size())
        return fail("deep attachment remap lacks a complete exact D source and boundary table");
    std::string mapError;
    if(!numi::human::validateSkinBoundaryNodeMap(boundaryMap,
            {boundaryMap.outer.size(),boundaryMap.skinInner.size(),boundaryMap.fatDeep.size()},mapError))
        return fail("deep attachment boundary map is invalid: "+mapError);
    std::set<std::uint64_t> stableIDs;
    std::set<std::pair<std::uint32_t,std::uint32_t>> stableSourceKeys;
    std::set<std::uint32_t> usedVolumeNodes;
    std::vector<PhysicalSkinStableDeepAttachmentMapRow> next;
    next.reserve(requests.size());
    for(const auto& request:requests){
        if(request.stableAttachmentID==0u||request.donorBody==NM_INVALID_INDEX||
           request.stableSourceVertex==NM_INVALID_INDEX||request.sourceDomain.empty()||
           !stableIDs.insert(request.stableAttachmentID).second||
           !stableSourceKeys.emplace(request.donorBody,request.stableSourceVertex).second)
            return fail("deep attachment request has a missing or duplicate stable identity");
        std::uint32_t match=NM_INVALID_INDEX;std::size_t matches=0u;
        for(std::size_t row=0;row<deepSurface.worldPoints.size();++row)
            if(deepSurface.donorBodyIndices[row]==request.donorBody&&
               deepSurface.sourceVertexIndices[row]==request.stableSourceVertex&&
               deepSourceRows[row].vertex>=0&&
               static_cast<std::uint32_t>(deepSourceRows[row].vertex)==request.stableSourceVertex&&
               deepSourceRows[row].face<0&&deepSourceRows[row].domain==request.sourceDomain){
                match=static_cast<std::uint32_t>(row);++matches;
            }
        if(matches!=1u)
            return fail("deep attachment stable source identity maps to "+std::to_string(matches)+
                        " exact D rows; exactly one is required");
        const auto volume=boundaryMap.fatDeep[match];
        if(volume>=boundaryMap.volumeNodeCount||!usedVolumeNodes.insert(volume).second)
            return fail("deep attachment rows collapse to a duplicate or invalid child volume node");
        next.push_back({request.stableAttachmentID,request.donorBody,request.stableSourceVertex,
                        match,volume});
    }
    output=std::move(next);error.clear();return true;
}

[[nodiscard]] inline bool compilePhysicalSkinRegisteredVolumeImport(
        PhysicalSkinChildMassMappingBundle& bundle,
        const PhysicalSkinRegisteredSurfaceCSVSet& registered,
        const std::span<const PhysicalSkinRegisteredVolumeNodeRow> nodeRows,
        const std::span<const PhysicalSkinStableDeepAttachmentRequest> deepAttachments,
        const std::span<const PhysicalSkinRegisteredBodyPose> allBodyCurrentPoses,
        const std::size_t sourceBodyCount,const double maximumParentRegistrationDistanceM,
        const std::string_view canonicalDetailedSourceDomain,
        const std::size_t detailedSourceVertexCount,const std::size_t detailedSourceFaceCount,
        PhysicalSkinRegisteredVolumeImportSidecars& sidecars,
        PhysicalSkinRegisteredVolumeImportReport& report,std::string& error,
        const std::span<const PhysicalSkinSourceDomainRegistration> declaredSourceDomains={},
        const PhysicalSkinRegisteredVolumeRegistrationDomain registrationDomain=
            PhysicalSkinRegisteredVolumeRegistrationDomain::sourceMassParent,
        const std::string_view operationalReferenceDomainSHA256={}) {
    using namespace physical_skin_registered_volume_import_detail;
    const auto fail=[&](std::string message){error=std::move(message);return false;};
    const bool typedSourceDomains=!declaredSourceDomains.empty();
    const bool currentFractionalReference=registrationDomain==
        PhysicalSkinRegisteredVolumeRegistrationDomain::currentFractionalReference;
    const bool separatedOperationalReference=currentFractionalReference||registrationDomain==
        PhysicalSkinRegisteredVolumeRegistrationDomain::candidateOperationalReference;
    if(currentFractionalReference&&!typedSourceDomains)
        return fail("current fractional reference requires explicit typed O/I/D source domains");
    if(separatedOperationalReference&&(!physical_skin_child_mass_detail::validSHA256(operationalReferenceDomainSHA256)||
       bundle.childTetrahedra.empty()||!registered.parentRegistrationIsHistoricalProvenanceOnly))
        return fail("separated operational reference requires a pinned positive candidate mesh and label domain");
    if(!separatedOperationalReference&&(!operationalReferenceDomainSHA256.empty()||
       registered.parentRegistrationIsHistoricalProvenanceOnly))
        return fail("legacy source-parent registration cannot carry operational-reference provenance mode");
    if(typedSourceDomains&&(!canonicalDetailedSourceDomain.empty()||
       detailedSourceVertexCount!=0u||detailedSourceFaceCount!=0u))
        return fail("typed source registry and canonical detailed-source counts cannot be mixed");
    const std::size_t nodeCount=bundle.referenceWorldPoints.size();
    if(nodeCount<4u||nodeRows.size()!=nodeCount||nodeCount>std::numeric_limits<std::uint32_t>::max()||
       bundle.childTetrahedra.empty()||bundle.childMaterialIndices.size()!=bundle.childTetrahedra.size()||
       bundle.childDonorBodyIndices.size()!=bundle.childTetrahedra.size()||
       bundle.childAnatomicalRegionIndices.size()!=bundle.childTetrahedra.size()||
       bundle.childStableSourceFaceIdentities.size()!=bundle.childTetrahedra.size()||
       bundle.parent.currentWorldPoints.size()!=bundle.parent.referenceWorldPoints.size()||
       bundle.parent.tetrahedra.empty()||sourceBodyCount==0u||
       registered.framesByDonor.size()!=sourceBodyCount||allBodyCurrentPoses.size()!=sourceBodyCount||
       (!bundle.currentWorldPoints.empty()&&bundle.currentWorldPoints!=bundle.referenceWorldPoints)||
       !std::isfinite(maximumParentRegistrationDistanceM)||maximumParentRegistrationDistanceM<=0.0)
        return fail("registered volume import requires complete TetGen cells/labels, same-target current/reference nodes, parent geometry, donor frames, and node rows");
    std::set<std::uint32_t> registeredBindings;
    for(std::size_t body=0;body<sourceBodyCount;++body){
        const auto& pose=allBodyCurrentPoses[body];
        if(!pose.available||pose.bodyIndex!=body||!finitePoint(pose.currentOrigin)||
           !finitePoint(pose.restOrigin)||
           !(pose.arithmetic==PhysicalSkinPoseArithmetic::nativeFloat32?
             physical_skin_registered_surface_csv_detail::nativeFloat32Rotation(pose.currentLocalToWorld):
             physical_skin_registered_surface_csv_detail::rotation(pose.currentLocalToWorld))||
           !(pose.arithmetic==PhysicalSkinPoseArithmetic::nativeFloat32?
             physical_skin_registered_surface_csv_detail::nativeFloat32Rotation(pose.restLocalToWorld):
             physical_skin_registered_surface_csv_detail::rotation(pose.restLocalToWorld)))
            return fail("full native all-bodies current/rest pose table is incomplete or invalid");
        const auto& registeredFrame=registered.framesByDonor[body];
        if(registeredFrame.available){
            if(pose.binding==NM_INVALID_INDEX||!registeredBindings.insert(pose.binding).second||
               pose.binding!=registeredFrame.binding||pose.arithmetic!=registeredFrame.arithmetic||
               registeredFrame.currentOrigin!=pose.currentOrigin||
               registeredFrame.currentR!=pose.currentLocalToWorld||
               registeredFrame.restOrigin!=pose.restOrigin||
               registeredFrame.restR!=pose.restLocalToWorld)
                return fail("registered donor binding current/rest frame differs from the pinned full native body pose");
        }else if(pose.binding!=NM_INVALID_INDEX){
            return fail("unregistered all-bodies pose carries a fabricated registered skin binding");
        }
    }
    for(unsigned layer=0;layer<3u;++layer){
        const auto& surface=registered.surfaces[layer];
        if(surface.worldPoints.empty()||surface.donorLocalPoints.size()!=surface.worldPoints.size()||
           surface.donorBodyIndices.size()!=surface.worldPoints.size()||
           surface.worldToDonorLocalLinear.size()!=surface.worldPoints.size()||
           registered.nodeSource[layer].size()!=surface.worldPoints.size()||
           registered.nodeParent[layer].size()!=surface.worldPoints.size()||surface.faces.empty())
            return fail("registered O/I/D surface or its exact node sidecars are incomplete");
    }
    PhysicalSkinChildMassMappingBundle nextBundle=bundle;
    PhysicalSkinRegisteredVolumeImportSidecars nextSidecars;
    PhysicalSkinRegisteredVolumeImportReport measured;
    nextBundle.outerSkin=registered.surfaces[0];
    nextBundle.independentSkinInner=registered.surfaces[1];
    nextBundle.independentFatDeep=registered.surfaces[2];
    nextBundle.outerSkin.sourceDomainIndices.clear();
    nextBundle.independentSkinInner.sourceDomainIndices.clear();
    nextBundle.independentFatDeep.sourceDomainIndices.clear();
    nextBundle.sourceDomains.clear();
    nextBundle.volumeNodeSourceDomainIndices.clear();
    if(typedSourceDomains){
        nextBundle.sourceDomains.assign(declaredSourceDomains.begin(),declaredSourceDomains.end());
        nextBundle.volumeNodeSourceDomainIndices.assign(nodeCount,NM_INVALID_INDEX);
        const std::array<PhysicalSkinSourceDomainRole,3> sourceRoles{
            PhysicalSkinSourceDomainRole::outerSurface,PhysicalSkinSourceDomainRole::innerSurface,
            PhysicalSkinSourceDomainRole::deepSurface};
        std::array<RegisteredSurface*,3> targetSurfaces{
            &nextBundle.outerSkin,&nextBundle.independentSkinInner,&nextBundle.independentFatDeep};
        for(unsigned layer=0;layer<3u;++layer){
            const auto rowCount=registered.surfaces[layer].worldPoints.size();
            targetSurfaces[layer]->sourceDomainIndices.resize(rowCount,NM_INVALID_INDEX);
            for(std::size_t row=0;row<rowCount;++row){
                std::uint32_t domainIndex=NM_INVALID_INDEX;
                if(!resolvePhysicalSkinSourceDomainIndex(declaredSourceDomains,
                        registered.nodeSource[layer][row].domain,sourceRoles[layer],domainIndex,error))
                    return fail("registered surface source domain is not pinned for its anatomical role: "+error);
                targetSurfaces[layer]->sourceDomainIndices[row]=domainIndex;
            }
        }
    }
    nextBundle.boundaryMap.volumeNodeCount=static_cast<std::uint32_t>(nodeCount);
    nextBundle.boundaryMap.outer.assign(registered.surfaces[0].worldPoints.size(),NM_INVALID_INDEX);
    nextBundle.boundaryMap.skinInner.assign(registered.surfaces[1].worldPoints.size(),NM_INVALID_INDEX);
    nextBundle.boundaryMap.fatDeep.assign(registered.surfaces[2].worldPoints.size(),NM_INVALID_INDEX);
    nextBundle.volumeNodeSourceVertexIndices.clear();
    nextBundle.volumeNodeSourceFaceIndices.clear();
    nextBundle.volumeNodeSourceBarycentric.clear();
    nextBundle.detailedSourceVertexCount=0u;
    nextBundle.detailedSourceFaceCount=0u;
    nextBundle.currentWorldPoints.resize(nodeCount);
    nextBundle.volumeNodeDonorBodyIndices.resize(nodeCount);
    nextBundle.volumeNodeDonorLocalPoints.resize(nodeCount);
    nextBundle.volumeNodeDonorOriginWorld.resize(nodeCount);
    nextBundle.volumeNodeDonorLocalToWorldLinear.resize(nodeCount);
    nextBundle.volumeNodeParentTetrahedra.resize(nodeCount);
    nextBundle.volumeNodeParentBarycentric.resize(nodeCount);
    nextBundle.volumeNodeParentResidualWorldM.resize(nodeCount);
    nextBundle.volumeNodeSourceParentNodeRows.clear();
    nextBundle.volumeNodeSourceParentRegistrationDistanceM.clear();
    nextBundle.volumeNodeOperationalReferenceTetrahedra.clear();
    nextBundle.volumeNodeOperationalReferenceBarycentric.clear();
    nextBundle.volumeNodeOperationalReferenceResidualWorldM.clear();
    nextBundle.volumeNodeOperationalReferenceDistanceM.clear();
    if(separatedOperationalReference){
        nextBundle.volumeNodeSourceParentNodeRows.assign(nodeCount,NM_INVALID_INDEX);
        nextBundle.volumeNodeSourceParentRegistrationDistanceM.resize(nodeCount,0.0);
        nextBundle.volumeNodeOperationalReferenceTetrahedra.resize(nodeCount,NM_INVALID_INDEX);
        nextBundle.volumeNodeOperationalReferenceBarycentric.resize(nodeCount);
        nextBundle.volumeNodeOperationalReferenceResidualWorldM.resize(nodeCount);
        nextBundle.volumeNodeOperationalReferenceDistanceM.resize(nodeCount,0.0);
        nextBundle.operationalReferenceDomainSHA256=std::string(operationalReferenceDomainSHA256);
    }else{
        nextBundle.operationalReferenceDomainSHA256.clear();
    }
    nextBundle.usesSeparatedOperationalReference=separatedOperationalReference;
    nextSidecars.sourceAncestryRows.resize(nodeCount);
    nextSidecars.currentParentRows.resize(nodeCount);
    nextSidecars.sourceDomains.resize(nodeCount);
    std::vector<std::uint8_t> seen(nodeCount,0u);
    std::vector<std::vector<std::uint32_t>> incidentCells(nodeCount);
    for(std::size_t cell=0;cell<bundle.childTetrahedra.size();++cell){
        const auto tet=bundle.childTetrahedra[cell];
        if(bundle.childMaterialIndices[cell]!=15u&&bundle.childMaterialIndices[cell]!=16u)
            return fail("child incident material is not skin 15 or fat 16");
        const auto donor=bundle.childDonorBodyIndices[cell];
        const auto region=bundle.childAnatomicalRegionIndices[cell];
        if(donor>=sourceBodyCount||region==NM_INVALID_INDEX||
           bundle.childStableSourceFaceIdentities[cell]==NM_INVALID_INDEX)
            return fail("child incident semantic tuple has an invalid donor, region, or stable source face");
        std::set<std::uint32_t> cellNodes;
        for(const auto node:tet){
            if(node>=nodeCount||!cellNodes.insert(node).second)
                return fail("child tetrahedron has an invalid or repeated joint node row");
            incidentCells[node].push_back(static_cast<std::uint32_t>(cell));
        }
    }
    std::vector<std::uint32_t> directSource(nodeCount,NM_INVALID_INDEX),faceSource(nodeCount,NM_INVALID_INDEX);
    std::vector<std::array<double,3>> sourceBary(nodeCount);
    std::set<std::string> nonemptySourceDomains;
    std::size_t sourceIdentityRows=0u,inferredRows=0u,sourceParentIdentityRows=0u;
    double maxCurrentError=0.0,maxReferenceError=0.0,maxResidualDifference=0.0;
    double maxHistoricalSourceParentDistance=0.0,maxOperationalReferenceDistance=0.0;
    double maxOperationalReferenceReconstructionError=0.0;
    std::vector<std::uint8_t> sourceParentNodeSeen(bundle.parent.currentWorldPoints.size(),0u);
    for(std::size_t inputRow=0;inputRow<nodeRows.size();++inputRow){
        const auto& row=nodeRows[inputRow];
        const std::size_t node=row.volumeNodeRow;
        if(node>=nodeCount||seen[node]||node!=inputRow)
            return fail("combined TetGen node-map has a duplicate, missing, or out-of-order joint node row");
        seen[node]=1u;
        if(!finitePoint(row.currentWorldPoint)||!finitePoint(row.donorLocalPoint)||
           row.donorBody>=sourceBodyCount||!allBodyCurrentPoses[row.donorBody].available||
           row.donorBinding!=allBodyCurrentPoses[row.donorBody].binding||
           row.geometricDonorBody>=sourceBodyCount||row.anatomicalRegion==NM_INVALID_INDEX)
            return fail("combined TetGen node row has invalid frame donor/binding, semantic donor, region, or all-bodies pose");
        if(!closePoint(row.currentWorldPoint,bundle.referenceWorldPoints[node],2.0e-8))
            return fail("current registration and TetGen reference node are not the same declared initialization-world target");
        const auto layer=roleIndex(row.role);
        std::string sourceError;
        if(!validSourceIdentity(row,sourceError))return fail(sourceError);
        if(row.sourceMappingKind=="vertex"||row.sourceMappingKind=="face"){
            nonemptySourceDomains.insert(row.sourceDomain);++sourceIdentityRows;
        }
        if(typedSourceDomains){
            if(layer<3u){
                const std::array<PhysicalSkinSourceDomainRole,3> sourceRoles{
                    PhysicalSkinSourceDomainRole::outerSurface,PhysicalSkinSourceDomainRole::innerSurface,
                    PhysicalSkinSourceDomainRole::deepSurface};
                std::uint32_t domainIndex=NM_INVALID_INDEX;
                if(!resolvePhysicalSkinSourceDomainIndex(declaredSourceDomains,row.sourceDomain,
                        sourceRoles[layer],domainIndex,error))
                    return fail("volume node source domain is not pinned for its registered layer: "+error);
                nextBundle.volumeNodeSourceDomainIndices[node]=domainIndex;
            }else if(row.sourceDomain!="derived_volume_interior_no_surface_ancestry"||
                     row.sourceMappingKind!="none"||row.sourceVertex!=NM_INVALID_INDEX||
                     row.sourceFace!=NM_INVALID_INDEX||row.sourceBarycentric!=std::array<double,3>{}||
                     row.sourceResidualWorldM!=V3{}){
                return fail("typed mixed-source interior node must carry explicit no-surface-ancestry state");
            }
        }
        const auto& frame=allBodyCurrentPoses[row.donorBody];
        V3 fromFrame=frame.currentOrigin;
        for(unsigned a=0;a<3;++a)for(unsigned b=0;b<3;++b)
            fromFrame[a]+=frame.currentLocalToWorld[3*a+b]*row.donorLocalPoint[b];
        if(!closePoint(fromFrame,row.currentWorldPoint,1.0e-7))
            return fail("combined TetGen node donor-local point does not reconstruct its current-world position");
        if(layer<3u){
            const auto& surface=registered.surfaces[layer];
            if(row.surfaceVertexRow>=surface.worldPoints.size())
                return fail("registered O/I/D TetGen row references an invalid surface vertex row");
            auto& mapped=layer==0u?nextBundle.boundaryMap.outer:
                         layer==1u?nextBundle.boundaryMap.skinInner:nextBundle.boundaryMap.fatDeep;
            if(mapped[row.surfaceVertexRow]!=NM_INVALID_INDEX)
                return fail("registered O/I/D source row is mapped to multiple TetGen volume nodes");
            const auto& sidecarFrame=registered.framesByDonor[row.donorBody];
            const auto& worldToLocal=surface.worldToDonorLocalLinear[row.surfaceVertexRow];
            const auto expectedWorldToLocal=physical_skin_registered_surface_csv_detail::worldToLocal(
                frame.currentLocalToWorld,frame.arithmetic);
            if(!sidecarFrame.available||
               !closePoint(row.currentWorldPoint,surface.worldPoints[row.surfaceVertexRow],2.0e-8)||
               row.donorBody!=surface.donorBodyIndices[row.surfaceVertexRow]||
               !closePoint(row.donorLocalPoint,surface.donorLocalPoints[row.surfaceVertexRow],2.0e-8)||
               !physical_skin_registered_surface_csv_detail::sameWorldToLocal(
                   worldToLocal,expectedWorldToLocal,frame.arithmetic)||
               !compareSource(row,registered.nodeSource[layer][row.surfaceVertexRow],sourceError))
                return fail(sourceError.empty()?"registered O/I/D TetGen node differs from its exact surface row":sourceError);
            const auto& parentRow=registered.nodeParent[layer][row.surfaceVertexRow];
            const bool inferred=row.parentRegistrationKind==
                "inferred_current_parent_tet_same_material_donor_region";
            if(!parentRow.available||parentRow.tet!=row.parentTet||parentRow.tieCount!=row.parentTieCount||
               parentRow.bary!=row.parentBarycentric||parentRow.residual!=row.parentCurrentResidualWorldM||
               parentRow.distance!=row.parentRegistrationDistanceM||
               parentRow.inferredCurrentParent!=inferred)
                return fail("registered O/I/D parent-current row differs from the exact sidecar registration");
            mapped[row.surfaceVertexRow]=static_cast<std::uint32_t>(node);
            ++measured.mappedBoundaryNodes[layer];
        }else if(layer!=3u||row.surfaceVertexRow!=NM_INVALID_INDEX){
            return fail("interior TetGen node unexpectedly claims a registered surface row");
        }
        if(row.parentTet>=bundle.parent.tetrahedra.size()||
           row.parentTet>=bundle.parent.materialIndices.size())
            return fail("node parent registration references a missing parent tet or label row");
        if(incidentCells[node].empty())
            return fail("combined TetGen node has no incident child cell for its declared semantics");
        std::uint32_t actualMaterialMask=0u;
        bool selectedSemanticIncident=false;
        for(const auto cell:incidentCells[node]){
            const auto material=bundle.childMaterialIndices[cell];
            actualMaterialMask|=(1u<<material);
            if((separatedOperationalReference||material==bundle.parent.materialIndices[row.parentTet])&&
               bundle.childDonorBodyIndices[cell]==row.geometricDonorBody&&
               bundle.childAnatomicalRegionIndices[cell]==row.anatomicalRegion)
                selectedSemanticIncident=true;
        }
        if(separatedOperationalReference){
            if(std::find(incidentCells[node].begin(),incidentCells[node].end(),row.operationalReferenceTet)==
               incidentCells[node].end())
                return fail("operational-reference support tet is not incident to its declared child node");
            const auto supportCell=row.operationalReferenceTet;
            if(bundle.childDonorBodyIndices[supportCell]!=row.geometricDonorBody||
               bundle.childAnatomicalRegionIndices[supportCell]!=row.anatomicalRegion||
               (actualMaterialMask&(1u<<bundle.childMaterialIndices[supportCell]))==0u)
                return fail("operational-reference cell labels differ from its node's incident material/donor/region domain");
        }
        if(actualMaterialMask!=row.incidentMaterialMask)
            return fail("node incident material mask differs from the actual child cell labels");
        if(!selectedSemanticIncident)
            return fail("node parent material/donor/region tuple is not present on an incident child cell");
        V3 referenceResidual{};double currentError=0.0,referenceError=0.0;
        if(!validParentRegistration(row,bundle.parent,maximumParentRegistrationDistanceM,
                bundle.referenceWorldPoints[node],referenceResidual,currentError,referenceError,sourceError,
                !separatedOperationalReference,
                separatedOperationalReference?row.sourceParentGeometricDonorBody:NM_INVALID_INDEX,
                separatedOperationalReference?row.sourceParentAnatomicalRegion:NM_INVALID_INDEX))
            return fail(sourceError);
        maxHistoricalSourceParentDistance=std::max(maxHistoricalSourceParentDistance,
            row.parentRegistrationDistanceM);
        if(separatedOperationalReference)
            nextBundle.volumeNodeSourceParentRegistrationDistanceM[node]=row.parentRegistrationDistanceM;
        maxCurrentError=std::max(maxCurrentError,currentError);
        maxReferenceError=std::max(maxReferenceError,referenceError);
        maxResidualDifference=std::max(maxResidualDifference,
            norm(sub(referenceResidual,row.parentCurrentResidualWorldM)));
        V3 operationalReferenceResidual{};double operationalError=0.0;
        if(separatedOperationalReference){
            if(row.sourceParentNodeRow!=NM_INVALID_INDEX){
                if(row.sourceParentNodeRow>=sourceParentNodeSeen.size()||
                   sourceParentNodeSeen[row.sourceParentNodeRow]++)
                    return fail("source-parent original-node injection is out of range or duplicated");
                if(row.sourceParentGeometricDonorBody>=sourceBodyCount||
                   row.sourceParentAnatomicalRegion==NM_INVALID_INDEX)
                    return fail("source-parent original-node injection has an invalid source geometric donor or region");
                const auto sourceTet=bundle.parent.tetrahedra[row.parentTet];
                bool sourceOneHot=false;
                for(unsigned corner=0;corner<4u;++corner){
                    const double expected=sourceTet[corner]==row.sourceParentNodeRow?1.0:0.0;
                    if(row.parentBarycentric[corner]!=expected)
                        return fail("source-parent node injection is not the exact one-hot historical parent registration");
                    sourceOneHot=sourceOneHot||expected==1.0;
                }
                if(!sourceOneHot)
                    return fail("source-parent original node is absent from its historical parent registration tet");
                ++sourceParentIdentityRows;
            }
            if(!validOperationalReferenceRegistration(row,nextBundle,maximumParentRegistrationDistanceM,
                    operationalReferenceResidual,operationalError,sourceError))
                return fail(sourceError);
            maxOperationalReferenceDistance=std::max(maxOperationalReferenceDistance,
                row.operationalReferenceDistanceM);
            maxOperationalReferenceReconstructionError=std::max(maxOperationalReferenceReconstructionError,
                operationalError);
            nextBundle.volumeNodeSourceParentNodeRows[node]=row.sourceParentNodeRow;
            nextBundle.volumeNodeOperationalReferenceTetrahedra[node]=row.operationalReferenceTet;
            nextBundle.volumeNodeOperationalReferenceBarycentric[node]=row.operationalReferenceBarycentric;
            nextBundle.volumeNodeOperationalReferenceResidualWorldM[node]=operationalReferenceResidual;
            nextBundle.volumeNodeOperationalReferenceDistanceM[node]=row.operationalReferenceDistanceM;
        }else if(row.sourceParentNodeRow!=NM_INVALID_INDEX||row.operationalReferenceTet!=NM_INVALID_INDEX){
            return fail("legacy source-parent route cannot carry separated operational-reference fields");
        }
        nextBundle.currentWorldPoints[node]=row.currentWorldPoint;
        nextBundle.volumeNodeDonorBodyIndices[node]=row.donorBody;
        nextBundle.volumeNodeDonorLocalPoints[node]=row.donorLocalPoint;
        nextBundle.volumeNodeDonorOriginWorld[node]=frame.currentOrigin;
        nextBundle.volumeNodeDonorLocalToWorldLinear[node]=frame.currentLocalToWorld;
        nextBundle.volumeNodeParentTetrahedra[node]=row.parentTet;
        nextBundle.volumeNodeParentBarycentric[node]=row.parentBarycentric;
        nextBundle.volumeNodeParentResidualWorldM[node]=referenceResidual;
        PhysicalSkinNodeSourceRow source;
        source.vertex=row.sourceVertex==NM_INVALID_INDEX?-1:row.sourceVertex;
        source.face=row.sourceFace==NM_INVALID_INDEX?-1:row.sourceFace;
        source.bary=row.sourceBarycentric;source.residual=row.sourceResidualWorldM;
        source.domain=row.sourceDomain;source.frameMethod=row.frameMethod;
        nextSidecars.sourceAncestryRows[node]=std::move(source);
        PhysicalSkinParentRegistrationRow parent;
        parent.available=true;parent.tet=row.parentTet;parent.tieCount=row.parentTieCount;
        parent.bary=row.parentBarycentric;parent.residual=row.parentCurrentResidualWorldM;
        parent.distance=row.parentRegistrationDistanceM;
        parent.inferredCurrentParent=
            row.parentRegistrationKind=="inferred_current_parent_tet_same_material_donor_region";
        nextSidecars.currentParentRows[node]=parent;
        nextSidecars.sourceDomains[node]=row.sourceDomain;
        ++measured.registeredParentRows;
        if(parent.inferredCurrentParent)++inferredRows;
        directSource[node]=row.sourceVertex;faceSource[node]=row.sourceFace;
        sourceBary[node]=row.sourceBarycentric;
    }
    if(std::find(seen.begin(),seen.end(),0u)!=seen.end())
        return fail("combined TetGen node-map omits one or more joint volume node rows");
    if(separatedOperationalReference&&!currentFractionalReference&&
       (sourceParentNodeSeen.size()!=bundle.parent.currentWorldPoints.size()||
        std::find(sourceParentNodeSeen.begin(),sourceParentNodeSeen.end(),0u)!=sourceParentNodeSeen.end()))
        return fail("separated operational-reference map does not retain every immutable source-parent node identity exactly once");
    if(std::any_of(nextBundle.boundaryMap.outer.begin(),nextBundle.boundaryMap.outer.end(),
                   [](auto n){return n==NM_INVALID_INDEX;})||
       std::any_of(nextBundle.boundaryMap.skinInner.begin(),nextBundle.boundaryMap.skinInner.end(),
                   [](auto n){return n==NM_INVALID_INDEX;})||
       std::any_of(nextBundle.boundaryMap.fatDeep.begin(),nextBundle.boundaryMap.fatDeep.end(),
                   [](auto n){return n==NM_INVALID_INDEX;}))
        return fail("combined TetGen node-map does not bijectively cover all O/I/D surface vertices");
    std::string mapError;
    if(!numi::human::validateSkinBoundaryNodeMap(nextBundle.boundaryMap,
            {registered.surfaces[0].worldPoints.size(),registered.surfaces[1].worldPoints.size(),
             registered.surfaces[2].worldPoints.size()},mapError))
        return fail("combined TetGen O/I/D boundary maps are invalid: "+mapError);
    measured.oneSourceDomain=nonemptySourceDomains.size()==1u&&
        (!typedSourceDomains||declaredSourceDomains.size()==1u);
    bool canonicalSourceMap=!canonicalDetailedSourceDomain.empty()&&measured.oneSourceDomain;
    for(const auto& domain:nonemptySourceDomains)
        if(domain!=canonicalDetailedSourceDomain)canonicalSourceMap=false;
    if(canonicalSourceMap&&!typedSourceDomains){
        std::vector<std::uint32_t> vertexRows(nodeCount,NM_INVALID_INDEX),faceRows(nodeCount,NM_INVALID_INDEX);
        for(std::size_t node=0;node<nodeCount;++node){
            if(directSource[node]!=NM_INVALID_INDEX){
                if(directSource[node]>=detailedSourceVertexCount)
                    return fail("registered volume direct source identity exceeds the declared canonical detail domain");
                vertexRows[node]=directSource[node];
            }
            if(faceSource[node]!=NM_INVALID_INDEX){
                if(faceSource[node]>=detailedSourceFaceCount)
                    return fail("registered volume source face exceeds the declared canonical detail domain");
                faceRows[node]=faceSource[node];
            }
        }
        nextBundle.detailedSourceVertexCount=detailedSourceVertexCount;
        nextBundle.detailedSourceFaceCount=detailedSourceFaceCount;
        nextBundle.volumeNodeSourceVertexIndices=std::move(vertexRows);
        nextBundle.volumeNodeSourceFaceIndices=std::move(faceRows);
        nextBundle.volumeNodeSourceBarycentric=std::move(sourceBary);
        measured.canonicalDetailedSourceMapPopulated=true;
    }
    if(typedSourceDomains){
        nextBundle.volumeNodeSourceVertexIndices=directSource;
        nextBundle.volumeNodeSourceFaceIndices=faceSource;
        nextBundle.volumeNodeSourceBarycentric=sourceBary;
        const auto topology=nextBundle.topologyView();
        if(!validatePhysicalSkinSourceDomains(nextBundle.outerSkin,topology,error))
            return fail("typed registered volume source namespaces failed validation: "+error);
        measured.typedSourceDomainMapPopulated=true;
        measured.sourceDomainCount=nextBundle.sourceDomains.size();
    }
    nextBundle.retainedOriginalNodeCount=0u;
    nextBundle.registeredBodyLocalToWorldLinear.resize(sourceBodyCount);
    nextBundle.registeredBodyOriginWorld.resize(sourceBodyCount);
    for(std::size_t donor=0;donor<sourceBodyCount;++donor){
        const auto& frame=allBodyCurrentPoses[donor];
        nextBundle.registeredBodyLocalToWorldLinear[donor]=frame.currentLocalToWorld;
        nextBundle.registeredBodyOriginWorld[donor]=frame.currentOrigin;
    }
    if(!mapPhysicalSkinStableDeepAttachments(deepAttachments,nextBundle.independentFatDeep,
            registered.nodeSource[2],nextBundle.boundaryMap,nextSidecars.deepAttachments,error))
        return false;
    nextBundle.stableDeepAttachments.clear();
    nextBundle.stableDeepAttachments.reserve(nextSidecars.deepAttachments.size());
    for(const auto& row:nextSidecars.deepAttachments)
        nextBundle.stableDeepAttachments.push_back({
            row.stableAttachmentID,row.donorBody,row.stableSourceVertex,
            row.deepSurfaceVertexRow,row.volumeNodeRow});
    measured.volumeNodeCount=nodeCount;measured.registeredParentRows=nodeCount;
    measured.inferredCurrentParentRows=inferredRows;measured.sourceIdentityRows=sourceIdentityRows;
    measured.maximumCurrentParentReconstructionErrorM=maxCurrentError;
    measured.maximumReferenceParentReconstructionErrorM=maxReferenceError;
    measured.maximumReferenceResidualDifferenceM=maxResidualDifference;
    measured.separatedOperationalReference=separatedOperationalReference;
    measured.sourceParentNodeIdentityRows=sourceParentIdentityRows;
    measured.maximumHistoricalSourceParentDistanceM=maxHistoricalSourceParentDistance;
    measured.maximumOperationalReferenceDistanceM=maxOperationalReferenceDistance;
    measured.maximumOperationalReferenceReconstructionErrorM=maxOperationalReferenceReconstructionError;
    bundle=std::move(nextBundle);sidecars=std::move(nextSidecars);report=measured;
    error.clear();return true;
}
} // namespace metalrobo::human::coarse_tissue

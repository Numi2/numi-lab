#include "NumiHumanConformingTissueRefinement.hpp"
#include <cassert>
#include <iostream>
#include <numeric>
using namespace metalrobo::human::coarse_tissue;
int main() {
 using P=std::array<double,3>;using T=std::array<std::uint32_t,4>;
 std::vector<P> sp{{0,0,0},{1,0,0},{0,1,0},{0,0,1}};
 std::vector<P> cp=sp;cp.push_back({.5,0,0});cp.push_back({0,.5,0});
 std::vector<T> st{{0,1,2,3}},ct{{4,1,2,3},{0,4,5,3},{5,4,2,3}};
 std::vector<std::array<std::uint32_t,2>> edges{{0,1},{0,2}};
 std::vector<std::uint32_t> parent{0,0,0},offsets{0,1,2,3,4,6,8},rows{0,1,2,3,0,1,0,2};
 std::vector<double> fractions{.5,.25,.25},weights{1,1,1,1,.5,.5,.5,.5};
 std::vector<std::uint32_t> sm{15},cm{15,15,15},sd{23},cd{23,23,23},sr{24},cr{24,24,24},sf{777},cf{777,777,777};
 std::vector<double> pv{.99/6},pm{1000./6},lower(17,0),upper(17,0);
 lower[15]=900;upper[15]=1100;lower[16]=850;upper[16]=950;
 const std::string pin(64,'a');
 ConformingTissueRefinementInput in{
  sp,st,edges,cp,ct,parent,fractions,offsets,rows,weights,
  sm,cm,sd,cd,sr,cr,sf,cf,pv,pm,lower,upper,pin,pin,pin,pin,pin,157u};
 ConformingTissueRefinementResult out;std::string error;
 assert(verifyConformingTissueRefinement(in,out,error));
 assert(out.maximumParentMassClosureErrorKg==0.0);
 assert(out.maximumParentMeasureClosureErrorM3==0.0);
 assert(out.childSourceReferenceMeasureM3[0]!=out.childParentImmutableReferenceMeasureM3[0]);
 assert(std::abs(std::accumulate(out.childMassKg.begin(),out.childMassKg.end(),0.)-1000./6)<1e-12);
 const auto reject=[&](const auto& bad) {
  ConformingTissueRefinementResult untouched;untouched.verificationSHA256="untouched";untouched.childMassKg={123.0};
  assert(!verifyConformingTissueRefinement(bad,untouched,error));
  assert(untouched.verificationSHA256=="untouched"&&untouched.childMassKg==std::vector<double>{123.0});
 };
 auto bad=in;auto badWeights=weights;badWeights[4]=.6;bad.nodeSourceWeights=badWeights;reject(bad);
 bad=in;auto badTet=ct;std::swap(badTet[0][0],badTet[0][1]);bad.refinedTetrahedra=badTet;reject(bad);
 bad=in;auto badLabel=cf;badLabel[0]=778;bad.refinedStableFaceIds=badLabel;reject(bad);
 bad=in;auto badFraction=fractions;badFraction[0]+=.01;bad.childSourceMeasureFractions=badFraction;reject(bad);
 bad=in;auto badPoints=cp;badPoints[4][0]=std::nextafter(.5f,1.f);bad.refinedReferencePoints=badPoints;reject(bad);
 bad=in;auto badEdges=edges;badEdges[1]=badEdges[0];bad.orderedSplitEdges=badEdges;reject(bad);
 bad=in;badEdges=edges;std::swap(badEdges[0][0],badEdges[0][1]);bad.orderedSplitEdges=badEdges;reject(bad);
 bad=in;auto missingOffsets=offsets;missingOffsets[5]=4;bad.nodeSourceOffsets=missingOffsets;reject(bad);
 bad=in;auto badSource=st;std::swap(badSource[0][0],badSource[0][1]);bad.sourceTetrahedra=badSource;reject(bad);
 bad=in;bad.lineagePacketSHA256="unpinned";reject(bad);
 // A complete material-interface star must refine both incident tissues.
 sp.push_back({0,0,-1});cp=sp;cp.push_back({.5,0,0});
 st={{0,1,2,3},{0,2,1,4}};
 ct={{0,5,2,3},{0,2,5,4},{5,1,2,3},{5,2,1,4}};
 edges={{0,1}};parent={0,1,0,1};fractions={.5,.5,.5,.5};
 offsets={0,1,2,3,4,5,7};rows={0,1,2,3,4,0,1};weights={1,1,1,1,1,.5,.5};
 sm={15,16};cm={15,16,15,16};sd={23,23};cd={23,23,23,23};sr={24,24};cr={24,24,24,24};
 sf={777,778};cf={777,778,777,778};pv={1./6,1./6};pm={1000./6,900./6};
 in={sp,st,edges,cp,ct,parent,fractions,offsets,rows,weights,sm,cm,sd,cd,sr,cr,sf,cf,pv,pm,lower,upper,pin,pin,pin,pin,pin,157u};
 assert(verifyConformingTissueRefinement(in,out,error));
 assert(out.childParentRows==parent);
 std::cout<<"PASS exact full-star replay, nested cell fractions, node CSR, shared material interface, immutable mass measure and 10 atomic rejection controls\n";
}

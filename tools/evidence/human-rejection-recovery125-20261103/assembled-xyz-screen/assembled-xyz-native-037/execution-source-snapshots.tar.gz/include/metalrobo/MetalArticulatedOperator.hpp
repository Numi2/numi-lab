#pragma once

#include "metalrobo/compensated_translation_gpu.h"

#include "metalrobo/EngineModel.hpp"
#include "metalrobo/millard_muscle_gpu.h"
#include "metalrobo/mujoco_muscle_gpu.h"
#include "metalrobo/numi_human_joint_equality_gpu.h"
#include "metalrobo/numanx_human_matter_gpu.h"
#include "metalrobo/numi_human_stand_gpu.h"
#include "metalrobo/numi_human_tendon_gpu.h"

#include <cstddef>
#include <cstdint>
#include <memory>
#include <limits>
#include <span>
#include <string>
#include <vector>

namespace metalrobo {

namespace detail {
[[nodiscard]] inline bool articulatedPureMassThreadgroupBytesChecked(
    const std::size_t bodyCount,
    const bool compensatedGeometry,
    std::size_t& outputBytes
) noexcept {
    constexpr std::size_t maximum = std::numeric_limits<std::size_t>::max();
    std::size_t bytes = 0u;
    const auto append = [&bytes](const std::size_t count,
                                 const std::size_t stride) noexcept {
        constexpr std::size_t maximumValue =
            std::numeric_limits<std::size_t>::max();
        if (count != 0u && stride > maximumValue / count) return false;
        const std::size_t value = count * stride;
        if (bytes > maximumValue - 15u) return false;
        bytes = (bytes + 15u) & ~std::size_t{15u};
        if (value > maximumValue - bytes) return false;
        bytes += value;
        return true;
    };
    const std::size_t positionStride = compensatedGeometry ? 32u : 16u;
    if (!append(bodyCount, positionStride) ||
        !append(bodyCount, 16u) ||
        !append(bodyCount, positionStride) ||
        !append(bodyCount, 16u) ||
        !append(bodyCount, sizeof(std::uint32_t)) ||
        !append(bodyCount, sizeof(std::uint32_t)) ||
        !append(bodyCount, sizeof(std::uint8_t))) {
        return false;
    }
    if (bytes > maximum - 15u) return false;
    outputBytes = (bytes + 15u) & ~std::size_t{15u};
    return bodyCount == 0u || outputBytes != 0u;
}
struct MetalArticulatedOperatorContextState;
struct MetalArticulatedOperatorSubmissionState;
struct MetalNumanXHumanMatterPreparedState;

[[nodiscard]] constexpr std::size_t
articulatedOperatorThreadgroupBytes(
    const std::size_t bodyCount,
    const std::size_t dofCount,
    const bool includeDenseDynamics = true,
    const bool compensatedGeometry = false
) noexcept {
    const auto aligned16 = [](const std::size_t value) {
        return (value + 15u) & ~std::size_t{15u};
    };
    std::size_t bytes = 0u;
    const auto append = [&bytes, &aligned16](
        const std::size_t value
    ) {
        bytes = aligned16(bytes);
        bytes += value;
    };
    // float3 occupies a 16-byte slot in Metal threadgroup memory.
    append((compensatedGeometry ? 32u : 16u) * bodyCount); // body position
    append(16u * bodyCount); // body rotation
    append((compensatedGeometry ? 32u : 16u) * bodyCount); // joint position
    append(16u * bodyCount); // joint axis
    append(sizeof(std::uint32_t) * bodyCount); // inbound joint
    append(sizeof(std::uint32_t) * bodyCount); // parent body
    append(sizeof(std::uint8_t) * bodyCount); // topology-known flags
    if (includeDenseDynamics) {
        append(sizeof(float) * dofCount * dofCount); // dense factor
        append(sizeof(float) * dofCount); // right-hand side
        append(sizeof(float) * dofCount); // forward solve
        append(sizeof(float) * dofCount); // solution
    } else {
        // Candidate point queries reuse one topology mask per body. This is
        // transient dispatch scratch, never cached across candidate epochs.
        append(sizeof(std::uint32_t) * bodyCount * ((dofCount + 31u) / 32u));
    }
    return aligned16(bytes);
}
} // namespace detail

// Immutable source program and mutable state sidecar for the Millard
// reference pass. It is optional: all spans empty preserves the articulated
// operator's historical kinematics/mass behavior. When present, the muscle
// pass executes after the FunctionBased kinematics/Jacobian kernel in the
// same command buffer and receives no CPU-restaged pose or Jacobian data.
struct MetalMillardReferenceInput {
    std::span<const MRMillardMuscleGPU> muscles{};
    std::span<const MRMillardMuscleStateGPU> states{};
    std::span<const MRMillardPathPointGPU> pathPoints{};
    std::span<const MRMillardSourceCurveGPU> curves{};
    std::span<const MRMillardCylinderWrapGPU> cylinderWraps{};

    [[nodiscard]] bool enabled() const noexcept {
        return !muscles.empty();
    }
};

// Immutable MyoSim source program and environment-major activation state for
// the MuJoCo general-muscle device reference. Its path kernel reads the
// articulated pose stream produced immediately before it in the same command
// buffer; no CPU-restaged geometry is admitted.
struct MetalMujocoMuscleReferenceInput {
    std::span<const MRMujocoMuscleGPU> muscles{};
    std::span<const MRMujocoMuscleStateGPU> states{};
    std::span<const MRMujocoMuscleSiteGPU> sites{};
    std::span<const MRMujocoMuscleWrapGPU> wraps{};
    std::span<const MRMujocoMuscleRouteNodeGPU> routeNodes{};
    // Index in the enclosing point-query stream of a dense per-body probe
    // block: COM, local +X, local +Y, local +Z. The source route kernel uses
    // it to reconstruct a world-space spatial Jacobian at each authored site
    // and tangent point, then emits source generalized muscle force on Metal.
    std::uint32_t bodyJacobianPointOffset = MR_INVALID_INDEX;

    [[nodiscard]] bool enabled() const noexcept {
        return !muscles.empty();
    }
};

// Borrowed device view shared by the pre-dynamics continuum pass and its
// post-validation reconciliation in every persistent-Human step. The first
// callback runs after tendon transfer but before articulated dynamics, so an
// accepted continuum reaction may replace (never duplicate) a declared share
// of the source J^T force. The second callback runs after stand validation and
// must commit or roll back the matching continuum transaction from device
// status. Neither callback may commit, wait, retain, or replace borrowed
// objects. Transfer records are environment-major [environment][endpoint].
using MetalNumiHumanTendonLoadEncodeCoupledCandidate = bool (*)(
    void* context,
    const void* query
) noexcept;

struct MetalNumiHumanTendonLoadPass {
    void* commandBuffer = nullptr;
    // Borrowed source-route program/result buffers. They let a downstream
    // anatomical owner replace a strict sub-route share without deleting the
    // selected muscle's proximal route or reconstructing force on the CPU.
    // All four buffers belong to the enclosing operator and have the same
    // lifetime and command-buffer restrictions as the tendon buffers below.
    void* mujocoMuscles = nullptr;
    void* mujocoSites = nullptr;
    void* mujocoWraps = nullptr;
    void* mujocoRouteNodes = nullptr;
    void* mujocoResults = nullptr;
    void* bindings = nullptr;
    void* envelopes = nullptr;
    void* transfers = nullptr;
    void* generalizedCorrections = nullptr;
    void* generalizedForces = nullptr;
    void* bodyPoses = nullptr;
    // Paired geometry uses the same environment/body stride as bodyPoses.
    // Null with zero address/count retains the legacy high-only view.
    void* bodyPositionLow = nullptr;
    std::uint64_t bodyPositionLowGPUAddress = 0u;
    std::uint64_t bodyPositionLowElementCount = 0u;
    void* pointJacobians = nullptr;
    void* standStatuses = nullptr;
    std::uint32_t stepIndex = 0u;
    std::uint32_t environmentCount = 0u;
    std::uint32_t endpointCount = 0u;
    std::uint32_t envelopeCount = 0u;
    std::uint32_t dofCount = 0u;
    std::uint32_t muscleCount = 0u;
    std::uint32_t siteCount = 0u;
    std::uint32_t wrapCount = 0u;
    std::uint32_t routeNodeCount = 0u;
    std::uint32_t generalizedForceStride = 0u;
    std::uint32_t generalizedForceOffset = 0u;
    std::uint32_t pointJacobianStride = 0u;
    std::uint32_t bodyJacobianPointOffset = MR_INVALID_INDEX;
    std::uint32_t bodyPoseStride = 0u;
    std::uint32_t articulationFirstBody = 0u;
    // Per-transaction Matter gravity scale; default preserves legacy behavior.
    float matterGravityScale = 1.0f;

    // Exact pre-dynamics source q paired with the captured FEM body load.
    // The optional capture path requires one environment and snapshots both
    // values before articulated dynamics can mutate pose/J buffers.
    void* sourceQ = nullptr;
    std::uint32_t sourceQCoordinateCount = 0u;
    std::uint64_t sourceQElementCount = 0u;
    // Exact source generalized velocity and per-environment source strides;
    // present only during a candidate-enabled preDynamics callback.
    void* sourceV = nullptr;
    std::uint64_t sourceVElementCount = 0u;
    std::uint32_t sourceQStride = 0u;
    std::uint32_t sourceVStride = 0u;
    std::uint32_t candidateBodyCount = 0u;

    // Optional caller-owned shared buffers for the accepted FEM-to-body
    // generalized load and its exact pre-dynamics source q. The adapter writes
    // them only after the exact Stand transaction is accepted; rejection
    // zeros both. Read only after command completion.
    void* acceptedFEMBodyGeneralizedLoadCapture = nullptr;
    std::uint64_t acceptedFEMBodyGeneralizedLoadGPUAddress = 0u;
    std::uint64_t acceptedFEMBodyGeneralizedLoadElementCount = 0u;
    void* acceptedFEMBodySourceQCapture = nullptr;
    std::uint64_t acceptedFEMBodySourceQGPUAddress = 0u;
    std::uint64_t acceptedFEMBodySourceQElementCount = 0u;

    // Optional ABI-7 transaction candidate bridge. It is present only for the
    // synchronous preDynamics call and returns false for unsupported operations.
    void* coupledCandidateContext = nullptr;
    MetalNumiHumanTendonLoadEncodeCoupledCandidate encodeCoupledCandidate = nullptr;
    // True only when the callback also exposes the ABI-8 raw source-mass service.
    bool sourceMassOperationsAvailable = false;
    // Identity of the borrowed candidate transaction, never inferred from a
    // coincident buffer address. Zero retains the legacy direct-only service.
    std::uint64_t candidateTransactionFingerprint = 0u;
    std::uint64_t candidateLinearizationEpoch = 0u;
    std::uint64_t candidateSlotGeneration = 0u;


    // ABI-9 transaction-only staging view, forwarded by the Resting owner.
    // The adapter must fill [environment][dof]; the articulated owner consumes
    // the scratch exactly once after preDynamics callbacks.
    void* stagedGeneralizedForce = nullptr;
    std::uint64_t stagedGeneralizedForceGPUAddress = 0u;
    std::uint64_t stagedGeneralizedForceElementCount = 0u;
    std::uint32_t stagedGeneralizedForceStride = 0u;
    // Initialization-only pressure traction transfer scale; default is full.
    float vascularPressureLoadScale = 1.0f;
};

using MetalNumiHumanTendonLoadEncode = bool (*)(
    void* context,
    const MetalNumiHumanTendonLoadPass& pass
);

// Called only if a downstream load pass was encoded but the enclosing Human
// command buffer is abandoned before commit. It releases consumer-side
// transaction ownership and must not touch the borrowed Metal resources.
using MetalNumiHumanTendonLoadAbort = void (*)(
    void* context,
    void* commandBuffer
);

struct MetalNumiHumanTendonLoadProgram {
    void* context = nullptr;
    MetalNumiHumanTendonLoadEncode encodePreDynamics = nullptr;
    MetalNumiHumanTendonLoadEncode encodePostValidation = nullptr;
    MetalNumiHumanTendonLoadAbort abort = nullptr;
    std::uint64_t fingerprint = 0u;

    [[nodiscard]] bool valid() const noexcept {
        return context != nullptr && encodePreDynamics != nullptr &&
            encodePostValidation != nullptr && abort != nullptr &&
            fingerprint != 0u;
    }

    [[nodiscard]] bool configured() const noexcept {
        return context != nullptr || encodePreDynamics != nullptr ||
            encodePostValidation != nullptr || abort != nullptr ||
            fingerprint != 0u;
    }
};

// Optional support-surface query refresh. The callback is offered after
// current-step kinematics, MyoSim/tendon evaluation, and the Human/Matter
// pre-dynamics apply. It may write only the pointWorld, pointPositionLow, and
// pointJacobians rows addressed by the immutable stand.contacts pointQueryIndex
// values. When the registered provider opts into per-contact fixed planes, it
// may additionally overwrite only planePoint/planeNormal on those contact
// records. Contact IDs, source geometry, friction/rest parameters, body poses,
// paired body positions, and every other point row remain read-only. Plane
// fields are transient derived data, not rollback state: regenerate them before
// every stand use. A second predictedFreeEndpoint phase may be offered after
// the exact free-velocity solve and before projected contact responses are
// assembled. Implementations append work to the same command buffer; they must
// not commit, wait, retain, read back, or replace borrowed resources.
enum class MetalNumiHumanSupportGeometryPhase : std::uint32_t {
    currentPose = 0u,
    predictedFreeEndpoint = 1u,
};

struct MetalNumiHumanSupportGeometryPass {
    std::uint32_t abiVersion = 3u;
    std::uint32_t structSize = sizeof(MetalNumiHumanSupportGeometryPass);
    void* commandBuffer = nullptr;
    void* bodyPoses = nullptr;
    void* bodyPositionLow = nullptr;
    void* pointWorld = nullptr;
    void* pointPositionLow = nullptr;
    void* pointJacobians = nullptr;
    void* standContacts = nullptr;
    std::uint32_t stepIndex = 0u;
    std::uint32_t articulationFirstBody = 0u;
    std::uint32_t bodyJacobianPointOffset = MR_INVALID_INDEX;
    std::uint32_t dofCount = 0u;
    std::uint64_t environmentCount = 0u;
    std::uint64_t bodyCount = 0u;
    std::uint64_t bodyPoseStride = 0u;
    std::uint64_t bodyPoseElementCount = 0u;
    std::uint64_t pointCount = 0u;
    std::uint64_t pointWorldStride = 0u;
    std::uint64_t pointWorldElementCount = 0u;
    std::uint64_t pointJacobianStride = 0u;
    std::uint64_t pointJacobianElementCount = 0u;
    std::uint64_t standContactCount = 0u;
    mr_float4 groundPoint{};
    mr_float4 groundNormal{};
    MetalNumiHumanSupportGeometryPhase phase =
        MetalNumiHumanSupportGeometryPhase::currentPose;
    void* sourceFreeVelocity = nullptr;
    std::uint64_t sourceFreeVelocityElementOffset = 0u;
    std::uint64_t sourceFreeVelocityElementCount = 0u;
    std::uint64_t sourceFreeVelocityElementStride = 0u;
    float timestepSeconds = 0.0f;
};

using MetalNumiHumanSupportGeometryEncode = bool (*)(
    void* context, const MetalNumiHumanSupportGeometryPass& pass
);
using MetalNumiHumanSupportGeometryAbort = void (*)(
    void* context, void* commandBuffer
);

struct MetalNumiHumanSupportGeometryProgram {
    void* context = nullptr;
    // Called for currentPose and, in the split GPU preview path, again for
    // predictedFreeEndpoint after the source free-velocity solve.
    MetalNumiHumanSupportGeometryEncode encodePreDynamics = nullptr;
    MetalNumiHumanSupportGeometryAbort abort = nullptr;
    std::uint64_t fingerprint = 0u;
    // The provider regenerates fixed-environment facet planes on the GPU.
    bool usePerContactSupportPlanes = false;

    [[nodiscard]] bool valid() const noexcept {
        return context != nullptr && encodePreDynamics != nullptr &&
            abort != nullptr && fingerprint != 0u;
    }
    [[nodiscard]] bool configured() const noexcept {
        return context != nullptr || encodePreDynamics != nullptr ||
            abort != nullptr || fingerprint != 0u || usePerContactSupportPlanes;
    }
};

enum class MetalNumanXTransactionPhase : std::uint32_t {
    beginStep = 0u,
    preDynamics = 1u,
    postDynamics = 2u,
    // Opt-in final phase: dispatched after tendon validation, before ordinary
    // Stand reconciliation so its final failure status can restore this step.
    acceptedPublication = 3u,
};

// ABI 4 is pre-deferred; ABI 5 adds deferred publication; ABI 6 adds a
// versioned live DoF-properties transaction lease.
inline constexpr std::uint32_t kMetalNumanXTransactionLegacyABIVersion = 4u;
inline constexpr std::uint32_t kMetalNumanXTransactionDeferredPublicationABIVersion = 5u;
inline constexpr std::uint32_t kMetalNumanXTransactionABIVersion = 6u;
inline constexpr std::uint32_t kMetalNumanXTransactionCandidateKinematicsABIVersion = 7u;
inline constexpr std::uint32_t kMetalNumanXTransactionSourceMassABIVersion = 8u;
inline constexpr std::uint32_t kMetalNumanXTransactionStagedForceABIVersion = 9u;
inline constexpr std::uint32_t
    kMetalNumanXTransactionSourceMassQueryLegacyABIVersion = 1u;
inline constexpr std::uint32_t
    kMetalNumanXTransactionSourceMassQueryCapabilityABIVersion = 2u;
inline constexpr std::uint32_t
    kMetalNumanXTransactionSourceMassQueryICBRecordABIVersion = 3u;

struct MetalNumanXHumanMatterCandidateQuery;
struct MetalNumanXTransactionPass;
using MetalNumanXTransactionEncodeExactCandidate = bool (*)(
    void* context,
    const MetalNumanXTransactionPass& pass,
    const MetalNumanXHumanMatterCandidateQuery& query
) noexcept;

// Typed, synchronous description of an owner-created ACTION command. The
// owner retains the underlying resources; Matter copies these bindings into
// its operator ICB during the same preDynamics callback.
struct MetalNumanXTransactionSourceMassICBRecord {
    std::uint32_t abiVersion = 1u;
    std::uint32_t structSize =
        sizeof(MetalNumanXTransactionSourceMassICBRecord);
    void* pipeline = nullptr;
    void* sourceMassMatrix = nullptr;
    void* input = nullptr;
    void* output = nullptr;
    void* statuses = nullptr;
    void* factorScratch = nullptr;
    void* assemblyStatuses = nullptr;
    void* diagonalScaleScratch = nullptr;
    void* factorValidity = nullptr;
    MRArticulatedSourceMassOperationDispatchGPU dispatch{};
    std::uint32_t threadgroupWidth = 0u;
    std::uint32_t groupCountX = 0u;
    std::uint32_t groupCountY = 0u;
    std::uint32_t groupCountZ = 0u;
};

struct MetalNumanXTransactionSourceMassQuery {
    std::uint32_t abiVersion =
        kMetalNumanXTransactionSourceMassQueryCapabilityABIVersion;
    std::uint32_t structSize = static_cast<std::uint32_t>(offsetof(
        MetalNumanXTransactionSourceMassQuery, indirectCommandRecordOutput));
    // ACTION computes output=M(q_source)*input. SOLVE computes output=M(q_source)^-1*input.
    // Input/output are environment-major float vectors; status is one uint per statusStride.
    std::uint32_t operation = MR_ARTICULATED_SOURCE_MASS_ACTION;
    std::uint32_t reserved0 = 0u;
    void* input = nullptr;
    void* output = nullptr;
    void* statuses = nullptr;
    void* candidateQ = nullptr; // non-null candidate-q services are not implemented
    std::uint64_t inputGPUAddress = 0u;
    std::uint64_t outputGPUAddress = 0u;
    std::uint64_t statusesGPUAddress = 0u;
    std::uint64_t candidateQGPUAddress = 0u;
    std::uint64_t inputElementCount = 0u;
    std::uint64_t outputElementCount = 0u;
    std::uint64_t statusElementCount = 0u;
    std::uint32_t generalizedVectorStride = 0u;
    std::uint32_t statusStride = 0u;
    // ABI 2 tail: optional same-command-buffer encoder lease and GPU-produced
    // one-environment indirect threadgroup tuple from the Matter caller.
    // The callback may encode on the lease, but must not end or retain it.
    void* borrowedComputeEncoder = nullptr;
    void* borrowedCommandBuffer = nullptr;
    void* indirectDispatchArguments = nullptr;
    std::uint64_t indirectDispatchArgumentsGPUAddress = 0u;
    std::uint64_t indirectDispatchArgumentsByteCapacity = 0u;
    std::uint64_t indirectDispatchTransactionFingerprint = 0u;
    std::uint64_t indirectDispatchLinearizationEpoch = 0u;
    std::uint64_t indirectDispatchSlotGeneration = 0u;
    // ABI 3: return a validated owner PSO/resource tuple for recording the
    // ACTION into Matter's ICB; null retains the ABI 1/2 dispatch behavior.
    MetalNumanXTransactionSourceMassICBRecord*
        indirectCommandRecordOutput = nullptr;
};
[[nodiscard]] inline constexpr std::uint32_t
metalNumanXTransactionSourceMassQueryStructSizeForABI(
    const std::uint32_t abiVersion
) noexcept {
    if (abiVersion ==
        kMetalNumanXTransactionSourceMassQueryLegacyABIVersion)
        return static_cast<std::uint32_t>(offsetof(
            MetalNumanXTransactionSourceMassQuery, borrowedComputeEncoder));
    if (abiVersion ==
        kMetalNumanXTransactionSourceMassQueryCapabilityABIVersion)
        return static_cast<std::uint32_t>(offsetof(
            MetalNumanXTransactionSourceMassQuery,
            indirectCommandRecordOutput));
    if (abiVersion ==
        kMetalNumanXTransactionSourceMassQueryICBRecordABIVersion)
        return static_cast<std::uint32_t>(
            sizeof(MetalNumanXTransactionSourceMassQuery));
    return 0u;
}
using MetalNumanXTransactionEncodeSourceMassOperation = bool (*)(
    void* context,
    const MetalNumanXTransactionPass& pass,
    const MetalNumanXTransactionSourceMassQuery& query
) noexcept;

enum MetalNumanXTransactionAccessFlag : std::uint32_t {
    MetalNumanXTransactionReadBorrowedState = 1u << 0u,
    // beginStep only: x in each MRMujocoMuscleStateGPU may be replaced by an
    // authenticated motor excitation before current-step kinematics.
    MetalNumanXTransactionWriteMujocoExcitation = 1u << 1u,
    // postDynamics or deferred acceptedPublication: a consumer may downgrade
    // successful Stand status to defined failure, never failure to success.
    MetalNumanXTransactionWriteStandFailure = 1u << 2u,
    // preDynamics only, opt-in single-environment body-property transaction.
    MetalNumanXTransactionWriteBodyProperties = 1u << 3u,
    MetalNumanXTransactionWriteGeneralizedForce = 1u << 4u,
    // acceptedPublication only: the callback may publish its own candidate
    // physiology state, gated on the final successful stand status.
    MetalNumanXTransactionWriteAcceptedPublication = 1u << 5u,
    // ABI 6 preDynamics only: mutate live DoF properties with owner rollback.
    MetalNumanXTransactionWriteDofProperties = 1u << 6u,
    // ABI 7 preDynamics only: exact candidate FK over the source checkpoint.
    MetalNumanXTransactionEncodeExactCandidateKinematics = 1u << 7u,
    // ABI 8 preDynamics only: exact M(q_source) action and factor solve.
    MetalNumanXTransactionEncodeSourceMassOperations = 1u << 8u,
    // ABI 9 preDynamics only: write a separate environment-major force scratch;
    // the articulated owner consumes it once before the Stand solve.
    MetalNumanXTransactionWriteStagedGeneralizedForce = 1u << 9u,
};

// Borrowed device view of one persistent NumanX step. The callback is an
// encoder hook: it may append work to commandBuffer but must not inspect GPU
// results synchronously, commit, wait, retain, or replace any borrowed object.
// beginStep precedes current-step kinematics; preDynamics follows current-step
// MyoSim activation and tendon transfer; postDynamics follows stand dynamics.
// At postDynamics, q/v/status are post-stand while poses, point streams, MyoSim
// results, and tendon transfers remain that step's pre-dynamics evaluation.
// When deferAcceptedPublication is enabled, acceptedPublication follows tendon
// post-validation, before ordinary Stand accepted-state reconciliation. A
// consumer may downgrade success to a defined failure at its final GPU gate,
// then must gate its own publication writes on that final status. It must not
// mutate physical state or turn an existing failure into success.
struct MetalNumanXTransactionPass {
    std::uint32_t abiVersion = kMetalNumanXTransactionABIVersion;
    std::uint32_t structSize = sizeof(MetalNumanXTransactionPass);
    std::uint32_t accessFlags = 0u;
    std::uint32_t reserved0 = 0u;

    void* commandBuffer = nullptr;
    void* q = nullptr;
    void* v = nullptr;
    void* bodyPoses = nullptr;
    void* pointWorld = nullptr;
    void* pointJacobians = nullptr;
    void* mujocoMuscles = nullptr;
    void* mujocoStates = nullptr;
    void* mujocoSites = nullptr;
    void* mujocoWraps = nullptr;
    void* mujocoRouteNodes = nullptr;
    void* mujocoResults = nullptr;
    void* mujocoGeneralizedForceArena = nullptr;
    void* tendonBindings = nullptr;
    void* tendonEnvelopes = nullptr;
    void* tendonTransfers = nullptr;
    void* tendonGeneralizedCorrections = nullptr;
    void* standStatuses = nullptr;

    MetalNumanXTransactionPhase phase =
        MetalNumanXTransactionPhase::beginStep;
    std::uint64_t programFingerprint = 0u;
    std::uint32_t stepIndex = 0u;
    std::uint32_t stepCount = 0u;
    float timestepSeconds = 0.0f;
    std::uint32_t articulationFirstBody = 0u;
    std::uint32_t bodyJacobianPointOffset = MR_INVALID_INDEX;

    std::uint64_t environmentCount = 0u;
    std::uint64_t qCoordinateCount = 0u;
    std::uint64_t qElementCount = 0u;
    std::uint64_t qStride = 0u;
    std::uint64_t dofCount = 0u;
    std::uint64_t vElementCount = 0u;
    std::uint64_t vStride = 0u;
    std::uint64_t bodyCount = 0u;
    std::uint64_t bodyPoseElementCount = 0u;
    std::uint64_t bodyPoseStride = 0u;
    std::uint64_t pointCount = 0u;
    std::uint64_t pointWorldElementCount = 0u;
    std::uint64_t pointWorldStride = 0u;
    std::uint64_t pointJacobianElementCount = 0u;
    std::uint64_t pointJacobianStride = 0u;

    std::uint64_t mujocoMuscleCount = 0u;
    std::uint64_t mujocoStateElementCount = 0u;
    std::uint64_t mujocoStateStride = 0u;
    std::uint64_t mujocoSiteCount = 0u;
    std::uint64_t mujocoWrapCount = 0u;
    std::uint64_t mujocoRouteNodeCount = 0u;
    std::uint64_t mujocoResultElementCount = 0u;
    std::uint64_t mujocoResultStride = 0u;
    std::uint64_t mujocoMuscleGeneralizedForceElementCount = 0u;
    std::uint64_t mujocoMuscleGeneralizedForceRowStride = 0u;
    std::uint64_t mujocoMuscleGeneralizedForceEnvironmentStride = 0u;
    std::uint64_t mujocoGeneralizedForceElementCount = 0u;
    std::uint64_t mujocoGeneralizedForceOffset = 0u;
    std::uint64_t mujocoGeneralizedForceStride = 0u;
    std::uint64_t mujocoGeneralizedForceArenaElementCount = 0u;

    std::uint64_t tendonBindingCount = 0u;
    std::uint64_t tendonEnvelopeCount = 0u;
    std::uint64_t tendonTransferElementCount = 0u;
    std::uint64_t tendonTransferStride = 0u;
    std::uint64_t tendonCorrectionElementCount = 0u;
    std::uint64_t tendonCorrectionStride = 0u;
    std::uint64_t standStatusElementCount = 0u;
    std::uint64_t standStatusStride = 0u;
    // Authoritative compensated translation and paired geometry; low xyz is in m.
    void* rootTranslation = nullptr;
    void* bodyPositionLow = nullptr;
    void* pointPositionLow = nullptr;
    std::uint64_t rootTranslationGPUAddress = 0u;
    std::uint64_t bodyPositionLowGPUAddress = 0u;
    std::uint64_t pointPositionLowGPUAddress = 0u;
    std::uint64_t rootTranslationElementCount = 0u;
    std::uint64_t bodyPositionLowElementCount = 0u;
    std::uint64_t pointPositionLowElementCount = 0u;

    // V3 read-only contact receptor inputs. Contacts are the immutable shared
    // MRNumiHumanStandContactGPU source rows; the FP32 vector arena is
    // environment-major. For contact c in environment e its normal and two
    // signed tangent impulses (N s) occupy
    //   e * standVectorStride + standContactImpulseOffset + 3 * c + [0,1,2].
    // Only postDynamics offers a CURRENT CANDIDATE impulse sample. Validate
    // standStatuses[e] (success and completedSteps == stepIndex + 1) on device
    // before using it, and retain resulting receptor output separately until
    // the enclosing submission has completed and passed the owner's gates.
    // beginStep is NOT a prior-accepted impulse lease: every new submission
    // clears this scratch, even when continuing an accepted split horizon.
    // The consumer must retain its own previously published receptor frame.
    // Sample acquisition is at the end of stepIndex with timestepSeconds;
    // delivery latency is a separate sensor-program property. Geometry in
    // pointWorld/Jacobians remains the step's pre-dynamics contact geometry.
    void* standContacts = nullptr;
    void* standVectorWorkspace = nullptr;
    std::uint64_t standContactCount = 0u;
    std::uint64_t standVectorElementCount = 0u;
    std::uint64_t standVectorStride = 0u;
    std::uint64_t standContactImpulseOffset = 0u;
    std::uint32_t standContactImpulseSampleStepIndex = MR_INVALID_INDEX;
    std::uint32_t standContactEnabled = 0u;
    mr_float4 standGroundPoint{};
    mr_float4 standGroundNormal{};

    // V4 opt-in: live candidate mass/COM/inertia. Checkpoint is the immutable
    // accepted start-of-step source. The physical owner restores it on reject.
    void* bodyProperties = nullptr;
    void* bodyPropertiesCheckpoint = nullptr;
    std::uint64_t bodyPropertyCount = 0u;

    // ABI 6 tail extension. ABI 4/5 callbacks receive the old structSize.
    void* dofProperties = nullptr;
    void* dofPropertiesCheckpoint = nullptr;
    std::uint64_t dofPropertyCount = 0u;

    // ABI 7 tail, valid only during the synchronous preDynamics callback.
    // The callback appends exact candidate kinematics to commandBuffer; it
    // cannot retain this context or pass and does not own mass action/publication.
    void* exactCandidateKinematicsContext = nullptr;
    MetalNumanXTransactionEncodeExactCandidate encodeExactCandidateKinematics = nullptr;
    std::uint32_t candidateSubstepIndex = 0u;
    std::uint32_t candidateTransactionSlot = 0u;
    std::uint32_t candidatePhysicsSubstepCount = 0u;
    std::uint32_t candidateControlStep = 0u;
    std::uint64_t candidateTransactionFingerprint = 0u;
    std::uint64_t candidateLinearizationEpoch = 0u;
    std::uint64_t candidateSlotGeneration = 0u;

    // ABI 8 tail: raw physical M(q_source), assembled before armature or
    // implicit-drive terms. The operation callback rejects candidateQ until
    // candidate-state body Jacobians are supplied by the articulated owner.
    void* sourceMassOperationContext = nullptr;
    MetalNumanXTransactionEncodeSourceMassOperation encodeSourceMassOperation = nullptr;
    void* sourceMassMatrix = nullptr;
    std::uint64_t sourceMassMatrixGPUAddress = 0u;
    std::uint64_t sourceMassMatrixElementCount = 0u;
    std::uint32_t sourceMassMatrixStride = 0u;
    void* sourceMassAssemblyStatuses = nullptr;
    std::uint64_t sourceMassAssemblyStatusesGPUAddress = 0u;
    std::uint64_t sourceMassAssemblyStatusElementCount = 0u;
    std::uint32_t sourceMassReserved0 = 0u;

    // ABI 9 tail. Scratch is cleared by the physical owner before preDynamics;
    // callbacks may write only [environment][dof] and must not retain the view.
    void* stagedGeneralizedForce = nullptr;
    std::uint64_t stagedGeneralizedForceGPUAddress = 0u;
    std::uint64_t stagedGeneralizedForceElementCount = 0u;
    std::uint32_t stagedGeneralizedForceStride = 0u;
    std::uint32_t stagedForceReserved0 = 0u;
};

[[nodiscard]] inline constexpr std::uint32_t
metalNumanXTransactionPassStructSizeForABI(
    const std::uint32_t abiVersion
) noexcept {
    if (abiVersion == kMetalNumanXTransactionCandidateKinematicsABIVersion)
        return static_cast<std::uint32_t>(offsetof(
            MetalNumanXTransactionPass, sourceMassOperationContext));
    if (abiVersion == kMetalNumanXTransactionSourceMassABIVersion)
        return static_cast<std::uint32_t>(offsetof(
            MetalNumanXTransactionPass, stagedGeneralizedForce));
    if (abiVersion == kMetalNumanXTransactionStagedForceABIVersion)
        return static_cast<std::uint32_t>(sizeof(MetalNumanXTransactionPass));
    if (abiVersion == kMetalNumanXTransactionABIVersion)
        return static_cast<std::uint32_t>(offsetof(
            MetalNumanXTransactionPass, exactCandidateKinematicsContext));
    if (abiVersion == kMetalNumanXTransactionLegacyABIVersion ||
        abiVersion == kMetalNumanXTransactionDeferredPublicationABIVersion)
        return static_cast<std::uint32_t>(
            offsetof(MetalNumanXTransactionPass, dofProperties));
    return 0u;
}

using MetalNumanXTransactionEncode = bool (*)(
    void* context,
    const MetalNumanXTransactionPass& pass
) noexcept;

// Called exactly once if at least one transaction phase was offered to the
// consumer and the enclosing command buffer is then abandoned before commit.
// It must release consumer-side transaction ownership without touching the
// borrowed Metal resources.
using MetalNumanXTransactionAbort = void (*)(
    void* context,
    void* commandBuffer
) noexcept;

struct MetalNumanXTransactionProgram {
    std::uint32_t abiVersion = kMetalNumanXTransactionABIVersion;
    std::uint32_t structSize = sizeof(MetalNumanXTransactionProgram);
    void* context = nullptr;
    MetalNumanXTransactionEncode encode = nullptr;
    MetalNumanXTransactionAbort abort = nullptr;
    std::uint64_t fingerprint = 0u;
    // Opt-in resident mass state; one environment, ordinary transaction only.
    bool writeBodyProperties = false;
    // Delay consumer publication until tendon validation. Its final GPU status
    // is reconciled by Stand before body/history publication. The callback must
    // gate its own accepted writes; struct size and tail-padding ABI are stable.
    bool deferAcceptedPublication = false;
    // ABI 6 only: candidate DoF metadata is checkpointed/reconciled by stand.
    bool writeDofProperties = false;
    // ABI 7 opt-in. Bounds the exact candidate point/Jacobian output.
    bool writeExactCandidateKinematics = false;
    std::uint32_t candidatePointCapacity = 0u;

    // This flag was padding in ABI 4. Never inspect it before ABI 5.
    [[nodiscard]] bool usesDeferredAcceptedPublication() const noexcept {
        return abiVersion >= kMetalNumanXTransactionDeferredPublicationABIVersion &&
            deferAcceptedPublication;
    }

    [[nodiscard]] bool usesDofProperties() const noexcept {
        return abiVersion >= kMetalNumanXTransactionABIVersion &&
            writeDofProperties;
    }

    [[nodiscard]] bool usesExactCandidateKinematics() const noexcept {
        return abiVersion >= kMetalNumanXTransactionCandidateKinematicsABIVersion &&
            writeExactCandidateKinematics;
    }

    [[nodiscard]] bool usesSourceMassOperations() const noexcept {
        return abiVersion >= kMetalNumanXTransactionSourceMassABIVersion &&
            writeExactCandidateKinematics;
    }

    [[nodiscard]] bool usesStagedGeneralizedForce() const noexcept {
        return abiVersion == kMetalNumanXTransactionStagedForceABIVersion;
    }

    [[nodiscard]] bool valid() const noexcept {
        const bool supportedVersion =
            abiVersion == kMetalNumanXTransactionLegacyABIVersion ||
            abiVersion == kMetalNumanXTransactionDeferredPublicationABIVersion ||
            abiVersion == kMetalNumanXTransactionABIVersion ||
            abiVersion == kMetalNumanXTransactionCandidateKinematicsABIVersion ||
            abiVersion == kMetalNumanXTransactionSourceMassABIVersion ||
            abiVersion == kMetalNumanXTransactionStagedForceABIVersion;
        const bool candidateKinematicsValid = !usesExactCandidateKinematics() ||
            ((abiVersion == kMetalNumanXTransactionCandidateKinematicsABIVersion ||
              abiVersion == kMetalNumanXTransactionSourceMassABIVersion ||
              abiVersion == kMetalNumanXTransactionStagedForceABIVersion) &&
             candidatePointCapacity > 0u &&
             candidatePointCapacity <= MR_ARTICULATED_OPERATOR_MAX_POINTS);
        const bool sourceMassValid = !usesSourceMassOperations() ||
            abiVersion == kMetalNumanXTransactionSourceMassABIVersion ||
            abiVersion == kMetalNumanXTransactionStagedForceABIVersion;
        const bool stagedForceValid = !usesStagedGeneralizedForce() ||
            abiVersion == kMetalNumanXTransactionStagedForceABIVersion;
        return supportedVersion &&
            structSize == sizeof(MetalNumanXTransactionProgram) &&
            context != nullptr && encode != nullptr && abort != nullptr &&
            fingerprint != 0u && candidateKinematicsValid && sourceMassValid &&
            stagedForceValid;
    }

    [[nodiscard]] bool configured() const noexcept {
        const bool legacyFieldsConfigured =
            structSize != sizeof(MetalNumanXTransactionProgram) ||
            context != nullptr || encode != nullptr || abort != nullptr ||
            fingerprint != 0u || writeBodyProperties;
        if (abiVersion == kMetalNumanXTransactionLegacyABIVersion) {
            // ABI 4 has no deferred-publication field; do not read its padding.
            return legacyFieldsConfigured;
        }
        if (abiVersion == kMetalNumanXTransactionDeferredPublicationABIVersion) {
            return legacyFieldsConfigured || usesDeferredAcceptedPublication();
        }
        if (abiVersion == kMetalNumanXTransactionABIVersion) {
            return legacyFieldsConfigured || usesDeferredAcceptedPublication() ||
                usesDofProperties();
        }
        if (abiVersion == kMetalNumanXTransactionCandidateKinematicsABIVersion ||
            abiVersion == kMetalNumanXTransactionSourceMassABIVersion ||
            abiVersion == kMetalNumanXTransactionStagedForceABIVersion) {
            return legacyFieldsConfigured || usesDeferredAcceptedPublication() ||
                usesDofProperties() || usesExactCandidateKinematics() ||
                candidatePointCapacity != 0u || usesStagedGeneralizedForce();
        }
        return true;
    }
};

static_assert(sizeof(MetalNumanXTransactionProgram) == 48u,
              "transaction program extensions must fit the tail padding");

enum class MetalNumanXHumanMatterPhase : std::uint32_t {
    beginStep = 0u,
    preDynamics = 1u,
    postDynamics = 2u,
};

inline constexpr std::uint32_t kMetalNumanXHumanMatterABIVersion =
    MR_NUMANX_HUMAN_MATTER_ABI_VERSION;
// Borrowed-pass v6 ends at pointPositionLowElementCount. V7 tail-appends the
// immutable source-dynamics witness without moving any v6 member. The
// pointer-free two-phase root/publication ABI remains v4.
inline constexpr std::uint32_t kMetalNumanXHumanMatterPassABIVersionV6 = 6u;
inline constexpr std::uint32_t kMetalNumanXHumanMatterPassABIVersion = 7u;
inline constexpr std::uint32_t kMetalNumanXHumanMatterDofLayoutVersion = 1u;

enum MetalNumanXHumanMatterAccessFlag : std::uint32_t {
    MetalNumanXHumanMatterReadLiveHumanState = 1u << 0u,
    MetalNumanXHumanMatterReadHumanCheckpoints = 1u << 1u,
    MetalNumanXHumanMatterReadSourceEffectiveTangent = 1u << 2u,
    MetalNumanXHumanMatterMayEncodeExactCandidate = 1u << 3u,
    MetalNumanXHumanMatterWriteStagedReaction = 1u << 4u,
    MetalNumanXHumanMatterWriteJointStatus = 1u << 5u,
    MetalNumanXHumanMatterWritePreparedPhysicsToken = 1u << 6u,
    MetalNumanXHumanMatterReadSourceDynamicsWitness = 1u << 7u,
};

inline constexpr std::uint32_t kMetalNumanXHumanMatterKnownAccess =
    MetalNumanXHumanMatterReadLiveHumanState |
    MetalNumanXHumanMatterReadHumanCheckpoints |
    MetalNumanXHumanMatterReadSourceEffectiveTangent |
    MetalNumanXHumanMatterMayEncodeExactCandidate |
    MetalNumanXHumanMatterWriteStagedReaction |
    MetalNumanXHumanMatterWriteJointStatus |
    MetalNumanXHumanMatterWritePreparedPhysicsToken |
    MetalNumanXHumanMatterReadSourceDynamicsWitness;

enum MetalNumanXHumanMatterCapability : std::uint32_t {
    // Exact q/body/attachment kinematics are encoded by the Human owner from
    // the supplied delta-v; no first-order pose approximation is admitted.
    MetalNumanXHumanMatterExactCandidateKinematics = 1u << 0u,
    // The exposed lower factor is the frozen source-step discrete velocity
    // tangent A0 = M(q0) + armature + h*D.  It is intentionally not named or
    // represented as a pure mass matrix.
    MetalNumanXHumanMatterSourceEffectiveTangent = 1u << 1u,
    // A separate staged generalized reaction A0*deltaV/h is consumed once
    // before stand.  It never aliases MyoSim's per-muscle or reduced rows.
    MetalNumanXHumanMatterStagedReaction = 1u << 2u,
    MetalNumanXHumanMatterJointDecision = 1u << 3u,
    MetalNumanXHumanMatterPreparedPhysicsGate = 1u << 4u,
    // The physical prepare token and proof use the exact-nanosecond V2
    // family and consume a device-private HumanIO admission receipt. Token
    // byte size is deliberately not a family discriminator.
    MetalNumanXHumanMatterExactClockAuthority = 1u << 5u,
    // Immutable environment-major [A0 diagonal | raw bias | raw RHS], each
    // segment exactly dofCount floats and captured before source factorization
    // or vector-scratch overwrite.
    MetalNumanXHumanMatterSourceDynamicsWitness = 1u << 6u,
};

enum class MetalNumanXHumanMatterTokenFamily : std::uint32_t {
    legacyMicrosecondsV1 = 1u,
    exactNanosecondsV2 = 2u,
};

inline constexpr std::uint32_t kMetalNumanXHumanMatterKnownCapabilities =
    MetalNumanXHumanMatterExactCandidateKinematics |
    MetalNumanXHumanMatterSourceEffectiveTangent |
    MetalNumanXHumanMatterStagedReaction |
    MetalNumanXHumanMatterJointDecision |
    MetalNumanXHumanMatterPreparedPhysicsGate |
    MetalNumanXHumanMatterExactClockAuthority |
    MetalNumanXHumanMatterSourceDynamicsWitness;

struct MetalNumanXHumanMatterPass;

enum MetalNumanXHumanMatterCandidateAccessFlag : std::uint32_t {
    MetalNumanXHumanMatterCandidateReadDeltaVelocity = 1u << 0u,
    MetalNumanXHumanMatterCandidateWriteQ = 1u << 1u,
    MetalNumanXHumanMatterCandidateWriteBodies = 1u << 2u,
    MetalNumanXHumanMatterCandidateReadPointQueries = 1u << 3u,
    MetalNumanXHumanMatterCandidateWritePointWorld = 1u << 4u,
    MetalNumanXHumanMatterCandidateWritePointJacobians = 1u << 5u,
};

inline constexpr std::uint32_t
    kMetalNumanXHumanMatterCandidateKnownAccess =
        MetalNumanXHumanMatterCandidateReadDeltaVelocity |
        MetalNumanXHumanMatterCandidateWriteQ |
        MetalNumanXHumanMatterCandidateWriteBodies |
        MetalNumanXHumanMatterCandidateReadPointQueries |
        MetalNumanXHumanMatterCandidateWritePointWorld |
        MetalNumanXHumanMatterCandidateWritePointJacobians;

// One exact candidate requested by the Matter adapter during preDynamics.
// deltaVelocity is environment-major [environment][160]. candidateQ and
// candidateBodies are authoritative outputs. Optional attachment queries are
// evaluated in the same generic kinematics dispatch as the four immutable
// Human body probes; pointWorld and pointJacobians name only the attachment
// suffix, not the private combined stream.
struct MetalNumanXHumanMatterCandidateQuery {
    std::uint32_t abiVersion = kMetalNumanXHumanMatterABIVersion;
    std::uint32_t structSize = sizeof(MetalNumanXHumanMatterCandidateQuery);
    std::uint32_t accessFlags = 0u;
    std::uint32_t reserved0 = 0u;

    void* deltaVelocity = nullptr;
    void* candidateQ = nullptr;
    void* candidateBodies = nullptr;
    void* pointQueries = nullptr;
    void* pointWorld = nullptr;
    void* pointJacobians = nullptr;

    std::uint64_t deltaVelocityGPUAddress = 0u;
    std::uint64_t candidateQGPUAddress = 0u;
    std::uint64_t candidateBodiesGPUAddress = 0u;
    std::uint64_t pointQueriesGPUAddress = 0u;
    std::uint64_t pointWorldGPUAddress = 0u;
    std::uint64_t pointJacobiansGPUAddress = 0u;

    std::uint32_t deltaVelocityStride = 0u;
    std::uint32_t candidateQStride = 0u;
    std::uint32_t candidateBodyStride = 0u;
    std::uint32_t pointCount = 0u;
    std::uint32_t pointStride = 0u;
    std::uint32_t pointWorldStride = 0u;
    std::uint32_t pointJacobianStride = 0u;
    std::uint32_t substepIndex = 0u;
    std::uint32_t transactionSlot = 0u;
    // ABI4 is one atomic control-step root. Matter must not expose an
    // intermediate physics substep that a later substep can roll back.
    std::uint32_t physicsSubstepCount = 0u;

    // Global adapter/Matter control root. This is not the local Human stand
    // step, which remains exactly zero in the one-step owner.
    std::uint32_t controlStep = 0u;
    std::uint64_t programFingerprint = 0u;
    std::uint64_t transactionFingerprint = 0u;
    std::uint64_t linearizationEpoch = 0u;
    std::uint64_t slotGeneration = 0u;
    // Authoritative compensated translation and paired geometry; low xyz is in m.
    void* candidateRootTranslation = nullptr;
    void* candidateBodyPositionLow = nullptr;
    void* pointPositionLow = nullptr;
    std::uint64_t candidateRootTranslationGPUAddress = 0u;
    std::uint64_t candidateBodyPositionLowGPUAddress = 0u;
    std::uint64_t pointPositionLowGPUAddress = 0u;
    std::uint64_t candidateRootTranslationElementCount = 0u;
    std::uint64_t candidateBodyPositionLowElementCount = 0u;
    std::uint64_t pointPositionLowElementCount = 0u;

};

using MetalNumanXHumanMatterEncodeExactCandidate = bool (*)(
    void* context,
    const MetalNumanXHumanMatterPass& pass,
    const MetalNumanXHumanMatterCandidateQuery& query
) noexcept;

// Borrowed view of one owner transaction. All native objects are unretained
// id<MTLBuffer>/id<MTLCommandBuffer> identities. The callback may encode only
// on commandBuffer; it must not commit, wait, retain, read back, or replace a
// resource. beginStep follows owner checkpointing and precedes motor mutation.
// preDynamics follows source kinematics, MyoSim, and exact A0 factorization;
// the owner consumes the staged reaction immediately after it returns.
// postDynamics follows stand and produces a quarantined physical prepare;
// later proposal/ACK/apply commands own root resolution.
struct MetalNumanXHumanMatterPass {
    std::uint32_t abiVersion = kMetalNumanXHumanMatterPassABIVersion;
    std::uint32_t structSize = sizeof(MetalNumanXHumanMatterPass);
    std::uint32_t accessFlags = 0u;
    std::uint32_t capabilities = 0u;

    MetalNumanXHumanMatterPhase phase =
        MetalNumanXHumanMatterPhase::beginStep;
    std::uint32_t stepIndex = 0u;
    std::uint32_t stepCount = 0u;
    std::uint32_t transactionSlot = 0u;
    std::uint32_t substepIndex = 0u;
    std::uint32_t physicsSubstepCount = 0u;

    // Global adapter/Matter control root, independent of local stepIndex.
    std::uint32_t controlStep = 0u;

    void* commandBuffer = nullptr;
    void* q = nullptr;
    void* v = nullptr;
    void* mujocoStates = nullptr;
    void* mujocoGeneralizedForceArena = nullptr;
    void* bodyPoses = nullptr;
    void* pointQueries = nullptr;
    void* pointWorld = nullptr;
    void* pointJacobians = nullptr;
    void* standStatuses = nullptr;

    void* qCheckpoint = nullptr;
    void* vCheckpoint = nullptr;
    // v_free = v0 + h A0^-1 (tau_source - bias_source), computed by the
    // owning Stand kernel before Matter. Candidate delta-v is relative to
    // this predictor. This private buffer must not alias live/checkpoint v.
    // Valid only after the preDynamics predictor encode on commandBuffer.
    void* sourcePredictedVelocity = nullptr;
    void* mujocoStateCheckpoint = nullptr;
    // Environment-major lower Cholesky of A0. The stand kernel subsequently
    // rebuilds and factors the same source-step bytes before its solve.
    void* sourceEffectiveTangentFactor = nullptr;
    void* ownerStatuses = nullptr;

    // Adapter-owned, same-device arenas. matterGeneralizedReaction is
    // [environment][160] force and is accumulated exactly once before stand.
    // jointStatuses use the 32-byte MRNumanXCoupledHumanStatusGPU prefix.
    // acceptedPhysicsStateTokens retain their source-compatible spelling but
    // are ABI4 *prepared* tokens: begin clears them, a physical reject clears
    // them, and physical prepare preserves the adapter's 64-byte record only
    // inside the quarantined slot.  They are never a root-commit publication.
    void* matterGeneralizedReaction = nullptr;
    void* jointStatuses = nullptr;
    void* acceptedPhysicsStateTokens = nullptr;

    void* exactCandidateContext = nullptr;
    MetalNumanXHumanMatterEncodeExactCandidate encodeExactCandidate = nullptr;

    std::uint64_t qGPUAddress = 0u;
    std::uint64_t vGPUAddress = 0u;
    std::uint64_t mujocoStatesGPUAddress = 0u;
    std::uint64_t mujocoGeneralizedForceArenaGPUAddress = 0u;
    std::uint64_t bodyPosesGPUAddress = 0u;
    std::uint64_t pointQueriesGPUAddress = 0u;
    std::uint64_t pointWorldGPUAddress = 0u;
    std::uint64_t pointJacobiansGPUAddress = 0u;
    std::uint64_t standStatusesGPUAddress = 0u;
    std::uint64_t qCheckpointGPUAddress = 0u;
    std::uint64_t vCheckpointGPUAddress = 0u;
    std::uint64_t sourcePredictedVelocityGPUAddress = 0u;
    std::uint64_t mujocoStateCheckpointGPUAddress = 0u;
    std::uint64_t sourceEffectiveTangentFactorGPUAddress = 0u;
    std::uint64_t ownerStatusesGPUAddress = 0u;
    std::uint64_t matterGeneralizedReactionGPUAddress = 0u;
    std::uint64_t jointStatusesGPUAddress = 0u;
    std::uint64_t acceptedPhysicsStateTokensGPUAddress = 0u;

    std::uint64_t environmentCount = 0u;
    std::uint64_t qCoordinateCount = 0u;
    std::uint64_t dofCount = 0u;
    std::uint64_t bodyCount = 0u;
    std::uint64_t pointCount = 0u;
    std::uint64_t mujocoStateCount = 0u;
    std::uint64_t qStride = 0u;
    std::uint64_t vStride = 0u;
    std::uint64_t bodyPoseStride = 0u;
    std::uint64_t pointStride = 0u;
    std::uint64_t pointWorldStride = 0u;
    std::uint64_t pointJacobianStride = 0u;
    std::uint64_t mujocoStateStride = 0u;
    std::uint64_t factorStride = 0u;
    std::uint64_t generalizedForceOffset = 0u;
    std::uint64_t generalizedForceStride = 0u;
    std::uint64_t generalizedForceArenaElementCount = 0u;
    std::uint64_t reactionStride = 0u;
    std::uint64_t jointStatusStride = 0u;
    std::uint64_t acceptedTokenStrideBytes = 0u;
    std::uint64_t bodyJacobianPointOffset = 0u;

    float timestepSeconds = 0.0f;
    std::uint32_t articulationIndex = 0u;
    std::uint32_t articulationFirstBody = 0u;
    std::uint32_t reserved0 = 0u;

    std::uint64_t programFingerprint = 0u;
    std::uint64_t transactionFingerprint = 0u;
    std::uint64_t linearizationEpoch = 0u;
    std::uint64_t slotGeneration = 0u;
    // Authoritative compensated translation and paired geometry; low xyz is in m.
    void* rootTranslation = nullptr;
    void* rootTranslationCheckpoint = nullptr;
    void* bodyPositionLow = nullptr;
    void* pointPositionLow = nullptr;
    std::uint64_t rootTranslationGPUAddress = 0u;
    std::uint64_t rootTranslationCheckpointGPUAddress = 0u;
    std::uint64_t bodyPositionLowGPUAddress = 0u;
    std::uint64_t pointPositionLowGPUAddress = 0u;
    std::uint64_t rootTranslationElementCount = 0u;
    std::uint64_t rootTranslationCheckpointElementCount = 0u;
    std::uint64_t bodyPositionLowElementCount = 0u;
    std::uint64_t pointPositionLowElementCount = 0u;

    // V7 tail. Environment-major, sourceDynamicsWitnessStride == 3*dofCount:
    // [0,nv) exact A0 diagonal, [nv,2nv) raw device bias, and [2nv,3nv)
    // raw generalized RHS before solveFactor overwrites its input.
    void* sourceDynamicsWitness = nullptr;
    std::uint64_t sourceDynamicsWitnessGPUAddress = 0u;
    std::uint64_t sourceDynamicsWitnessElementCount = 0u;
    std::uint64_t sourceDynamicsWitnessStride = 0u;

};

using MetalNumanXHumanMatterEncode = bool (*)(
    void* context,
    const MetalNumanXHumanMatterPass& pass
) noexcept;

using MetalNumanXHumanMatterAbort = void (*)(
    void* context,
    void* commandBuffer
) noexcept;

inline constexpr std::uint32_t kMetalNumanXHumanIOPublicationABIVersion = 1u;
inline constexpr std::uint32_t
    kMetalNumanXHumanIOExactPublicationABIVersion = 2u;

enum class MetalNumanXHumanIOCandidatePublicationDisposition : std::uint32_t {
    released = 1u,
    rejected = 2u,
    terminalNoTouch = 3u,
};

struct MetalNumanXHumanIOCandidatePublicationBinding {
    std::uint32_t abiVersion =
        kMetalNumanXHumanIOPublicationABIVersion;
    std::uint32_t structSize = sizeof(
        MetalNumanXHumanIOCandidatePublicationBinding);
    std::uint32_t environmentCount = 0u;
    std::uint32_t transactionSlot = 0u;
    std::uint32_t stepIndex = 0u;
    std::uint32_t substepIndex = 0u;
    std::uint32_t physicsSubstepCount = 0u;
    std::uint32_t controlStep = 0u;
    std::uint64_t ownerProgramFingerprint = 0u;
    std::uint64_t transactionFingerprint = 0u;
    std::uint64_t linearizationEpoch = 0u;
    std::uint64_t slotGeneration = 0u;
    std::uint64_t physicsTokenFingerprint = 0u;
    std::uint64_t proposalFingerprint = 0u;
    std::uint64_t ackFingerprint = 0u;
    std::uint64_t appliedDecisionFingerprint = 0u;
    std::uint64_t jointCommitFingerprint = 0u;
    std::uint64_t brainGeneration = 0u;
    std::uint64_t candidateKeyFingerprint = 0u;
    std::uint64_t acceptedBrainGeneration = 0u;
    std::uint64_t sensorGeneration = 0u;
    std::uint64_t humanIOProgramFingerprint = 0u;
    std::uint64_t sensorFingerprint = 0u;
    std::uint64_t transactionInstanceFingerprint = 0u;
    std::uint64_t candidatePublicationFingerprint = 0u;
    std::uint64_t deviceRegistryID = 0u;
    std::uint64_t humanIOIdentityFingerprint = 0u;
    std::uint64_t bindingFingerprint = 0u;
};

enum class MetalNumanXHumanIOCandidatePublicationCommitStatus :
    std::uint32_t {
    committed = 1u,
};

struct MetalNumanXHumanIOCandidatePublicationCommit {
    std::uint32_t abiVersion =
        kMetalNumanXHumanIOPublicationABIVersion;
    std::uint32_t structSize = sizeof(
        MetalNumanXHumanIOCandidatePublicationCommit);
    MetalNumanXHumanIOCandidatePublicationCommitStatus status =
        MetalNumanXHumanIOCandidatePublicationCommitStatus::committed;
    std::uint32_t reserved0 = 0u;
    std::uint64_t candidatePublicationFingerprint = 0u;
    std::uint64_t bindingFingerprint = 0u;
    std::uint64_t jointCommitFingerprint = 0u;
    std::uint64_t brainGeneration = 0u;
    std::uint64_t fenceFingerprint = 0u;
};

using MetalNumanXHumanIOReservePublishedRoot = bool (*)(
    void* context,
    std::uint64_t candidatePublicationFingerprint,
    const MetalNumanXHumanIOCandidatePublicationBinding& binding
) noexcept;

using MetalNumanXHumanIOPublishCandidate =
    MetalNumanXHumanIOCandidatePublicationDisposition (*)(
    void* context,
    std::uint64_t candidatePublicationFingerprint,
    const MetalNumanXHumanIOCandidatePublicationCommit& commit
) noexcept;

using MetalNumanXHumanIORejectCandidate =
    MetalNumanXHumanIOCandidatePublicationDisposition (*)(
    void* context,
    std::uint64_t candidatePublicationFingerprint
) noexcept;

// Pointer-bearing host capability for one already-materialized, unpublished
// HumanIO sensor candidate. Its FNV identity deliberately excludes context and
// callback addresses; candidatePublicationFingerprint binds the exact local
// buffer objects, GPU ranges, scalar types, and layout inside HumanIO.
struct MetalNumanXHumanIOCandidatePublicationProgram {
    std::uint32_t abiVersion =
        kMetalNumanXHumanIOPublicationABIVersion;
    std::uint32_t structSize = sizeof(
        MetalNumanXHumanIOCandidatePublicationProgram);
    void* context = nullptr;
    MetalNumanXHumanIOReservePublishedRoot reservePublishedRoot = nullptr;
    MetalNumanXHumanIOPublishCandidate publishCandidate = nullptr;
    MetalNumanXHumanIORejectCandidate rejectCandidate = nullptr;
    std::uint64_t candidateKeyFingerprint = 0u;
    std::uint64_t transactionFingerprint = 0u;
    std::uint64_t acceptedBrainGeneration = 0u;
    std::uint64_t sensorGeneration = 0u;
    std::uint64_t humanIOProgramFingerprint = 0u;
    std::uint64_t sensorFingerprint = 0u;
    std::uint64_t transactionInstanceFingerprint = 0u;
    std::uint64_t candidatePublicationFingerprint = 0u;
    std::uint64_t deviceRegistryID = 0u;
    std::uint64_t identityFingerprint = 0u;

    [[nodiscard]] std::uint64_t computedIdentityFingerprint()
        const noexcept {
        std::uint64_t hash = 14695981039346656037ull;
        constexpr std::uint64_t prime = 1099511628211ull;
        const auto mix32 = [&hash](std::uint32_t value) noexcept {
            for (std::uint32_t byte = 0u; byte < 4u; ++byte) {
                hash ^= static_cast<std::uint8_t>(value >> (8u * byte));
                hash *= prime;
            }
        };
        const auto mix64 = [&hash](std::uint64_t value) noexcept {
            for (std::uint32_t byte = 0u; byte < 8u; ++byte) {
                hash ^= static_cast<std::uint8_t>(value >> (8u * byte));
                hash *= prime;
            }
        };
        mix32(abiVersion);
        mix32(structSize);
        mix64(candidateKeyFingerprint);
        mix64(transactionFingerprint);
        mix64(acceptedBrainGeneration);
        mix64(sensorGeneration);
        mix64(humanIOProgramFingerprint);
        mix64(sensorFingerprint);
        mix64(transactionInstanceFingerprint);
        mix64(candidatePublicationFingerprint);
        mix64(deviceRegistryID);
        return hash == 0u ? 14695981039346656037ull : hash;
    }

    [[nodiscard]] bool valid() const noexcept {
        const bool knownABI =
            abiVersion == kMetalNumanXHumanIOPublicationABIVersion ||
            abiVersion == kMetalNumanXHumanIOExactPublicationABIVersion;
        return knownABI &&
            structSize == sizeof(*this) && context != nullptr &&
            reservePublishedRoot != nullptr && publishCandidate != nullptr &&
            rejectCandidate != nullptr && candidateKeyFingerprint != 0u &&
            transactionFingerprint != 0u && acceptedBrainGeneration != 0u &&
            sensorGeneration != 0u && humanIOProgramFingerprint != 0u &&
            sensorFingerprint != 0u && transactionInstanceFingerprint != 0u &&
            candidatePublicationFingerprint != 0u &&
            deviceRegistryID != 0u &&
            identityFingerprint != 0u &&
            identityFingerprint == computedIdentityFingerprint();
    }

    [[nodiscard]] bool configured() const noexcept {
        return abiVersion != kMetalNumanXHumanIOPublicationABIVersion ||
            structSize != sizeof(*this) || context != nullptr ||
            reservePublishedRoot != nullptr || publishCandidate != nullptr ||
            rejectCandidate != nullptr || candidateKeyFingerprint != 0u ||
            transactionFingerprint != 0u || acceptedBrainGeneration != 0u ||
            sensorGeneration != 0u || humanIOProgramFingerprint != 0u ||
            sensorFingerprint != 0u || transactionInstanceFingerprint != 0u ||
            candidatePublicationFingerprint != 0u ||
            deviceRegistryID != 0u || identityFingerprint != 0u;
    }
};

static_assert(sizeof(MetalNumanXHumanIOCandidatePublicationBinding) == 192u);
static_assert(alignof(MetalNumanXHumanIOCandidatePublicationBinding) == 8u);
static_assert(offsetof(
    MetalNumanXHumanIOCandidatePublicationBinding,
    ownerProgramFingerprint
) == 32u);
static_assert(offsetof(
    MetalNumanXHumanIOCandidatePublicationBinding,
    bindingFingerprint
) == 184u);
static_assert(sizeof(MetalNumanXHumanIOCandidatePublicationCommit) == 56u);
static_assert(offsetof(
    MetalNumanXHumanIOCandidatePublicationCommit,
    candidatePublicationFingerprint
) == 16u);
static_assert(sizeof(MetalNumanXHumanIOCandidatePublicationProgram) == 120u);
static_assert(offsetof(
    MetalNumanXHumanIOCandidatePublicationProgram,
    transactionFingerprint
) == 48u);
static_assert(offsetof(
    MetalNumanXHumanIOCandidatePublicationProgram,
    identityFingerprint
) == 112u);

struct MetalNumanXHumanMatterPrepareLease {
    std::uint32_t abiVersion = kMetalNumanXHumanMatterABIVersion;
    std::uint32_t structSize = sizeof(MetalNumanXHumanMatterPrepareLease);
    std::uint32_t environmentCount = 0u;
    std::uint32_t transactionSlot = 0u;
    std::uint32_t stepIndex = 0u;
    std::uint32_t substepIndex = 0u;
    std::uint32_t physicsSubstepCount = 0u;
    std::uint32_t controlStep = 0u;
    std::uint32_t qCoordinateCount = 0u;
    std::uint32_t dofCount = 0u;
    std::uint32_t dofLayoutVersion = 0u;
    std::uint32_t reservedDofLayout = 0u;

    std::uint32_t preparedTokenStrideBytes = 0u;
    std::uint32_t proposalStride = 0u;
    std::uint32_t proposedTokenStrideBytes = 0u;
    std::uint32_t applyActionStride = 0u;
    std::uint32_t matterApplyOutcomeStride = 0u;
    std::uint32_t appliedOutcomeStride = 0u;
    std::uint32_t finalTokenStrideBytes = 0u;
    std::uint32_t publicationFenceStride = 0u;

    void* preparedPhysicsStateTokens = nullptr;
    void* proposals = nullptr;
    void* proposedPhysicsStateTokens = nullptr;
    void* applyActions = nullptr;
    void* matterApplyOutcomes = nullptr;
    void* appliedOutcomes = nullptr;
    void* finalAcceptedPhysicsStateTokens = nullptr;
    void* publicationFences = nullptr;
    void* physicalPreparedEvent = nullptr;

    std::uint64_t preparedPhysicsStateTokensGPUAddress = 0u;
    std::uint64_t proposalsGPUAddress = 0u;
    std::uint64_t proposedPhysicsStateTokensGPUAddress = 0u;
    std::uint64_t applyActionsGPUAddress = 0u;
    std::uint64_t matterApplyOutcomesGPUAddress = 0u;
    std::uint64_t appliedOutcomesGPUAddress = 0u;
    std::uint64_t finalAcceptedPhysicsStateTokensGPUAddress = 0u;
    std::uint64_t publicationFencesGPUAddress = 0u;

    std::uint64_t preparedPhysicsStateTokenByteCount = 0u;
    std::uint64_t proposalElementCount = 0u;
    std::uint64_t proposedPhysicsStateTokenByteCount = 0u;
    std::uint64_t applyActionElementCount = 0u;
    std::uint64_t matterApplyOutcomeElementCount = 0u;
    std::uint64_t appliedOutcomeElementCount = 0u;
    std::uint64_t finalAcceptedPhysicsStateTokenByteCount = 0u;
    std::uint64_t publicationFenceElementCount = 0u;

    std::uint64_t physicalPreparedEventValue = 0u;
    std::uint64_t proposalEventValue = 0u;
    std::uint64_t appliedEventValue = 0u;

    std::uint64_t programFingerprint = 0u;
    std::uint64_t transactionFingerprint = 0u;
    std::uint64_t linearizationEpoch = 0u;
    std::uint64_t slotGeneration = 0u;
    MetalNumanXHumanIOCandidatePublicationProgram humanIOCandidate{};
};

using MetalNumanXHumanMatterAcquirePrepareLease = bool (*)(
    void* context,
    const MetalNumanXHumanMatterPrepareLease& lease
) noexcept;

// The exact HumanIO publication capability does not exist until the first
// physical command has completed and HumanIO has certified its materialized
// candidate. This one-shot callback immutably attaches that post-command
// capability to the already-quarantined adapter generation. The staged lease
// contains the candidate; the originally acquired lease contains an empty
// candidate program.
using MetalNumanXHumanMatterBindHumanIOCandidatePublication = bool (*)(
    void* context,
    const MetalNumanXHumanMatterPrepareLease& lease,
    const MetalNumanXHumanIOCandidatePublicationProgram& candidate
) noexcept;

// Host disposition returned only after the adapter has inspected its exact
// completed finalization generation. `released` is the sole authority for the
// Human owner to invalidate/reap the prepared root. `restoreRequired` retains
// the immutable checkpoints and permits only a fresh forceReject command.
// `terminalNoTouch` permanently quarantines the generation: neither owner may
// restore, publish, release, nor reuse it before context teardown.
enum class MetalNumanXHumanMatterPrepareLeaseDisposition : std::uint32_t {
    released = 1u,
    restoreRequired = 2u,
    terminalNoTouch = 3u,
    acceptedPendingPublication = 4u,
};

using MetalNumanXHumanMatterReleasePrepareLease =
    MetalNumanXHumanMatterPrepareLeaseDisposition (*)(
    void* context,
    const MetalNumanXHumanMatterPrepareLease& lease,
    void* finalCommandBuffer,
    bool completed
) noexcept;

struct MetalNumanXHumanMatterProposalView {
    std::uint32_t abiVersion = kMetalNumanXHumanMatterABIVersion;
    std::uint32_t structSize = sizeof(MetalNumanXHumanMatterProposalView);
    void* proposals = nullptr;
    void* proposedPhysicsStateTokens = nullptr;
    std::uint64_t proposalsGPUAddress = 0u;
    std::uint64_t proposedPhysicsStateTokensGPUAddress = 0u;
    std::uint64_t proposalElementCount = 0u;
    std::uint64_t proposedPhysicsStateTokenByteCount = 0u;
    std::uint32_t proposalStride = 0u;
    std::uint32_t proposedTokenStrideBytes = 0u;
    std::uint64_t proposalEventValue = 0u;
};

struct MetalNumanXHumanMatterBrainPreflightView {
    std::uint32_t abiVersion = kMetalNumanXHumanMatterABIVersion;
    std::uint32_t structSize = sizeof(
        MetalNumanXHumanMatterBrainPreflightView);
    void* brainCommitPreflights = nullptr;
    void* preflightReadyEvent = nullptr;
    std::uint64_t brainCommitPreflightsGPUAddress = 0u;
    std::uint64_t brainCommitPreflightElementCount = 0u;
    std::uint64_t preflightReadyEventValue = 0u;
    std::uint32_t brainCommitPreflightStride = 0u;
    std::uint32_t environmentCount = 0u;
    std::uint32_t transactionSlot = 0u;
    std::uint32_t stepIndex = 0u;
    std::uint32_t substepIndex = 0u;
    std::uint32_t physicsSubstepCount = 0u;
    std::uint32_t controlStep = 0u;
    std::uint64_t programFingerprint = 0u;
    std::uint64_t transactionFingerprint = 0u;
    std::uint64_t linearizationEpoch = 0u;
    std::uint64_t slotGeneration = 0u;
};

using MetalNumanXHumanMatterReservePreparedApplication = bool (*)(
    void* context,
    const MetalNumanXHumanMatterPrepareLease& lease,
    const MetalNumanXHumanMatterProposalView& proposal,
    const MetalNumanXHumanMatterBrainPreflightView& preflight
) noexcept;

enum class MetalNumanXHumanMatterApplyMode : std::uint32_t {
    validateBrainAck = 0u,
    forceReject = 1u,
};

enum class MetalNumanXHumanMatterApplyTerminalStatus : std::uint32_t {
    acceptedPendingPublication = 1u,
    rejectedReleased = 2u,
    terminalNoTouch = 3u,
};

using MetalNumanXHumanMatterApplyCompletion = void (*)(
    void* context,
    MetalNumanXHumanMatterApplyTerminalStatus status,
    std::uint64_t slotGeneration
) noexcept;

struct MetalNumanXHumanMatterApplyPass {
    std::uint32_t abiVersion = kMetalNumanXHumanMatterABIVersion;
    std::uint32_t structSize = sizeof(MetalNumanXHumanMatterApplyPass);
    MetalNumanXHumanMatterApplyMode mode =
        MetalNumanXHumanMatterApplyMode::validateBrainAck;
    std::uint32_t reserved0 = 0u;
    void* commandBuffer = nullptr;
    void* brainAcks = nullptr;
    void* brainAckEvent = nullptr;
    std::uint64_t brainAcksGPUAddress = 0u;
    std::uint64_t brainAckElementCount = 0u;
    std::uint64_t brainAckEventValue = 0u;
    std::uint32_t brainAckStride = 0u;
    std::uint32_t environmentCount = 0u;
    std::uint32_t transactionSlot = 0u;
    std::uint32_t stepIndex = 0u;
    std::uint32_t substepIndex = 0u;
    std::uint32_t physicsSubstepCount = 0u;
    std::uint32_t controlStep = 0u;
    std::uint64_t programFingerprint = 0u;
    std::uint64_t transactionFingerprint = 0u;
    std::uint64_t linearizationEpoch = 0u;
    std::uint64_t slotGeneration = 0u;
};

using MetalNumanXHumanMatterEncodePreparedApply = bool (*)(
    void* context,
    const MetalNumanXHumanMatterPrepareLease& lease,
    const MetalNumanXHumanMatterApplyPass& pass
) noexcept;

using MetalNumanXHumanMatterAbortPreparedApply = void (*)(
    void* context,
    const MetalNumanXHumanMatterPrepareLease& lease,
    const MetalNumanXHumanMatterApplyPass& pass
) noexcept;

struct MetalNumanXHumanMatterPublicationFenceView {
    std::uint32_t abiVersion = kMetalNumanXHumanMatterABIVersion;
    std::uint32_t structSize = sizeof(
        MetalNumanXHumanMatterPublicationFenceView);
    void* publicationFences = nullptr;
    std::uint64_t publicationFencesGPUAddress = 0u;
    std::uint64_t publicationFenceElementCount = 0u;
    std::uint32_t publicationFenceStride = 0u;
    std::uint32_t environmentCount = 0u;
    std::uint32_t transactionSlot = 0u;
    std::uint32_t stepIndex = 0u;
    std::uint32_t substepIndex = 0u;
    std::uint32_t physicsSubstepCount = 0u;
    std::uint32_t controlStep = 0u;
    std::uint64_t programFingerprint = 0u;
    std::uint64_t transactionFingerprint = 0u;
    std::uint64_t linearizationEpoch = 0u;
    std::uint64_t slotGeneration = 0u;
};

struct MetalNumanXHumanMatterPublicationReservationView {
    std::uint32_t abiVersion = kMetalNumanXHumanMatterABIVersion;
    std::uint32_t structSize = sizeof(
        MetalNumanXHumanMatterPublicationReservationView);
    MetalNumanXHumanMatterProposalView proposal{};
    MetalNumanXHumanMatterPublicationFenceView fence{};
    void* appliedOutcomes = nullptr;
    void* finalAcceptedPhysicsStateTokens = nullptr;
    std::uint64_t appliedOutcomesGPUAddress = 0u;
    std::uint64_t finalAcceptedPhysicsStateTokensGPUAddress = 0u;
    std::uint64_t appliedOutcomeElementCount = 0u;
    std::uint64_t finalAcceptedPhysicsStateTokenByteCount = 0u;
    std::uint32_t appliedOutcomeStride = 0u;
    std::uint32_t finalTokenStrideBytes = 0u;
    std::uint64_t jointCommitFingerprint = 0u;
    std::uint64_t brainGeneration = 0u;
    MetalNumanXHumanIOCandidatePublicationBinding humanIOBinding{};
};

using MetalNumanXHumanMatterReservePublishedRoot = bool (*)(
    void* context,
    const MetalNumanXHumanMatterPrepareLease& lease,
    const MetalNumanXHumanMatterPublicationReservationView& reservation
) noexcept;

using MetalNumanXHumanMatterReleasePublishedRoot =
    MetalNumanXHumanMatterPrepareLeaseDisposition (*)(
    void* context,
    const MetalNumanXHumanMatterPrepareLease& lease,
    const MetalNumanXHumanMatterPublicationFenceView& fence
) noexcept;

struct MetalNumanXHumanMatterProgram {
    std::uint32_t abiVersion = kMetalNumanXHumanMatterABIVersion;
    std::uint32_t structSize = sizeof(MetalNumanXHumanMatterProgram);
    std::uint32_t capabilities = 0u;
    std::uint32_t accessFlags = 0u;

    void* context = nullptr;
    MetalNumanXHumanMatterEncode encode = nullptr;
    MetalNumanXHumanMatterAbort abort = nullptr;
    // Required ABI4 lifetime handshake. acquirePrepareLease must make the exact
    // adapter token slot immutable before the first physical command commits.
    // releasePrepareLease is called after an apply command completes, before
    // the Human owner clears any prepared state. Its explicit disposition is
    // then applied only after the owner reacquires and revalidates the exact
    // generation/apply attempt. It is called with completed=false for a GPU
    // error, pre-commit unwind, or terminal context teardown; that return value
    // cannot authorize publication or slot reuse.
    MetalNumanXHumanMatterAcquirePrepareLease acquirePrepareLease = nullptr;
    MetalNumanXHumanMatterBindHumanIOCandidatePublication
        bindHumanIOCandidatePublication = nullptr;
    MetalNumanXHumanMatterReleasePrepareLease releasePrepareLease = nullptr;
    // ABI4: proposal is mutation-free. The adapter reserves the exact proposal
    // generation before Brain ACK, consumes the owner apply action on the later
    // borrowed command buffer, writes its integrity-checked Matter outcome, and
    // releases an accepted root only after a COMMITTED publication fence.
    MetalNumanXHumanMatterReservePreparedApplication
        reservePreparedApplication = nullptr;
    MetalNumanXHumanMatterEncodePreparedApply encodePreparedApply = nullptr;
    MetalNumanXHumanMatterAbortPreparedApply abortPreparedApply = nullptr;
    MetalNumanXHumanMatterReservePublishedRoot reservePublishedRoot = nullptr;
    MetalNumanXHumanMatterReleasePublishedRoot releasePublishedRoot = nullptr;
    std::uint64_t fingerprint = 0u;

    void* matterGeneralizedReaction = nullptr;
    void* jointStatuses = nullptr;
    void* acceptedPhysicsStateTokens = nullptr;
    void* matterApplyOutcomes = nullptr;
    std::uint64_t matterGeneralizedReactionGPUAddress = 0u;
    std::uint64_t jointStatusesGPUAddress = 0u;
    std::uint64_t acceptedPhysicsStateTokensGPUAddress = 0u;
    std::uint64_t matterApplyOutcomesGPUAddress = 0u;
    std::uint64_t matterGeneralizedReactionElementCount = 0u;
    std::uint64_t jointStatusElementCount = 0u;
    std::uint64_t acceptedPhysicsStateTokenByteCount = 0u;
    std::uint64_t matterApplyOutcomeElementCount = 0u;

    std::uint32_t environmentCount = 0u;
    std::uint32_t reactionStride = 0u;
    std::uint32_t jointStatusStride = 0u;
    std::uint32_t acceptedTokenStrideBytes = 0u;
    std::uint32_t matterApplyOutcomeStride = 0u;
    std::uint32_t transactionSlot = 0u;
    std::uint32_t substepIndex = 0u;
    // The current owner ABI admits exactly one physics substep and therefore
    // one start-of-control checkpoint. A future multi-substep ABI must retain
    // one prepared root across all substeps instead of publishing per-substep.
    std::uint32_t physicsSubstepCount = 0u;
    // Maximum attachment-query suffix admitted by the owner. The private
    // generic-kinematics stream also carries four immutable probes per Human
    // body, so validation requires 4*bodyCount+candidatePointCapacity <= the
    // generic operator point ceiling. Zero remains valid for body-only exact
    // candidate calls.
    std::uint32_t candidatePointCapacity = 0u;

    // Global control-root identity supplied by the adapter. Zero is a valid
    // first root; every later pass/lease/witness/applied record must match it.
    std::uint32_t controlStep = 0u;
    // Logical articulation shape. The adapter's reaction arena remains
    // capacity-strided, while live q/v/A0 are exact logical strides.
    std::uint32_t qCoordinateCount = 0u;
    std::uint32_t dofCount = 0u;
    std::uint32_t dofLayoutVersion = 0u;
    std::uint64_t transactionFingerprint = 0u;
    std::uint64_t linearizationEpoch = 0u;
    std::uint64_t slotGeneration = 0u;
    MetalNumanXHumanMatterTokenFamily tokenFamily =
        MetalNumanXHumanMatterTokenFamily::legacyMicrosecondsV1;
    std::uint32_t reservedTokenFamily = 0u;
    // Required only for exactNanosecondsV2. The owner admits the exact
    // program only when this is the simultaneously attached HumanIO
    // transaction program, closing cross-command receipt replay.
    std::uint64_t humanIOProgramFingerprint = 0u;

    [[nodiscard]] bool valid() const noexcept {
        constexpr std::uint32_t requiredCapabilities =
            MetalNumanXHumanMatterSourceEffectiveTangent |
            MetalNumanXHumanMatterSourceDynamicsWitness |
            MetalNumanXHumanMatterStagedReaction |
            MetalNumanXHumanMatterJointDecision |
            MetalNumanXHumanMatterPreparedPhysicsGate;
        constexpr std::uint32_t requiredAccess =
            MetalNumanXHumanMatterReadLiveHumanState |
            MetalNumanXHumanMatterReadHumanCheckpoints |
            MetalNumanXHumanMatterReadSourceEffectiveTangent |
            MetalNumanXHumanMatterReadSourceDynamicsWitness |
            MetalNumanXHumanMatterWriteStagedReaction |
            MetalNumanXHumanMatterWriteJointStatus |
            MetalNumanXHumanMatterWritePreparedPhysicsToken;
        const bool exactCapability =
            (capabilities &
             MetalNumanXHumanMatterExactCandidateKinematics) != 0u;
        const bool exactAccess =
            (accessFlags &
             MetalNumanXHumanMatterMayEncodeExactCandidate) != 0u;
        const bool exactClock =
            (capabilities &
             MetalNumanXHumanMatterExactClockAuthority) != 0u;
        const bool familyValid = exactClock
            ? tokenFamily ==
                    MetalNumanXHumanMatterTokenFamily::exactNanosecondsV2 &&
                humanIOProgramFingerprint != 0u
            : tokenFamily ==
                    MetalNumanXHumanMatterTokenFamily::legacyMicrosecondsV1 &&
                humanIOProgramFingerprint == 0u;
        return abiVersion == kMetalNumanXHumanMatterABIVersion &&
            structSize == sizeof(MetalNumanXHumanMatterProgram) &&
            (capabilities &
             ~kMetalNumanXHumanMatterKnownCapabilities) == 0u &&
            (capabilities & requiredCapabilities) == requiredCapabilities &&
            (accessFlags & ~kMetalNumanXHumanMatterKnownAccess) == 0u &&
            (accessFlags & requiredAccess) == requiredAccess &&
            exactCapability == exactAccess &&
            familyValid && reservedTokenFamily == 0u &&
            (exactCapability
                 ? candidatePointCapacity <=
                       MR_ARTICULATED_OPERATOR_MAX_POINTS
                 : candidatePointCapacity == 0u) &&
            context != nullptr && encode != nullptr && abort != nullptr &&
            acquirePrepareLease != nullptr &&
            bindHumanIOCandidatePublication != nullptr &&
            releasePrepareLease != nullptr &&
            reservePreparedApplication != nullptr &&
            encodePreparedApply != nullptr && abortPreparedApply != nullptr &&
            reservePublishedRoot != nullptr &&
            releasePublishedRoot != nullptr &&
            fingerprint != 0u && transactionFingerprint != 0u &&
            linearizationEpoch != 0u && slotGeneration != 0u &&
            dofLayoutVersion == kMetalNumanXHumanMatterDofLayoutVersion &&
            dofCount != 0u &&
            dofCount <= MR_NUMANX_COUPLED_HUMAN_MAX_DOFS &&
            qCoordinateCount == dofCount + 1u &&
            qCoordinateCount <= MR_NUMANX_COUPLED_HUMAN_MAX_Q &&
            physicsSubstepCount == 1u && substepIndex == 0u &&
            environmentCount == 1u &&
            matterGeneralizedReaction != nullptr && jointStatuses != nullptr &&
            acceptedPhysicsStateTokens != nullptr &&
            matterApplyOutcomes != nullptr &&
            matterGeneralizedReactionGPUAddress != 0u &&
            jointStatusesGPUAddress != 0u &&
            acceptedPhysicsStateTokensGPUAddress != 0u &&
            matterApplyOutcomesGPUAddress != 0u &&
            reactionStride == MR_NUMI_HUMAN_STAND_MAX_DOFS &&
            jointStatusStride != 0u &&
            acceptedTokenStrideBytes ==
                MR_NUMANX_HUMAN_MATTER_ACCEPTED_TOKEN_BYTES &&
            matterApplyOutcomeStride != 0u &&
            matterGeneralizedReactionElementCount >=
                static_cast<std::uint64_t>(environmentCount) *
                    reactionStride &&
            jointStatusElementCount >=
                static_cast<std::uint64_t>(environmentCount - 1u) *
                    jointStatusStride + 1u &&
            acceptedPhysicsStateTokenByteCount >=
                static_cast<std::uint64_t>(environmentCount) *
                    acceptedTokenStrideBytes &&
            matterApplyOutcomeElementCount >=
                static_cast<std::uint64_t>(environmentCount - 1u) *
                    matterApplyOutcomeStride + 1u;
    }

    [[nodiscard]] bool configured() const noexcept {
        return abiVersion != kMetalNumanXHumanMatterABIVersion ||
            structSize != sizeof(MetalNumanXHumanMatterProgram) ||
            capabilities != 0u || accessFlags != 0u || context != nullptr ||
            encode != nullptr || abort != nullptr ||
            acquirePrepareLease != nullptr ||
            bindHumanIOCandidatePublication != nullptr ||
            releasePrepareLease != nullptr ||
            reservePreparedApplication != nullptr ||
            encodePreparedApply != nullptr || abortPreparedApply != nullptr ||
            reservePublishedRoot != nullptr ||
            releasePublishedRoot != nullptr || fingerprint != 0u ||
            matterGeneralizedReaction != nullptr || jointStatuses != nullptr ||
            acceptedPhysicsStateTokens != nullptr ||
            matterApplyOutcomes != nullptr ||
            matterGeneralizedReactionGPUAddress != 0u ||
            jointStatusesGPUAddress != 0u ||
            acceptedPhysicsStateTokensGPUAddress != 0u ||
            matterApplyOutcomesGPUAddress != 0u ||
            matterGeneralizedReactionElementCount != 0u ||
            jointStatusElementCount != 0u ||
            acceptedPhysicsStateTokenByteCount != 0u ||
            matterApplyOutcomeElementCount != 0u ||
            environmentCount != 0u || reactionStride != 0u ||
            jointStatusStride != 0u || acceptedTokenStrideBytes != 0u ||
            matterApplyOutcomeStride != 0u ||
            qCoordinateCount != 0u || dofCount != 0u ||
            dofLayoutVersion != 0u ||
            transactionSlot != 0u || substepIndex != 0u ||
            physicsSubstepCount != 0u ||
            candidatePointCapacity != 0u ||
            controlStep != 0u ||
            tokenFamily !=
                MetalNumanXHumanMatterTokenFamily::legacyMicrosecondsV1 ||
            reservedTokenFamily != 0u ||
            humanIOProgramFingerprint != 0u ||
            transactionFingerprint != 0u || linearizationEpoch != 0u ||
            slotGeneration != 0u;
    }
};

enum class MetalNumanXHumanMatterProposalMode : std::uint32_t {
    validateBrainWitness = 0u,
    forceReject = 1u,
};

struct MetalNumanXHumanMatterProposalRequest {
    std::uint32_t abiVersion = kMetalNumanXHumanMatterABIVersion;
    std::uint32_t structSize = sizeof(MetalNumanXHumanMatterProposalRequest);
    MetalNumanXHumanMatterProposalMode mode =
        MetalNumanXHumanMatterProposalMode::validateBrainWitness;
    std::uint32_t reserved1 = 0u;
    void* commandBuffer = nullptr;
    void* brainCommitWitnesses = nullptr;
    void* brainPrepareCompleteEvent = nullptr;
    std::uint64_t brainPrepareCompleteEventValue = 0u;
    std::uint64_t brainCommitWitnessesGPUAddress = 0u;
    std::uint64_t brainCommitWitnessElementCount = 0u;
    std::uint32_t brainCommitWitnessStride = 0u;
    std::uint32_t environmentCount = 0u;
    std::uint32_t transactionSlot = 0u;
    std::uint32_t stepIndex = 0u;
    std::uint32_t substepIndex = 0u;
    std::uint32_t physicsSubstepCount = 0u;
    std::uint32_t controlStep = 0u;
    std::uint64_t programFingerprint = 0u;
    std::uint64_t transactionFingerprint = 0u;
    std::uint64_t linearizationEpoch = 0u;
    std::uint64_t slotGeneration = 0u;
};

struct MetalNumanXHumanMatterApplyRequest {
    std::uint32_t abiVersion = kMetalNumanXHumanMatterABIVersion;
    std::uint32_t structSize = sizeof(MetalNumanXHumanMatterApplyRequest);
    MetalNumanXHumanMatterApplyMode mode =
        MetalNumanXHumanMatterApplyMode::validateBrainAck;
    std::uint32_t reserved0 = 0u;
    void* commandBuffer = nullptr;
    void* brainAcks = nullptr;
    void* brainAckEvent = nullptr;
    // Exactly once after command completion and adapter disposition, never at
    // GPU event-signal time. Resources remain quarantined through callback
    // return. abortApply on an uncommitted command produces no callback.
    void* completionContext = nullptr;
    MetalNumanXHumanMatterApplyCompletion completion = nullptr;
    std::uint64_t brainAckEventValue = 0u;
    std::uint64_t brainAcksGPUAddress = 0u;
    std::uint64_t brainAckElementCount = 0u;
    std::uint32_t brainAckStride = 0u;
    std::uint32_t environmentCount = 0u;
    std::uint32_t transactionSlot = 0u;
    std::uint32_t stepIndex = 0u;
    std::uint32_t substepIndex = 0u;
    std::uint32_t physicsSubstepCount = 0u;
    std::uint32_t controlStep = 0u;
    std::uint64_t programFingerprint = 0u;
    std::uint64_t transactionFingerprint = 0u;
    std::uint64_t linearizationEpoch = 0u;
    std::uint64_t slotGeneration = 0u;
};

struct MetalNumanXHumanMatterPublicationReservationRequest {
    std::uint32_t abiVersion = kMetalNumanXHumanMatterABIVersion;
    std::uint32_t structSize = sizeof(
        MetalNumanXHumanMatterPublicationReservationRequest);
    std::uint32_t environmentCount = 0u;
    std::uint32_t transactionSlot = 0u;
    std::uint32_t stepIndex = 0u;
    std::uint32_t substepIndex = 0u;
    std::uint32_t physicsSubstepCount = 0u;
    std::uint32_t controlStep = 0u;
    std::uint64_t programFingerprint = 0u;
    std::uint64_t transactionFingerprint = 0u;
    std::uint64_t linearizationEpoch = 0u;
    std::uint64_t slotGeneration = 0u;
    std::uint64_t jointCommitFingerprint = 0u;
    std::uint64_t brainGeneration = 0u;
};

struct MetalNumanXHumanMatterPublicationReleaseRequest {
    std::uint32_t abiVersion = kMetalNumanXHumanMatterABIVersion;
    std::uint32_t structSize = sizeof(
        MetalNumanXHumanMatterPublicationReleaseRequest);
    void* publicationFences = nullptr;
    std::uint64_t publicationFencesGPUAddress = 0u;
    std::uint64_t publicationFenceElementCount = 0u;
    std::uint32_t publicationFenceStride = 0u;
    std::uint32_t environmentCount = 0u;
    std::uint32_t transactionSlot = 0u;
    std::uint32_t stepIndex = 0u;
    std::uint32_t substepIndex = 0u;
    std::uint32_t physicsSubstepCount = 0u;
    std::uint32_t controlStep = 0u;
    std::uint64_t programFingerprint = 0u;
    std::uint64_t transactionFingerprint = 0u;
    std::uint64_t linearizationEpoch = 0u;
    std::uint64_t slotGeneration = 0u;
    std::uint64_t jointCommitFingerprint = 0u;
    std::uint64_t brainGeneration = 0u;
};

struct MetalNumanXHumanMatterPreparedView {
    std::uint32_t abiVersion = kMetalNumanXHumanMatterABIVersion;
    std::uint32_t structSize = sizeof(MetalNumanXHumanMatterPreparedView);
    std::uint32_t environmentCount = 0u;
    std::uint32_t transactionSlot = 0u;
    std::uint32_t stepIndex = 0u;
    std::uint32_t substepIndex = 0u;
    std::uint32_t physicsSubstepCount = 0u;
    std::uint32_t finalTokenStrideBytes = 0u;

    std::uint32_t proposalStride = 0u;
    std::uint32_t proposedTokenStrideBytes = 0u;
    std::uint32_t applyActionStride = 0u;
    std::uint32_t matterApplyOutcomeStride = 0u;
    std::uint32_t appliedOutcomeStride = 0u;
    std::uint32_t publicationFenceStride = 0u;

    // Low-level transaction SPI. All arenas are persistent exact same-device
    // MTLBuffer identities retained by the prepared capability. Applied bytes
    // are quarantined and are not externally authoritative before an exact
    // COMMITTED publication fence and successful releasePublishedRoot.
    // physicalPreparedEvent is owner-produced only: consumers wait for the
    // physicalPreparedEventValue before Brain preparation and wait for
    // proposalEventValue / appliedEventValue are liveness order only; every
    // consumer must also validate the corresponding status and fingerprint.
    void* preparedPhysicsStateTokens = nullptr;
    void* finalAcceptedPhysicsStateTokens = nullptr;
    void* proposals = nullptr;
    void* proposedPhysicsStateTokens = nullptr;
    void* applyActions = nullptr;
    void* matterApplyOutcomes = nullptr;
    void* appliedOutcomes = nullptr;
    void* publicationFences = nullptr;
    void* physicalPreparedEvent = nullptr;
    std::uint64_t preparedPhysicsStateTokensGPUAddress = 0u;
    std::uint64_t finalAcceptedPhysicsStateTokensGPUAddress = 0u;
    std::uint64_t proposalsGPUAddress = 0u;
    std::uint64_t proposedPhysicsStateTokensGPUAddress = 0u;
    std::uint64_t applyActionsGPUAddress = 0u;
    std::uint64_t matterApplyOutcomesGPUAddress = 0u;
    std::uint64_t appliedOutcomesGPUAddress = 0u;
    std::uint64_t publicationFencesGPUAddress = 0u;
    std::uint64_t preparedPhysicsStateTokenByteCount = 0u;
    std::uint64_t finalAcceptedPhysicsStateTokenByteCount = 0u;
    std::uint64_t proposalElementCount = 0u;
    std::uint64_t proposedPhysicsStateTokenByteCount = 0u;
    std::uint64_t applyActionElementCount = 0u;
    std::uint64_t matterApplyOutcomeElementCount = 0u;
    std::uint64_t appliedOutcomeElementCount = 0u;
    std::uint64_t publicationFenceElementCount = 0u;
    std::uint64_t physicalPreparedEventValue = 0u;
    std::uint64_t proposalEventValue = 0u;
    std::uint64_t appliedEventValue = 0u;

    std::uint32_t controlStep = 0u;
    std::uint32_t qCoordinateCount = 0u;
    std::uint32_t dofCount = 0u;
    std::uint32_t dofLayoutVersion = 0u;
    std::uint64_t programFingerprint = 0u;
    std::uint64_t transactionFingerprint = 0u;
    std::uint64_t linearizationEpoch = 0u;
    std::uint64_t slotGeneration = 0u;
    // Populated only after the post-physical one-shot candidate bind. These
    // are pointer-free identities; the callback program remains private to the
    // quarantined prepared lease.
    std::uint64_t humanIOCandidateKeyFingerprint = 0u;
    std::uint64_t acceptedBrainGeneration = 0u;
    std::uint64_t humanIOSensorGeneration = 0u;
    std::uint64_t humanIOProgramFingerprint = 0u;
    std::uint64_t humanIOSensorFingerprint = 0u;
    std::uint64_t humanIOTransactionInstanceFingerprint = 0u;
    std::uint64_t humanIOCandidatePublicationFingerprint = 0u;
    std::uint64_t humanIODeviceRegistryID = 0u;
    std::uint64_t humanIOIdentityFingerprint = 0u;
};

enum class MetalNumanXHumanMatterOperationStatus : std::uint32_t {
    success = 0u,
    invalidHandle,
    invalidRequest,
    alreadyFinalizing,
    metalEncoderFailure,
    terminalNoTouch,
};

struct MetalNumanXHumanMatterOperationDiagnostics {
    MetalNumanXHumanMatterOperationStatus status =
        MetalNumanXHumanMatterOperationStatus::success;
    bool encoded = false;
    std::string message;

    [[nodiscard]] bool succeeded() const noexcept {
        return status == MetalNumanXHumanMatterOperationStatus::success;
    }
};

enum class MetalNumanXHumanMatterProposalCompletionStatus : std::uint32_t {
    ready = 1u,
    terminalNoTouch = 2u,
};

enum class MetalNumanXHumanMatterPhysicalCompletionStatus : std::uint32_t {
    ready = 1u,
    terminalNoTouch = 2u,
};

// One-shot borrowed notification for the original physical command. Owner
// state and the device-written physical status are settled before delivery;
// the owner mutex is never held while the callback runs. Late registration
// invokes synchronously before returning.
using MetalNumanXHumanMatterPhysicalCompletion = void (*)(
    void* context,
    MetalNumanXHumanMatterPhysicalCompletionStatus status,
    std::uint64_t slotGeneration
) noexcept;

// One-shot borrowed callback for the exact prepared generation. The owner
// mutex is not held while it runs. A READY callback may synchronously reserve
// the prepared application from inside the callback.
using MetalNumanXHumanMatterProposalCompletion = void (*)(
    void* context,
    MetalNumanXHumanMatterProposalCompletionStatus status,
    std::uint64_t slotGeneration
) noexcept;

// Move-only capability for one quarantined physical prepare. It adopts the
// original submission and retains owner checkpoints without retaining any old
// borrowed pass or command buffer. Proposal is mutation-free; apply can mutate
// Human/Matter only after exact Brain ACK. ACCEPT remains quarantined until a
// COMMITTED publication fence is released. Any terminal-no-touch disposition
// permanently prevents restore, publication, and slot reuse.
class MetalNumanXHumanMatterPrepared {
public:
    MetalNumanXHumanMatterPrepared() noexcept;
    ~MetalNumanXHumanMatterPrepared();
    MetalNumanXHumanMatterPrepared(
        MetalNumanXHumanMatterPrepared&& other
    ) noexcept;
    MetalNumanXHumanMatterPrepared& operator=(
        MetalNumanXHumanMatterPrepared&& other
    ) noexcept;
    MetalNumanXHumanMatterPrepared(
        const MetalNumanXHumanMatterPrepared&
    ) = delete;
    MetalNumanXHumanMatterPrepared& operator=(
        const MetalNumanXHumanMatterPrepared&
    ) = delete;

    [[nodiscard]] bool valid() const noexcept;
    [[nodiscard]] bool view(
        MetalNumanXHumanMatterPreparedView& output
    ) const noexcept;
    [[nodiscard]] bool encodeWaitForPhysicalPrepare(
        void* commandBuffer
    ) noexcept;
    [[nodiscard]] bool registerPhysicalCompletion(
        void* completionContext,
        MetalNumanXHumanMatterPhysicalCompletion completion
    ) noexcept;
    // Installs the exact unpublished HumanIO sensor candidate after the first
    // physical command has completed successfully. Legal exactly once and
    // only before proposal; wrong, stale, duplicate, or late capabilities are
    // rejected without replacing the installed generation.
    [[nodiscard]] bool bindHumanIOCandidatePublication(
        const MetalNumanXHumanIOCandidatePublicationProgram& candidate
    ) noexcept;
    [[nodiscard]] MetalNumanXHumanMatterOperationDiagnostics
    proposePrepared(
        const MetalNumanXHumanMatterProposalRequest& request
    ) noexcept;
    // Registers after proposePrepared succeeds. Internal proposal state and
    // the owner completion event are settled before the callback. If the
    // proposal command already completed, registration invokes synchronously.
    [[nodiscard]] bool registerProposalCompletion(
        void* completionContext,
        MetalNumanXHumanMatterProposalCompletion completion
    ) noexcept;
    [[nodiscard]] bool abortProposal(void* commandBuffer) noexcept;
    // Called after proposal-command completion and before the Brain ACK is
    // submitted. It performs the adapter's fallible exact-generation
    // reservation; no later ACCEPT ACK is admissible without it.
    [[nodiscard]] bool reservePreparedApplication(
        const MetalNumanXHumanMatterBrainPreflightView& preflight
    ) noexcept;
    [[nodiscard]] MetalNumanXHumanMatterOperationDiagnostics
    applyPrepared(
        const MetalNumanXHumanMatterApplyRequest& request
    ) noexcept;
    [[nodiscard]] bool abortApply(void* commandBuffer) noexcept;
    // Prevalidates the exact owner-owned PENDING fence range and the completed
    // applied-output range before any Brain pointer flip.
    [[nodiscard]] bool reservePublishedRoot(
        const MetalNumanXHumanMatterPublicationReservationRequest& request
    ) noexcept;
    // Nonthrow release after the caller overwrites the reserved fence with the
    // exact COMMITTED record. Only adapter `released` clears the quarantine.
    [[nodiscard]] MetalNumanXHumanMatterPrepareLeaseDisposition
    releasePublishedRoot(
        const MetalNumanXHumanMatterPublicationReleaseRequest& request
    ) noexcept;

private:
    friend class MetalArticulatedOperatorContext;
    friend class MetalArticulatedOperatorSubmission;
    std::shared_ptr<detail::MetalArticulatedOperatorContextState> state_;
    std::shared_ptr<detail::MetalNumanXHumanMatterPreparedState> capability_;
    std::uint64_t slotGeneration_ = 0u;
};

// Immutable step-gated activation of a retained prefix of the complete
// source equality payload. The full ordered payload remains bound and resident;
// only the Stand dispatch row count changes at releaseStep. A zero/zero record
// disables the schedule. Callers must split a submission at the event boundary.
struct MetalNumiHumanJointEqualityPrefixRelease {
    std::uint32_t releaseStep = 0u;
    std::uint32_t retainedPrefixCount = 0u;

    [[nodiscard]] bool configured() const noexcept {
        return releaseStep != 0u || retainedPrefixCount != 0u;
    }
};

// Immutable articulated-gravity load ramp indexed by one-based accepted steps.
// The default record is disabled and leaves the model's full gravity unchanged.
// This changes only the articulated Human gravity RHS; coupled Matter gravity
// remains owned by its existing transaction.
struct MetalNumiHumanGravityScaleRamp {
    std::uint32_t firstAcceptedStep = 0u;
    std::uint32_t fullGravityAcceptedStep = 0u;
    float initialScale = 1.0f;
    float fullGravityScale = 1.0f;

    [[nodiscard]] bool configured() const noexcept {
        return firstAcceptedStep != 0u ||
            fullGravityAcceptedStep != 0u ||
            initialScale != 1.0f || fullGravityScale != 1.0f;
    }

    [[nodiscard]] float scaleAtAcceptedStep(
        const std::uint32_t acceptedStep
    ) const noexcept {
        if (!configured()) return 1.0f;
        if (acceptedStep <= firstAcceptedStep) return initialScale;
        if (acceptedStep >= fullGravityAcceptedStep) return fullGravityScale;
        const float t = static_cast<float>(
            acceptedStep - firstAcceptedStep
        ) / static_cast<float>(
            fullGravityAcceptedStep - firstAcceptedStep
        );
        return initialScale + t * (fullGravityScale - initialScale);
    }
};

// Persistent large-state Human horizon. This is deliberately coupled to the
// MyoSim sidecar: each device step recomputes source routes and J^T muscle
// force from the current q before advancing activation and dynamics. Support
// contacts address source-authored point queries in the enclosing stream.
// Root assistance is a world wrench on the floating base, never joint torque.
struct MetalNumiHumanStandInput {
    std::span<const float> v{};
    // Optional constant external generalized load, one nv vector per environment.
    // Never use this for solved equality/contact/limit reactions or for tissue
    // stiffness. Those contributions have current-state owners below.
    std::span<const float> preloadedGeneralizedForce{};
    // Immutable row-major K[nv,nv] followed by scalar rest coordinates r[nv].
    // The host validates symmetry, positive semidefiniteness and zero root
    // rows/columns. Each device step includes K(q-r)+hKv in the bias and h^2K
    // in the SAME effective factor used for constraint response columns.
    std::span<const float> passiveJointProgram{};
    // Optional fixed-capacity convex unilateral periarticular reference terms.
    std::span<const MRNumiHumanHipCapsuleTermGPU> hipCapsuleTerms{};
    std::span<const MRNumiHumanStandContactGPU> contacts{};
    // The pre-dynamics support geometry callback writes one fixed-world bed
    // plane point/normal into each contact record on GPU for this pose.
    // Currently admitted only for one environment and without warm-start.
    bool usePerContactSupportPlanes = false;
    // Optional observer-only accepted-step range, inclusive and one-based.
    // Zero/zero disables it. The same immutable range is carried by every
    // continuation; the dispatch selects only the matching global step.
    // Capture requires readStandConstraintDiagnostics and one-step submissions
    // for any segment overlapping this range.
    std::uint32_t rootMomentumDiagnosticFirstAcceptedStep = 0u;
    std::uint32_t rootMomentumDiagnosticLastAcceptedStep = 0u;
    // Exact scalar joint manifold imported from the source model. These rows
    // carry bilateral reaction impulses during dynamics; dependent q/v are
    // projected back onto the same polynomial after each accepted step.
    std::span<const MRNumiHumanJointEqualityGPU> jointEqualities{};
    // Optional release schedule over that immutable payload. At/after the
    // absolute release step, dispatch only the declared retained prefix.
    MetalNumiHumanJointEqualityPrefixRelease jointEqualityPrefixRelease{};
    // Optional NHTENDON2/3 program. When present, one terminal-load transaction
    // executes from the current MyoSim force field before every dynamics step.
    // Transfer alone retains MyoSim's original J^T wrench. A configured
    // two-phase consumer may replace only its explicitly declared share with
    // a solved continuum reaction before dynamics. Transfer generalized
    // corrections remain diagnostics and are never added as direct torque.
    std::span<const MRNumiHumanTendonBindingGPU> tendonBindings{};
    std::span<const MRNumiHumanTendonEnvelopeGPU> tendonEnvelopes{};
    MetalNumiHumanTendonLoadProgram tendonLoadProgram{};
    MetalNumiHumanSupportGeometryProgram supportGeometryProgram{};
    MetalNumanXTransactionProgram numanXTransactionProgram{};
    MetalNumanXHumanMatterProgram numanXHumanMatterProgram{};
    // Local steps encoded by this submission. A caller that must observe an
    // accepted state after every step may split one authoritative horizon
    // across submissions on one context. In that case stepIndexOffset names
    // the first global step and authoritativeStepCount retains the immutable
    // total horizon. Every nonzero offset must immediately follow the exact
    // prior published q/v/MyoSim/root bytes under the same immutable input
    // boundary; a fresh context, a skipped step, or a changed boundary fails
    // before dispatch.
    // Zero authoritativeStepCount selects the legacy single-submission
    // contract (total == stepCount); stepIndexOffset must then also be zero.
    std::uint32_t stepCount = 0u;
    std::uint32_t stepIndexOffset = 0u;
    std::uint32_t authoritativeStepCount = 0u;
    std::uint32_t contactIterationCount = 12u;
    bool enableContact = true;
    bool enableRootAssistance = false;
    mr_float4 groundPoint{0.0f, 0.0f, 0.0f, 0.0f};
    mr_float4 groundNormal{0.0f, 1.0f, 0.0f, 0.0f};
    mr_float4 targetRootPosition{0.0f, 0.0f, 0.0f, 0.0f};
    mr_float4 targetRootOrientation{0.0f, 0.0f, 0.0f, 1.0f};
    // linear stiffness, linear damping, angular stiffness, angular damping.
    mr_float4 assistanceGains{0.0f, 0.0f, 0.0f, 0.0f};

    MetalNumiHumanGravityScaleRamp gravityScaleRamp{};
    // Predetermined external force in world-space newtons at the root origin.
    // Bound with the episode's immutable input boundary; every continuation
    // must retain the same force and half-open authoritative step window.
    // Physical start/duration are stepWindow.x/y * the context's fixed dt.
    // The all-zero default is disabled. This is never stability assistance.
    MRNumiHumanTimedRootForceGPU timedRootForce{};

    [[nodiscard]] bool enabled() const noexcept {
        return stepCount != 0u;
    }
};

// Exact authorization to advance device-resident q/v/MyoSim state published
// by the preceding accepted Human root. Matter roots additionally bind their
// accepted token and HumanIO program. Legacy Stand roots bind the exact
// immutable input-program fingerprint and accepted generation. A valid
// continuation never supplies host copies of q, v, or MyoSim state; those
// streams remain in the context-owned Metal arena. Once resident state exists,
// an implicit host reset is rejected.
struct MetalArticulatedOperatorResidentStateContinuation {
    std::uint64_t previousTransactionFingerprint = 0u;
    std::uint64_t previousPhysicsGeneration = 0u;
    // Exact-family continuations additionally name the accepted token and the
    // transaction-scoped HumanIO program that produced the resident state.
    // Legacy continuations keep both words zero.
    std::uint64_t previousAcceptedTokenFingerprint = 0u;
    std::uint64_t previousHumanIOProgramFingerprint = 0u;

    [[nodiscard]] bool configured() const noexcept {
        return previousTransactionFingerprint != 0u ||
            previousPhysicsGeneration != 0u ||
            previousAcceptedTokenFingerprint != 0u ||
            previousHumanIOProgramFingerprint != 0u;
    }

    [[nodiscard]] bool valid() const noexcept {
        return previousTransactionFingerprint != 0u &&
            previousPhysicsGeneration != 0u &&
            ((previousAcceptedTokenFingerprint == 0u &&
              previousHumanIOProgramFingerprint == 0u) ||
             (previousAcceptedTokenFingerprint != 0u &&
              previousHumanIOProgramFingerprint != 0u));
    }

    [[nodiscard]] bool validLegacy() const noexcept {
        return valid() && previousAcceptedTokenFingerprint == 0u;
    }

    [[nodiscard]] bool validExact() const noexcept {
        return valid() && previousAcceptedTokenFingerprint != 0u;
    }
};

// Packed, environment-major input for the synchronous Metal articulated
// operator. q contains environmentCount * articulation.nq floats. points
// contains environmentCount * pointCount records. All query body indices are
// global EngineModel body indices. A Millard source program indexes `points`
// directly and therefore retains one authoritative device kinematics stream.
struct MetalArticulatedOperatorInput {
    std::uint32_t articulationIndex = 0u;
    std::size_t environmentCount = 0u;
    std::size_t pointCount = 0u;
    std::span<const float> q{};
    // Optional canonical authoritative translation, one per floating-root
    // environment, with exactly matching q.xyz projection. In a Stand horizon,
    // empty creates the episode reference from q.xyz; continuations retain it.
    // Without Stand, a nonempty span explicitly selects read-only paired FK and
    // MyoSim source evaluation. This requires pointJacobiansOnly and excludes
    // Millard and resident continuation. The supplied q/v/root records are not
    // advanced and no Stand callback, clock, or accepted root is published.
    // A positive source constitutive evaluation timestep still produces its
    // private candidate muscle-state result, exactly as in the legacy evaluator.
    // Empty retains legacy one-pass scalar geometry outside Stand.
    std::span<const MRCompensatedRootTranslationGPU> rootTranslations{};
    // Optional environment-major articulation velocity. Required only when a
    // caller needs nonzero MyoSim path velocity; stand horizons source the
    // current device-resident velocity sidecar directly.
    std::span<const float> v{};
    std::span<const MRArticulatedPointImpulseGPU> points{};
    MetalMillardReferenceInput millard{};
    MetalMujocoMuscleReferenceInput mujoco{};
    MetalNumiHumanStandInput stand{};
    // Evaluate the registered supportGeometryProgram on the current q using
    // the point-Jacobian-only paired-FK path, then return its derived contact
    // planes and matching point buffers without running a Stand step.
    bool captureSupportGeometryOnly = false;
    MetalArticulatedOperatorResidentStateContinuation residentContinuation{};
    // Opt in to an accepted legacy Stand root without a NumanX Human/Matter
    // ACK owner. The context fingerprints the immutable source/program
    // boundary and publishes a new generation only after the full native
    // status/result gate succeeds. Continuations must name that immediately
    // preceding generation and leave q, rootTranslations, v, and MyoSim states
    // empty so the exact accepted device buffers are consumed in place.
    bool publishAcceptedResidentState = false;
    // Keep default full typed output collection. A false value is admitted
    // only with accepted-resident publication and returns the compact
    // articulated/Stand status records while q/v/MyoSim and derived arrays
    // remain device-resident for MetalArticulatedOperatorPhysicalStateObserver.
    bool collectFullResultToHost = true;
};

enum class MetalStandEqualityDeferralFault : std::uint8_t {
    none = 0u,
    unavailableReducedMap = 1u,
    projectedColumnFallback = 2u,
    lateBaseFallback = 3u,
    invalid = 255u,
};

struct MetalArticulatedOperatorConfig {
    // The dense mass matrix is a correctness diagnostic. The factor-backed
    // impulse solve always runs; disabling this avoids its output bandwidth.
    bool writeDiagnosticMassMatrix = false;
    // Emits body/point kinematics and analytic point Jacobians without
    // assembling or factorizing the mass matrix. Generalized impulse and
    // delta-velocity outputs are deterministically zero. This mode is used by
    // the multi-articulation contact frontend before batched inverse ABA.
    bool pointJacobiansOnly = false;
    // When non-zero, advance each valid MyoSim activation after its force
    // reference and reduction pass in the same Metal command buffer. The Human
    // production path uses the versioned exact first-order hold; callers retain
    // the returned state sidecar and feed it into their next transaction. Zero
    // preserves the historical force-only behavior.
    float mujocoActivationTimestepSeconds = 0.0f;
    // Select ABI 3's exact first-order hold. False retains ABI 2's historical
    // explicit-Euler update for legacy callers and compatibility tests.
    bool mujocoActivationExactFirstOrderHold = true;
    // Empty discovers the co-installed metallib relative to the loaded
    // MetalRobo dylib, with the configured build-tree path as a fallback.
    // A non-empty path is an explicit trusted ABI-compatible override.
    std::string metallibPath;
    // Read-only final-step constraint evidence, including signed source-limit
    // multipliers by DOF, published through the accepted-result boundary.
    // The extra device write is enabled only for this diagnostic path.
    bool readStandConstraintDiagnostics = false;
    // Development path: keep stand assembly and completion in separate GPU
    // dispatches of the same authoritative command buffer. Both phases use
    // the same physical owner and accepted-state transaction.
    bool splitStandSolve = false;
    // Reuse each fixed source-limit equality response derivative across the
    // ordered sweeps of one split GPU root. Unsupported shapes and scalar or
    // CPU completion retain the original finish specialization.
    bool cacheStandLimitEqualityResponses = false;
    // Compile a conservative authored effective-operator graph and factor
    // leaves before ancestors. Experimental; numerical/physical admission is
    // unchanged. CPU completion is incompatible with this upper factor.
    bool sparseStandOperator = false;
    // Default-off response-only nullspace solve for validated scalar
    // equality graphs. The source-matrix snapshot lives only through phases
    // 1, 4, and 5 of one root command buffer; it is derived scratch.
    bool reducedStandProjectedResponses = false;
    // Default-off use of the validated reduced factor for the two initial
    // bilateral velocity refinements. Enabling it also prepares that map.
    bool reducedStandBaseProjection = false;
    // Reuse one exact body MotionColumn for each canonical COM/+axis point
    // probe block. The point-world and point-Jacobian rows remain published.
    // This changes only the evaluation path and is bound to continuation
    // identity when an authoritative Stand horizon is configured.
    bool fuseCanonicalBodyProbes = false;
    // Default-off GPU-predicated omission of legacy equality responses and
    // full Schur factor, with in-command-buffer fallback reconstruction.
    bool deferStandEqualityData = false;
    // Diagnostic-only forcing of one deferred-path recovery branch. The
    // selected branch always resolves through the unchanged legacy equations.
    MetalStandEqualityDeferralFault standEqualityDeferralFault =
        MetalStandEqualityDeferralFault::none;
    // Opt-in equilibrated Cholesky attempt for its small reduced SPD factor.
    // A rejected candidate falls back to the default pivoted bilateral factor.
    bool reducedStandCholesky = false;
    // Experimental SIMD32 contact-family sweep for the 128-DOF cooperative
    // finish. Prep and all non-contact constraints retain the 128-thread path.
    bool firstSimdStandContactSweep = false;
    // Default-off ordered one-pass limit projection, retaining authored row
    // order and all existing checks/work accounting.
    bool onePassStandOrderedLimits = false;
    // Experimental default-off relocation of limit/equality reaction and work
    // bookkeeping to an ordered replay within each coupled sweep. Candidate
    // velocity updates retain their existing order and arithmetic.
    bool deferStandEqualityDiagnostics = false;
    // Opt-in 7,800-float threadgroup prefix for 65-96-row equality LU.
    bool hybridStandEqualityFactorCache = false;
    // Default-off source contact impulse guess retained by the existing
    // accepted-state transaction. Only split GPU finish reads it; final PGS
    // sweeps, ordering, and stopping rules remain unchanged.
    bool standContactWarmStart = false;
    // Opt-in per-row PGS stop bound: contact/linear rows use m/s and angular
    // rows use rad/s. The same numeric SI bound applies independently to each;
    // this is not a dimensionally uniform norm or physiological tolerance.
    // Zero retains fixed sweeps. Values up to 1e-6 enter continuation identity.
    float standPgsVelocityResidualTolerance = 0.0f;
    // Optional speculative-contact candidate admission override. Zero retains
    // the source contact activation distance and warm-start policy.
    float speculativeContactAdmissionDistanceMeters = 0.0f;
};

enum class MetalArticulatedOperatorHostStatus : std::uint32_t {
    success = 0u,
    invalidModel,
    unsupportedTopology,
    invalidDimensions,
    capacityOverflow,
    arithmeticOverflow,
    nonfiniteInput,
    invalidPointQuery,
    metallibUnavailable,
    metalDeviceUnavailable,
    metalDeviceUnsupported,
    metalLibraryFailure,
    metalPipelineFailure,
    metalBufferFailure,
    metalCommandFailure,
    gpuEnvironmentFailure,
    internalFailure,
    contextBusy,
    externalProgramFailure,
};

// The host always derives compact strides; callers cannot smuggle unchecked
// buffer layouts into the raw kernel. Counts and byte sizes are retained so a
// batch can be audited without reconstructing overflow-sensitive arithmetic.
struct MetalArticulatedOperatorLayout {
    MRArticulatedOperatorDispatchGPU dispatch{};
    std::size_t qElements = 0u;
    std::size_t qBytes = 0u;
    std::size_t pointElements = 0u;
    std::size_t pointBytes = 0u;
    std::size_t bodyPoseElements = 0u;
    std::size_t bodyPoseBytes = 0u;
    std::size_t pointWorldElements = 0u;
    std::size_t pointWorldBytes = 0u;
    std::size_t massMatrixElements = 0u;
    std::size_t massMatrixBytes = 0u;
    std::size_t pointJacobianElements = 0u;
    std::size_t pointJacobianBytes = 0u;
    std::size_t generalizedElements = 0u;
    std::size_t generalizedBytes = 0u;
    std::size_t statusElements = 0u;
    std::size_t statusBytes = 0u;
    std::size_t millardMuscleElements = 0u;
    std::size_t millardMuscleBytes = 0u;
    std::size_t millardStateElements = 0u;
    std::size_t millardStateBytes = 0u;
    std::size_t millardPathPointElements = 0u;
    std::size_t millardPathPointBytes = 0u;
    std::size_t millardCurveElements = 0u;
    std::size_t millardCurveBytes = 0u;
    std::size_t millardWrapElements = 0u;
    std::size_t millardWrapBytes = 0u;
    std::size_t millardResultElements = 0u;
    std::size_t millardResultBytes = 0u;
    std::size_t millardGeneralizedForceElements = 0u;
    std::size_t millardGeneralizedForceBytes = 0u;
    std::size_t mujocoMuscleElements = 0u;
    std::size_t mujocoMuscleBytes = 0u;
    std::size_t mujocoStateElements = 0u;
    std::size_t mujocoStateBytes = 0u;
    std::size_t mujocoSiteElements = 0u;
    std::size_t mujocoSiteBytes = 0u;
    std::size_t mujocoWrapElements = 0u;
    std::size_t mujocoWrapBytes = 0u;
    std::size_t mujocoRouteNodeElements = 0u;
    std::size_t mujocoRouteNodeBytes = 0u;
    std::size_t mujocoResultElements = 0u;
    std::size_t mujocoResultBytes = 0u;
    std::size_t mujocoMuscleGeneralizedForceElements = 0u;
    std::size_t mujocoMuscleGeneralizedForceBytes = 0u;
    std::size_t mujocoGeneralizedForceElements = 0u;
    std::size_t mujocoGeneralizedForceBytes = 0u;
    // Private suballocation in the mutually-exclusive source-muscle force
    // workspace: per-muscle rows followed by their environment reduction.
    std::size_t mujocoForceWorkspaceElements = 0u;
    std::size_t standVelocityElements = 0u;
    std::size_t standVelocityBytes = 0u;
    std::size_t standContactElements = 0u;
    std::size_t standContactBytes = 0u;
    std::size_t standJointEqualityElements = 0u;
    std::size_t standJointEqualityBytes = 0u;
    std::size_t standPassiveJointElements = 0u;
    std::size_t standPassiveJointBytes = 0u;
    std::size_t standSpatialJacobianElements = 0u;
    std::size_t standBodyMotionElements = 0u;
    std::size_t standFactorElements = 0u;
    std::size_t standVectorElements = 0u;
    std::size_t standResponseElements = 0u;
    std::size_t standScratchBytes = 0u;
    std::size_t standStatusElements = 0u;
    std::size_t standStatusBytes = 0u;
    std::size_t standTendonBindingElements = 0u;
    std::size_t standTendonBindingBytes = 0u;
    std::size_t standTendonEnvelopeElements = 0u;
    std::size_t standTendonEnvelopeBytes = 0u;
    std::size_t standTendonTransferElements = 0u;
    std::size_t standTendonTransferBytes = 0u;
    std::size_t standTendonCorrectionElements = 0u;
    std::size_t standTendonCorrectionBytes = 0u;
    // Private owner-transaction arena. These bytes exist only when a valid
    // MetalNumanXHumanMatterProgram is attached to a one-step stand input.
    std::size_t humanMatterQCheckpointElements = 0u;
    std::size_t humanMatterQCheckpointBytes = 0u;
    std::size_t humanMatterVCheckpointElements = 0u;
    std::size_t humanMatterVCheckpointBytes = 0u;
    std::size_t humanMatterMujocoCheckpointElements = 0u;
    std::size_t humanMatterMujocoCheckpointBytes = 0u;
    std::size_t humanMatterSourceFactorElements = 0u;
    std::size_t humanMatterSourceFactorBytes = 0u;
    std::size_t humanMatterOwnerStatusElements = 0u;
    std::size_t humanMatterOwnerStatusBytes = 0u;
    std::size_t humanMatterCandidatePointElements = 0u;
    std::size_t humanMatterCandidatePointBytes = 0u;
    std::size_t humanMatterCandidateBodyPoseElements = 0u;
    std::size_t humanMatterCandidateBodyPoseBytes = 0u;
    std::size_t humanMatterCandidatePointWorldElements = 0u;
    std::size_t humanMatterCandidatePointWorldBytes = 0u;
    std::size_t humanMatterCandidatePointJacobianElements = 0u;
    std::size_t humanMatterCandidatePointJacobianBytes = 0u;
    std::size_t humanMatterCandidateOperatorScratchElements = 0u;
    std::size_t humanMatterCandidateOperatorScratchBytes = 0u;
    std::size_t humanMatterCandidateOperatorStatusElements = 0u;
    std::size_t humanMatterCandidateOperatorStatusBytes = 0u;
    std::size_t humanMatterProposalElements = 0u;
    std::size_t humanMatterProposalBytes = 0u;
    std::size_t humanMatterProposedTokenElements = 0u;
    std::size_t humanMatterProposedTokenBytes = 0u;
    std::size_t humanMatterApplyActionElements = 0u;
    std::size_t humanMatterApplyActionBytes = 0u;
    std::size_t humanMatterAppliedOutcomeElements = 0u;
    std::size_t humanMatterAppliedOutcomeBytes = 0u;
    std::size_t humanMatterFinalAcceptedTokenElements = 0u;
    std::size_t humanMatterFinalAcceptedTokenBytes = 0u;
    std::size_t humanMatterPublicationFenceElements = 0u;
    std::size_t humanMatterPublicationFenceBytes = 0u;
    // Includes immutable model buffers and one-element placeholders required
    // to bind logically empty Metal buffers.
    std::size_t totalAllocatedBytes = 0u;
    // Tail-added with borrowed-pass v7; one immutable [environment][3*nv]
    // source-dynamics record owned by the Human transaction.
    std::size_t humanMatterSourceDynamicsWitnessElements = 0u;
    std::size_t humanMatterSourceDynamicsWitnessBytes = 0u;
};

struct MetalArticulatedOperatorResult {
    MetalArticulatedOperatorLayout layout{};
    std::vector<MRArticulatedBodyPoseGPU> bodyPoses;
    std::vector<MRArticulatedPointWorldGPU> pointWorld;
    // Present for explicit paired evaluation or a Stand horizon. These are the
    // evaluated root coordinates and companions to body/point highs. Read-only
    // evaluation preserves the input root records exactly.
    std::vector<MRCompensatedRootTranslationGPU> rootTranslations;
    std::vector<mr_float4> bodyPositionLow;
    std::vector<mr_float4> pointPositionLow;
    std::vector<float> diagnosticMassMatrix;
    std::vector<float> pointJacobians;
    // Non-committing current-pose support-geometry capture. These are the
    // callback-updated contact rows; pointWorld/pointPositionLow/pointJacobians
    // above contain the matching point-query rows. Empty for ordinary runs.
    std::vector<MRNumiHumanStandContactGPU> supportGeometryContacts;
    std::vector<float> generalizedImpulse;
    std::vector<float> deltaVelocity;
    std::vector<MRArticulatedOperatorStatusGPU> statuses;
    std::vector<MRMillardMuscleResultGPU> millardResults;
    std::vector<float> millardGeneralizedForces;
    std::vector<MRMujocoMuscleResultGPU> mujocoResults;
    // Device-published activation sidecar after the optional explicit step.
    // Excitation is preserved; invalid reference records retain their prior
    // state so a caller can decide whether to retry or reject the transaction.
    std::vector<MRMujocoMuscleStateGPU> mujocoActivationStates;
    // Device-produced [environment][muscle][dof] source contributions and
    // their deterministic [environment][dof] reduction.
    std::vector<float> mujocoMuscleGeneralizedForces;
    std::vector<float> mujocoGeneralizedForces;
    // Final device state and cumulative horizon diagnostics. Empty for the
    // historical one-pass operator path.
    std::vector<float> standQ;
    std::vector<MRCompensatedRootTranslationGPU> standRootTranslations;
    std::vector<float> standV;
    std::vector<MRNumiHumanStandStatusGPU> standStatuses;
    // Final accepted step's exact endpoint-to-node transaction and its
    // wrench-equivalence diagnostic. Earlier steps remain device-resident and
    // are available to an optional per-step borrowed consumer.
    std::vector<MRNumiHumanTendonTransferResultGPU> standTendonTransfers;
    std::vector<float> standTendonGeneralizedCorrections;
    // Optional final accepted step only, environment-major. Contacts use
    // [normal, tangent0, tangent1] in the Stand kernel's pre-step basis;
    // equalities include reactions induced by source limits. Derivatives are
    // the exact native pre-step linearization. pointJacobians/MyoSim forces
    // likewise describe that step's pre-dynamics evaluation, not terminal q.
    // The optional direct source-limit multipliers are signed generalized
    // impulses indexed by DOF. Equality reactions induced by limits remain
    // in standJointEqualityImpulses and are not folded into this array.
    std::vector<float> standContactImpulses;
    // Present only for an accepted per-contact-plane stand result with
    // constraint diagnostics enabled. Aligned with standContactImpulses by
    // source contact index; these are the exact GPU-written world normals
    // used to interpret [normal, tangent0, tangent1] impulse components.
    std::vector<mr_float4> standContactPlaneNormals;
    std::vector<float> standJointEqualityImpulses;
    std::vector<float> standSourceLimitImpulses;
    std::vector<float> standJointEqualityDerivatives;
    std::vector<float> standFreeVelocity;
    std::vector<float> standPreviousVelocity;
    // Optional accepted-step state after integration and coupled constraint
    // sweeps, immediately before exact equality coordinate projection.
    std::vector<float> standPreProjectionQ;
    std::vector<float> standPreProjectionV;
    // Accepted bounded-Q observer only. Raw body-kinetic mass rows are
    // [root x/y/z][local velocity DOF], before effective diagonal terms and
    // factorization. Momentum stages are [free xyz, post-coupled-sweep xyz],
    // both evaluated at the same pre-step q. Empty outside captured steps.
    std::vector<float> standBodyKineticRootMassRows;
    std::vector<float> standBodyKineticRootMomentumStages;
};

struct MetalArticulatedOperatorDiagnostics {
    MetalArticulatedOperatorHostStatus status =
        MetalArticulatedOperatorHostStatus::success;
    MetalArticulatedOperatorLayout layout{};
    bool dispatched = false;
    bool published = false;
    // Pipeline specialization and per-submission use of exact canonical body
    // probe fusion. The dispatch flag is the device-side usage identity.
    bool canonicalBodyProbeFusionPipelineEnabled = false;
    bool canonicalBodyProbeFusionUsed = false;
    std::uint32_t successfulEnvironmentCount = 0u;
    std::uint32_t failedEnvironmentCount = 0u;
    std::uint32_t firstFailingEnvironment = MR_INVALID_INDEX;
    std::uint32_t firstGPUStatusCode =
        MR_ARTICULATED_OPERATOR_SUCCESS;
    std::uint32_t completedStandSteps = 0u;
    std::uint32_t firstStandGPUStatusCode =
        MR_NUMI_HUMAN_STAND_SUCCESS;
    float speculativeContactAdmissionOverrideRequestedMeters = 0.0f;
    float speculativeContactAdmissionEffectiveMaximumMeters = 0.0f;
    // Exact owning command-buffer and external-program identities. Downstream
    // candidate publishers must match both before accepting a zero-copy view.
    std::uint64_t numanXProgramFingerprint = 0u;
    std::uintptr_t commandBufferIdentity = 0u;
    double elapsedMilliseconds = 0.0;
    // Present when an opted-in legacy accepted root was published. These
    // values are the only authorization for the next resident continuation.
    std::uint64_t residentStateTransactionFingerprint = 0u;
    std::uint64_t residentStateGeneration = 0u;
    // Optional timings for a completed submission. GPU time excludes queue
    // scheduling and host copies; a zero value means Metal did not report it.
    double gpuMilliseconds = 0.0;
    double hostWaitMilliseconds = 0.0;
    double hostCopyMilliseconds = 0.0;
    std::string deviceName;
    std::string message;

    [[nodiscard]] bool succeeded() const noexcept {
        return status == MetalArticulatedOperatorHostStatus::success;
    }
};

// Lifetime counters for a reusable operator context. retainedBufferBytes is
// the physical capacity of the grow-only Metal buffer arena; an individual
// result layout continues to report only that batch's required bytes.
struct MetalArticulatedOperatorContextStats {
    std::uint64_t pipelineCreationCount = 0u;
    std::uint64_t bufferAllocationCount = 0u;
    std::uint64_t bufferGrowthCount = 0u;
    std::uint64_t submissionCount = 0u;
    // Submissions that consumed q/v/MyoSim directly from the exact preceding
    // published root instead of uploading a host reset image.
    std::uint64_t residentContinuationSubmissionCount = 0u;
    std::uint64_t completedSubmissionCount = 0u;
    // Destruction fallback waits only while Metal still reports nonterminal
    // work. Prepared ACCEPT/REJECT and late terminal cleanup increment the
    // nonwaiting counter instead.
    std::uint64_t submissionDestructorWaitCount = 0u;
    std::uint64_t terminalSubmissionNonwaitingReapCount = 0u;
    std::size_t retainedBufferBytes = 0u;
    bool hasInFlightSubmission = false;
};

inline constexpr std::uint32_t
    kMetalArticulatedOperatorPhysicalStateObserverABIVersion = 1u;

// Borrowed, read-only view of the exact Human state at a released accepted
// root. The callback may encode reads of these four authoritative arenas onto
// commandBuffer and may write only caller-owned diagnostic output. It must not
// mutate, retain, replace, commit, or wait for any borrowed object. Poses,
// contacts, forces, statuses, and other derived state are intentionally absent.
struct MetalArticulatedOperatorPhysicalStateObserverPass {
    std::uint32_t abiVersion =
        kMetalArticulatedOperatorPhysicalStateObserverABIVersion;
    std::uint32_t structSize =
        sizeof(MetalArticulatedOperatorPhysicalStateObserverPass);
    std::uint32_t environmentCount = 0u;
    std::uint32_t reserved0 = 0u;

    void* commandBuffer = nullptr;
    void* rootTranslations = nullptr;
    void* q = nullptr;
    void* v = nullptr;
    void* mujocoStates = nullptr;

    std::uint64_t rootTranslationsGPUAddress = 0u;
    std::uint64_t qGPUAddress = 0u;
    std::uint64_t vGPUAddress = 0u;
    std::uint64_t mujocoStatesGPUAddress = 0u;

    std::uint64_t rootTranslationElementCount = 0u;
    std::uint64_t qElementCount = 0u;
    std::uint64_t vElementCount = 0u;
    std::uint64_t mujocoStateElementCount = 0u;

    std::uint32_t rootTranslationStride = 0u;
    std::uint32_t qStride = 0u;
    std::uint32_t vStride = 0u;
    std::uint32_t mujocoStateStride = 0u;

    // Identity of the accepted root whose exact bytes are being observed.
    std::uint64_t transactionFingerprint = 0u;
    std::uint64_t physicsGeneration = 0u;
    std::uint64_t acceptedTokenFingerprint = 0u;
};

using MetalArticulatedOperatorEncodePhysicalStateObserver = bool (*)(
    void* context,
    const MetalArticulatedOperatorPhysicalStateObserverPass& pass
) noexcept;

class MetalArticulatedOperatorContext;

// A committed Metal batch. submit() copies all caller-owned spans before
// returning, so their storage can immediately be reused. wait() may be called
// once and transactionally publishes the completed typed result. Destroying a
// live submission waits for the GPU and discards its result, making context
// and submission destruction safe in either order.
class MetalArticulatedOperatorSubmission {
public:
    MetalArticulatedOperatorSubmission() noexcept;
    ~MetalArticulatedOperatorSubmission();

    MetalArticulatedOperatorSubmission(
        MetalArticulatedOperatorSubmission&& other
    ) noexcept;
    MetalArticulatedOperatorSubmission& operator=(
        MetalArticulatedOperatorSubmission&& other
    ) noexcept;

    MetalArticulatedOperatorSubmission(
        const MetalArticulatedOperatorSubmission&
    ) = delete;
    MetalArticulatedOperatorSubmission& operator=(
        const MetalArticulatedOperatorSubmission&
    ) = delete;

    [[nodiscard]] bool valid() const noexcept;

    // Transfers this submission into the prepared capability without waiting
    // on the first command buffer. On success this submission becomes empty;
    // the capability (and the final-CB completion handler) jointly own the
    // submission until the event-ordered final command completes.
    [[nodiscard]] bool extractPreparedHumanMatter(
        MetalNumanXHumanMatterPrepared& output
    ) noexcept;

    [[nodiscard]] MetalArticulatedOperatorDiagnostics wait(
        MetalArticulatedOperatorResult& result
    );

private:
    friend class MetalArticulatedOperatorContext;
    std::unique_ptr<
        detail::MetalArticulatedOperatorSubmissionState
    > state_;
};

// Reusable execution context for steady-state simulation. Device discovery,
// metallib loading, command-queue creation, and pipeline compilation happen at
// most once. Its fixed-binding buffer arena is reused and grows geometrically as batch
// sizes increase. Calls are thread-safe, but a context deliberately admits
// only one in-flight submission because every batch shares the same arena;
// independent contexts provide safe overlap when multiple queues are useful.
class MetalArticulatedOperatorContext {
public:
    // Completes caller-owned neural shadow work after one accepted standing
    // step on this SAME physical owner's queue. The callback receives only the
    // borrowed command buffer, writes no physical state, and cannot submit/wait.
    // Failure terminally closes this context; it never rewrites physical success
    // as joint acceptance. GPU times are from the actual completion command.
    [[nodiscard]] bool finishStandController(
        const MetalArticulatedOperatorDiagnostics& accepted,
        void* context, bool (*encode)(void*, void*) noexcept,
        double& gpuStartSeconds, double& gpuEndSeconds, std::string& error);

    // Explicit quiescent collection on the original owner queue; no physical
    // dispatch or clock advance. Callback writes only its diagnostic buffers.
    [[nodiscard]] bool flushReadOnlyObserver(void* context,
        bool (*encode)(void*,void*) noexcept, std::string& error);

    // Encodes one read-only observation on the owner queue and waits for its
    // completion. This succeeds only after a released accepted Human root
    // (Matter-owned or opted-in legacy Stand) has been published.
    [[nodiscard]] bool flushPhysicalStateObserver(
        void* context,
        MetalArticulatedOperatorEncodePhysicalStateObserver encode,
        std::string& error
    );

    explicit MetalArticulatedOperatorContext(
        MetalArticulatedOperatorConfig config = {}
    );
    ~MetalArticulatedOperatorContext();

    MetalArticulatedOperatorContext(
        MetalArticulatedOperatorContext&& other
    ) noexcept;
    MetalArticulatedOperatorContext& operator=(
        MetalArticulatedOperatorContext&& other
    ) noexcept;

    MetalArticulatedOperatorContext(
        const MetalArticulatedOperatorContext&
    ) = delete;
    MetalArticulatedOperatorContext& operator=(
        const MetalArticulatedOperatorContext&
    ) = delete;

    // Encodes and commits without waiting for GPU completion. Host validation,
    // capacity growth, and all input copies are complete before this returns.
    // submission must be empty and remains unchanged on rejection.
    [[nodiscard]] MetalArticulatedOperatorDiagnostics submit(
        const EngineModel& model,
        const MetalArticulatedOperatorInput& input,
        MetalArticulatedOperatorSubmission& submission
    );

    // Convenience synchronous path using submit() followed by wait().
    [[nodiscard]] MetalArticulatedOperatorDiagnostics run(
        const EngineModel& model,
        const MetalArticulatedOperatorInput& input,
        MetalArticulatedOperatorResult& result
    );

    [[nodiscard]] MetalArticulatedOperatorContextStats stats()
        const noexcept;

    // Copies only the accepted contact-history records, excluding transient
    // request identities. Requires a quiescent context and is intended for
    // transaction diagnostics.
    [[nodiscard]] bool copyStandContactWarmStartHistoryForDiagnostics(
        std::vector<std::uint8_t>& acceptedRecords,
        std::string& error
    ) const;

private:
    std::shared_ptr<
        detail::MetalArticulatedOperatorContextState
    > state_;
};

// Executes one synchronous command buffer. The EngineModel and every layout,
// span, query, required element count, byte count, Metal allocation, and
// pipeline capability are checked before encoding. The raw kernel binding
// table remains private to the Objective-C++ implementation.
//
// Host-side failure leaves result bit-for-bit unchanged. Once a command
// completes, the entire typed batch and its per-environment GPU statuses are
// published together. A GPU environment failure therefore returns
// gpuEnvironmentFailure with published=true so the status stream remains
// inspectable; failed environments have zeroed payload slots.
[[nodiscard]] MetalArticulatedOperatorDiagnostics
runMetalArticulatedOperator(
    const EngineModel& model,
    const MetalArticulatedOperatorInput& input,
    MetalArticulatedOperatorResult& result,
    const MetalArticulatedOperatorConfig& config = {}
);

[[nodiscard]] const char* metalArticulatedOperatorHostStatusName(
    MetalArticulatedOperatorHostStatus status
) noexcept;

} // namespace metalrobo

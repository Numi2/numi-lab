#import <Foundation/Foundation.h>
#import <Metal/Metal.h>
#include "numi/matter/matter.hpp"
#include "metalrobo/engine_types.h"
#include "cardiac_material_reference.hpp"
#include "../src/fem_reference_geometry.hpp"
#include <algorithm>
#include <bit>
#include <cstring>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <limits>
#include <sstream>

// Synthetic conforming two-tet explicit-reference constitutive/transaction fixture.
// The Guccione and neo-Hookean energies are sourced; these densities, geometry,
// loading, state/rate laws and learned networks are numerical controls. This
// does not supply anatomical density or a source-calibrated cardiac wall.
namespace {
constexpr unsigned kBacktrackingFixtureElementCount = 521u;
using namespace numi::matter;
namespace ref=numi_cardiac_reference;
using ref::Matrix;
using Vec=std::array<double,3>;
void need(bool ok,const std::string& message){if(!ok)throw std::runtime_error(message);}
std::string number(double x){std::ostringstream s;s<<std::setprecision(17)<<x;return s.str();}
std::string diagnostic(const std::vector<Diagnostic>& values){std::string out;for(const auto& v:values)out+=v.message+"; ";return out;}
template<class T> bool same(const std::vector<T>& a,const std::vector<T>& b){return a.size()==b.size()&&(a.empty()||std::memcmp(a.data(),b.data(),a.size()*sizeof(T))==0);}
template<class T> std::vector<T> repeat(const std::vector<T>& a,unsigned count=2){std::vector<T> out;for(unsigned i=0;i<count;++i)out.insert(out.end(),a.begin(),a.end());return out;}
template<class T> void paired(const std::vector<T>& a,const char* label){need(a.size()%2==0,std::string(label)+" arity");const auto n=a.size()/2;need(!n||std::memcmp(a.data(),a.data()+n,n*sizeof(T))==0,std::string(label)+" paired environments differ");}
template<class T> void envSame(const std::vector<T>& a,const std::vector<T>& b,unsigned e,const char* label){need(a.size()==b.size()&&a.size()%2==0,std::string(label)+" arity");const auto n=a.size()/2;need(!n||std::memcmp(a.data()+e*n,b.data()+e*n,n*sizeof(T))==0,std::string(label)+" isolated transaction changed state");}
template<class T> id<MTLBuffer> buffer(id<MTLDevice> d,const std::vector<T>& input){const T zero{};return [d newBufferWithBytes:(input.empty()?&zero:input.data()) length:std::max(std::size_t(1),input.size())*sizeof(T) options:MTLResourceStorageModeShared];}
Vec xyz(const nm_float4& a){return {a.x,a.y,a.z};}
Vec sub(Vec a,const Vec& b){for(unsigned i=0;i<3;++i)a[i]-=b[i];return a;}
Vec transform(const Matrix& a,const Vec& b){Vec c{};for(unsigned i=0;i<3;++i)for(unsigned j=0;j<3;++j)c[i]+=a[3*i+j]*b[j];return c;}
double dot(const Vec& a,const Vec& b){return a[0]*b[0]+a[1]*b[1]+a[2]*b[2];}
Matrix outer(const Vec& a,const Vec& b){Matrix c{};for(unsigned i=0;i<3;++i)for(unsigned j=0;j<3;++j)c[3*i+j]=a[i]*b[j];return c;}
Matrix columns(const Vec& a,const Vec& b,const Vec& c){return {a[0],b[0],c[0],a[1],b[1],c[1],a[2],b[2],c[2]};}
Matrix inverseRest(const NMTetrahedronGPU& t){return {t.inverseRestRow0.x,t.inverseRestRow0.y,t.inverseRestRow0.z,t.inverseRestRow1.x,t.inverseRestRow1.y,t.inverseRestRow1.z,t.inverseRestRow2.x,t.inverseRestRow2.y,t.inverseRestRow2.z};}
Matrix frame(const nm_float4& raw){
    const double inv=1/std::sqrt(double(raw.x)*raw.x+double(raw.y)*raw.y+double(raw.z)*raw.z+double(raw.w)*raw.w);
    const double x=raw.x*inv,y=raw.y*inv,z=raw.z*inv,w=raw.w*inv;
    return {1-2*(y*y+z*z),2*(x*y-z*w),2*(x*z+y*w),2*(x*y+z*w),1-2*(x*x+z*z),2*(y*z-x*w),2*(x*z-y*w),2*(y*z+x*w),1-2*(x*x+y*y)};
}
void set(MaterialProgram& m,const std::string& name,double value){for(auto& p:m.parameters)if(p.name==name){p.defaultValue=value;return;}throw std::runtime_error("missing "+name);}
WorldSource source(const MaterialProgram& first,const MaterialProgram& second,bool combined=false){
    WorldSource s;s.environmentCount=2;s.gravity={0,0,0};s.frameTimestep=1e-4;
    s.materials={first,second};s.mixedSolver.relativeResidual=1e-7;s.mixedSolver.newtonIterations=12;s.mixedSolver.fgmresIterations=64;
    ObjectSource o;o.name="synthetic_independently_authored_reference";o.representation=Representation::fem;o.mixedFEM=false;
    o.deformableContact=false;o.deformableSelfContact=false;o.characteristicLength=.015625;
    constexpr double l=.015625;
    o.femReferenceNodes={{{0,0,0}},{{l,0,0}},{{0,l,0}},{{0,0,l}},{{0,0,-l}}};
    // Exact binary affine preload, independent of the material parser and
    // cooker. It is supplied data, not an inverse unloading algorithm.
    const Matrix f{1.015625,.0078125,0,0,1,0,0,0,1};const Vec translation{.03125,-.015625,.0078125};
    for(const auto& x:o.femReferenceNodes){auto p=transform(f,x);for(unsigned j=0;j<3;++j)p[j]+=translation[j];o.femNodes.push_back(p);}
    o.tetrahedra={{{0,1,2,3}},{{0,2,1,4}}};o.femFixedNodes={0,1,2};
    o.femReferenceSourceIdentity={0x29595b22aedcde73ull,0x6f1d688db49d2714ull,0x6eed2d5d77f3dbd6ull,0x6f9ec94305b73627ull};
    if(combined){o.femMaterialIndices={0,1};o.femMaterialSourceIdentity={1,2,3,4};
        o.femMaterialFrameRotations={{{0,0,std::sin(.305),std::cos(.305)}},{{0,std::sin(-.245),0,std::cos(-.245)}}};
        o.femMaterialFrameSourceIdentity={5,6,7,8};}
    s.objects={o};return s;
}
WorldSource thinSkewSource(const WorldSource& regionalReference,bool displacementGradient){
    auto s=regionalReference;auto& o=s.objects[0];
    const Vec origin{.04127,-.02863,.05219};
    const Vec a{.00421,.00037,0.0},b{.00113,.00273,0.0},c{.00014,.00009,.0000307};
    const auto point=[&](const Vec& delta){return Vec{origin[0]+delta[0],origin[1]+delta[1],origin[2]+delta[2]};};
    o.femReferenceNodes={origin,point(a),point(b),point(c),point(Vec{-c[0],-c[1],-c[2]})};
    o.femNodes=o.femReferenceNodes;o.femReferenceDisplacementGradient=displacementGradient;
    o.femReferenceSourceIdentity={0x9a831c5a8f0b6d11ull,0x672ef91a1b094ed3ull,
        0xbb857ac30216de44ull,0x5f1ce8a773b20d96ull};
    return s;
}
CompiledWorld cook(const WorldSource& s){auto c=compileWorld(s,{.maximumRateExponent=0,.emitSpecializedMetal=false});need(c.succeeded(),"reference fixture compile: "+diagnostic(c.diagnostics));return std::move(c.world);}
void smallCellScaleChecks(const WorldSource& baseline){
    for(const double length:{1.0,1.0e-3,1.0e-5,2.0e-6}){
        auto s=baseline;auto& o=s.objects.front();
        o.femReferenceNodes={{{0,0,0}},{{length,0,0}},{{0,length,0}},
            {{0,0,length}},{{0,0,-length}}};
        o.femNodes=o.femReferenceNodes;o.femReferenceDisplacementGradient=true;
        const auto world=cook(s);need(world.fem.tetrahedra.size()==2u,"small-cell scale element count");
        for(std::size_t ti=0;ti<world.fem.tetrahedra.size();++ti){
            const auto& tet=world.fem.tetrahedra[ti];const auto inv=inverseRest(tet);
            const Matrix expected=ti==0u?Matrix{1,0,0,0,1,0,0,0,1}:Matrix{0,1,0,1,0,0,0,0,-1};
            for(unsigned entry=0;entry<9u;++entry)
                need(std::abs(inv[entry]*length-expected[entry])<2.0e-7,
                    "small-cell normalized inverse changed with scale");
            need(std::isfinite(tet.inverseRestRow0.w)&&tet.inverseRestRow0.w>0.0f,
                "small-cell physical volume is not representable");
        }
        auto inverted=s;std::swap(inverted.objects[0].tetrahedra[0].nodes[0],inverted.objects[0].tetrahedra[0].nodes[1]);
        need(!compileWorld(inverted,{.maximumRateExponent=0,.emitSpecializedMetal=false}).succeeded(),
            "small-cell scale check admitted an inverted tetrahedron");
        auto singular=s;singular.objects[0].femReferenceNodes[3]=singular.objects[0].femReferenceNodes[0];
        singular.objects[0].femNodes=singular.objects[0].femReferenceNodes;
        need(!compileWorld(singular,{.maximumRateExponent=0,.emitSpecializedMetal=false}).succeeded(),
            "small-cell scale check admitted a singular tetrahedron");
    }
    auto belowVolume=baseline;auto& o=belowVolume.objects.front();
    for(auto& x:o.femReferenceNodes)for(auto& component:x)component*=1.0e-5;
    o.femNodes=o.femReferenceNodes;o.femReferenceDisplacementGradient=true;
    need(!compileWorld(belowVolume,{.maximumRateExponent=0,.emitSpecializedMetal=false}).succeeded(),
        "small-cell scale check weakened the physical volume floor");
    std::cout<<"reference_small_cell_scale=PASS scales=4 inverted=REJECT singular=REJECT physical_volume_floor=unchanged\n";
}
struct Device {
    id<MTLDevice> device;id<MTLCommandQueue> queue;id<MTLLibrary> library;
    id<MTLComputePipelineState> forcePipeline,operatorPipeline,backtrackingPipeline;
    id<MTLComputePipelineState> parallelBacktrackingInitializePipeline;
    id<MTLComputePipelineState> parallelBacktrackingTilesPipeline;
    id<MTLComputePipelineState> parallelBacktrackingFinalizePipeline;
    id<MTLComputePipelineState> parallelBacktrackingPreparePipeline;
    Device(){device=MTLCreateSystemDefaultDevice();need(device!=nil,"Metal unavailable");
        need([[device name] rangeOfString:@"Apple"].location!=NSNotFound&&[[device name] rangeOfString:@"Paravirtual"].location==NSNotFound,"physical Apple Metal required");
        queue=[device newCommandQueue];NSError* error=nil;
        library=[device newLibraryWithURL:[NSURL fileURLWithPath:[NSString stringWithUTF8String:NUMI_MATTER_METALLIB]] error:&error];need(library!=nil,"production Matter metallib unavailable");
        forcePipeline=make(@"numi_matter_metal::nm_fem_internal_forces");operatorPipeline=make(@"numi_matter_metal::nm_fem_apply_operator_elements");
        backtrackingPipeline=make(@"numi_matter_metal::nm_fem_select_backtracking");
        parallelBacktrackingInitializePipeline=make(
            @"numi_matter_metal::nm_fem_parallel_backtracking_initialize");
        parallelBacktrackingTilesPipeline=make(
            @"numi_matter_metal::nm_fem_parallel_backtracking_tiles");
        parallelBacktrackingFinalizePipeline=make(
            @"numi_matter_metal::nm_fem_parallel_backtracking_finalize");
        parallelBacktrackingPreparePipeline=make(
            @"numi_matter_metal::nm_fem_parallel_backtracking_prepare_remaining");}
    id<MTLComputePipelineState> make(NSString* name){NSError* error=nil;MTLFunctionConstantValues* constants=[MTLFunctionConstantValues new];const BOOL disabled=NO;[constants setConstantValue:&disabled type:MTLDataTypeBool atIndex:34u];auto f=[library newFunctionWithName:name constantValues:constants error:&error];need(f!=nil,"production FEM function missing");auto p=[device newComputePipelineStateWithFunction:f error:&error];need(p!=nil,"production FEM pipeline failed");return p;}
};
struct BacktrackingResult { float alpha;float minimumJ;float trials;std::uint32_t status;std::uint32_t skippedTetTrials;std::uint32_t laterTileGroups; };
BacktrackingResult selectBacktracking(Device& d,bool invalidNonLeader,bool fixedNode,
    bool displacementGradient=false,bool enableCollapse=false,bool completedLatch=false,
    bool forceVolumeFallback=false,bool parallelTiles=false,
    unsigned invalidElementIndex=57u,bool exhaustTrials=false){
    constexpr unsigned elementCount=kBacktrackingFixtureElementCount;
    constexpr unsigned nodesPerElement=4u;
    NMMatterDispatchGPU dispatch{};dispatch.environmentCount=1u;dispatch.objectCount=1u;
    dispatch.femNodeCount=elementCount*nodesPerElement;dispatch.tetrahedronCount=elementCount;
    dispatch.gravityAndTimestep.w=1.0f;dispatch.numericalLimits.z=0.35f;
    NMMicrostepGPU microstep{};microstep.time.y=1.0f;
    NMMixedSolverGPU solver{};solver.nonlinearIterations.w=2u;
    solver.residualTolerances.y=1.0e-8f;
    if(forceVolumeFallback)solver.globalization.x=0.5f;
    NMContinuumObjectGPU object{};object.representation=NM_REPRESENTATION_FEM;
    object.flags=NM_OBJECT_ACTIVE;object.elementCount=elementCount;object.solver.y=0u;
    if(forceVolumeFallback){object.flags|=NM_OBJECT_MIXED_FEM;dispatch.mixedMaterialCount=1u;}
    NMMaterialGPU material{};material.validity={0.35f,2.0f,1.0e30f,1.0e30f};
    NMMixedMaterialGPU mixedMaterial{};mixedMaterial.mechanics={1.0f,0.0f,0.0f,0.0f};
    NMFGMRESStateGPU fgmresState{};fgmresState.nonlinear.w=completedLatch?1.0f:0.0f;
    NMSchedulerStateGPU scheduler{};scheduler.numerical.w=1.0f;
    NMAdaptiveStateGPU adaptive{};adaptive.activeRepresentation=NM_REPRESENTATION_FEM;
    std::vector<NMFEMNodeStateGPU> accepted(dispatch.femNodeCount),candidate(dispatch.femNodeCount);
    std::vector<nm_float4> correction(2u*dispatch.femNodeCount,nm_float4{});
    std::vector<NMTetrahedronGPU> tetrahedra(elementCount);
    for(unsigned element=0;element<elementCount;++element){
        const unsigned base=nodesPerElement*element;
        const nm_float4 positions[4]={{0,0,0,1},{1,0,0,1},{0,1,0,1},{0,0,1,1}};
        for(unsigned slot=0;slot<nodesPerElement;++slot){
            auto& node=accepted[base+slot];node.positionAndMass=positions[slot];
            node.restAndFixed=positions[slot];node.restAndFixed.w=0.0f;node.velocityAndInverseMass.w=1.0f;
            node.referenceDisplacementAndMode.w=displacementGradient?1.0f:0.0f;
            candidate[base+slot]=node;
        }
        auto& tet=tetrahedra[element];tet.nodes={base,base+1u,base+2u,base+3u};
        tet.inverseRestRow0={1,0,0,1.0f/6.0f};tet.inverseRestRow1={0,1,0,0};tet.inverseRestRow2={0,0,1,0};
        tet.identity={0u,0u,0u,NM_OBJECT_ACTIVE};
        if(displacementGradient)tet.identity.w|=NM_TETRAHEDRON_REFERENCE_DISPLACEMENT_GRADIENT;
    }
    if(invalidNonLeader){
        // Only the tet on SIMD lane 57 becomes inadmissible at alpha=1:
        // J=0.3139282, while alpha=0.5 gives J=0.6569641.
        const unsigned invalidElement = std::min(
            invalidElementIndex, elementCount - 1u);
        correction[nodesPerElement*invalidElement+1u].x =
            exhaustTrials ? -2.0f : -0.6860718f;
    }
    if(fixedNode){
        // A threatening correction must not move an authored fixed node.
        accepted[1].restAndFixed.w=1.0f;candidate[1]=accepted[1];correction[1].x=-0.9f;
    }
    std::vector<NMMatterStatusGPU> status(1);
    std::vector<nm_float4> lineSearch(1);
    std::vector<std::uint32_t> skippedTetTrials(1,0u);
    std::vector<NMFEMFieldStateGPU> fieldStates(dispatch.femNodeCount);
    if(forceVolumeFallback)for(auto& field:fieldStates)field.primary.x=1.0f;
    const auto objects=buffer(d.device,std::vector<NMContinuumObjectGPU>{object});
    const auto materials=buffer(d.device,std::vector<NMMaterialGPU>{material});
    const auto acceptedBuffer=buffer(d.device,accepted),candidateBuffer=buffer(d.device,candidate);
    const auto correctionBuffer=buffer(d.device,correction),tetrahedronBuffer=buffer(d.device,tetrahedra);
    const auto schedulerBuffer=buffer(d.device,std::vector<NMSchedulerStateGPU>{scheduler});
    const auto adaptiveBuffer=buffer(d.device,std::vector<NMAdaptiveStateGPU>{adaptive});
    const auto lineSearchBuffer=buffer(d.device,lineSearch),statusBuffer=buffer(d.device,status);
    const auto mixedBuffer=buffer(d.device,std::vector<NMMixedMaterialGPU>{mixedMaterial});
    const auto fieldBuffer=buffer(d.device,fieldStates);
    const auto fgmresStateBuffer=buffer(d.device,std::vector<NMFGMRESStateGPU>{fgmresState});
    const std::uint32_t collapseEnabled=enableCollapse?1u:0u;
    const auto collapseFlagBuffer=buffer(d.device,std::vector<std::uint32_t>{collapseEnabled});
    const auto skippedTetTrialsBuffer=buffer(d.device,skippedTetTrials);
    const std::uint32_t maximumTiles =
        (elementCount + 255u) / 256u;
    const std::size_t partialCount =
        std::size_t(NM_MIXED_LINE_SEARCH_MAX_STEPS) * maximumTiles;
    std::vector<nm_float4> compactPartials(partialCount + 4u);
    for (std::size_t i = partialCount; i < compactPartials.size(); ++i)
        compactPartials[i] = {777.0f, 778.0f, 779.0f, 780.0f};
    const auto parallelPartialsBuffer=buffer(d.device, compactPartials);
    const auto parallelAcceptedBuffer=buffer(
        d.device,std::vector<std::uint32_t>(1u,0u));
    const auto parallelIndirectBuffer=buffer(
        d.device,std::vector<NMIndirectDispatchGPU>{{0u,1u,1u,0u}});
    const auto emptyPrograms = buffer(
        d.device, std::vector<NMScalarProgramGPU>(1u));
    const auto emptyInstructions = buffer(
        d.device, std::vector<NMExpressionInstructionGPU>(1u));
    const auto emptyParameters = buffer(d.device, std::vector<float>(1u));
    const auto emptyMaterialState = buffer(d.device, std::vector<float>(1u));
    const std::uint32_t validateConstitutiveStress = 0u;
    auto command=[d.queue commandBuffer];auto encoder=[command computeCommandEncoder];
    if(parallelTiles){
        [encoder setComputePipelineState:d.parallelBacktrackingInitializePipeline];
        [encoder setBytes:&dispatch length:sizeof(dispatch) atIndex:0];
        [encoder setBuffer:objects offset:0 atIndex:1];
        [encoder setBuffer:lineSearchBuffer offset:0 atIndex:2];
        [encoder setBuffer:parallelAcceptedBuffer offset:0 atIndex:3];
        [encoder dispatchThreadgroups:MTLSizeMake(1,1,1)
            threadsPerThreadgroup:MTLSizeMake(32,1,1)];
        [encoder memoryBarrierWithScope:MTLBarrierScopeBuffers];

        const auto bindTiles=[&](const unsigned trialStart,const unsigned trialCount){
            [encoder setBytes:&dispatch length:sizeof(dispatch) atIndex:0];
            [encoder setBytes:&microstep length:sizeof(microstep) atIndex:1];
            [encoder setBytes:&solver length:sizeof(solver) atIndex:2];
            [encoder setBuffer:objects offset:0 atIndex:3];
            [encoder setBuffer:materials offset:0 atIndex:4];
            [encoder setBuffer:acceptedBuffer offset:0 atIndex:5];
            [encoder setBuffer:candidateBuffer offset:0 atIndex:6];
            [encoder setBuffer:correctionBuffer offset:0 atIndex:7];
            [encoder setBuffer:tetrahedronBuffer offset:0 atIndex:8];
            [encoder setBuffer:schedulerBuffer offset:0 atIndex:9];
            [encoder setBuffer:adaptiveBuffer offset:0 atIndex:10];
            [encoder setBuffer:statusBuffer offset:0 atIndex:11];
            [encoder setBuffer:parallelPartialsBuffer offset:0 atIndex:12];
            [encoder setBytes:&maximumTiles length:sizeof(maximumTiles) atIndex:13];
            [encoder setBuffer:parallelAcceptedBuffer offset:0 atIndex:14];
            [encoder setBytes:&trialStart length:sizeof(trialStart) atIndex:15];
            [encoder setBytes:&trialCount length:sizeof(trialCount) atIndex:16];
            [encoder setBuffer:emptyPrograms offset:0 atIndex:17];
            [encoder setBuffer:emptyInstructions offset:0 atIndex:18];
            [encoder setBuffer:emptyParameters offset:0 atIndex:19];
            [encoder setBytes:&validateConstitutiveStress length:sizeof(validateConstitutiveStress) atIndex:20];
        };
        const auto bindFinalize=[&](const unsigned trialStart,const unsigned trialCount){
            [encoder setBytes:&dispatch length:sizeof(dispatch) atIndex:0];
            [encoder setBytes:&microstep length:sizeof(microstep) atIndex:1];
            [encoder setBytes:&solver length:sizeof(solver) atIndex:2];
            [encoder setBuffer:objects offset:0 atIndex:3];
            [encoder setBuffer:schedulerBuffer offset:0 atIndex:4];
            [encoder setBuffer:adaptiveBuffer offset:0 atIndex:5];
            [encoder setBuffer:statusBuffer offset:0 atIndex:6];
            [encoder setBuffer:lineSearchBuffer offset:0 atIndex:7];
            [encoder setBuffer:parallelPartialsBuffer offset:0 atIndex:8];
            [encoder setBytes:&maximumTiles length:sizeof(maximumTiles) atIndex:9];
            [encoder setBuffer:parallelAcceptedBuffer offset:0 atIndex:10];
            [encoder setBytes:&trialStart length:sizeof(trialStart) atIndex:11];
            [encoder setBytes:&trialCount length:sizeof(trialCount) atIndex:12];
        };
        const unsigned firstStart=0u,firstCount=1u;
        [encoder setComputePipelineState:d.parallelBacktrackingTilesPipeline];
        bindTiles(firstStart,firstCount);
        [encoder dispatchThreadgroups:MTLSizeMake(maximumTiles,1,1)
            threadsPerThreadgroup:MTLSizeMake(256,1,1)];
        [encoder memoryBarrierWithScope:MTLBarrierScopeBuffers];
        [encoder setComputePipelineState:d.parallelBacktrackingFinalizePipeline];
        bindFinalize(firstStart,firstCount);
        [encoder dispatchThreadgroups:MTLSizeMake(1,1,1)
            threadsPerThreadgroup:MTLSizeMake(32,1,1)];
        [encoder memoryBarrierWithScope:MTLBarrierScopeBuffers];

        const unsigned candidateCount=std::min<unsigned>(
            solver.nonlinearIterations.w,NM_MIXED_LINE_SEARCH_MAX_STEPS);
        const unsigned remaining=candidateCount>1u?candidateCount-1u:0u;
        if(remaining>0u){
            [encoder setComputePipelineState:d.parallelBacktrackingPreparePipeline];
            [encoder setBytes:&dispatch length:sizeof(dispatch) atIndex:0];
            [encoder setBytes:&microstep length:sizeof(microstep) atIndex:1];
            [encoder setBytes:&solver length:sizeof(solver) atIndex:2];
            [encoder setBuffer:objects offset:0 atIndex:3];
            [encoder setBuffer:schedulerBuffer offset:0 atIndex:4];
            [encoder setBuffer:adaptiveBuffer offset:0 atIndex:5];
            [encoder setBuffer:statusBuffer offset:0 atIndex:6];
            [encoder setBuffer:parallelAcceptedBuffer offset:0 atIndex:7];
            [encoder setBytes:&maximumTiles length:sizeof(maximumTiles) atIndex:8];
            [encoder setBuffer:parallelIndirectBuffer offset:0 atIndex:9];
            [encoder dispatchThreadgroups:MTLSizeMake(1,1,1)
                threadsPerThreadgroup:MTLSizeMake(32,1,1)];
            [encoder memoryBarrierWithScope:MTLBarrierScopeBuffers];
            [encoder setComputePipelineState:d.parallelBacktrackingTilesPipeline];
            const unsigned laterStart=1u;
            bindTiles(laterStart,remaining);
            [encoder dispatchThreadgroupsWithIndirectBuffer:parallelIndirectBuffer
                indirectBufferOffset:0
                threadsPerThreadgroup:MTLSizeMake(256,1,1)];
            [encoder memoryBarrierWithScope:MTLBarrierScopeBuffers];
            [encoder setComputePipelineState:d.parallelBacktrackingFinalizePipeline];
            bindFinalize(laterStart,remaining);
            [encoder dispatchThreadgroups:MTLSizeMake(1,1,1)
                threadsPerThreadgroup:MTLSizeMake(32,1,1)];
            [encoder memoryBarrierWithScope:MTLBarrierScopeBuffers];
        }
    }
    [encoder setComputePipelineState:d.backtrackingPipeline];
    [encoder setBytes:&dispatch length:sizeof(dispatch) atIndex:0];
    [encoder setBytes:&microstep length:sizeof(microstep) atIndex:1];
    [encoder setBytes:&solver length:sizeof(solver) atIndex:2];
    [encoder setBuffer:objects offset:0 atIndex:3];[encoder setBuffer:materials offset:0 atIndex:4];
    [encoder setBuffer:acceptedBuffer offset:0 atIndex:5];[encoder setBuffer:candidateBuffer offset:0 atIndex:6];
    [encoder setBuffer:correctionBuffer offset:0 atIndex:7];[encoder setBuffer:tetrahedronBuffer offset:0 atIndex:8];
    [encoder setBuffer:schedulerBuffer offset:0 atIndex:9];[encoder setBuffer:adaptiveBuffer offset:0 atIndex:10];
    [encoder setBuffer:lineSearchBuffer offset:0 atIndex:11];[encoder setBuffer:statusBuffer offset:0 atIndex:12];
    [encoder setBuffer:mixedBuffer offset:0 atIndex:13];[encoder setBuffer:fieldBuffer offset:0 atIndex:14];
    [encoder setBuffer:fgmresStateBuffer offset:0 atIndex:15];
    [encoder setBuffer:collapseFlagBuffer offset:0 atIndex:16];
    [encoder setBuffer:skippedTetTrialsBuffer offset:0 atIndex:17];
    const std::uint32_t parallelNonMixed=parallelTiles?1u:0u;
    [encoder setBytes:&parallelNonMixed length:sizeof(parallelNonMixed) atIndex:18];
    [encoder setBuffer:emptyPrograms offset:0 atIndex:19];
    [encoder setBuffer:emptyInstructions offset:0 atIndex:20];
    [encoder setBuffer:emptyParameters offset:0 atIndex:21];
    [encoder setBuffer:emptyMaterialState offset:0 atIndex:22];
    [encoder setBytes:&validateConstitutiveStress
        length:sizeof(validateConstitutiveStress) atIndex:23];
    [encoder dispatchThreadgroups:MTLSizeMake(1,1,1) threadsPerThreadgroup:MTLSizeMake(256,1,1)];
    [encoder endEncoding];[command commit];[command waitUntilCompleted];
    need(command.status==MTLCommandBufferStatusCompleted,"FEM backtracking command failed");
    const auto* compactWords =
        static_cast<const nm_float4*>(parallelPartialsBuffer.contents);
    for (std::size_t i = partialCount; i < compactPartials.size(); ++i)
        need(compactWords[i].x == 777.0f && compactWords[i].y == 778.0f &&
            compactWords[i].z == 779.0f && compactWords[i].w == 780.0f,
            "compact backtracking tile scratch overflow");
    const auto result=*static_cast<const nm_float4*>(lineSearchBuffer.contents);
    const auto matterStatus=*static_cast<const NMMatterStatusGPU*>(statusBuffer.contents);
    const auto skipped=*static_cast<const std::uint32_t*>(skippedTetTrialsBuffer.contents);
    const auto* laterDispatch =
        static_cast<const NMIndirectDispatchGPU*>(parallelIndirectBuffer.contents);
    return {result.x,result.y,result.z,matterStatus.code,skipped,
            laterDispatch->threadgroupsX};
}
void backtrackingLaneReductionChecks(Device& d){
    for(const bool displacementGradient:{false,true}){
    const auto laneWitness=selectBacktracking(d,true,false,displacementGradient);
    need(laneWitness.status==NM_STATUS_SUCCESS,"nonleader invalid tet rejected status="+std::to_string(laneWitness.status));
    need(std::abs(laneWitness.alpha-0.5f)<1.0e-6f&&laneWitness.minimumJ>0.65f&&laneWitness.minimumJ<0.67f,
        "nonleader invalid tet was omitted from FEM backtracking reduction alpha="+number(laneWitness.alpha)+" minJ="+number(laneWitness.minimumJ));
    const auto fixed=selectBacktracking(d,false,true,displacementGradient);
    need(fixed.status==NM_STATUS_SUCCESS&&std::abs(fixed.alpha-1.0f)<1.0e-6f&&std::abs(fixed.minimumJ-1.0f)<1.0e-6f,
        "fixed-node backtracking control changed alpha or J");
    const auto valid=selectBacktracking(d,false,false,displacementGradient);
    need(valid.status==NM_STATUS_SUCCESS&&std::abs(valid.alpha-1.0f)<1.0e-6f&&std::abs(valid.minimumJ-1.0f)<1.0e-6f,
        "fully admissible FEM backtracking control changed alpha or J");
    if(!displacementGradient){
        const auto completed=selectBacktracking(d,false,false,false,true,true,false);
        need(completed.status==valid.status&&completed.alpha==valid.alpha&&
            completed.minimumJ==valid.minimumJ&&completed.trials==valid.trials&&
            completed.skippedTetTrials==0u,
            "completed zero-direction first acceptance changed output or counted nonexistent work");
        const auto fallbackReference=selectBacktracking(d,false,false,false,false,false,true);
        const auto fallbackCollapsed=selectBacktracking(d,false,false,false,true,true,true);
        need(fallbackReference.status==NM_STATUS_SUCCESS&&
            fallbackCollapsed.status==fallbackReference.status&&
            fallbackCollapsed.alpha==fallbackReference.alpha&&
            std::abs(fallbackCollapsed.alpha-0.5f)<1.0e-6f&&
            fallbackCollapsed.minimumJ==fallbackReference.minimumJ&&
            fallbackCollapsed.trials==fallbackReference.trials&&
            fallbackCollapsed.skippedTetTrials==kBacktrackingFixtureElementCount,
            "completed zero-direction collapse changed the exact bounded fallback");
        const auto unlatched=selectBacktracking(d,false,false,false,true,false,false);
        need(unlatched.alpha==valid.alpha&&unlatched.skippedTetTrials==0u,
            "unlatched zero direction incorrectly collapsed trial loop");
        const auto nonzero=selectBacktracking(d,true,false,false,true,true,false);
        need(nonzero.alpha==laneWitness.alpha&&nonzero.skippedTetTrials==0u,
            "nonzero correction incorrectly collapsed trial loop");
    }
    const auto compareParallel = [&](const bool invalid, const bool fixed,
                                     const bool mixed, const unsigned invalidIndex) {
        const auto reference = selectBacktracking(d,invalid,fixed,
            displacementGradient,false,false,mixed,false,invalidIndex);
        const auto tiled = selectBacktracking(d,invalid,fixed,
            displacementGradient,false,false,mixed,true,invalidIndex);
        need(tiled.status==reference.status&&tiled.alpha==reference.alpha&&
             tiled.minimumJ==reference.minimumJ&&tiled.trials==reference.trials,
             "tiled generic backtracking differs from legacy alpha/J/status");
        if (invalid && !mixed)
            need(tiled.laterTileGroups==3u,
                "rejected alpha-one object did not activate exactly three later tile groups");
        else
            need(tiled.laterTileGroups==0u,
                "accepted or mixed object unnecessarily activated later tile groups");
    };
    compareParallel(false,false,false,57u);
    compareParallel(true,false,false,520u);
    compareParallel(false,true,false,57u);
    compareParallel(false,false,true,57u); // mixed pressure merit stays legacy.
    if(!displacementGradient) {
        const auto reference=selectBacktracking(d,true,false,false,false,false,
            false,false,520u,true);
        const auto tiled=selectBacktracking(d,true,false,false,false,false,
            false,true,520u,true);
        need(tiled.status==reference.status&&tiled.alpha==reference.alpha&&
             tiled.minimumJ==reference.minimumJ&&tiled.trials==reference.trials,
             "tiled exhausted-trial failure diagnostics differ from legacy");
        need(tiled.laterTileGroups==3u,
             "exhausted alpha-one rejection did not dispatch the later tile range");
    }
    std::cout<<"fem_backtracking_lane_reduction=pass lane=57 rejected_J=0.3139282 accepted_alpha=0.5 accepted_min_J="
        <<laneWitness.minimumJ<<" fixed_node_control=pass valid_control=pass reference_displacement="<<displacementGradient<<std::endl;
    }
}
BacktrackingResult selectConstitutiveStressBacktracking(
    Device& d, const float stressLimit, const bool enableStressCheck,
    const bool twoTetWitness = false, const bool parallelTiles = false) {
    NMMatterDispatchGPU dispatch{};
    dispatch.environmentCount = 1u;
    dispatch.objectCount = 1u;
    dispatch.femNodeCount = twoTetWitness ? 8u : 4u;
    dispatch.tetrahedronCount = twoTetWitness ? 257u : 1u;
    dispatch.parameterCount = 1u;
    dispatch.gravityAndTimestep.w = 1.0f;
    dispatch.numericalLimits.z = 0.35f;
    NMMicrostepGPU microstep{};
    microstep.time.y = 1.0f;
    NMMixedSolverGPU solver{};
    solver.nonlinearIterations.w = 2u;
    solver.residualTolerances.y = 1.0e-8f;
    NMContinuumObjectGPU object{};
    object.representation = NM_REPRESENTATION_FEM;
    object.flags = NM_OBJECT_ACTIVE;
    object.elementCount = dispatch.tetrahedronCount;
    NMMaterialGPU material{};
    material.constitutiveKind = NM_CONSTITUTIVE_BYTECODE;
    material.parameterOffset = 0u;
    material.parameterCount = 1u;
    material.stateCount = 0u;
    material.stressProgramOffset = 0u;
    material.tangentProgramOffset = NM_INVALID_INDEX;
    material.validityProgram = NM_INVALID_INDEX;
    material.stateInitialOffset = NM_INVALID_INDEX;
    material.stateUpdateProgramOffset = NM_INVALID_INDEX;
    material.dissipationProgram = NM_INVALID_INDEX;
    material.projectionKind = NM_MATERIAL_PROJECTION_GENERIC;
    material.viscousStressProgramOffset = NM_INVALID_INDEX;
    material.viscousTangentProgramOffset = NM_INVALID_INDEX;
    material.implicitResidualProgramOffset = NM_INVALID_INDEX;
    material.implicitJacobianProgramOffset = NM_INVALID_INDEX;
    material.implicitDeformationProgramOffset = NM_INVALID_INDEX;
    material.stressStateDerivativeProgramOffset = NM_INVALID_INDEX;
    material.bulk = {1.0f, 0.0f, 0.0f, 0.0f};
    material.validity = {0.35f, 2.5f, stressLimit, 1.0e30f};
    NMSchedulerStateGPU scheduler{};
    scheduler.numerical.w = 1.0f;
    NMAdaptiveStateGPU adaptive{};
    adaptive.activeRepresentation = NM_REPRESENTATION_FEM;
    std::vector<NMFEMNodeStateGPU> accepted(dispatch.femNodeCount),
        candidate(dispatch.femNodeCount);
    const nm_float4 points[8] = {
        {0, 0, 0, 1}, {1, 0, 0, 1},
        {0, 1, 0, 1}, {0, 0, 1, 1},
        {10, 0, 0, 1}, {11, 0, 0, 1},
        {10, 1, 0, 1}, {10, 0, 1, 1},
    };
    for (unsigned node = 0u; node < dispatch.femNodeCount; ++node) {
        accepted[node].positionAndMass = points[node];
        accepted[node].restAndFixed = points[node];
        accepted[node].restAndFixed.w = 0.0f;
        accepted[node].velocityAndInverseMass.w = 1.0f;
        candidate[node] = accepted[node];
    }
    std::vector<nm_float4> correction(2u * dispatch.femNodeCount);
    correction[1].x = 1.0f; // First tet: J(alpha=1)=2; J(0.5)=1.5.
    if (twoTetWitness)
        correction[5u].x = 0.2f;
        // Second tet remains valid at alpha=1 while the first is stress-invalid.
    NMTetrahedronGPU tetrahedron{};
    tetrahedron.nodes = {0u, 1u, 2u, 3u};
    tetrahedron.inverseRestRow0 = {1, 0, 0, 1.0f / 6.0f};
    tetrahedron.inverseRestRow1 = {0, 1, 0, 0};
    tetrahedron.inverseRestRow2 = {0, 0, 1, 0};
    tetrahedron.identity = {0u, 0u, 0u, NM_OBJECT_ACTIVE};
    std::vector<NMTetrahedronGPU> tetrahedra{tetrahedron};
    if (twoTetWitness) {
        NMTetrahedronGPU second = tetrahedron;
        second.nodes = {4u, 5u, 6u, 7u};
        // The selector gives one tet to each lane. Put a valid second tet at
        // index 256 so lane 0 must retain its invalid result from index 0.
        tetrahedra.resize(dispatch.tetrahedronCount, second);
        tetrahedra[0] = tetrahedron;
    }
    std::vector<NMScalarProgramGPU> programs(9u);
    std::vector<NMExpressionInstructionGPU> instructions(11u);
    programs[0] = {0u, 3u, 2u, 0u};
    instructions[0].opcode = NM_EXPR_F;
    instructions[0].index = 0u;
    instructions[1].opcode = NM_EXPR_PARAMETER;
    instructions[1].index = 0u;
    instructions[2].opcode = NM_EXPR_MULTIPLY;
    for (unsigned component = 1u; component < 9u; ++component) {
        const unsigned instruction = component + 2u;
        programs[component] = {instruction, 1u, 1u, 0u};
        instructions[instruction].opcode = NM_EXPR_CONSTANT;
        instructions[instruction].immediate.x = 0.0f;
    }
    const auto objects = buffer(d.device, std::vector<NMContinuumObjectGPU>{object});
    const auto materials = buffer(d.device, std::vector<NMMaterialGPU>{material});
    const auto acceptedBuffer = buffer(d.device, accepted);
    const auto candidateBuffer = buffer(d.device, candidate);
    const auto correctionBuffer = buffer(d.device, correction);
    const auto tetrahedronBuffer = buffer(d.device, tetrahedra);
    const auto schedulerBuffer =
        buffer(d.device, std::vector<NMSchedulerStateGPU>{scheduler});
    const auto adaptiveBuffer =
        buffer(d.device, std::vector<NMAdaptiveStateGPU>{adaptive});
    const auto lineSearchBuffer =
        buffer(d.device, std::vector<nm_float4>(1u));
    const auto statusBuffer =
        buffer(d.device, std::vector<NMMatterStatusGPU>(1u));
    const auto mixedBuffer =
        buffer(d.device, std::vector<NMMixedMaterialGPU>(1u));
    const auto fieldBuffer =
        buffer(d.device, std::vector<NMFEMFieldStateGPU>(4u));
    const auto fgmresBuffer =
        buffer(d.device, std::vector<NMFGMRESStateGPU>(1u));
    const auto collapseBuffer =
        buffer(d.device, std::vector<std::uint32_t>{0u});
    const auto skippedBuffer =
        buffer(d.device, std::vector<std::uint32_t>{0u});
    const auto programsBuffer = buffer(d.device, programs);
    const auto instructionsBuffer = buffer(d.device, instructions);
    const auto parametersBuffer =
        buffer(d.device, std::vector<float>{1.0e6f});
    const auto acceptedMaterialStateBuffer =
        buffer(d.device, std::vector<float>{0.0f});
    const unsigned maximumTiles=(dispatch.tetrahedronCount+255u)/256u;
    const std::size_t partialCount =
        std::size_t(NM_MIXED_LINE_SEARCH_MAX_STEPS) * maximumTiles;
    std::vector<nm_float4> compactPartials(partialCount + 4u);
    for (std::size_t i = partialCount; i < compactPartials.size(); ++i)
        compactPartials[i] = {777.0f, 778.0f, 779.0f, 780.0f};
    const auto parallelPartialsBuffer=buffer(d.device, compactPartials);
    const auto parallelAcceptedBuffer=buffer(
        d.device,std::vector<std::uint32_t>(1u,0u));
    const auto parallelIndirectBuffer=buffer(
        d.device,std::vector<NMIndirectDispatchGPU>{{0u,1u,1u,0u}});
    const std::uint32_t parallelNonMixed = parallelTiles ? 1u : 0u;
    const std::uint32_t validateStress = enableStressCheck ? 1u : 0u;
    auto command = [d.queue commandBuffer];
    auto encoder = [command computeCommandEncoder];
    if(parallelTiles){
        [encoder setComputePipelineState:d.parallelBacktrackingInitializePipeline];
        [encoder setBytes:&dispatch length:sizeof(dispatch) atIndex:0];
        [encoder setBuffer:objects offset:0 atIndex:1];
        [encoder setBuffer:lineSearchBuffer offset:0 atIndex:2];
        [encoder setBuffer:parallelAcceptedBuffer offset:0 atIndex:3];
        [encoder dispatchThreadgroups:MTLSizeMake(1,1,1)
            threadsPerThreadgroup:MTLSizeMake(32,1,1)];
        [encoder memoryBarrierWithScope:MTLBarrierScopeBuffers];

        const auto bindTiles=[&](const unsigned trialStart,const unsigned trialCount){
            [encoder setBytes:&dispatch length:sizeof(dispatch) atIndex:0];
            [encoder setBytes:&microstep length:sizeof(microstep) atIndex:1];
            [encoder setBytes:&solver length:sizeof(solver) atIndex:2];
            [encoder setBuffer:objects offset:0 atIndex:3];
            [encoder setBuffer:materials offset:0 atIndex:4];
            [encoder setBuffer:acceptedBuffer offset:0 atIndex:5];
            [encoder setBuffer:candidateBuffer offset:0 atIndex:6];
            [encoder setBuffer:correctionBuffer offset:0 atIndex:7];
            [encoder setBuffer:tetrahedronBuffer offset:0 atIndex:8];
            [encoder setBuffer:schedulerBuffer offset:0 atIndex:9];
            [encoder setBuffer:adaptiveBuffer offset:0 atIndex:10];
            [encoder setBuffer:statusBuffer offset:0 atIndex:11];
            [encoder setBuffer:parallelPartialsBuffer offset:0 atIndex:12];
            [encoder setBytes:&maximumTiles length:sizeof(maximumTiles) atIndex:13];
            [encoder setBuffer:parallelAcceptedBuffer offset:0 atIndex:14];
            [encoder setBytes:&trialStart length:sizeof(trialStart) atIndex:15];
            [encoder setBytes:&trialCount length:sizeof(trialCount) atIndex:16];
            [encoder setBuffer:programsBuffer offset:0 atIndex:17];
            [encoder setBuffer:instructionsBuffer offset:0 atIndex:18];
            [encoder setBuffer:parametersBuffer offset:0 atIndex:19];
            [encoder setBytes:&validateStress length:sizeof(validateStress) atIndex:20];
        };
        const auto bindFinalize=[&](const unsigned trialStart,const unsigned trialCount){
            [encoder setBytes:&dispatch length:sizeof(dispatch) atIndex:0];
            [encoder setBytes:&microstep length:sizeof(microstep) atIndex:1];
            [encoder setBytes:&solver length:sizeof(solver) atIndex:2];
            [encoder setBuffer:objects offset:0 atIndex:3];
            [encoder setBuffer:schedulerBuffer offset:0 atIndex:4];
            [encoder setBuffer:adaptiveBuffer offset:0 atIndex:5];
            [encoder setBuffer:statusBuffer offset:0 atIndex:6];
            [encoder setBuffer:lineSearchBuffer offset:0 atIndex:7];
            [encoder setBuffer:parallelPartialsBuffer offset:0 atIndex:8];
            [encoder setBytes:&maximumTiles length:sizeof(maximumTiles) atIndex:9];
            [encoder setBuffer:parallelAcceptedBuffer offset:0 atIndex:10];
            [encoder setBytes:&trialStart length:sizeof(trialStart) atIndex:11];
            [encoder setBytes:&trialCount length:sizeof(trialCount) atIndex:12];
        };
        const unsigned firstStart=0u,firstCount=1u;
        [encoder setComputePipelineState:d.parallelBacktrackingTilesPipeline];
        bindTiles(firstStart,firstCount);
        [encoder dispatchThreadgroups:MTLSizeMake(maximumTiles,1,1)
            threadsPerThreadgroup:MTLSizeMake(256,1,1)];
        [encoder memoryBarrierWithScope:MTLBarrierScopeBuffers];
        [encoder setComputePipelineState:d.parallelBacktrackingFinalizePipeline];
        bindFinalize(firstStart,firstCount);
        [encoder dispatchThreadgroups:MTLSizeMake(1,1,1)
            threadsPerThreadgroup:MTLSizeMake(32,1,1)];
        [encoder memoryBarrierWithScope:MTLBarrierScopeBuffers];

        const unsigned candidateCount=std::min<unsigned>(
            solver.nonlinearIterations.w,NM_MIXED_LINE_SEARCH_MAX_STEPS);
        const unsigned remaining=candidateCount>1u?candidateCount-1u:0u;
        if(remaining>0u){
            [encoder setComputePipelineState:d.parallelBacktrackingPreparePipeline];
            [encoder setBytes:&dispatch length:sizeof(dispatch) atIndex:0];
            [encoder setBytes:&microstep length:sizeof(microstep) atIndex:1];
            [encoder setBytes:&solver length:sizeof(solver) atIndex:2];
            [encoder setBuffer:objects offset:0 atIndex:3];
            [encoder setBuffer:schedulerBuffer offset:0 atIndex:4];
            [encoder setBuffer:adaptiveBuffer offset:0 atIndex:5];
            [encoder setBuffer:statusBuffer offset:0 atIndex:6];
            [encoder setBuffer:parallelAcceptedBuffer offset:0 atIndex:7];
            [encoder setBytes:&maximumTiles length:sizeof(maximumTiles) atIndex:8];
            [encoder setBuffer:parallelIndirectBuffer offset:0 atIndex:9];
            [encoder dispatchThreadgroups:MTLSizeMake(1,1,1)
                threadsPerThreadgroup:MTLSizeMake(32,1,1)];
            [encoder memoryBarrierWithScope:MTLBarrierScopeBuffers];
            [encoder setComputePipelineState:d.parallelBacktrackingTilesPipeline];
            const unsigned laterStart=1u;
            bindTiles(laterStart,remaining);
            [encoder dispatchThreadgroupsWithIndirectBuffer:parallelIndirectBuffer
                indirectBufferOffset:0
                threadsPerThreadgroup:MTLSizeMake(256,1,1)];
            [encoder memoryBarrierWithScope:MTLBarrierScopeBuffers];
            [encoder setComputePipelineState:d.parallelBacktrackingFinalizePipeline];
            bindFinalize(laterStart,remaining);
            [encoder dispatchThreadgroups:MTLSizeMake(1,1,1)
                threadsPerThreadgroup:MTLSizeMake(32,1,1)];
            [encoder memoryBarrierWithScope:MTLBarrierScopeBuffers];
        }
    }
    [encoder setComputePipelineState:d.backtrackingPipeline];
    [encoder setBytes:&dispatch length:sizeof(dispatch) atIndex:0];
    [encoder setBytes:&microstep length:sizeof(microstep) atIndex:1];
    [encoder setBytes:&solver length:sizeof(solver) atIndex:2];
    [encoder setBuffer:objects offset:0 atIndex:3];
    [encoder setBuffer:materials offset:0 atIndex:4];
    [encoder setBuffer:acceptedBuffer offset:0 atIndex:5];
    [encoder setBuffer:candidateBuffer offset:0 atIndex:6];
    [encoder setBuffer:correctionBuffer offset:0 atIndex:7];
    [encoder setBuffer:tetrahedronBuffer offset:0 atIndex:8];
    [encoder setBuffer:schedulerBuffer offset:0 atIndex:9];
    [encoder setBuffer:adaptiveBuffer offset:0 atIndex:10];
    [encoder setBuffer:lineSearchBuffer offset:0 atIndex:11];
    [encoder setBuffer:statusBuffer offset:0 atIndex:12];
    [encoder setBuffer:mixedBuffer offset:0 atIndex:13];
    [encoder setBuffer:fieldBuffer offset:0 atIndex:14];
    [encoder setBuffer:fgmresBuffer offset:0 atIndex:15];
    [encoder setBuffer:collapseBuffer offset:0 atIndex:16];
    [encoder setBuffer:skippedBuffer offset:0 atIndex:17];
    [encoder setBytes:&parallelNonMixed length:sizeof(parallelNonMixed) atIndex:18];
    [encoder setBuffer:programsBuffer offset:0 atIndex:19];
    [encoder setBuffer:instructionsBuffer offset:0 atIndex:20];
    [encoder setBuffer:parametersBuffer offset:0 atIndex:21];
    [encoder setBuffer:acceptedMaterialStateBuffer offset:0 atIndex:22];
    [encoder setBytes:&validateStress length:sizeof(validateStress) atIndex:23];
    [encoder dispatchThreadgroups:MTLSizeMake(1, 1, 1)
        threadsPerThreadgroup:MTLSizeMake(256, 1, 1)];
    [encoder endEncoding];
    [command commit];
    [command waitUntilCompleted];
    need(command.status == MTLCommandBufferStatusCompleted,
        "constitutive stress line-search command failed");
    const auto* compactWords =
        static_cast<const nm_float4*>(parallelPartialsBuffer.contents);
    for (std::size_t i = partialCount; i < compactPartials.size(); ++i)
        need(compactWords[i].x == 777.0f && compactWords[i].y == 778.0f &&
            compactWords[i].z == 779.0f && compactWords[i].w == 780.0f,
            "compact constitutive backtracking tile scratch overflow");
    const auto result =
        *static_cast<const nm_float4*>(lineSearchBuffer.contents);
    const auto matterStatus =
        *static_cast<const NMMatterStatusGPU*>(statusBuffer.contents);
    const auto skipped =
        *static_cast<const std::uint32_t*>(skippedBuffer.contents);
    return {result.x, result.y, result.z, matterStatus.code, skipped, 0u};
}
void backtrackingConstitutiveValidityChecks(Device& d) {
    const float scale = 1.0e6f;
    const auto unchanged = selectConstitutiveStressBacktracking(
        d, 1.75f * scale, false);
    need(unchanged.status == NM_STATUS_SUCCESS &&
        unchanged.alpha == 1.0f,
        "default-off constitutive validity changed the legacy full-step choice");
    const auto backtracked = selectConstitutiveStressBacktracking(
        d, 1.75f * scale, true);
    need(backtracked.status == NM_STATUS_SUCCESS &&
        backtracked.alpha == 0.5f &&
        backtracked.minimumJ > 1.49f && backtracked.minimumJ < 1.51f,
        "stress-invalid moderate-J full step was not backtracked to the valid half step");
    const auto cumulative = selectConstitutiveStressBacktracking(
        d, 1.75f * scale, true, true);
    need(cumulative.status == NM_STATUS_SUCCESS &&
        cumulative.alpha == 0.5f &&
        cumulative.minimumJ > 1.09f && cumulative.minimumJ < 1.11f,
        "a later valid tetrahedron erased the earlier stress-invalid tet result");
    const auto exhausted = selectConstitutiveStressBacktracking(
        d, 1.25f * scale, true);
    need(exhausted.status == NM_STATUS_NONLINEAR_SOLVER_FAILURE &&
        exhausted.alpha == 0.0f,
        "all-stress-invalid candidates did not fail closed");
    for (const bool witness : {false, true}) {
        for (const float limit : {1.75f * scale, 1.25f * scale, 3.0f * scale}) {
            for (const bool enabled : {false, true}) {
                const auto serial=selectConstitutiveStressBacktracking(
                    d,limit,enabled,witness,false);
                const auto parallel=selectConstitutiveStressBacktracking(
                    d,limit,enabled,witness,true);
                need(serial.alpha==parallel.alpha &&
                     serial.minimumJ==parallel.minimumJ &&
                     serial.status==parallel.status,
                     "parallel constitutive backtracking differs from serial");
            }
        }
    }
    std::cout << "fem_backtracking_constitutive_validity=pass default=legacy "
        << "stress_invalid_J2_to_valid_J1_5=backtracked "
        << "earlier_invalid_survives_later_valid=pass "
        << "all_invalid=failed_closed\n";
}
struct Inputs {
    std::vector<NMFEMNodeStateGPU> nodes;
    std::vector<NMFEMFieldStateGPU> fields;
    std::vector<nm_float4> direction;
    std::vector<float> state;
};
Inputs manufactured(const CompiledWorld& w){
    Inputs v;v.nodes=repeat(w.fem.nodes);v.fields=repeat(w.fem.fields);v.direction.resize(4*w.dispatch.femNodeCount);
    const Matrix h{.19,-.13,.07,.11,-.17,.04,-.05,.09,.14};
    for(unsigned env=0;env<2;++env)for(unsigned n=0;n<w.dispatch.femNodeCount;++n){const unsigned i=env*w.dispatch.femNodeCount+n;
        const Vec x=xyz(w.fem.nodes[n].restAndFixed),d=transform(h,x);
        v.direction[i]={float(d[0]),float(d[1]),float(d[2]),0};}
    v.state.resize(2*w.dispatch.tetrahedronCount*w.dispatch.materialStateStride);
    for(unsigned e=0;e<2;++e)for(unsigned ti=0;ti<w.dispatch.tetrahedronCount;++ti){
        const auto& m=w.materials[w.fem.tetrahedra[ti].identity.x];
        for(unsigned i=0;i<m.stateCount;++i)v.state[(e*w.dispatch.tetrahedronCount+ti)*w.dispatch.materialStateStride+i]=w.stateInitials[m.stateInitialOffset+i];}
    return v;
}
std::vector<NMFEMElementVectorGPU> dispatch(Device& d,const CompiledWorld& w,const Inputs& input,bool tangent){
    NMMicrostepGPU micro{};micro.flags=NM_MICROSTEP_FGMRES_OPERATOR;micro.time={w.dispatch.gravityAndTimestep.w,1/w.dispatch.gravityAndTimestep.w,0,0};
    std::vector<float> parameters;for(unsigned e=0;e<2;++e)for(const auto& p:w.parameters)parameters.push_back(p.valueAndBounds.x);
    const auto objects=buffer(d.device,w.objects),materials=buffer(d.device,w.materials),programs=buffer(d.device,w.scalarPrograms),instructions=buffer(d.device,w.instructions);
    const auto params=buffer(d.device,parameters),nodes=buffer(d.device,input.nodes),tets=buffer(d.device,repeat(w.fem.tetrahedra)),state=buffer(d.device,input.state);
    const auto schedulers=buffer(d.device,repeat(w.schedulers)),adaptive=buffer(d.device,repeat(w.adaptive)),mixed=buffer(d.device,w.mixedMaterials),fields=buffer(d.device,input.fields);
    const auto learned=buffer(d.device,w.learnedMaterials),layers=buffer(d.device,w.learnedLayers),weights=buffer(d.device,w.learnedWeights),direction=buffer(d.device,input.direction);
    const auto solver=buffer(d.device,std::vector<NMFGMRESStateGPU>(2)),status=buffer(d.device,std::vector<NMMatterStatusGPU>(2));
    const unsigned count=2*w.dispatch.tetrahedronCount;const auto output=buffer(d.device,std::vector<NMFEMElementVectorGPU>(count));
    const auto tangentCacheDummy=buffer(d.device,std::vector<std::uint32_t>(1));
    const auto fallbackMetrics=buffer(d.device,
        std::vector<nm_float4>(w.dispatch.environmentCount,nm_float4{}));
    auto command=[d.queue commandBuffer];auto encoder=[command computeCommandEncoder];[encoder setComputePipelineState:tangent?d.operatorPipeline:d.forcePipeline];
    [encoder setBytes:&w.dispatch length:sizeof(w.dispatch) atIndex:0];[encoder setBytes:&micro length:sizeof(micro) atIndex:1];
    [encoder setBuffer:objects offset:0 atIndex:2];[encoder setBuffer:materials offset:0 atIndex:3];[encoder setBuffer:programs offset:0 atIndex:4];[encoder setBuffer:instructions offset:0 atIndex:5];
    [encoder setBuffer:params offset:0 atIndex:6];[encoder setBuffer:nodes offset:0 atIndex:7];[encoder setBuffer:tets offset:0 atIndex:8];[encoder setBuffer:state offset:0 atIndex:9];
    if(tangent){[encoder setBuffer:direction offset:0 atIndex:10];[encoder setBuffer:schedulers offset:0 atIndex:11];[encoder setBuffer:adaptive offset:0 atIndex:12];[encoder setBuffer:output offset:0 atIndex:13];[encoder setBuffer:status offset:0 atIndex:14];
        [encoder setBuffer:mixed offset:0 atIndex:16];[encoder setBuffer:fields offset:0 atIndex:17];[encoder setBuffer:learned offset:0 atIndex:18];[encoder setBuffer:layers offset:0 atIndex:19];[encoder setBuffer:weights offset:0 atIndex:20];
        [encoder setBytes:&w.mixedSolver length:sizeof(w.mixedSolver) atIndex:21];[encoder setBuffer:solver offset:0 atIndex:22];
        [encoder setBuffer:tangentCacheDummy offset:0 atIndex:23];
        [encoder setBuffer:tangentCacheDummy offset:0 atIndex:24];
        const std::uint32_t useCache=0u;
        [encoder setBytes:&useCache length:sizeof(useCache) atIndex:25];
        [encoder setBuffer:fallbackMetrics offset:0 atIndex:26];}
    else{[encoder setBuffer:schedulers offset:0 atIndex:10];[encoder setBuffer:adaptive offset:0 atIndex:11];[encoder setBuffer:output offset:0 atIndex:12];[encoder setBuffer:status offset:0 atIndex:13];
        [encoder setBuffer:mixed offset:0 atIndex:14];[encoder setBuffer:fields offset:0 atIndex:15];[encoder setBuffer:learned offset:0 atIndex:16];[encoder setBuffer:layers offset:0 atIndex:17];[encoder setBuffer:weights offset:0 atIndex:18];}
    [encoder dispatchThreads:MTLSizeMake(count,1,1) threadsPerThreadgroup:MTLSizeMake(32,1,1)];[encoder endEncoding];[command commit];[command waitUntilCompleted];
    need(command.status==MTLCommandBufferStatusCompleted,"direct production FEM command failed");
    const auto* statuses=static_cast<const NMMatterStatusGPU*>(status.contents);for(unsigned e=0;e<2;++e)need(statuses[e].code==NM_STATUS_SUCCESS,"direct production FEM rejected state code="+std::to_string(statuses[e].code));
    const auto* values=static_cast<const NMFEMElementVectorGPU*>(output.contents);return {values,values+count};
}
Matrix gradient(const CompiledWorld& w,const Inputs& v,unsigned e,unsigned ti,bool rate=false,bool direction=false){
    const auto& t=w.fem.tetrahedra[ti];const unsigned base=e*w.dispatch.femNodeCount;
    const auto at=[&](unsigned n){return direction?xyz(v.direction[base+n]):rate?xyz(v.nodes[base+n].velocityAndInverseMass):xyz(v.nodes[base+n].positionAndMass);};
    if(!rate&&!direction&&(t.identity.w&NM_TETRAHEDRON_REFERENCE_DISPLACEMENT_GRADIENT)!=0u){
        const auto displacement=[&](unsigned n){
            const auto& node=v.nodes[base+n];
            return Vec{
                double(node.referenceDisplacementAndMode.x)+double(node.referenceDisplacementLow.x),
                double(node.referenceDisplacementAndMode.y)+double(node.referenceDisplacementLow.y),
                double(node.referenceDisplacementAndMode.z)+double(node.referenceDisplacementLow.z)};
        };
        const Vec u=displacement(t.nodes.x);
        Matrix result=ref::multiply(columns(sub(displacement(t.nodes.y),u),sub(displacement(t.nodes.z),u),sub(displacement(t.nodes.w),u)),inverseRest(t));
        for(unsigned i=0;i<3;++i)result[4*i]+=1.0;
        return result;
    }
    const Vec x=at(t.nodes.x);return ref::multiply(columns(sub(at(t.nodes.y),x),sub(at(t.nodes.z),x),sub(at(t.nodes.w),x)),inverseRest(t));
}
Matrix executableRestF32(const CompiledWorld& w,unsigned ti,bool displacementGradient){
    const auto& t=w.fem.tetrahedra[ti];
    const std::array<unsigned,4> ids{t.nodes.x,t.nodes.y,t.nodes.z,t.nodes.w};
    const std::array<float,9> inverse{t.inverseRestRow0.x,t.inverseRestRow0.y,t.inverseRestRow0.z,
        t.inverseRestRow1.x,t.inverseRestRow1.y,t.inverseRestRow1.z,
        t.inverseRestRow2.x,t.inverseRestRow2.y,t.inverseRestRow2.z};
    if(displacementGradient){
        std::array<float,12> displacementHigh{},displacementLow{};
        for(unsigned n=0;n<4;++n){
            const auto& node=w.fem.nodes[ids[n]];
            const float hi[3]={node.referenceDisplacementAndMode.x,
                node.referenceDisplacementAndMode.y,node.referenceDisplacementAndMode.z};
            const float lo[3]={node.referenceDisplacementLow.x,
                node.referenceDisplacementLow.y,node.referenceDisplacementLow.z};
            for(unsigned axis=0;axis<3;++axis){
                displacementHigh[3*n+axis]=hi[axis];
                displacementLow[3*n+axis]=lo[axis];
            }
        }
        constexpr std::array<float,9> identityFrame{1,0,0,0,1,0,0,0,1};
        std::array<float,9> deformationHigh{},deformationLow{};
        nmFEMReferenceDeformationWords(displacementHigh.data(),displacementLow.data(),
            inverse.data(),identityFrame.data(),deformationHigh.data(),deformationLow.data());
        Matrix f{};
        for(unsigned i=0;i<9;++i)f[i]=double(deformationHigh[i])+double(deformationLow[i]);
        return f;
    }
    std::array<std::array<float,3>,4> current{};
    for(unsigned n=0;n<4;++n){const auto& node=w.fem.nodes[ids[n]];
        current[n]={node.positionAndMass.x,node.positionAndMass.y,node.positionAndMass.z};}
    std::array<float,9> edge{};
    for(unsigned r=0;r<3;++r)for(unsigned c=0;c<3;++c)
        edge[3*r+c]=current[c+1][r]-current[0][r];
    Matrix f{};
    for(unsigned r=0;r<3;++r)for(unsigned c=0;c<3;++c){
        const float a=edge[3*r]*inverse[c],b=edge[3*r+1]*inverse[3+c],d=edge[3*r+2]*inverse[6+c];
        f[3*r+c]=double((a+b)+d);}
    return f;
}
std::array<Vec,4> forces(const NMTetrahedronGPU& t,const Matrix& p){
    const Matrix a=ref::scale(ref::multiply(p,ref::transpose(inverseRest(t))),-double(t.inverseRestRow0.w));
    std::array<Vec,4> out{};for(unsigned n=1;n<4;++n)for(unsigned i=0;i<3;++i){out[n][i]=a[3*i+n-1];out[0][i]-=out[n][i];}return out;
}
std::array<Vec,4> forces(const NMFEMElementVectorGPU& v){return {xyz(v.node0),xyz(v.node1),xyz(v.node2),xyz(v.node3)};}
using Oracle=std::function<ref::Result(unsigned,const Matrix&,const Matrix&,const Matrix&,const Matrix&)>;
double compare(const CompiledWorld& w,const Inputs& v,const std::vector<NMFEMElementVectorGPU>& actual,bool tangent,const Oracle& oracle){
    double error=0,scale=0;
    for(unsigned e=0;e<2;++e)for(unsigned ti=0;ti<w.dispatch.tetrahedronCount;++ti){const auto& t=w.fem.tetrahedra[ti];
        const Matrix q=(w.objects[t.identity.y].flags&NM_OBJECT_FEM_MATERIAL_FRAME)?frame(t.materialFrameRotation):ref::identity;
        const auto result=oracle(ti,gradient(w,v,e,ti),gradient(w,v,e,ti,false,true),gradient(w,v,e,ti,true),q);
        const auto expected=forces(t,tangent?result.tangent:result.stress),observed=forces(actual[e*w.dispatch.tetrahedronCount+ti]);
        for(unsigned n=0;n<4;++n)for(unsigned i=0;i<3;++i){need(std::isfinite(observed[n][i]),"nonfinite production force/tangent");error=std::max(error,std::abs(observed[n][i]-expected[n][i]));scale=std::max(scale,std::abs(expected[n][i]));}}
    return error/std::max(1e-10,scale);
}
double finiteDifference(Device& d,const CompiledWorld& w,const Inputs& v,const std::vector<NMFEMElementVectorGPU>& tangent){
    constexpr double epsilon=1./2048;Inputs plus=v,minus=v;const double dt=w.dispatch.gravityAndTimestep.w;const unsigned count=2*w.dispatch.femNodeCount;
    for(unsigned i=0;i<count;++i){const auto p=v.direction[i];
        plus.nodes[i].positionAndMass.x+=epsilon*p.x;minus.nodes[i].positionAndMass.x-=epsilon*p.x;
        plus.nodes[i].positionAndMass.y+=epsilon*p.y;minus.nodes[i].positionAndMass.y-=epsilon*p.y;
        plus.nodes[i].positionAndMass.z+=epsilon*p.z;minus.nodes[i].positionAndMass.z-=epsilon*p.z;
        if(plus.nodes[i].referenceDisplacementAndMode.w==1.0f){
            const float directionComponent[3]={p.x,p.y,p.z};
            float* plusHigh[3]={&plus.nodes[i].referenceDisplacementAndMode.x,
                &plus.nodes[i].referenceDisplacementAndMode.y,&plus.nodes[i].referenceDisplacementAndMode.z};
            float* plusLow[3]={&plus.nodes[i].referenceDisplacementLow.x,
                &plus.nodes[i].referenceDisplacementLow.y,&plus.nodes[i].referenceDisplacementLow.z};
            float* minusHigh[3]={&minus.nodes[i].referenceDisplacementAndMode.x,
                &minus.nodes[i].referenceDisplacementAndMode.y,&minus.nodes[i].referenceDisplacementAndMode.z};
            float* minusLow[3]={&minus.nodes[i].referenceDisplacementLow.x,
                &minus.nodes[i].referenceDisplacementLow.y,&minus.nodes[i].referenceDisplacementLow.z};
            float* plusPosition[3]={&plus.nodes[i].positionAndMass.x,
                &plus.nodes[i].positionAndMass.y,&plus.nodes[i].positionAndMass.z};
            float* minusPosition[3]={&minus.nodes[i].positionAndMass.x,
                &minus.nodes[i].positionAndMass.y,&minus.nodes[i].positionAndMass.z};
            const float rest[3]={plus.nodes[i].restAndFixed.x,
                plus.nodes[i].restAndFixed.y,plus.nodes[i].restAndFixed.z};
            for(unsigned axis=0;axis<3;++axis){
                const auto positive=mrCompensatedAdd({*plusHigh[axis],*plusLow[axis]},
                    mrCompensatedProduct(float(epsilon),directionComponent[axis]));
                const auto negative=mrCompensatedAdd({*minusHigh[axis],*minusLow[axis]},
                    mrCompensatedProduct(float(-epsilon),directionComponent[axis]));
                *plusHigh[axis]=positive.high;*plusLow[axis]=positive.low;
                *minusHigh[axis]=negative.high;*minusLow[axis]=negative.low;
                *plusPosition[axis]=mrCompensatedProjectionScalar(rest[axis],positive.high,positive.low);
                *minusPosition[axis]=mrCompensatedProjectionScalar(rest[axis],negative.high,negative.low);
            }
        }
        plus.nodes[i].velocityAndInverseMass.x+=epsilon*p.x/dt;minus.nodes[i].velocityAndInverseMass.x-=epsilon*p.x/dt;
        plus.nodes[i].velocityAndInverseMass.y+=epsilon*p.y/dt;minus.nodes[i].velocityAndInverseMass.y-=epsilon*p.y/dt;
        plus.nodes[i].velocityAndInverseMass.z+=epsilon*p.z/dt;minus.nodes[i].velocityAndInverseMass.z-=epsilon*p.z/dt;
        plus.fields[i].secondary.x+=epsilon*v.direction[count+i].w/dt;minus.fields[i].secondary.x-=epsilon*v.direction[count+i].w/dt;}
    const auto fp=dispatch(d,w,plus,false),fm=dispatch(d,w,minus,false);double error=0,scale=0;
    for(unsigned e=0;e<tangent.size();++e){const auto a=forces(fp[e]),b=forces(fm[e]),t=forces(tangent[e]);for(unsigned n=0;n<4;++n)for(unsigned i=0;i<3;++i){const double fd=(a[n][i]-b[n][i])/(2*epsilon);error=std::max(error,std::abs(fd-t[n][i]));scale=std::max(scale,std::abs(t[n][i]));}}
    return error/std::max(1e-10,scale);
}
struct Run {
    Device& device;CompiledWorld world;Runtime runtime;id<MTLBuffer> statuses;
    Run(Device& d,const WorldSource& s):device(d),world(cook(s)){
        const auto path=std::filesystem::temp_directory_path()/(std::string("numi-reference-")+[[NSUUID UUID] UUIDString].UTF8String+".nmatterpack");
        CompileResult package;package.world=world;std::string error;need(writePackage(package,path,&error),error);CompiledWorld loaded;
        const bool ok=readPackage(path,loaded,nullptr,&error);std::error_code remove;std::filesystem::remove(path,remove);need(ok&&!remove&&loaded.fingerprint==world.fingerprint,"reference package roundtrip: "+error);world=std::move(loaded);
        RuntimeConfiguration c;c.metallib=NUMI_MATTER_METALLIB;c.environmentCount=2;c.adaptiveTransfer=false;c.captureEvents=false;c.captureDiagnostics=true;
        const auto initialized=runtime.initialize(world,c);need(initialized.encoded,initialized.message);statuses=buffer(device.device,std::vector<MRMetalWorldStatusGPU>(2));}
    RuntimeStateSnapshot state(){auto s=runtime.snapshot();need(s.available,s.message);return s;}
    void restore(const RuntimeStateSnapshot& s){const auto r=runtime.restore(s);need(r.encoded,r.message);}
    void step(unsigned index,int reject=-1,int reset=-1){
        auto* incoming=static_cast<MRMetalWorldStatusGPU*>(statuses.contents);for(unsigned e=0;e<2;++e){incoming[e]={};incoming[e].environment=e;}
        auto command=[device.queue commandBuffer];EncodeRequest request;request.commandBuffer=(__bridge void*)command;request.environmentStatuses=(__bridge void*)statuses;
        request.controlStep=index;request.physicsSubsteps=1;request.timestepSeconds=runtime.timestepSeconds();request.runAdaptiveTransfer=false;
        id<MTLBuffer> resets=nil,failure=nil;
        if(reset>=0){std::vector<unsigned> mask((index+1)*2);mask[index*2+unsigned(reset)]=1;resets=buffer(device.device,mask);request.resetMasks=(__bridge void*)resets;request.resetMaskStepStride=2;}
        request.phase=EncodePhase::preDynamics;auto result=runtime.encode(request);need(result.encoded,result.message);
        if(reject>=0){MRMetalWorldStatusGPU bad{};bad.environment=unsigned(reject);bad.code=MR_STEP_DID_NOT_CONVERGE;failure=buffer(device.device,std::vector<MRMetalWorldStatusGPU>{bad});auto blit=[command blitCommandEncoder];[blit copyFromBuffer:failure sourceOffset:0 toBuffer:statuses destinationOffset:unsigned(reject)*sizeof(bad) size:sizeof(bad)];[blit endEncoding];}
        request.phase=EncodePhase::postCommit;result=runtime.encode(request);need(result.encoded,result.message);[command commit];[command waitUntilCompleted];need(command.status==MTLCommandBufferStatusCompleted,"integrated reference command failed");
        const auto after=state();for(unsigned e=0;e<2;++e)if(int(e)!=reject)need(after.statuses[e].code==NM_STATUS_SUCCESS,"integrated reference step="+std::to_string(index)+" env="+std::to_string(e)+" status="+std::to_string(after.statuses[e].code)+" residual="+number(after.statuses[e].diagnostics.z));
        if(reject>=0)need(after.statuses[unsigned(reject)].code!=NM_STATUS_SUCCESS,"injected reference rejection lost");(void)resets;(void)failure;
    }
};
bool physicalSame(const RuntimeStateSnapshot& a,const RuntimeStateSnapshot& b){return same(a.femNodes,b.femNodes)&&same(a.femFields,b.femFields)&&same(a.femMaterialState,b.femMaterialState)&&same(a.femTopologyTetrahedra,b.femTopologyTetrahedra)&&same(a.femTopologyNodes,b.femTopologyNodes)&&same(a.cohesiveFaces,b.cohesiveFaces)&&same(a.punctureChannels,b.punctureChannels)&&same(a.topologyStates,b.topologyStates)&&same(a.environmentParameters,b.environmentParameters)&&same(a.identification,b.identification);}
void contactRHSWitnessCheck(Device& device,WorldSource authored) {
    authored.environmentCount=1;
    const auto execute=[&](bool capture) {
        if(capture)setenv("NM_FEM_CONTACT_RHS_WITNESS","1",1);else unsetenv("NM_FEM_CONTACT_RHS_WITNESS");
        Runtime runtime;RuntimeConfiguration c;c.metallib=NUMI_MATTER_METALLIB;
        c.environmentCount=1;c.adaptiveTransfer=false;c.captureDiagnostics=true;
        const auto initialized=runtime.initialize(cook(authored),c);need(initialized.encoded,initialized.message);
        auto statuses=buffer(device.device,std::vector<MRMetalWorldStatusGPU>(1));
        auto command=[device.queue commandBuffer];EncodeRequest request;
        request.commandBuffer=(__bridge void*)command;request.environmentStatuses=(__bridge void*)statuses;
        request.controlStep=0;request.physicsSubsteps=1;request.timestepSeconds=runtime.timestepSeconds();
        request.runAdaptiveTransfer=false;request.phase=EncodePhase::preDynamics;
        auto result=runtime.encode(request);need(result.encoded,result.message);
        request.phase=EncodePhase::postCommit;result=runtime.encode(request);need(result.encoded,result.message);
        [command commit];[command waitUntilCompleted];
        need(command.status==MTLCommandBufferStatusCompleted,"contact RHS diagnostic command failed");
        auto state=runtime.snapshot();need(state.available&&state.statuses[0].code==NM_STATUS_SUCCESS,
            "contact RHS fixture did not accept its physical step");
        return state;
    };
    const auto control=execute(false),captured=execute(true);
    unsetenv("NM_FEM_CONTACT_RHS_WITNESS");
    need(physicalSame(control,captured),"read-only RHS witness changed accepted physical state");
    std::cout<<"contact_rhs_witness=PASS one_environment=true accepted_step_parity=bitwise callback_lifetime=exercised\n";
}


unsigned cpuCheckCount=0;
void cpuChecks(const WorldSource& authored){
    const auto w=cook(authored);need(w.fem.nodes.size()==5&&w.fem.tetrahedra.size()==2,"reference fixture duplicated shared nodes");
    need((w.objects[0].flags&NM_OBJECT_FEM_REFERENCE_CONFIGURATION)!=0,"reference ownership absent");
    std::vector<double> mass(5);double elementMass=0;
    constexpr double volume=.015625*.015625*.015625/6;
    for(const auto& t:w.fem.tetrahedra){need(t.inverseRestRow0.w==float(volume),"reference volume came from loaded geometry");
        const double m=double(w.materials[t.identity.x].bulk.x)*double(t.inverseRestRow0.w);elementMass+=m;
        for(unsigned n:{t.nodes.x,t.nodes.y,t.nodes.z,t.nodes.w})mass[n]+=.25*m;}
    Vec referenceMoment{},currentMoment{};double nodalMass=0;
    for(unsigned n=0;n<5;++n){const auto& node=w.fem.nodes[n];const float m=float(mass[n]),inv=n<3?0.f:float(1/mass[n]);
        need(node.positionAndMass.w==m&&node.velocityAndInverseMass.w==inv,"reference mass/inverse not the canonical reference-density sum");
        need(xyz(node.positionAndMass)==authored.objects[0].femNodes[n],"initial current coordinates lost");
        need(xyz(node.restAndFixed)==authored.objects[0].femReferenceNodes[n],"reference coordinates lost");
        nodalMass+=m;for(unsigned j=0;j<3;++j){referenceMoment[j]+=m*xyz(node.restAndFixed)[j];currentMoment[j]+=m*xyz(node.positionAndMass)[j];}}
    need(std::abs(nodalMass-elementMass)<1e-7*elementMass,"mechanical reference mass not conserved within FP32 rounding");
    Vec referenceCenter{},currentCenter{};for(unsigned j=0;j<3;++j){referenceCenter[j]=referenceMoment[j]/nodalMass;currentCenter[j]=currentMoment[j]/nodalMass;
        need(xyz(w.adaptive[0].referenceCenter)[j]==float(referenceCenter[j]),"reference COM uses loaded positions");
        need(xyz(w.adaptive[0].centerAndRadius)[j]==float(currentCenter[j]),"initial COM uses unloaded reference positions");}
    Matrix nodeInertia{},elementInertia{};
    for(unsigned n=0;n<5;++n){const Vec r=sub(xyz(w.fem.nodes[n].positionAndMass),currentCenter);const auto xx=outer(r,r);for(unsigned i=0;i<9;++i)nodeInertia[i]+=float(mass[n])*((i%4==0?dot(r,r):0)-xx[i]);}
    for(const auto& t:w.fem.tetrahedra){const double quarter=.25*double(w.materials[t.identity.x].bulk.x)*double(t.inverseRestRow0.w);
        for(unsigned n:{t.nodes.x,t.nodes.y,t.nodes.z,t.nodes.w}){const Vec r=sub(authored.objects[0].femNodes[n],currentCenter);const auto xx=outer(r,r);for(unsigned i=0;i<9;++i)elementInertia[i]+=quarter*((i%4==0?dot(r,r):0)-xx[i]);}}
    double inertiaError=0,inertiaScale=0;for(unsigned i=0;i<9;++i){inertiaError=std::max(inertiaError,std::abs(nodeInertia[i]-elementInertia[i]));inertiaScale=std::max(inertiaScale,std::abs(elementInertia[i]));}
    need(inertiaError<1e-7*inertiaScale,"initial lumped inertia not reference-mass weighted");++cpuCheckCount;
    const Matrix expectedF{1.015625,.0078125,0,0,1,0,0,0,1};const auto input=manufactured(w);
    for(unsigned ti=0;ti<2;++ti)need(gradient(w,input,0,ti)==expectedF,"known affine initial F is not initial edges times reference inverse");++cpuCheckCount;
    auto changed=authored;changed.objects[0].femNodes=changed.objects[0].femReferenceNodes;const auto relaxed=cook(changed);
    for(unsigned n=0;n<5;++n)need(relaxed.fem.nodes[n].positionAndMass.w==w.fem.nodes[n].positionAndMass.w&&relaxed.fem.nodes[n].velocityAndInverseMass.w==w.fem.nodes[n].velocityAndInverseMass.w,"current deformation changed reference mass");
    need(same(relaxed.fem.tetrahedra,w.fem.tetrahedra)&&relaxed.fingerprint!=w.fingerprint,"initial state/reference fingerprint ownership invalid");++cpuCheckCount;
    changed=authored;changed.objects[0].femReferenceSourceIdentity[0]^=1;need(cook(changed).fingerprint!=w.fingerprint,"reference source identity not fingerprinted");++cpuCheckCount;
    changed=authored;changed.objects[0].femReferenceNodes[3][2]*=1.125;need(cook(changed).fingerprint!=w.fingerprint,"reference geometry not fingerprinted");++cpuCheckCount;
    auto legacy=authored;legacy.objects[0].femReferenceNodes.clear();legacy.objects[0].femReferenceSourceIdentity={};const auto old=cook(legacy);
    need(!(old.objects[0].flags&NM_OBJECT_FEM_REFERENCE_CONFIGURATION),"empty reference changed legacy flag");
    for(const auto& n:old.fem.nodes)need(xyz(n.positionAndMass)==xyz(n.restAndFixed),"empty reference changed legacy rest initialization");
    for(const auto& t:old.fem.tetrahedra)need(t.inverseRestRow0.w>float(volume),"legacy reference no longer uses initial geometry");++cpuCheckCount;
    const auto reject=[&](const char* label,const std::function<void(WorldSource&)>& change){auto s=authored;change(s);const auto c=compileWorld(s,{.maximumRateExponent=0,.emitSpecializedMetal=false});need(!c.succeeded(),std::string("reference source accepted ")+label);++cpuCheckCount;};
    reject("missing identity",[](auto& s){s.objects[0].femReferenceSourceIdentity={};});
    reject("orphan identity",[](auto& s){s.objects[0].femReferenceNodes.clear();});
    reject("short reference",[](auto& s){s.objects[0].femReferenceNodes.pop_back();});
    reject("long reference",[](auto& s){s.objects[0].femReferenceNodes.push_back({1,1,1});});
    reject("nonfinite reference",[](auto& s){s.objects[0].femReferenceNodes[0][0]=std::numeric_limits<double>::quiet_NaN();});
    reject("FP32 overflowing reference",[](auto& s){s.objects[0].femReferenceNodes[0][0]=1e100;});
    reject("collapsed reference",[](auto& s){s.objects[0].femReferenceNodes[3]=s.objects[0].femReferenceNodes[0];});
    reject("inverted reference",[](auto& s){s.objects[0].femReferenceNodes[3][2]*=-1;});
    reject("collapsed initial",[](auto& s){s.objects[0].femNodes[3]=s.objects[0].femNodes[0];});
    reject("inverted initial",[](auto& s){s.objects[0].femNodes[3][2]=s.objects[0].femNodes[4][2];});
    reject("nonfinite initial",[](auto& s){s.objects[0].femNodes[0][0]=std::numeric_limits<double>::infinity();});
    reject("out of material domain",[](auto& s){for(auto& x:s.objects[0].femNodes)for(double& a:x)a*=100;});
    reject("automatic",[](auto& s){s.objects[0].automaticRepresentation=true;});
    reject("MPM",[](auto& s){s.objects[0].representation=Representation::mpm;});
    reject("mixed",[](auto& s){s.objects[0].mixedFEM=true;});
    reject("multiphysics",[](auto& s){s.objects[0].multiphysics.enabled=true;});
    reject("field boundary",[](auto& s){FieldBoundarySource b;b.node=0;b.flags=NM_FIELD_DIRICHLET_TEMPERATURE;b.stableIdentifier=1;s.objects[0].fieldBoundaries={b};});
    reject("identification",[](auto& s){s.objects[0].identifiable=true;});
    reject("identified selected material",[](auto& s){s.materials[0].parameters[0].identifiable=true;});
    reject("missing density",[](auto& s){set(s.materials[0],"density",0);});
    reject("adaptive",[](auto& s){s.objects[0].adaptive=true;});
    reject("mutable topology",[](auto& s){s.objects[0].mutationPolicy.enabled=true;});
    reject("mutation command",[](auto& s){MutationCommandSource c;c.stableIdentifier=1;c.target=0;s.objects[0].mutationCommands={c};});
    reject("other mutable object",[](auto& s){auto other=s.objects[0];other.name="mutable_other";other.femReferenceNodes.clear();other.femReferenceSourceIdentity={};other.mutationPolicy.enabled=true;s.objects.push_back(other);});
    const auto rejectCooked=[&](const char* label,const std::function<void(CompiledWorld&)>& change){auto c=w;change(c);c.fingerprint=compiledWorldFingerprint(c);std::string error;need(!validateCompiledWorldLayout(c,&error),std::string("resealed cooked reference accepted ")+label);++cpuCheckCount;};
    rejectCooked("reference identity",[](auto& c){c.objects[0].referenceSourceIdentity[0]=c.objects[0].referenceSourceIdentity[1]=c.objects[0].referenceSourceIdentity[2]=c.objects[0].referenceSourceIdentity[3]=0;});
    rejectCooked("reference node",[](auto& c){c.fem.nodes[3].restAndFixed.x=.001f;});
    rejectCooked("inverse reference",[](auto& c){c.fem.tetrahedra[0].inverseRestRow0.x=std::nextafter(c.fem.tetrahedra[0].inverseRestRow0.x,0.f);});
    rejectCooked("reference volume",[](auto& c){c.fem.tetrahedra[0].inverseRestRow0.w*=2;});
    rejectCooked("reference center",[](auto& c){c.adaptive[0].referenceCenter.x=.5f;});
    rejectCooked("initial center",[](auto& c){c.adaptive[0].centerAndRadius.x=.5f;});
    rejectCooked("object reference mass",[](auto& c){c.adaptive[0].massAndError.x*=2;});
    rejectCooked("reference row padding",[](auto& c){c.fem.tetrahedra[0].inverseRestRow1.w=1;});
    rejectCooked("inverted initial",[](auto& c){c.fem.nodes[3].positionAndMass.z=c.fem.nodes[4].positionAndMass.z;});
    rejectCooked("nodal mass",[](auto& c){c.fem.nodes[3].positionAndMass.w=std::nextafter(c.fem.nodes[3].positionAndMass.w,1.f);});
    rejectCooked("noncanonical fixed tag",[](auto& c){c.fem.nodes[3].restAndFixed.w=.75f;});
    const auto path=std::filesystem::temp_directory_path()/(std::string("numi-reference-cpu-")+[[NSUUID UUID] UUIDString].UTF8String+".nmatterpack");
    CompileResult package;package.world=w;std::string error;need(writePackage(package,path,&error),error);CompiledWorld loaded;
    const bool ok=readPackage(path,loaded,nullptr,&error);std::error_code removed;std::filesystem::remove(path,removed);
    need(ok&&!removed&&loaded.fingerprint==w.fingerprint&&same(loaded.objects,w.objects)&&same(loaded.fem.nodes,w.fem.nodes)&&same(loaded.fem.tetrahedra,w.fem.tetrahedra),"reference package roundtrip "+error);++cpuCheckCount;
    std::cout<<"reference_compiler_checks="<<cpuCheckCount<<" reference_volume_m3="<<volume<<" reference_mass_kg="<<elementMass<<" initial_J="<<ref::determinant(expectedF)<<" inertia_relative_error="<<inertiaError/inertiaScale<<'\n';
}
void referenceDisplacementChecks(const WorldSource& regionalReference){
    auto authored=regionalReference;authored.objects[0].femReferenceDisplacementGradient=true;
    const auto w=cook(authored);const auto& object=w.objects[0];
    need((object.flags&NM_OBJECT_FEM_REFERENCE_DISPLACEMENT_GRADIENT)!=0&&
         (object.flags&NM_OBJECT_FEM_REFERENCE_CONFIGURATION)!=0&&
         (object.flags&NM_OBJECT_FEM_REGIONAL_MATERIAL)!=0,
         "reference-displacement ownership flags were not cooked");
    for(const auto& t:w.fem.tetrahedra)
        need((t.identity.w&NM_TETRAHEDRON_REFERENCE_DISPLACEMENT_GRADIENT)!=0,
             "reference-displacement element flag was not cooked");
    for(const auto& node:w.fem.nodes)
        need(node.referenceDisplacementAndMode.w==1.0f&&node.referenceDisplacementLow.w==0.0f&&
             mrCompensatedCanonicalScalar(node.referenceDisplacementAndMode.x,node.referenceDisplacementLow.x)&&
             mrCompensatedCanonicalScalar(node.referenceDisplacementAndMode.y,node.referenceDisplacementLow.y)&&
             mrCompensatedCanonicalScalar(node.referenceDisplacementAndMode.z,node.referenceDisplacementLow.z)&&
             node.positionAndMass.x==mrCompensatedProjectionScalar(node.restAndFixed.x,
                 node.referenceDisplacementAndMode.x,node.referenceDisplacementLow.x)&&
             node.positionAndMass.y==mrCompensatedProjectionScalar(node.restAndFixed.y,
                 node.referenceDisplacementAndMode.y,node.referenceDisplacementLow.y)&&
             node.positionAndMass.z==mrCompensatedProjectionScalar(node.restAndFixed.z,
                 node.referenceDisplacementAndMode.z,node.referenceDisplacementLow.z),
             "reference-displacement node state is not a canonical high/low pair");
    auto loaded=manufactured(w);const Matrix expected{1.015625,.0078125,0,0,1,0,0,0,1};
    const auto highOnly=loaded;
    auto& pairedNode=loaded.nodes[3];
    pairedNode.referenceDisplacementLow.x=0x1p-35f;
    pairedNode.positionAndMass.x=mrCompensatedProjectionScalar(
        pairedNode.restAndFixed.x,pairedNode.referenceDisplacementAndMode.x,
        pairedNode.referenceDisplacementLow.x);
    need(mrCompensatedCanonicalScalar(pairedNode.referenceDisplacementAndMode.x,
             pairedNode.referenceDisplacementLow.x),"finite-difference low limb is not normalized");
    const Matrix highOnlyGradient=gradient(w,highOnly,0,0);
    const Matrix pairGradient=gradient(w,loaded,0,0);
    need(std::abs((pairGradient[2]-highOnlyGradient[2])-0x1p-29)<1e-15,
         "independent CPU FEM gradient ignored the reference-displacement low limb");++cpuCheckCount;
    double affineError=0;
    for(unsigned ti=0;ti<w.dispatch.tetrahedronCount;++ti){const auto actual=gradient(w,loaded,0,ti);
        for(unsigned i=0;i<9;++i)affineError=std::max(affineError,std::abs(actual[i]-expected[i]));}
    need(affineError<1e-6,"reference-displacement affine F differs from I+grad(u)");++cpuCheckCount;

    auto restSource=authored;restSource.objects[0].femNodes=restSource.objects[0].femReferenceNodes;
    const auto rest=cook(restSource);const auto restInput=manufactured(rest);double restError=0;
    for(const auto& t:rest.fem.tetrahedra){const auto actual=detail::femReferenceDeterminantInterval(t,rest.fem.nodes.data());
        need(actual.nominal==1.0f&&actual.strictlyAdmitted(rest.materials[t.identity.x].validity),
             "zero displacement did not produce exact executable rest J=1");
    }
    for(unsigned ti=0;ti<rest.dispatch.tetrahedronCount;++ti){const auto f=gradient(rest,restInput,0,ti);
        for(unsigned i=0;i<9;++i)restError=std::max(restError,std::abs(f[i]-ref::identity[i]));}
    need(restError==0.0,"CPU reference-displacement rest gradient was not exactly identity");++cpuCheckCount;

    auto rotatedSource=authored;const Matrix rotation{0,-1,0,1,0,0,0,0,1};const Vec translation{.03125,-.015625,.0078125};
    for(unsigned n=0;n<rotatedSource.objects[0].femReferenceNodes.size();++n){auto p=transform(rotation,rotatedSource.objects[0].femReferenceNodes[n]);
        for(unsigned j=0;j<3;++j)p[j]+=translation[j];rotatedSource.objects[0].femNodes[n]=p;}
    const auto rotated=cook(rotatedSource);const auto rotatedInput=manufactured(rotated);double rotationError=0;
    for(unsigned ti=0;ti<rotated.dispatch.tetrahedronCount;++ti){const auto f=gradient(rotated,rotatedInput,0,ti);
        for(unsigned i=0;i<9;++i)rotationError=std::max(rotationError,std::abs(f[i]-rotation[i]));}
    need(rotationError<1e-6,"reference-displacement rigid rotation did not produce F=R");++cpuCheckCount;

    const auto legacy=cook(regionalReference);
    need(w.fingerprint!=legacy.fingerprint&&
         !(legacy.objects[0].flags&NM_OBJECT_FEM_REFERENCE_DISPLACEMENT_GRADIENT),
         "opt-in kinematics was not separately fingerprinted or changed legacy defaults");++cpuCheckCount;
    const auto rejectSource=[&](const char* label,const std::function<void(WorldSource&)>& change){auto s=authored;change(s);
        const auto c=compileWorld(s,{.maximumRateExponent=0,.emitSpecializedMetal=false});
        need(!c.succeeded(),std::string("reference-displacement source accepted ")+label);++cpuCheckCount;};
    rejectSource("missing regional field",[](auto& s){s.objects[0].femMaterialIndices.clear();s.objects[0].femMaterialSourceIdentity={};});
    rejectSource("missing reference coordinates",[](auto& s){s.objects[0].femReferenceNodes.clear();s.objects[0].femReferenceSourceIdentity={};});
    rejectSource("adaptive representation",[](auto& s){s.objects[0].adaptive=true;});
    rejectSource("mutable topology",[](auto& s){s.objects[0].mutationPolicy.enabled=true;});
    rejectSource("mixed FEM",[](auto& s){s.objects[0].mixedFEM=true;});
    rejectSource("multiphysics",[](auto& s){s.objects[0].multiphysics.enabled=true;});
    rejectSource("nodal field",[](auto& s){FieldBoundarySource b;b.node=0;b.flags=NM_FIELD_DIRICHLET_TEMPERATURE;b.stableIdentifier=1;s.objects[0].fieldBoundaries={b};});
    rejectSource("identification",[](auto& s){s.objects[0].identifiable=true;});
    const auto rejectCooked=[&](const char* label,const std::function<void(CompiledWorld&)>& change){auto c=w;change(c);
        c.fingerprint=compiledWorldFingerprint(c);std::string error;
        need(!validateCompiledWorldLayout(c,&error),std::string("reference-displacement cooked layout accepted ")+label);++cpuCheckCount;};
    rejectCooked("object mode without element mode",[](auto& c){c.fem.tetrahedra[0].identity.w&=~NM_TETRAHEDRON_REFERENCE_DISPLACEMENT_GRADIENT;});
    rejectCooked("element mode without object mode",[](auto& c){c.objects[0].flags&=~NM_OBJECT_FEM_REFERENCE_DISPLACEMENT_GRADIENT;});
    rejectCooked("reference low reserved component",[](auto& c){c.fem.nodes[3].referenceDisplacementLow.w=1.0f;});
    rejectCooked("nonfinite reference low limb",[](auto& c){c.fem.nodes[3].referenceDisplacementLow.x=std::numeric_limits<float>::infinity();});
    rejectCooked("noncanonical reference pair",[](auto& c){c.fem.nodes[3].referenceDisplacementLow.x=0.125f;});
    const auto path=std::filesystem::temp_directory_path()/(std::string("numi-reference-displacement-")+[[NSUUID UUID] UUIDString].UTF8String+".nmatterpack");
    CompileResult package;package.world=w;std::string error;need(writePackage(package,path,&error),error);CompiledWorld decoded;
    const bool ok=readPackage(path,decoded,nullptr,&error);std::error_code removed;
    need(ok&&!removed&&decoded.fingerprint==w.fingerprint&&same(decoded.objects,w.objects)&&
         same(decoded.fem.nodes,w.fem.nodes)&&same(decoded.fem.tetrahedra,w.fem.tetrahedra),
         "reference-displacement package roundtrip "+error);++cpuCheckCount;
    {
        std::fstream packageBytes(path,std::ios::in|std::ios::out|std::ios::binary);
        need(packageBytes.good(),"could not reopen Matter package for stale-ABI guard check");
        constexpr std::streamoff abiOffset = 16 + 2 * std::streamoff(sizeof(std::uint32_t));
        const std::uint32_t previousAbi = NM_MATTER_ABI_VERSION - 1u;
        packageBytes.seekp(abiOffset);
        packageBytes.write(reinterpret_cast<const char*>(&previousAbi),sizeof(previousAbi));
        packageBytes.flush();
        need(packageBytes.good(),"could not encode stale Matter ABI fixture");
    }
    CompiledWorld staleAbi;error.clear();
    const bool staleAbiAccepted=readPackage(path,staleAbi,nullptr,&error);
    const bool removedPackage=std::filesystem::remove(path,removed);
    need(!staleAbiAccepted&&removedPackage&&!removed&&error=="matter package ABI mismatch: recook required",
         "pre-ABI40 package was not rejected by the explicit ABI guard: "+error);++cpuCheckCount;
    std::cout<<"reference_displacement_cpu=pass checks="<<cpuCheckCount<<" affine_F_max_error="<<affineError
        <<" rest_F_max_error="<<restError<<" rigid_rotation_F_max_error="<<rotationError
        <<" default_path=unchanged fingerprint=bound package=roundtrip\n";
}
void thinSkewArithmeticChecks(const WorldSource& regionalReference){
    const auto oldWorld=cook(thinSkewSource(regionalReference,false));
    const auto newWorld=cook(thinSkewSource(regionalReference,true));
    double oldRestFError=0,newRestFError=0,oldGreenStrainError=0;
    for(unsigned ti=0;ti<newWorld.dispatch.tetrahedronCount;++ti){
        const auto oldF=executableRestF32(oldWorld,ti,false);
        const auto newF=executableRestF32(newWorld,ti,true);
        Matrix green=ref::sub(ref::multiply(ref::transpose(oldF),oldF),ref::identity);
        for(double& value:green)value*=.5;
        for(unsigned i=0;i<9;++i){
            oldRestFError=std::max(oldRestFError,std::abs(oldF[i]-ref::identity[i]));
            newRestFError=std::max(newRestFError,std::abs(newF[i]-ref::identity[i]));
            oldGreenStrainError=std::max(oldGreenStrainError,std::abs(green[i]));
        }
        const auto interval=detail::femReferenceDeterminantInterval(
            newWorld.fem.tetrahedra[ti],newWorld.fem.nodes.data());
        need(interval.nominal==1.0f&&interval.strictlyAdmitted(
            newWorld.materials[newWorld.fem.tetrahedra[ti].identity.x].validity),
            "thin translated reference did not preserve exact rest J");
    }
    need(oldRestFError>0.0,"thin/skew control unexpectedly has exact legacy FP32 identity");
    need(newRestFError==0.0,"reference-displacement thin/skew rest F is not exact identity");++cpuCheckCount;
    std::cout<<"reference_displacement_thin_skew_cpu=pass checks="<<cpuCheckCount
        <<" horizontal_scale_m=0.00421 thickness_m=3.07e-5 translated_origin_m=0.05219"
        <<" legacy_rest_F_max_error="<<oldRestFError
        <<" legacy_green_strain_max="<<oldGreenStrainError
        <<" displacement_rest_F_max_error="<<newRestFError<<'\n';
}
void generalReferenceChecks(const WorldSource& authored){
    auto s=authored;auto& o=s.objects[0];
    // Rotation/shear with every matrix entry nonzero, at a translated
    // reference origin. This exercises the general adjugate and FP32 cook.
    const Matrix a{1,.25,.0625,-.125,1.125,.1875,.125,-.0625,.875};
    const Matrix f{1.015625,.0078125,0,0,1,0,0,0,1};
    const Vec origin{.3125,-.4375,.625},translation{.03125,-.015625,.0078125};
    for(unsigned n=0;n<o.femReferenceNodes.size();++n){auto x=transform(a,o.femReferenceNodes[n]);for(unsigned j=0;j<3;++j)x[j]+=origin[j];
        auto p=transform(f,x);for(unsigned j=0;j<3;++j)p[j]+=translation[j];o.femReferenceNodes[n]=x;o.femNodes[n]=p;}
    const auto w=cook(s);const auto input=manufactured(w);double inverseError=0,deformationError=0;
    for(unsigned ti=0;ti<2;++ti){const auto& t=w.fem.tetrahedra[ti];const auto x0=xyz(w.fem.nodes[t.nodes.x].restAndFixed);
        const Matrix edges=columns(sub(xyz(w.fem.nodes[t.nodes.y].restAndFixed),x0),sub(xyz(w.fem.nodes[t.nodes.z].restAndFixed),x0),sub(xyz(w.fem.nodes[t.nodes.w].restAndFixed),x0));
        const auto independentInverse=ref::transpose(ref::inverseTranspose(edges)),stored=inverseRest(t),actualF=gradient(w,input,0,ti);
        for(unsigned j=0;j<9;++j){inverseError=std::max(inverseError,std::abs(stored[j]-independentInverse[j])/std::max(1.,std::abs(independentInverse[j])));deformationError=std::max(deformationError,std::abs(actualF[j]-f[j]));}}
    need(inverseError<1e-7&&deformationError<1e-6,"general affine reference did not preserve independent inverse/F");++cpuCheckCount;
    const auto path=std::filesystem::temp_directory_path()/(std::string("numi-reference-general-")+[[NSUUID UUID] UUIDString].UTF8String+".nmatterpack");
    CompileResult package;package.world=w;std::string error;need(writePackage(package,path,&error),error);CompiledWorld loaded;
    const bool ok=readPackage(path,loaded,nullptr,&error);std::error_code removed;std::filesystem::remove(path,removed);
    need(ok&&!removed&&loaded.fingerprint==w.fingerprint&&same(loaded.fem.tetrahedra,w.fem.tetrahedra)&&same(loaded.fem.nodes,w.fem.nodes),"non-axis-aligned reference package rejected "+error);++cpuCheckCount;
    std::cout<<"general_reference_compiler_checks="<<cpuCheckCount<<" inverse_relative_error="<<inverseError<<" affine_F_max_error="<<deformationError<<" origin_translated=true\n";
}
WorldSource boundarySource(const WorldSource& authored,float stretch){
    auto s=authored;auto& o=s.objects[0];o.femMaterialIndices.clear();o.femMaterialSourceIdentity={};o.femMaterialFrameRotations.clear();o.femMaterialFrameSourceIdentity={};
    const float a=.00037f;
    o.femReferenceNodes={{{0,0,0}},{{a,0,0}},{{0,a,0}},{{0,0,a}},{{0,0,-a}}};o.femNodes=o.femReferenceNodes;
    for(auto& x:o.femNodes)x[2]=float(float(x[2])*stretch);
    for(auto& m:s.materials)m.minimumDeterminant=.2;
    return s;
}
void executableBoundaryChecks(const WorldSource& authored){
    const auto good=boundarySource(authored,.201f);const auto w=cook(good);const float a=.00037f,z=a*.2f;
    auto boundary=w;boundary.fem.nodes[3].positionAndMass.z=z;boundary.fem.nodes[4].positionAndMass.z=-z;
    const auto interval=detail::femReferenceDeterminantInterval(boundary.fem.tetrahedra[0],boundary.fem.nodes.data());
    const auto limits=w.materials[0].validity;const double oldRatio=double(z)/a;
    need(oldRatio>limits.x&&interval.nominal<limits.x,"FP32 inverse determinant boundary repro changed");
    need(!interval.strictlyAdmitted(limits)&&interval.possiblyAdmissible(limits),"FP32 rounding interval did not classify ambiguous boundary");++cpuCheckCount;
    const auto rejected=compileWorld(boundarySource(authored,.2f),{.maximumRateExponent=0,.emitSpecializedMetal=false});
    need(!rejected.succeeded()&&diagnostic(rejected.diagnostics).find("executable FP32 determinant interior")!=std::string::npos,"source admitted ratio-valid but executable-ambiguous boundary");++cpuCheckCount;
    boundary.fingerprint=compiledWorldFingerprint(boundary);std::string error;
    need(!validateCompiledWorldLayout(boundary,&error)&&error.find("reference coordinates")!=std::string::npos,"resealed cooked geometry admitted executable-ambiguous boundary");++cpuCheckCount;
    const auto interior=detail::femReferenceDeterminantInterval(w.fem.tetrahedra[0],w.fem.nodes.data());need(interior.strictlyAdmitted(limits),"safe interior was rejected");++cpuCheckCount;
    auto outside=boundary;outside.fem.nodes[3].positionAndMass.z=a*.19f;outside.fem.nodes[4].positionAndMass.z=-a*.19f;
    need(!detail::femReferenceDeterminantInterval(outside.fem.tetrahedra[0],outside.fem.nodes.data()).possiblyAdmissible(limits),"provably outside interval was admitted");++cpuCheckCount;
    auto overflow=w.fem.tetrahedra[0];overflow.inverseRestRow0.x=std::numeric_limits<float>::max();overflow.inverseRestRow1.y=std::numeric_limits<float>::max();
    const auto unsafe=detail::femReferenceDeterminantInterval(overflow,w.fem.nodes.data());need(!unsafe.strictlyAdmitted(limits)&&!unsafe.possiblyAdmissible(limits),"unbounded FP32 intermediate overflow admitted");++cpuCheckCount;
    auto subnormal=w.fem.tetrahedra[0];subnormal.inverseRestRow0.x=std::numeric_limits<float>::denorm_min();
    const auto subnormalInverse=detail::femReferenceDeterminantInterval(subnormal,w.fem.nodes.data());
    need(!subnormalInverse.strictlyAdmitted(limits)&&!subnormalInverse.possiblyAdmissible(limits),"subnormal inverse input admitted despite FTZ ambiguity");++cpuCheckCount;
    auto subnormalNodes=w.fem.nodes;subnormalNodes[0].positionAndMass.x=std::numeric_limits<float>::denorm_min();
    const auto subnormalPosition=detail::femReferenceDeterminantInterval(w.fem.tetrahedra[0],subnormalNodes.data());
    need(!subnormalPosition.strictlyAdmitted(limits)&&!subnormalPosition.possiblyAdmissible(limits),"subnormal current coordinate admitted despite FTZ ambiguity");++cpuCheckCount;
    std::cout<<"reference_executable_boundary_checks="<<cpuCheckCount<<" old_ratio="<<oldRatio<<" host_nominal_FP32_J="<<interval.nominal<<" minimum_J="<<limits.x
        <<" determinant_interval_center="<<interval.center<<" determinant_interval_radius="<<interval.radius<<" source_cooked_boundary=rejected snapshot_boundary=ambiguous_not_certified\n";
}
void boundaryRestoreChecks(Device& d,const WorldSource& authored){
    Run run(d,boundarySource(authored,.201f));const auto initial=run.state();auto boundary=initial;const float a=.00037f,z=a*.2f;
    for(unsigned e=0;e<2;++e){boundary.femNodes[e*5+3].positionAndMass.z=z;boundary.femNodes[e*5+4].positionAndMass.z=-z;}
    run.restore(boundary);need(physicalSame(boundary,run.state()),"rounding-ambiguous boundary restore changed state");
    auto outside=boundary;outside.femNodes[3].positionAndMass.z=a*.19f;outside.femNodes[4].positionAndMass.z=-a*.19f;
    const auto result=run.runtime.restore(outside);need(!result.encoded&&physicalSame(boundary,run.state()),"provably outside reference snapshot accepted or mutated state");
    run.restore(initial);need(physicalSame(initial,run.state()),"safe initial state could not be restored after boundary control");
    std::cout<<"reference_boundary_restore=overlap_accepted_without_strict_GPU_certification provably_outside=denied restoration=unchanged\n";
}
void directChecks(Device& d,const WorldSource& authored,const char* label){
    const auto w=cook(authored);const auto input=manufactured(w);
    const Oracle oracle=[&](unsigned ti,const Matrix& f,const Matrix& h,const Matrix&,const Matrix& q){
        if(w.fem.tetrahedra[ti].identity.x==0)return ref::framedGuccione(f,h,q);
        auto r=ref::neoHookean(ref::multiply(f,q),ref::multiply(h,q));r.stress=ref::multiply(r.stress,ref::transpose(q));r.tangent=ref::multiply(r.tangent,ref::transpose(q));return r;};
    const auto f=dispatch(d,w,input,false),j=dispatch(d,w,input,true);
    const double fe=compare(w,input,f,false,oracle),je=compare(w,input,j,true,oracle),fd=finiteDifference(d,w,input,j);
    need(fe<3e-4&&je<3e-4&&fd<3e-3,"production reference prestress/tangent failed force="+number(fe)+" tangent="+number(je)+" FD="+number(fd));
    double forceScale=0,net=0;for(const auto& raw:f){Vec sum{};for(const auto& v:forces(raw))for(unsigned i=0;i<3;++i){sum[i]+=v[i];forceScale=std::max(forceScale,std::abs(v[i]));}for(double x:sum)net=std::max(net,std::abs(x));}
    need(forceScale>1e-3&&net<1e-6*forceScale,"prestress is missing or internal element forces violate translation invariance");
    auto relaxed=authored;relaxed.objects[0].femNodes=relaxed.objects[0].femReferenceNodes;const auto rw=cook(relaxed);const auto rf=dispatch(d,rw,manufactured(rw),false);
    double zeroScale=0;for(const auto& raw:rf)for(const auto& v:forces(raw))for(double x:v)zeroScale=std::max(zeroScale,std::abs(x));
    need(zeroScale<1e-4*forceScale,"supplied reference zero-load control has unexpected stress");
    std::cout<<"reference_direct_case="<<label<<" force_relative_error="<<fe<<" tangent_relative_error="<<je<<" finite_difference_relative_error="<<fd<<" initial_prestress_nodal_force_N="<<forceScale<<" internal_force_balance_relative="<<net/forceScale<<" unloaded_force_N="<<zeroScale<<'\n';
}
void rigidRotationChecks(Device& d,const WorldSource& regionalReference){
    auto authored=regionalReference;auto& object=authored.objects[0];
    object.femReferenceDisplacementGradient=true;
    const Matrix rotation{0,-1,0,1,0,0,0,0,1};const Vec translation{.03125,-.015625,.0078125};
    for(unsigned n=0;n<object.femReferenceNodes.size();++n){auto p=transform(rotation,object.femReferenceNodes[n]);
        for(unsigned j=0;j<3;++j)p[j]+=translation[j];object.femNodes[n]=p;}
    const auto w=cook(authored);const auto input=manufactured(w);
    double cpuError=0;for(unsigned ti=0;ti<w.dispatch.tetrahedronCount;++ti){const auto f=gradient(w,input,0,ti);
        for(unsigned i=0;i<9;++i)cpuError=std::max(cpuError,std::abs(f[i]-rotation[i]));}
    need(cpuError<1e-6,"rigid-rotation CPU kinematics did not produce F=R");
    const Oracle oracle=[&](unsigned ti,const Matrix& f,const Matrix& h,const Matrix&,const Matrix& q){
        if(w.fem.tetrahedra[ti].identity.x==0)return ref::framedGuccione(f,h,q);
        auto r=ref::neoHookean(ref::multiply(f,q),ref::multiply(h,q));
        r.stress=ref::multiply(r.stress,ref::transpose(q));r.tangent=ref::multiply(r.tangent,ref::transpose(q));return r;};
    const auto force=dispatch(d,w,input,false),tangent=dispatch(d,w,input,true);
    double maximumForce=0;for(const auto& item:force)for(const auto& value:forces(item))
        for(double component:value)maximumForce=std::max(maximumForce,std::abs(component));
    const double tangentError=compare(w,input,tangent,true,oracle),fd=finiteDifference(d,w,input,tangent);
    need(maximumForce<1e-4&&tangentError<3e-4&&fd<3e-3,
         "production FEM rigid rotation/tangent check failed force_N="+number(maximumForce)+
         " tangent="+number(tangentError)+" FD="+number(fd));
    std::cout<<"reference_displacement_rigid_rotation=pass cpu_F_max_error="<<cpuError
        <<" production_force_max_N="<<maximumForce<<" tangent_relative_error="<<tangentError
        <<" finite_difference_relative_error="<<fd<<'\n';
}
void thinSkewMetalRestCheck(Device& d,const WorldSource& regionalReference){
    const auto authored=thinSkewSource(regionalReference,true);const auto w=cook(authored);
    const auto input=manufactured(w);const auto values=dispatch(d,w,input,false);double maximumForce=0;
    for(const auto& item:values)for(const auto& value:forces(item))
        for(double component:value)maximumForce=std::max(maximumForce,std::abs(component));
    need(maximumForce==0.0,"production thin/skew reference-rest forces are nonzero: "+number(maximumForce));
    std::cout<<"reference_displacement_thin_skew_metal_rest=pass force_max_N="
        <<maximumForce<<" geometry=translated_skew_30.7um\n";
}
void integratedChecks(Device& device,const WorldSource& authored,unsigned steps,const char* label){
    Run run(device,authored);const auto initial=run.state();RuntimeStateSnapshot one;double motion=0;
    for(unsigned i=0;i<steps;++i){run.step(i);const auto s=run.state();if(i==0)one=s;paired(s.femNodes,"accepted reference nodes");
        for(unsigned n=0;n<s.femNodes.size();++n){need(s.femNodes[n].positionAndMass.w==initial.femNodes[n].positionAndMass.w&&s.femNodes[n].velocityAndInverseMass.w==initial.femNodes[n].velocityAndInverseMass.w,"reference trajectory changed mechanical mass");
            if(n%5<3)need(xyz(s.femNodes[n].positionAndMass)==xyz(initial.femNodes[n].positionAndMass),"fixed initial loaded node snapped to reference");
            const auto delta=sub(xyz(s.femNodes[n].positionAndMass),xyz(initial.femNodes[n].positionAndMass));motion=std::max(motion,std::sqrt(dot(delta,delta)));}}
    const auto final=run.state();need(motion>1e-7,"initial prestress did not cause mechanical relaxation");run.restore(initial);for(unsigned i=0;i<steps;++i)run.step(i);need(physicalSame(final,run.state()),"reference replay not bitwise");
    const auto before=run.state();run.step(steps,1);const auto rejected=run.state();envSame(before.femNodes,rejected.femNodes,1,"rejected reference nodes");envSame(before.femMaterialState,rejected.femMaterialState,1,"rejected reference state");
    const auto deny=[&](const char* name,const std::function<void(RuntimeStateSnapshot&)>& change){auto c=rejected;change(c);const auto result=run.runtime.restore(c);need(!result.encoded&&physicalSame(rejected,run.state()),std::string("reference snapshot accepted or changed state for ")+name);};
    deny("reference coordinates",[](auto& s){s.femNodes[3].restAndFixed.x=.001f;});
    deny("reference center",[](auto& s){s.adaptive[0].referenceCenter.x=.5f;});
    deny("reference operator",[](auto& s){s.femTopologyTetrahedra[0].inverseRestRow0.x=std::nextafter(s.femTopologyTetrahedra[0].inverseRestRow0.x,0.f);});
    deny("reference volume",[](auto& s){s.femTopologyTetrahedra[0].inverseRestRow0.w*=2;});
    deny("connectivity",[](auto& s){std::swap(s.femTopologyTetrahedra[0].nodes.x,s.femTopologyTetrahedra[0].nodes.y);});
    deny("material owner",[](auto& s){++s.femTopologyTetrahedra[0].identity.x;});
    deny("topology lineage",[](auto& s){s.femTopologyNodes[0].identity.x=s.femTopologyNodes[1].identity.x;});
    deny("topology accounting",[](auto& s){s.topologyStates[0].accounting.x=std::nextafter(s.topologyStates[0].accounting.x,1.f);});
    deny("mass",[](auto& s){s.femNodes[3].positionAndMass.w=std::nextafter(s.femNodes[3].positionAndMass.w,1.f);});
    deny("inverse mass",[](auto& s){s.femNodes[3].velocityAndInverseMass.w=std::nextafter(s.femNodes[3].velocityAndInverseMass.w,0.f);});
    deny("fixed constraint",[](auto& s){s.femNodes[3].restAndFixed.w=1;});
    if (authored.objects[0].femReferenceDisplacementGradient) {
        deny("reference-displacement mode tag",[](auto& s){s.femNodes[3].referenceDisplacementAndMode.w=0.0f;});
        deny("reference-displacement low reserved component",[](auto& s){s.femNodes[3].referenceDisplacementLow.w=1.0f;});
        deny("reference-displacement nonfinite low limb",[](auto& s){s.femNodes[3].referenceDisplacementLow.x=std::numeric_limits<float>::quiet_NaN();});
        deny("reference-displacement noncanonical pair",[](auto& s){s.femNodes[3].referenceDisplacementLow.x=0.125f;});
        deny("reference-displacement materialization",[](auto& s){s.femNodes[3].positionAndMass.x=std::nextafter(s.femNodes[3].positionAndMass.x,INFINITY);});
    }
    deny("inverted current geometry",[](auto& s){s.femNodes[3].positionAndMass.z=s.femNodes[4].positionAndMass.z;});
    deny("collapsed current geometry",[](auto& s){const auto p=s.femNodes[0].positionAndMass;s.femNodes[3].positionAndMass.x=p.x;s.femNodes[3].positionAndMass.y=p.y;s.femNodes[3].positionAndMass.z=p.z;});
    deny("nonfinite current geometry",[](auto& s){s.femNodes[3].positionAndMass.x=std::numeric_limits<float>::infinity();});
    deny("fixed density parameter",[](auto& s){s.environmentParameters[0]=std::nextafter(s.environmentParameters[0],0.f);});
    deny("scheduler floor",[](auto& s){++s.schedulers[1].baseExponent;});
    deny("generation",[](auto& s){++s.allocationGeneration;});
    deny("representation",[](auto& s){s.adaptive[0].activeRepresentation=NM_REPRESENTATION_RIGID;});
    if(!authored.objects[0].femMaterialFrameRotations.empty())deny("reference material frame",[](auto& s){s.femTopologyTetrahedra[0].materialFrameRotation={0,0,0,1};});
    run.step(steps+1,-1,1);const auto reset=run.state();envSame(one.femNodes,reset.femNodes,1,"reset to supplied initial loaded nodes");envSame(one.femMaterialState,reset.femMaterialState,1,"reset reference state");
    std::cout<<"reference_runtime_case="<<label<<" accepted_steps="<<steps<<" environments=2 motion_m="<<motion<<" replay=bitwise rollback=isolated reset=loaded_initial_bitwise snapshot_rebinding=denied reference_mass=unchanged\n";
}
} // namespace
int main(int argc,char** argv){@autoreleasepool{try{
    need((argc==2&&std::string(argv[1])=="--backtracking-only")||argc==3||(argc==4&&(std::string(argv[3])=="--cpu-only"||std::string(argv[3])=="--contact-rhs-only")),"usage: fem-reference-check GUCCIONE.nmatter NEO.nmatter [--cpu-only] | --backtracking-only");
    if(argc==2){Device device;backtrackingLaneReductionChecks(device);backtrackingConstitutiveValidityChecks(device);return 0;}
    auto a=parseMatterFile(argv[1]),b=parseMatterFile(argv[2]);need(a.succeeded()&&b.succeeded(),diagnostic(a.diagnostics)+diagnostic(b.diagnostics));
    set(a.material,"density",900);set(b.material,"density",1200); // synthetic fixture only
    const auto simple=source(a.material,b.material),combined=source(a.material,b.material,true);
    if(argc==4&&std::string(argv[3])=="--contact-rhs-only"){Device device;contactRHSWitnessCheck(device,simple);return 0;}
    auto displacement=combined;displacement.objects[0].femReferenceDisplacementGradient=true;
    std::cout<<std::setprecision(17)<<"reference_abi="<<NM_MATTER_ABI_VERSION<<'\n';smallCellScaleChecks(combined);cpuChecks(simple);cpuChecks(combined);referenceDisplacementChecks(combined);thinSkewArithmeticChecks(combined);generalReferenceChecks(simple);generalReferenceChecks(combined);executableBoundaryChecks(simple);
    if(argc==4){std::cout<<"fem_reference_compiler_check=pass unloaded_reference_recovered=false anatomical_wall_qualified=false\n";return 0;}
    Device device;std::cout<<"reference_device="<<[device.device name].UTF8String<<'\n';
    backtrackingLaneReductionChecks(device);
    backtrackingConstitutiveValidityChecks(device);
    boundaryRestoreChecks(device,simple);directChecks(device,simple,"reference_only");directChecks(device,combined,"reference_regional_frames");
    directChecks(device,displacement,"reference_displacement_regional_frames");rigidRotationChecks(device,combined);thinSkewMetalRestCheck(device,combined);
    integratedChecks(device,simple,16,"reference_only");integratedChecks(device,combined,16,"reference_regional_frames");
    integratedChecks(device,displacement,16,"reference_displacement_regional_frames");
    std::cout<<"fem_reference_check=pass unloaded_reference_recovered=false anatomical_wall_qualified=false source_density_supplied=false active_cardiac_source_reproduced=false\n";return 0;
}catch(const std::exception& e){std::cerr<<"fem reference check failed: "<<e.what()<<'\n';return 1;}}}

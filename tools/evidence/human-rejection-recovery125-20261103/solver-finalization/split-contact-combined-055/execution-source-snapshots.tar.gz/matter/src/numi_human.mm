#include "numi/matter/numi_human.hpp"
#include "numi/matter/fem_body_triangle_contact_sample.hpp"
#include "numi/matter/fem_body_triangle_contact_neighborhood_validation.hpp"
#include "numi/matter/fem_body_contact_static_bvh.hpp"
#include "numi/matter/fem_body_contact_sample_grouping.hpp"
#include "fem_surface_attachment_validation.hpp"
#include "immutable_shared_contact_storage.hpp"
#include "metal_encoder_timing.hpp"

#include <CommonCrypto/CommonDigest.h>

#import <Foundation/Foundation.h>
#import <Metal/Metal.h>

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <limits>
#include <numeric>
#include <string>
#include <string_view>
#include <type_traits>
#include <utility>
#include <vector>

namespace numi::matter {
namespace {

static_assert(
    NM_NUMI_HUMAN_ARTICULAR_CONTACT_AUDIT_MAX_STEPS ==
        MR_NUMI_HUMAN_STAND_MAX_STEPS);

std::uint64_t appendFingerprint(
    std::uint64_t fingerprint,
    const void* bytes,
    const std::size_t count
) noexcept {
    const auto* values = static_cast<const std::uint8_t*>(bytes);
    for (std::size_t index = 0u; index < count; ++index) {
        fingerprint ^= values[index];
        fingerprint *= 1099511628211ull;
    }
    return fingerprint;
}

bool encodeTransactionCoupledCandidateBridge(
    void* context,
    const CoupledCandidateQuery& query
) {
    const auto* pass = static_cast<const metalrobo::MetalNumiHumanTendonLoadPass*>(context);
    if (pass == nullptr || pass->coupledCandidateContext == nullptr ||
        pass->encodeCoupledCandidate == nullptr) {
        return false;
    }
    return pass->encodeCoupledCandidate(
        pass->coupledCandidateContext, &query);
}

bool finiteScale(const nm_float4& scale) noexcept {
    return std::isfinite(scale.x) && std::isfinite(scale.y) &&
        std::isfinite(scale.z) && std::isfinite(scale.w);
}

bool exactEnvironmentOptIn(const char* name) noexcept {
    if (name == nullptr) return false;
    const char* value = std::getenv(name);
    return value != nullptr && std::strcmp(value, "1") == 0;
}

bool implicitSpringResidualArmijoUnavailable() noexcept {
    constexpr const char* selectors[] = {
        "NM_FEM_RESIDUAL_ARMIJO_ROOT",
        "NM_FEM_COHESIVE_RESIDUAL_ARMIJO_ROOT",
        "NM_FEM_CAPSULE_RESIDUAL_ARMIJO_ROOT",
        "NM_FEM_CAPSULE_BOX_RESIDUAL_ARMIJO_ROOT",
        "NM_FEM_FULL_CONTACT_RESIDUAL_ARMIJO_ROOT",
    };
    for (const char* selector : selectors) {
        if (std::getenv(selector) != nullptr) return true;
    }
    return false;
}

float scaleComponent(
    const nm_float4& scale, const std::uint32_t index
) noexcept {
    switch (index) {
        case 0u: return scale.x;
        case 1u: return scale.y;
        case 2u: return scale.z;
        case 3u: return scale.w;
    }
    return std::numeric_limits<float>::quiet_NaN();
}

constexpr std::string_view kAdapterSnapshotDomain =
    "numi.matter.numi-human-tendon-fem-adapter-authority.v1";

class AdapterSnapshotWriter {
public:
    bool appendU32(
        const std::string_view field, const std::uint32_t value
    ) {
        return appendFieldName(field) && appendLittleEndian(value);
    }

    bool appendU64(
        const std::string_view field, const std::uint64_t value
    ) {
        return appendFieldName(field) && appendLittleEndian(value);
    }

    template <typename T>
    bool appendVector(
        const std::string_view field, const std::vector<T>& values
    ) {
        static_assert(std::is_trivially_copyable_v<T>);
        if (!appendFieldName(field) ||
            !appendLittleEndian(static_cast<std::uint64_t>(sizeof(T))) ||
            !appendLittleEndian(static_cast<std::uint64_t>(values.size()))) {
            return false;
        }
        if (values.size() >
            std::numeric_limits<std::size_t>::max() / sizeof(T)) {
            return false;
        }
        const std::size_t byteCount = values.size() * sizeof(T);
        if (byteCount != 0u) {
            const auto* begin = reinterpret_cast<const std::uint8_t*>(
                values.data());
            bytes_.insert(bytes_.end(), begin, begin + byteCount);
        }
        return true;
    }

    bool appendDomain() {
        return appendString(kAdapterSnapshotDomain);
    }

    [[nodiscard]] std::vector<std::uint8_t> take() && {
        return std::move(bytes_);
    }

private:
    template <typename T>
    bool appendLittleEndian(const T value) {
        static_assert(std::is_unsigned_v<T>);
        for (std::size_t byte = 0u; byte < sizeof(T); ++byte) {
            bytes_.push_back(static_cast<std::uint8_t>(
                value >> (8u * byte)));
        }
        return true;
    }

    bool appendString(const std::string_view value) {
        return appendLittleEndian(static_cast<std::uint64_t>(value.size())) &&
            (bytes_.insert(bytes_.end(), value.begin(), value.end()), true);
    }

    bool appendFieldName(const std::string_view field) {
        return appendString(field);
    }

    std::vector<std::uint8_t> bytes_;
};

template <typename T>
bool sameVectorBytes(
    const std::vector<T>& lhs, const std::vector<T>& rhs
) noexcept {
    static_assert(std::is_trivially_copyable_v<T>);
    return lhs.size() == rhs.size() &&
        (lhs.empty() ||
         std::memcmp(lhs.data(), rhs.data(), lhs.size() * sizeof(T)) == 0);
}

} // namespace

bool canonicalNumiHumanTendonFEMLoadAdapterSnapshotV1(
    const NumiHumanTendonFEMLoadAdapterSnapshotV1& snapshot,
    std::vector<std::uint8_t>& output,
    std::string& error
) noexcept {
    try {
        error.clear();
        if (!snapshot.available ||
            snapshot.formatVersion !=
                kNumiHumanTendonFEMLoadAdapterSnapshotVersionV1) {
            error = "Numi Human tendon/FEM adapter snapshot is unavailable or has an unsupported version";
            return false;
        }
        AdapterSnapshotWriter writer;
        if (!writer.appendDomain() ||
            !writer.appendU32("formatVersion", snapshot.formatVersion) ||
            !writer.appendU64(
                "adapterFingerprint", snapshot.adapterFingerprint) ||
            !writer.appendU64(
                "runtimeDeviceProgramFingerprint",
                snapshot.runtimeDeviceProgramFingerprint) ||
            !writer.appendU32(
                "environmentCount", snapshot.environmentCount) ||
            !writer.appendU32("endpointCount", snapshot.endpointCount) ||
            !writer.appendU32("femNodeCount", snapshot.femNodeCount) ||
            !writer.appendU32(
                "contactSampleCount", snapshot.contactSampleCount) ||
            !writer.appendU32(
                "femBodyContactSampleCount",
                snapshot.femBodyContactSampleCount) ||
            !writer.appendU32(
                "articularContactSampleCount",
                snapshot.articularContactSampleCount) ||
            !writer.appendU32(
                "articularContactPairCount",
                snapshot.articularContactPairCount) ||
            !writer.appendU32(
                "passiveLigamentCount", snapshot.passiveLigamentCount) ||
            !writer.appendU32(
                "passiveRoutedBandCount",
                snapshot.passiveRoutedBandCount) ||
            !writer.appendU32(
                "boundBodyPoseStride", snapshot.boundBodyPoseStride) ||
            !writer.appendU32(
                "encodedPassCount", snapshot.encodedPassCount) ||
            !writer.appendU32("abortCount", snapshot.abortCount) ||
            !writer.appendU32(
                "articularAttemptedStepCount",
                snapshot.articularAttemptedStepCount) ||
            !writer.appendVector(
                "anchorReactionAcceptedHistory:nm_float4",
                snapshot.anchorReactionAcceptedHistory) ||
            !writer.appendVector(
                "femBodyContactAcceptedHistory:NMNumiHumanArticularContactAuditGPU",
                snapshot.femBodyContactAcceptedHistory) ||
            !writer.appendVector(
                "articularContactAcceptedHistory:NMNumiHumanArticularContactAuditGPU",
                snapshot.articularContactAcceptedHistory) ||
            !writer.appendVector(
                "articularContactPairForceAcceptedHistory:f32",
                snapshot.articularContactPairForceAcceptedHistory) ||
            !writer.appendVector(
                "passiveLigamentAcceptedState:NMNumiHumanPassiveLigamentAuditGPU",
                snapshot.passiveLigamentAcceptedState) ||
            !writer.appendVector(
                "passiveRoutedBandAcceptedState:NMNumiHumanPassiveRoutedBandAuditGPU",
                snapshot.passiveRoutedBandAcceptedState)) {
            error = "Numi Human tendon/FEM adapter snapshot canonical framing overflowed";
            return false;
        }
        std::vector<std::uint8_t> candidate = std::move(writer).take();
        output = std::move(candidate);
        return true;
    } catch (const std::exception& exception) {
        error = std::string(
            "Numi Human tendon/FEM adapter snapshot canonicalization failed: ") +
            exception.what();
        return false;
    } catch (...) {
        error =
            "Numi Human tendon/FEM adapter snapshot canonicalization failed";
        return false;
    }
}

bool digestNumiHumanTendonFEMLoadAdapterSnapshotV1(
    const NumiHumanTendonFEMLoadAdapterSnapshotV1& snapshot,
    NumiHumanTendonFEMLoadAdapterDigest& output,
    std::string& error
) noexcept {
    std::vector<std::uint8_t> canonical;
    if (!canonicalNumiHumanTendonFEMLoadAdapterSnapshotV1(
            snapshot, canonical, error)) {
        return false;
    }
    if (canonical.size() > std::numeric_limits<CC_LONG>::max()) {
        error = "Numi Human tendon/FEM adapter authority exceeds SHA-256 input bounds";
        return false;
    }
    NumiHumanTendonFEMLoadAdapterDigest candidate{};
    if (CC_SHA256(
            canonical.data(), static_cast<CC_LONG>(canonical.size()),
            candidate.data()) == nullptr) {
        error = "Numi Human tendon/FEM adapter SHA-256 failed";
        return false;
    }
    output = candidate;
    error.clear();
    return true;
}

bool sameNumiHumanTendonFEMLoadAdapterSnapshotAuthorityV1(
    const NumiHumanTendonFEMLoadAdapterSnapshotV1& lhs,
    const NumiHumanTendonFEMLoadAdapterSnapshotV1& rhs
) noexcept {
    return lhs.available && rhs.available &&
        lhs.formatVersion == rhs.formatVersion &&
        lhs.adapterFingerprint == rhs.adapterFingerprint &&
        lhs.runtimeDeviceProgramFingerprint ==
            rhs.runtimeDeviceProgramFingerprint &&
        lhs.environmentCount == rhs.environmentCount &&
        lhs.endpointCount == rhs.endpointCount &&
        lhs.femNodeCount == rhs.femNodeCount &&
        lhs.contactSampleCount == rhs.contactSampleCount &&
        lhs.femBodyContactSampleCount == rhs.femBodyContactSampleCount &&
        lhs.articularContactSampleCount == rhs.articularContactSampleCount &&
        lhs.articularContactPairCount == rhs.articularContactPairCount &&
        lhs.passiveLigamentCount == rhs.passiveLigamentCount &&
        lhs.passiveRoutedBandCount == rhs.passiveRoutedBandCount &&
        lhs.boundBodyPoseStride == rhs.boundBodyPoseStride &&
        lhs.encodedPassCount == rhs.encodedPassCount &&
        lhs.abortCount == rhs.abortCount &&
        lhs.articularAttemptedStepCount ==
            rhs.articularAttemptedStepCount &&
        sameVectorBytes(
            lhs.anchorReactionAcceptedHistory,
            rhs.anchorReactionAcceptedHistory) &&
        sameVectorBytes(
            lhs.femBodyContactAcceptedHistory,
            rhs.femBodyContactAcceptedHistory) &&
        sameVectorBytes(
            lhs.articularContactAcceptedHistory,
            rhs.articularContactAcceptedHistory) &&
        sameVectorBytes(
            lhs.articularContactPairForceAcceptedHistory,
            rhs.articularContactPairForceAcceptedHistory) &&
        sameVectorBytes(
            lhs.passiveLigamentAcceptedState,
            rhs.passiveLigamentAcceptedState) &&
        sameVectorBytes(
            lhs.passiveRoutedBandAcceptedState,
            rhs.passiveRoutedBandAcceptedState) &&
        lhs.authoritySHA256 == rhs.authoritySHA256;
}

bool evaluateNumiHumanPassiveLigamentFiber(
    const NMNumiHumanPassiveLigamentGPU& ligament,
    const double currentCentroidLengthMeters,
    NumiHumanPassiveLigamentFiberEvaluation& result
) noexcept {
    result = {};
    const nm_float4 material = ligament.material;
    const nm_float4 reference = ligament.reference;
    if (ligament.flags != NM_NUMI_HUMAN_PASSIVE_LIGAMENT_ACTIVE ||
        ligament.reserved0 != 0u || !finiteScale(material) ||
        !finiteScale(reference) || material.x <= 0.0f ||
        material.y <= 0.0f || material.z <= 0.0f ||
        material.w <= 1.0f || reference.x <= 0.0f ||
        reference.y <= 0.0f || reference.z < 1.0f ||
        reference.w != 0.0f ||
        !std::isfinite(currentCentroidLengthMeters) ||
        currentCentroidLengthMeters <= 0.0) {
        return false;
    }
    const double stretch = reference.z *
        currentCentroidLengthMeters / reference.x;
    if (!std::isfinite(stretch) || stretch <= 0.0) return false;
    double stress = 0.0;
    if (stretch > 1.0 && stretch < material.w) {
        stress = material.x * std::expm1(material.y * (stretch - 1.0));
    } else if (stretch >= material.w) {
        const double c6 = material.x *
                std::expm1(material.y * (material.w - 1.0)) -
            material.z * material.w;
        stress = material.z * stretch + c6;
    }
    const double tension = stress * reference.y;
    if (!std::isfinite(stress) || stress < 0.0 ||
        !std::isfinite(tension) || tension < 0.0) return false;
    result.effectiveStretch = stretch;
    result.fiberStressPascals = stress;
    result.tensionNewtons = tension;
    return true;
}

bool evaluateNumiHumanPassiveRoutedBand(
    const NMNumiHumanPassiveRoutedBandGPU& band,
    const double geometricLengthMeters,
    const double signedWindingRadians,
    NumiHumanPassiveRoutedBandEvaluation& result
) noexcept {
    result = {};
    const nm_float4 axisRadius = band.pulleyLocalAxisAndRadius;
    const nm_float4 neutral = band.neutralRelativeOrientation;
    const nm_float4 material = band.material;
    const nm_float4 reference = band.reference;
    const double axisLength = std::sqrt(
        static_cast<double>(axisRadius.x) * axisRadius.x +
        static_cast<double>(axisRadius.y) * axisRadius.y +
        static_cast<double>(axisRadius.z) * axisRadius.z);
    const double neutralLength = std::sqrt(
        static_cast<double>(neutral.x) * neutral.x +
        static_cast<double>(neutral.y) * neutral.y +
        static_cast<double>(neutral.z) * neutral.z +
        static_cast<double>(neutral.w) * neutral.w);
    if (band.flags != NM_NUMI_HUMAN_PASSIVE_ROUTED_BAND_ACTIVE ||
        band.originBodyIndex == NM_INVALID_INDEX ||
        band.pulleyBodyIndex == NM_INVALID_INDEX ||
        band.insertionBodyIndex == NM_INVALID_INDEX ||
        !finiteScale(band.originLocalPoint) ||
        !finiteScale(band.pulleyLocalPoint) ||
        !finiteScale(band.insertionLocalPoint) ||
        band.originLocalPoint.w != 0.0f ||
        band.pulleyLocalPoint.w != 0.0f ||
        band.insertionLocalPoint.w != 0.0f ||
        !finiteScale(axisRadius) || !finiteScale(neutral) ||
        !finiteScale(material) || !finiteScale(reference) ||
        std::abs(axisLength - 1.0) > 1.0e-5 || axisRadius.w <= 0.0f ||
        std::abs(neutralLength - 1.0) > 1.0e-5 ||
        material.x <= 0.0f || material.y <= 0.0f ||
        material.z <= 0.0f || material.w < 0.0f || material.w >= 0.5f ||
        reference.x <= 0.0f || reference.y <= 0.0f ||
        reference.z <= 0.0f || reference.w != 0.0f ||
        !std::isfinite(geometricLengthMeters) ||
        geometricLengthMeters <= 0.0 ||
        !std::isfinite(signedWindingRadians)) {
        return false;
    }
    const double routeLength = geometricLengthMeters +
        axisRadius.w * std::abs(signedWindingRadians);
    const double stretch = routeLength / reference.x;
    const double strain = stretch - 1.0;
    if (!std::isfinite(routeLength) || !std::isfinite(stretch) ||
        stretch <= 0.0 || !std::isfinite(strain) ||
        strain > reference.z) return false;

    const auto tensionAtStretch = [&](const double lambda) noexcept {
        if (lambda <= 1.0) return 0.0;
        const double lambda2 = lambda * lambda;
        const double stress =
            static_cast<double>(material.x) *
                (lambda2 - 1.0 / lambda) +
            static_cast<double>(material.y) /
                (2.0 * static_cast<double>(material.z)) *
                std::expm1(static_cast<double>(material.z) *
                    (lambda2 - 1.0)) * lambda2;
        const double area = static_cast<double>(reference.y) *
            std::pow(lambda, -2.0 * static_cast<double>(material.w));
        return stress * area;
    };
    const double tension = tensionAtStretch(stretch);
    if (!std::isfinite(tension) || tension < 0.0) return false;

    double energy = 0.0;
    if (stretch > 1.0) {
        constexpr std::uint32_t intervals = 32u;
        const double h = (stretch - 1.0) / intervals;
        double integral = tensionAtStretch(1.0) + tension;
        for (std::uint32_t index = 1u; index < intervals; ++index) {
            integral += (index & 1u ? 4.0 : 2.0) *
                tensionAtStretch(1.0 + h * index);
        }
        energy = reference.x * h * integral / 3.0;
    }
    if (!std::isfinite(energy) || energy < 0.0) return false;
    result.routeLengthMeters = routeLength;
    result.stretch = stretch;
    result.strain = strain;
    result.tensionNewtons = tension;
    result.storedEnergyJoules = energy;
    return true;
}

NumiHumanFEMPrestressDiagnostics prepareNumiHumanFEMPrestressStage(
    const CompiledWorld& world,
    const std::span<const NumiHumanFEMPrestressTarget> targets,
    const float fraction,
    RuntimeStateSnapshot& snapshot
) {
    NumiHumanFEMPrestressDiagnostics diagnostics;
    diagnostics.fraction = fraction;
    const auto reject = [&](const NumiHumanFEMPrestressStatus status,
                            const std::uint32_t target,
                            std::string message) {
        diagnostics.status = status;
        diagnostics.failingTarget = target;
        diagnostics.message = std::move(message);
        return diagnostics;
    };
    if (!snapshot.available || snapshot.deviceProgramFingerprint == 0u) {
        return reject(
            NumiHumanFEMPrestressStatus::invalidSnapshot,
            NM_INVALID_INDEX,
            "prestress staging requires an available device snapshot"
        );
    }
    if (!std::isfinite(fraction) || fraction < 0.0f || fraction > 1.0f) {
        return reject(
            NumiHumanFEMPrestressStatus::invalidFraction,
            NM_INVALID_INDEX,
            "prestress fraction must be finite and within [0, 1]"
        );
    }
    const std::size_t parameterCount = world.dispatch.parameterCount;
    const std::size_t environmentCount = world.dispatch.environmentCount;
    if (parameterCount == 0u || environmentCount == 0u ||
        world.parameters.size() != parameterCount ||
        snapshot.environmentParameters.size() !=
            parameterCount * environmentCount) {
        return reject(
            NumiHumanFEMPrestressStatus::invalidParameterArena,
            NM_INVALID_INDEX,
            "prestress parameter arena does not match the cooked world"
        );
    }
    if (targets.empty()) {
        return reject(
            NumiHumanFEMPrestressStatus::invalidParameter,
            NM_INVALID_INDEX,
            "prestress staging requires at least one parameter target"
        );
    }

    std::vector<bool> parameterSeen(parameterCount, false);
    std::vector<std::pair<std::uint32_t, float>> stagedValues;
    stagedValues.reserve(targets.size());
    for (std::uint32_t targetIndex = 0u;
         targetIndex < targets.size(); ++targetIndex) {
        const auto& target = targets[targetIndex];
        if (target.materialIndex >= world.materials.size()) {
            return reject(
                NumiHumanFEMPrestressStatus::invalidMaterial,
                targetIndex,
                "prestress target material index escapes the cooked world"
            );
        }
        const NMMaterialGPU& material = world.materials[target.materialIndex];
        if (target.localParameterIndex >= material.parameterCount ||
            material.parameterOffset >= parameterCount ||
            target.localParameterIndex >=
                parameterCount - material.parameterOffset) {
            return reject(
                NumiHumanFEMPrestressStatus::invalidParameter,
                targetIndex,
                "prestress target parameter index escapes its material"
            );
        }
        const std::uint32_t parameter =
            material.parameterOffset + target.localParameterIndex;
        if (parameterSeen[parameter]) {
            return reject(
                NumiHumanFEMPrestressStatus::duplicateParameter,
                targetIndex,
                "prestress target parameter is duplicated"
            );
        }
        parameterSeen[parameter] = true;
        const auto& bounds = world.parameters[parameter].valueAndBounds;
        const float value = target.neutralValue +
            fraction * (target.sourceValue - target.neutralValue);
        if (!std::isfinite(target.neutralValue) ||
            !std::isfinite(target.sourceValue) || !std::isfinite(value) ||
            target.neutralValue < bounds.y || target.neutralValue > bounds.z ||
            target.sourceValue < bounds.y || target.sourceValue > bounds.z ||
            value < bounds.y || value > bounds.z) {
            return reject(
                NumiHumanFEMPrestressStatus::invalidBounds,
                targetIndex,
                "prestress target or staged value violates authored bounds"
            );
        }
        diagnostics.maximumAbsoluteParameterDelta = std::max(
            diagnostics.maximumAbsoluteParameterDelta,
            std::abs(value - target.neutralValue)
        );
        stagedValues.emplace_back(parameter, value);
    }

    std::vector<float> staged = snapshot.environmentParameters;
    for (std::uint32_t environment = 0u;
         environment < environmentCount; ++environment) {
        const std::size_t base = environment * parameterCount;
        for (const auto& [parameter, value] : stagedValues)
            staged[base + parameter] = value;
    }
    snapshot.environmentParameters = std::move(staged);
    diagnostics.status = NumiHumanFEMPrestressStatus::success;
    diagnostics.appliedParameterCount = static_cast<std::uint32_t>(
        stagedValues.size() * environmentCount);
    diagnostics.message = "prestress parameter stage prepared";
    return diagnostics;
}

struct NumiHumanTendonFEMLoadAdapter::State {
    Runtime* runtime = nullptr;
    std::vector<NMNumiHumanTendonFEMNodeLoadGPU> nodeLoads;
    std::vector<NMNumiHumanTendonFEMNodeAnchorGPU> nodeAnchors;
    std::vector<NMNumiHumanTendonFEMEndpointReplacementGPU> replacements;
    std::vector<NMNumiHumanFEMContactSampleGPU> contactSamples;
    std::vector<NMNumiHumanFEMContactContributionGPU> contactContributions;
    std::vector<NMIncidenceRangeGPU> contactRanges;
    std::vector<NMNumiHumanFEMBodyContactSampleGPU> femBodyContactSamplesStaging;
    std::span<const NMNumiHumanFEMBodyContactSampleGPU> femBodyContactSamples;
    std::vector<NMNumiHumanFEMBodyContactNeighborhoodRangeGPU> femBodyContactNeighborhoodRangesStaging;
    std::span<const NMNumiHumanFEMBodyContactNeighborhoodRangeGPU> femBodyContactNeighborhoodRanges;
    std::vector<NMNumiHumanFEMBodyContactNeighborhoodRangeGPU> femBodyContactSolverNeighborhoodRangesStaging;
    std::span<const NMNumiHumanFEMBodyContactNeighborhoodRangeGPU> femBodyContactSolverNeighborhoodRanges;
    std::vector<NMNumiHumanFEMBodyContactNeighborhoodTriangleGPU> femBodyContactNeighborhoodTrianglesStaging;
    std::span<const NMNumiHumanFEMBodyContactNeighborhoodTriangleGPU> femBodyContactNeighborhoodTriangles;
    std::vector<NMNumiHumanFEMBodyContactBVHNodeGPU> femBodyContactNeighborhoodBVHNodesStaging;
    std::span<const NMNumiHumanFEMBodyContactBVHNodeGPU> femBodyContactNeighborhoodBVHNodes;
    std::vector<NMNumiHumanFEMSurfaceAttachmentGPU> femSurfaceAttachments;
    std::vector<NMNumiHumanFEMBodyContactSampleGPU> femBodyContactSolverSamplesStaging;
    std::span<const NMNumiHumanFEMBodyContactSampleGPU> femBodyContactSolverSamples;
    std::vector<NMNumiHumanFEMBodyContactSampleGPU> femBodyContactGroupedSolverSamplesStaging;
    std::span<const NMNumiHumanFEMBodyContactSampleGPU> femBodyContactGroupedSolverSamples;
    std::vector<NMNumiHumanFEMBodyContactNeighborhoodRangeGPU> femBodyContactGroupedSolverNeighborhoodRangesStaging;
    std::span<const NMNumiHumanFEMBodyContactNeighborhoodRangeGPU> femBodyContactGroupedSolverNeighborhoodRanges;
    std::vector<std::uint32_t> femBodyContactSolverGroupCounts;
    bool hasMultiMasterTriangleContact = false;
    bool contactRowCache = false;
    bool contactAABBExclusion = false;
    bool contactExactMotionCache = false;
    bool contactCompactQueries = false;
    std::uint32_t contactQueryTileCount = 0u, contactQueryBlockCount = 0u;
    __strong id<MTLBuffer> contactQueryTiles = nil, contactQueryBlockSums = nil;
    __strong id<MTLBuffer> contactQueryBlockOffsets = nil, contactQueryIndices = nil;
    __strong id<MTLBuffer> contactQueryWork = nil;
    __strong id<MTLComputePipelineState> contactQueryClassify = nil, contactQueryScanTiles = nil;
    __strong id<MTLComputePipelineState> contactQueryScanBlocks = nil, contactQueryScatter = nil;
    __strong id<MTLBuffer> contactMotionFlags = nil;
    __strong id<MTLBuffer> contactMotionPositions = nil;
    __strong id<MTLBuffer> contactMotionPoseWords = nil;
    __strong id<MTLComputePipelineState> contactMotionPreparePipeline = nil;
    __strong id<MTLBuffer> femBodyContactRowCache = nil;
    std::vector<NMNumiHumanFEMBodyContactSampleGPU>
        implicitSpringSamples;
    std::vector<MRArticulatedPointImpulseGPU> implicitSpringPointQueries;
    std::uint32_t implicitSpringCount = 0u;
    [[nodiscard]] bool hasFEMBodyInteraction() const noexcept {
        return !femBodyContactSamples.empty() ||
            !femSurfaceAttachments.empty();
    }
    std::vector<NMNumiHumanArticularContactSampleGPU> articularContactSamples;
    std::vector<NMIncidenceRangeGPU> articularContactPairRanges;
    std::vector<NMNumiHumanPassiveLigamentGPU> passiveLigaments;
    std::vector<NMNumiHumanPassiveRoutedBandGPU> passiveRoutedBands;
    std::filesystem::path metallib;
    NumiHumanTendonFEMLoadExecutionMode executionMode =
        NumiHumanTendonFEMLoadExecutionMode::standaloneRuntime;
    void* acceptedStepExtensionContext = nullptr;
    EncodeAcceptedStepExtension encodeAcceptedStepExtension = nullptr;
    std::uint64_t acceptedStepExtensionFingerprint = 0u;
    bool deferAcceptedControlCursorPublication = false;
    bool deferAcceptedStepExtensionFinalization = false;
    bool deferAcceptedAuditPublication = false;
    std::uint32_t expectedMicrotickCount = 1u;
    std::uintptr_t acceptedAuditPendingCommandBufferIdentity = 0u;
    void* acceptedAuditPendingStandStatuses = nullptr;
    std::uint32_t acceptedAuditPendingStepIndex = 0u;
    std::uint32_t endpointCount = 0u;
    std::uint32_t environmentCount = 0u;
    std::uint32_t activeAnchorCount = 0u;
    std::uint32_t encodedPassCount = 0u;
    std::uint32_t abortCount = 0u;
    std::uint32_t preSourceCorrectionEncodeCount = 0u;
    std::uint32_t deferredExternalForceBorrowCount = 0u;
    std::uint32_t runtimePreDynamicsEncodeCount = 0u;
    std::uint32_t runtimePostCommitEncodeCount = 0u;
    std::uint32_t articularBodyPoseStride = 0u;
    // Allocation cache retained across accepted-state restore. The bound
    // stride above is authoritative; this value only describes private
    // scratch capacity that may be reused after restoring a pre-pass state.
    std::uint32_t allocatedArticularBodyPoseStride = 0u;
    std::uint32_t articularMechanicalSampleCount = 0u;
    std::uint32_t articularInternalSameBodySampleCount = 0u;
    std::uint32_t articularContactPairCount = 0u;
    std::uint32_t articularAttemptedStepCount = 0u;
    std::uint64_t fingerprint = 0u;
    std::uint64_t runtimeDeviceProgramFingerprint = 0u;
    std::uintptr_t deferredCommandBufferIdentity = 0u;
    std::uint32_t deferredStepIndex = 0u;
    bool deferredExternalForcesAvailable = false;
    std::string message;

    // Host shadows make an accepted snapshot restorable before the lazy Metal
    // buffers have been materialized by a borrowed pass. Once materialized,
    // snapshot() reads the authoritative shared GPU buffers directly.
    std::vector<nm_float4> anchorReactionAcceptedHistory;
    std::vector<NMNumiHumanArticularContactAuditGPU>
        femBodyContactAcceptedHistory;
    std::vector<NMNumiHumanArticularContactAuditGPU>
        articularContactAcceptedHistory;
    std::vector<float> articularContactPairForceAcceptedHistory;
    std::vector<NMNumiHumanPassiveLigamentAuditGPU>
        passiveLigamentAcceptedState;
    std::vector<NMNumiHumanPassiveRoutedBandAuditGPU>
        passiveRoutedBandAcceptedState;

    __strong id<MTLDevice> device = nil;
    __strong id<MTLLibrary> library = nil;
    __strong id<MTLComputePipelineState> provisionalStatusPipeline = nil;
    __strong id<MTLComputePipelineState> femBodyContactSampleValidationPipeline = nil;
    __strong id<MTLComputePipelineState> femBodyContactSampleValidationReducePipeline = nil;
    __strong id<MTLComputePipelineState> statusPipeline = nil;
    __strong id<MTLComputePipelineState> forcePipeline = nil;
    __strong id<MTLComputePipelineState> forceAuditPipeline = nil;
    std::uint32_t nodeWorkTiles = 0u;
    bool sparseAnchorProjection = true;
    __strong id<MTLBuffer> nodeValidationPartials = nil;
    __strong id<MTLBuffer> nodeValidationFirstInvalid = nil;
    __strong id<MTLBuffer> nodeForceAuditPartials = nil;
    __strong id<MTLBuffer> activeAnchorIndices = nil;
    __strong id<MTLComputePipelineState> nodeValidationPartialPipeline = nil;
    __strong id<MTLComputePipelineState> nodeValidationFinishPipeline = nil;
    __strong id<MTLComputePipelineState> nodeForceAuditPartialPipeline = nil;
    __strong id<MTLComputePipelineState> nodeForceAuditFinishPipeline = nil;

    __strong id<MTLComputePipelineState> contactForcePipeline = nil;
    __strong id<MTLComputePipelineState> femBodyContactForcePipeline = nil;
    __strong id<MTLComputePipelineState> femBodyContactGroupedForcePipeline = nil;
    __strong id<MTLComputePipelineState> femBodyContactWrenchPipeline = nil;
    __strong id<MTLComputePipelineState> femBodyContactWrenchPartialPipeline = nil;
    __strong id<MTLComputePipelineState> femBodyContactWrenchFinishPipeline = nil;
    __strong id<MTLBuffer> femBodyContactWrenchIndices = nil;
    __strong id<MTLBuffer> femBodyContactWrenchTiles = nil;
    __strong id<MTLBuffer> femBodyContactWrenchBodyRanges = nil;
    __strong id<MTLBuffer> femBodyContactWrenchPartials = nil;
    std::uint32_t femBodyContactWrenchTileCount = 0u;

    __strong id<MTLComputePipelineState> femSurfaceAttachmentForcePipeline = nil;
    __strong id<MTLComputePipelineState> femSurfaceAttachmentWrenchPipeline = nil;
    __strong id<MTLComputePipelineState>
        femBodyContactGeneralizedLoadPreparePipeline = nil;
    __strong id<MTLComputePipelineState>
        femAnchorReactionLoadAddPipeline = nil;
    __strong id<MTLComputePipelineState>
        femBodyContactGeneralizedLoadCommitPipeline = nil;
    __strong id<MTLComputePipelineState> femBodyContactAuditPipeline = nil;
    __strong id<MTLComputePipelineState> femBodyContactAuditPartialPipeline = nil;
    __strong id<MTLComputePipelineState> femBodyContactAuditFinishPipeline = nil;
    __strong id<MTLBuffer> femBodyContactAuditPartialBuffer = nil;
    std::uint32_t femBodyContactAuditTiles = 0u;
    __strong id<MTLComputePipelineState> articularContactPipeline = nil;
    __strong id<MTLComputePipelineState> articularContactAuditPipeline = nil;
    __strong id<MTLComputePipelineState> articularContactAuditCommitPipeline = nil;
    __strong id<MTLComputePipelineState> articularContactPairAuditPipeline = nil;
    __strong id<MTLComputePipelineState> articularContactPairAuditCommitPipeline = nil;
    __strong id<MTLComputePipelineState> passiveLigamentAuditPipeline = nil;
    __strong id<MTLComputePipelineState> passiveLigamentAuditCommitPipeline = nil;
    __strong id<MTLComputePipelineState> passiveLigamentDeferredAuditCommitPipeline = nil;
    __strong id<MTLComputePipelineState> passiveRoutedBandAuditPipeline = nil;
    __strong id<MTLComputePipelineState> passiveRoutedBandAuditCommitPipeline = nil;
    __strong id<MTLComputePipelineState> passiveRoutedBandDeferredAuditCommitPipeline = nil;
    __strong id<MTLComputePipelineState> targetPipeline = nil;
    __strong id<MTLComputePipelineState> reactionAuditPipeline = nil;
    __strong id<MTLComputePipelineState> reactionAuditCommitPipeline = nil;
    __strong id<MTLComputePipelineState> reactionPipeline = nil;
    __strong id<MTLComputePipelineState> preSourceCorrectionPipeline = nil;
    __strong id<MTLBuffer> nodeLoadBuffer = nil;
    __strong id<MTLBuffer> nodeAnchorBuffer = nil;
    __strong id<MTLBuffer> replacementBuffer = nil;
    __strong id<MTLBuffer> contactSampleBuffer = nil;
    __strong id<MTLBuffer> contactContributionBuffer = nil;
    __strong id<MTLBuffer> contactRangeBuffer = nil;
    __strong id<MTLBuffer> femBodyContactSampleBuffer = nil;
    __strong id<MTLBuffer> femBodyContactSolverSampleBuffer = nil;
    __strong id<MTLBuffer> femBodyContactGroupedSolverSampleBuffer = nil;
    __strong id<MTLBuffer> femBodyContactGroupedSolverRangeBuffer = nil;
    __strong id<MTLBuffer> femBodyContactSolverGroupCountBuffer = nil;
    __strong id<MTLBuffer> femBodyContactNeighborhoodRangeBuffer = nil;
    __strong id<MTLBuffer> femBodyContactSolverNeighborhoodRangeBuffer = nil;
    __strong id<MTLBuffer> femBodyContactNeighborhoodTriangleBuffer = nil;
    __strong id<MTLBuffer> femBodyContactNeighborhoodBVHNodeBuffer = nil;
    __strong id<MTLBuffer> femBodyContactSampleValidationBuffer = nil;
    __strong id<MTLBuffer> femBodyContactSampleValidationBlockBuffer = nil;
    __strong id<MTLBuffer> femSurfaceAttachmentBuffer = nil;
    __strong id<MTLBuffer> implicitSpringSampleBuffer = nil;
    __strong id<MTLBuffer> implicitSpringPointQueryBuffer = nil;
    __strong id<MTLBuffer> femBodyContactWrenchBuffer = nil;
    __strong id<MTLBuffer> femBodyContactGeneralizedLoadPendingBuffer = nil;
    __strong id<MTLBuffer> femBodySourceQPendingBuffer = nil;
    void* acceptedWrenchSourceCommandBuffer = nullptr;
    void* acceptedWrenchSourceBodyPoses = nullptr;
    void* acceptedWrenchSourcePointJacobians = nullptr;
    void* acceptedWrenchSourceQ = nullptr;
    std::uint32_t acceptedWrenchSourceQCoordinateCount = 0u;
    std::uint32_t acceptedWrenchSourceStepIndex = 0u;
    std::uint32_t acceptedWrenchSourceDofCount = 0u;
    std::uint32_t acceptedWrenchSourceBodyPoseStride = 0u;
    std::uint32_t acceptedWrenchSourcePointJacobianStride = 0u;
    std::uint32_t acceptedWrenchSourceBodyJacobianPointOffset =
        MR_INVALID_INDEX;
    std::uint32_t acceptedWrenchSourceArticulationFirstBody = 0u;
    bool acceptedWrenchSourceValid = false;
    __strong id<MTLBuffer> femBodyContactAuditBuffer = nil;
    __strong id<MTLBuffer> femBodyContactAuditHistoryBuffer = nil;
    __strong id<MTLBuffer> articularContactSampleBuffer = nil;
    __strong id<MTLBuffer> articularContactPairRangeBuffer = nil;
    __strong id<MTLBuffer> articularBodyWrenchBuffer = nil;
    __strong id<MTLBuffer> articularContactAuditBuffer = nil;
    __strong id<MTLBuffer> articularContactAuditHistoryBuffer = nil;
    __strong id<MTLBuffer> articularContactPairAuditBuffer = nil;
    __strong id<MTLBuffer> articularContactPairAuditHistoryBuffer = nil;
    __strong id<MTLBuffer> passiveLigamentBuffer = nil;
    __strong id<MTLBuffer> passiveLigamentAuditBuffer = nil;
    __strong id<MTLBuffer> passiveLigamentAcceptedAuditBuffer = nil;
    __strong id<MTLBuffer> passiveRoutedBandBuffer = nil;
    __strong id<MTLBuffer> passiveRoutedBandAuditBuffer = nil;
    __strong id<MTLBuffer> passiveRoutedBandAcceptedAuditBuffer = nil;
    __strong id<MTLBuffer> externalForceBuffer = nil;
    __strong id<MTLBuffer> externalForceAuditBuffer = nil;
    __strong id<MTLBuffer> anchorReactionAuditBuffer = nil;
    __strong id<MTLBuffer> anchorReactionAuditHistoryBuffer = nil;
    __strong id<MTLBuffer> kinematicTargetBuffer = nil;
    __strong id<MTLBuffer> worldStatusBuffer = nil;
};

NumiHumanTendonFEMLoadAdapter::NumiHumanTendonFEMLoadAdapter() = default;
NumiHumanTendonFEMLoadAdapter::~NumiHumanTendonFEMLoadAdapter() = default;
NumiHumanTendonFEMLoadAdapter::NumiHumanTendonFEMLoadAdapter(
    NumiHumanTendonFEMLoadAdapter&&
) noexcept = default;
NumiHumanTendonFEMLoadAdapter& NumiHumanTendonFEMLoadAdapter::operator=(
    NumiHumanTendonFEMLoadAdapter&&
) noexcept = default;

bool NumiHumanTendonFEMLoadAdapter::initialize(
    Runtime& runtime,
    const NumiHumanTendonFEMLoadSource& source,
    const NumiHumanTendonFEMLoadConfiguration& configuration
) {
    const bool passiveAttachmentOnly = source.endpointReplacements.empty();
    const bool hasContact = !source.contactSamples.empty();
    const bool standalone = configuration.executionMode ==
        NumiHumanTendonFEMLoadExecutionMode::standaloneRuntime;
    const bool deferred = configuration.executionMode ==
        NumiHumanTendonFEMLoadExecutionMode::numanXDeferred;
    if (!runtime.valid() || source.nodeLoads.empty() ||
        source.nodeAnchors.size() != source.nodeLoads.size() ||
        source.nodeLoads.size() != runtime.femNodeCount() ||
        source.environmentCount != runtime.environmentCount() ||
        source.endpointCount == 0u || source.environmentCount == 0u ||
        !std::isfinite(source.productionForceOwnerFraction) ||
        (passiveAttachmentOnly
            ? source.productionForceOwnerFraction != 0.0f
            : !(source.productionForceOwnerFraction > 0.0f)) ||
        source.productionForceOwnerFraction > 1.0f ||
        configuration.metallib.empty() ||
        !std::filesystem::is_regular_file(configuration.metallib) ||
        (!standalone && !deferred) ||
        configuration.expectedMicrotickCount == 0u ||
        configuration.expectedMicrotickCount > (1u << NM_MAX_RATE_EXPONENT) ||
        (configuration.expectedMicrotickCount &
         (configuration.expectedMicrotickCount - 1u)) != 0u ||
        (configuration.expectedMicrotickCount != 1u &&
         (!standalone || (configuration.reserved0 &
          kNumiHumanTendonFEMLoadDeferAcceptedAuditPublication) == 0u)) ||
        (configuration.reserved0 &
         ~kNumiHumanTendonFEMLoadDeferAcceptedAuditPublication) != 0u ||
        configuration.implicitElasticBodySpringCount >
            kNumiHumanTendonFEMImplicitSpringMaximum ||
        (configuration.allowStandaloneImplicitCandidateOwner &&
         (!standalone ||
          configuration.implicitElasticBodySpringCount == 0u ||
          !runtime.requiresCoupledCandidate())) ||
        (configuration.implicitElasticBodySpringCount != 0u &&
         (!runtime.requiresCoupledCandidate() ||
          (!deferred &&
           !(standalone &&
             configuration.allowStandaloneImplicitCandidateOwner)) ||
          implicitSpringResidualArmijoUnavailable())) ||
        ((configuration.acceptedStepExtensionContext == nullptr) !=
         (configuration.encodeAcceptedStepExtension == nullptr)) ||
        ((configuration.acceptedStepExtensionContext == nullptr) !=
         (configuration.acceptedStepExtensionFingerprint == 0u)) ||
        ((configuration.deferAcceptedControlCursorPublication ||
          configuration.deferAcceptedStepExtensionFinalization) &&
         configuration.encodeAcceptedStepExtension == nullptr) ||
        (configuration.encodeAcceptedStepExtension != nullptr && !standalone) ||
        ((configuration.reserved0 &
          kNumiHumanTendonFEMLoadDeferAcceptedAuditPublication) != 0u &&
         (!standalone ||
          configuration.encodeAcceptedStepExtension == nullptr ||
          !configuration.deferAcceptedControlCursorPublication ||
          !configuration.deferAcceptedStepExtensionFinalization)) ||
        source.articularContactSamples.size() >
            std::numeric_limits<std::uint32_t>::max() ||
        source.articularContactPairRanges.size() >
            std::numeric_limits<std::uint32_t>::max() ||
        source.femBodyContactSamples.size() >
            std::numeric_limits<std::uint32_t>::max() ||
        source.femSurfaceAttachments.size() >
            std::numeric_limits<std::uint32_t>::max() ||
        source.passiveLigaments.size() >
            std::numeric_limits<std::uint32_t>::max() ||
        source.passiveRoutedBands.size() >
            std::numeric_limits<std::uint32_t>::max() ||
        (hasContact != !source.contactContributions.empty()) ||
        (hasContact != !source.contactRanges.empty()) ||
        (hasContact &&
            (source.contactRanges.size() != source.nodeLoads.size() ||
             source.contactSamples.size() >
                 std::numeric_limits<std::uint32_t>::max() ||
             source.contactContributions.size() >
                 std::numeric_limits<std::uint32_t>::max() ||
             source.contactSamples.size() >
                 source.contactContributions.size() / 4u))) {
        return false;
    }
    if (source.femBodyContactNeighborhoodBVHNodes.empty()) {
        if (!fem_body_contact_neighborhood::validNeighborhoodSpans(
                source.femBodyContactSamples,
                source.femBodyContactNeighborhoodRanges,
                source.femBodyContactNeighborhoodTriangles)) return false;
    } else if (!fem_body_contact_bvh::validCompleteStaticBVHSpans(
            source.femBodyContactSamples,
            source.femBodyContactNeighborhoodRanges,
            source.femBodyContactNeighborhoodTriangles,
            source.femBodyContactNeighborhoodBVHNodes)) return false;
    if (source.femBodyContactNeighborhoodTriangles.size() >
        std::numeric_limits<std::uint32_t>::max()) return false;
    if (hasContact) {
        std::vector<std::array<std::uint32_t, 4u>> roleCounts(
            source.contactSamples.size());
        std::uint64_t nextContribution = 0u;
        for (std::uint32_t node = 0u;
             node < source.contactRanges.size(); ++node) {
            const NMIncidenceRangeGPU range = source.contactRanges[node];
            if (range.first != nextContribution ||
                static_cast<std::uint64_t>(range.first) + range.count >
                    source.contactContributions.size()) return false;
            for (std::uint32_t local = 0u; local < range.count; ++local) {
                const auto& contribution = source.contactContributions[
                    range.first + local];
                if (contribution.sampleIndex >= source.contactSamples.size() ||
                    contribution.role > 3u || contribution.reserved0 != 0u ||
                    contribution.reserved1 != 0u) return false;
                const auto& sample =
                    source.contactSamples[contribution.sampleIndex];
                std::uint32_t owner = sample.slaveNode;
                switch (contribution.role) {
                    case 1u: owner = sample.masterNode0; break;
                    case 2u: owner = sample.masterNode1; break;
                    case 3u: owner = sample.masterNode2; break;
                    default: break;
                }
                if (owner != node ||
                    ++roleCounts[contribution.sampleIndex][contribution.role] !=
                        1u) return false;
            }
            nextContribution += range.count;
        }
        if (nextContribution != source.contactContributions.size() ||
            source.contactContributions.size() !=
                4u * source.contactSamples.size()) return false;
        for (std::uint32_t index = 0u;
             index < source.contactSamples.size(); ++index) {
            const auto& sample = source.contactSamples[index];
            const auto& roles = roleCounts[index];
            const nm_float4 bary =
                sample.barycentricAndReferenceSeparation;
            const nm_float4 normal = sample.normalAndArea;
            const nm_float4 stiffness = sample.stiffness;
            const double normalLength = std::sqrt(
                normal.x * normal.x + normal.y * normal.y +
                normal.z * normal.z);
            if (sample.slaveNode >= source.nodeLoads.size() ||
                sample.masterNode0 >= source.nodeLoads.size() ||
                sample.masterNode1 >= source.nodeLoads.size() ||
                sample.masterNode2 >= source.nodeLoads.size() ||
                sample.slaveNode == sample.masterNode0 ||
                sample.slaveNode == sample.masterNode1 ||
                sample.slaveNode == sample.masterNode2 ||
                sample.masterNode0 == sample.masterNode1 ||
                sample.masterNode0 == sample.masterNode2 ||
                sample.masterNode1 == sample.masterNode2 ||
                !finiteScale(bary) || bary.x < 0.0f || bary.y < 0.0f ||
                bary.z < 0.0f ||
                std::abs(bary.x + bary.y + bary.z - 1.0f) > 1.0e-5f ||
                !finiteScale(normal) ||
                std::abs(normalLength - 1.0) > 1.0e-5 ||
                normal.w <= 0.0f || !finiteScale(stiffness) ||
                stiffness.x <= 0.0f || stiffness.y != 0.0f ||
                stiffness.z != 0.0f || stiffness.w != 0.0f ||
                std::any_of(roles.begin(), roles.end(),
                            [](const std::uint32_t count) {
                                return count != 1u;
                            })) return false;
        }
    }
    if (!detail::validFEMSurfaceAttachmentSamples(
            source.femSurfaceAttachments, source.nodeLoads.size())) return false;
    const auto contactOwnership =
        fem_body_contact_grouping::validateDistinctBodyTriangleSlaves(
            source.femBodyContactSamples, source.nodeAnchors);
    if (!contactOwnership.accepted()) return false;
    const bool hasMultiMasterTriangleContact =
        contactOwnership.hasDistinctBodyTriangleDuplicates;
    {
        for (const auto& sample : source.femBodyContactSamples) {
            const nm_float4 point = sample.bodyLocalPointAndArea;
            const nm_float4 normal =
                sample.bodyLocalNormalAndReferenceSeparation;
            const nm_float4 stiffness =
                sample.stiffnessAndNormalStrainPerPressure;
            const std::uint32_t elasticFlags =
                NM_NUMI_HUMAN_FEM_BODY_CONTACT_ACTIVE |
                NM_NUMI_HUMAN_FEM_BODY_CONTACT_ELASTIC_ATTACHMENT;
            const std::uint32_t triangleFlags =
                NM_NUMI_HUMAN_FEM_BODY_CONTACT_ACTIVE |
                NM_NUMI_HUMAN_FEM_BODY_CONTACT_TRIANGLE_CONTACT;
            const bool elasticAttachment = sample.flags == elasticFlags;
            const bool triangleContact = sample.flags == triangleFlags;
            bool validPayload = false;
            if (triangleContact) {
                // Exact flag, finite packed coordinates, positive slave
                // quadrature area/material values, and nondegenerate master
                // triangle are rejected before any GPU upload.
                validPayload =
                    numi::matter::fem_body_triangle_contact::
                        validTriangleContactSample(sample);
            } else {
                const double normalLength = std::sqrt(
                    normal.x * normal.x + normal.y * normal.y +
                    normal.z * normal.z);
                validPayload =
                    (sample.flags == NM_NUMI_HUMAN_FEM_BODY_CONTACT_ACTIVE ||
                     elasticAttachment) &&
                    finiteScale(point) && point.w > 0.0f &&
                    finiteScale(normal) &&
                    std::abs(normalLength - 1.0) <= 1.0e-5 &&
                    normal.w >= 0.0f &&
                    (!elasticAttachment || normal.w == 0.0f) &&
                    finiteScale(stiffness) && stiffness.x > 0.0f &&
                    stiffness.y > 0.0f && stiffness.z == 0.0f &&
                    stiffness.w == 0.0f;
            }
            if (sample.slaveNode >= source.nodeLoads.size() ||
                sample.bodyIndex == NM_INVALID_INDEX ||
                (!triangleContact &&
                 sample.flags != NM_NUMI_HUMAN_FEM_BODY_CONTACT_ACTIVE &&
                 !elasticAttachment) ||
                sample.reserved0 != 0u || !validPayload ||
                (source.nodeAnchors[sample.slaveNode].flags &
                    NM_NUMI_HUMAN_TENDON_FEM_NODE_ANCHOR_ACTIVE) != 0u) {
                return false;
            }
        }
    }
    if (!source.articularContactPairRanges.empty()) {
        if (source.articularContactSamples.empty()) return false;
        std::uint64_t nextSample = 0u;
        for (const auto& range : source.articularContactPairRanges) {
            if (range.count == 0u || range.first != nextSample ||
                static_cast<std::uint64_t>(range.first) + range.count >
                    source.articularContactSamples.size()) {
                return false;
            }
            nextSample += range.count;
        }
        if (nextSample != source.articularContactSamples.size()) return false;
    }
    for (const auto& sample : source.articularContactSamples) {
        const nm_float4 slave = sample.slaveLocalPointAndArea;
        const nm_float4 triangle0 =
            sample.masterLocalTriangle0AndReferenceSeparation;
        const nm_float4 triangle1 =
            sample.masterLocalTriangle1AndStiffness;
        const nm_float4 triangle2 =
            sample.masterLocalTriangle2AndNormalStrainPerPressure;
        const nm_float4 referenceNormal =
            sample.masterLocalReferenceNormalAndReserved;
        const std::array<nm_float4, 3u> adjacentOpposite{{
            sample.masterLocalAdjacentOpposite0AndActive,
            sample.masterLocalAdjacentOpposite1AndActive,
            sample.masterLocalAdjacentOpposite2AndActive,
        }};
        const double edge10x = triangle1.x - triangle0.x;
        const double edge10y = triangle1.y - triangle0.y;
        const double edge10z = triangle1.z - triangle0.z;
        const double edge20x = triangle2.x - triangle0.x;
        const double edge20y = triangle2.y - triangle0.y;
        const double edge20z = triangle2.z - triangle0.z;
        const double normalX = edge10y * edge20z - edge10z * edge20y;
        const double normalY = edge10z * edge20x - edge10x * edge20z;
        const double normalZ = edge10x * edge20y - edge10y * edge20x;
        const double squaredNormalLength = normalX * normalX +
            normalY * normalY + normalZ * normalZ;
        const double referenceNormalLength = std::sqrt(
            referenceNormal.x * referenceNormal.x +
            referenceNormal.y * referenceNormal.y +
            referenceNormal.z * referenceNormal.z);
        const bool sameBody =
            sample.slaveBodyIndex == sample.masterBodyIndex;
        const std::uint32_t expectedFlags = sameBody
            ? NM_NUMI_HUMAN_ARTICULAR_CONTACT_INTERNAL_SAME_BODY
            : NM_NUMI_HUMAN_ARTICULAR_CONTACT_ACTIVE;
        bool adjacencyValid = true;
        const std::array<nm_float4, 3u> triangle{{
            triangle0, triangle1, triangle2}};
        for (std::uint32_t edge = 0u; edge < 3u; ++edge) {
            const nm_float4 opposite = adjacentOpposite[edge];
            if (!finiteScale(opposite) ||
                (opposite.w != 0.0f && opposite.w != 1.0f)) {
                adjacencyValid = false;
                break;
            }
            if (opposite.w == 0.0f) {
                adjacencyValid = opposite.x == 0.0f &&
                    opposite.y == 0.0f && opposite.z == 0.0f;
                if (!adjacencyValid) break;
                continue;
            }
            const nm_float4 first = triangle[edge];
            const nm_float4 second = triangle[(edge + 1u) % 3u];
            const double firstX = second.x - first.x;
            const double firstY = second.y - first.y;
            const double firstZ = second.z - first.z;
            const double secondX = opposite.x - first.x;
            const double secondY = opposite.y - first.y;
            const double secondZ = opposite.z - first.z;
            const double crossX = firstY * secondZ - firstZ * secondY;
            const double crossY = firstZ * secondX - firstX * secondZ;
            const double crossZ = firstX * secondY - firstY * secondX;
            const double squaredLength = crossX * crossX + crossY * crossY +
                crossZ * crossZ;
            adjacencyValid = std::isfinite(squaredLength) &&
                squaredLength > 1.0e-20;
            if (!adjacencyValid) break;
        }
        if (sample.slaveBodyIndex == NM_INVALID_INDEX ||
            sample.masterBodyIndex == NM_INVALID_INDEX ||
            sample.flags != expectedFlags ||
            sample.reserved0 != 0u || !finiteScale(slave) ||
            !finiteScale(triangle0) || !finiteScale(triangle1) ||
            !finiteScale(triangle2) || !finiteScale(referenceNormal) ||
            slave.w <= 0.0f ||
            !(std::isfinite(squaredNormalLength) &&
              squaredNormalLength > 1.0e-20) ||
            triangle1.w <= 0.0f || triangle2.w <= 0.0f ||
            std::abs(referenceNormalLength - 1.0) > 1.0e-5 ||
            referenceNormal.w != 0.0f || !adjacencyValid) {
            return false;
        }
    }
    for (const auto& ligament : source.passiveLigaments) {
        NumiHumanPassiveLigamentFiberEvaluation referenceEvaluation;
        if (ligament.firstBodyIndex == NM_INVALID_INDEX ||
            ligament.secondBodyIndex == NM_INVALID_INDEX ||
            ligament.firstBodyIndex == ligament.secondBodyIndex ||
            ligament.flags != NM_NUMI_HUMAN_PASSIVE_LIGAMENT_ACTIVE ||
            ligament.reserved0 != 0u ||
            !finiteScale(ligament.firstLocalPoint) ||
            !finiteScale(ligament.secondLocalPoint) ||
            ligament.firstLocalPoint.w != 0.0f ||
            ligament.secondLocalPoint.w != 0.0f ||
            !evaluateNumiHumanPassiveLigamentFiber(
                ligament, ligament.reference.x, referenceEvaluation)) {
            return false;
        }
    }
    for (const auto& band : source.passiveRoutedBands) {
        NumiHumanPassiveRoutedBandEvaluation referenceEvaluation;
        if (band.pulleyBodyIndex == band.insertionBodyIndex ||
            !evaluateNumiHumanPassiveRoutedBand(
                band, band.reference.x, 0.0, referenceEvaluation)) {
            return false;
        }
    }
    std::vector<double> endpointSignedScales(source.endpointCount, 0.0);
    std::vector<double> endpointAbsoluteScales(source.endpointCount, 0.0);
    std::uint32_t anchorCount = 0u;
    for (const NMNumiHumanTendonFEMNodeLoadGPU& load : source.nodeLoads) {
        if (!finiteScale(load.scale)) return false;
        for (std::uint32_t slot = 0u; slot < 4u; ++slot) {
            const std::uint32_t endpoint = load.endpointIndex[slot];
            const float scale = scaleComponent(load.scale, slot);
            if ((endpoint == NM_INVALID_INDEX) != (scale == 0.0f) ||
                (endpoint != NM_INVALID_INDEX && endpoint >= source.endpointCount)) {
                return false;
            }
            for (std::uint32_t previous = 0u; previous < slot; ++previous) {
                if (endpoint != NM_INVALID_INDEX &&
                    load.endpointIndex[previous] == endpoint) {
                    return false;
                }
            }
            if (endpoint != NM_INVALID_INDEX) {
                endpointSignedScales[endpoint] += scale;
                endpointAbsoluteScales[endpoint] += std::abs(scale);
            }
        }
    }
    for (const NMNumiHumanTendonFEMNodeAnchorGPU& anchor :
         source.nodeAnchors) {
        if (!finiteScale(anchor.localPoint) || anchor.reserved0 != 0u ||
            anchor.reserved1 != 0u ||
            (anchor.flags &
                ~NM_NUMI_HUMAN_TENDON_FEM_NODE_ANCHOR_ACTIVE) != 0u ||
            anchor.localPoint.w != 0.0f) {
            return false;
        }
        if ((anchor.flags &
                NM_NUMI_HUMAN_TENDON_FEM_NODE_ANCHOR_ACTIVE) == 0u) {
            if (anchor.bodyIndex != NM_INVALID_INDEX ||
                anchor.localPoint.x != 0.0f || anchor.localPoint.y != 0.0f ||
                anchor.localPoint.z != 0.0f) {
                return false;
            }
        } else {
            if (anchor.bodyIndex == NM_INVALID_INDEX) return false;
            ++anchorCount;
        }
    }
    std::vector<bool> loadEndpoints(source.endpointCount, false);
    std::vector<bool> anchorEndpoints(source.endpointCount, false);
    std::vector<bool> expectedLoadedEndpoints(source.endpointCount, false);
    for (const NMNumiHumanTendonFEMEndpointReplacementGPU& replacement :
         source.endpointReplacements) {
        constexpr std::uint32_t replacementFlagMask =
            NM_NUMI_HUMAN_TENDON_FEM_ENDPOINT_REPLACEMENT_ACTIVE |
            NM_NUMI_HUMAN_TENDON_FEM_ENDPOINT_REPLACEMENT_FULL_MUSCLE_ROW |
            NM_NUMI_HUMAN_TENDON_FEM_ENDPOINT_REPLACEMENT_DISTAL_FORCE_COUPLE;
        const bool fullMuscleRow = (replacement.flags &
            NM_NUMI_HUMAN_TENDON_FEM_ENDPOINT_REPLACEMENT_FULL_MUSCLE_ROW) != 0u;
        const bool distalForceCouple = (replacement.flags &
            NM_NUMI_HUMAN_TENDON_FEM_ENDPOINT_REPLACEMENT_DISTAL_FORCE_COUPLE) != 0u;
        if ((replacement.flags &
                NM_NUMI_HUMAN_TENDON_FEM_ENDPOINT_REPLACEMENT_ACTIVE) == 0u ||
            (replacement.flags & ~replacementFlagMask) != 0u ||
            (distalForceCouple && !fullMuscleRow) ||
            replacement.reserved0 != 0u ||
            replacement.loadEndpointIndex >= source.endpointCount ||
            replacement.anchorEndpointIndex >= source.endpointCount ||
            replacement.loadEndpointIndex == replacement.anchorEndpointIndex ||
            !finiteScale(replacement.forceOwnerFraction) ||
            replacement.forceOwnerFraction.x <= 0.0f ||
            replacement.forceOwnerFraction.x > 1.0f ||
            replacement.forceOwnerFraction.y != 0.0f ||
            replacement.forceOwnerFraction.z != 0.0f ||
            replacement.forceOwnerFraction.w != 0.0f ||
            std::abs(replacement.forceOwnerFraction.x -
                source.productionForceOwnerFraction) > 1.0e-6f ||
            loadEndpoints[replacement.loadEndpointIndex] ||
            anchorEndpoints[replacement.anchorEndpointIndex]) {
            return false;
        }
        loadEndpoints[replacement.loadEndpointIndex] = true;
        anchorEndpoints[replacement.anchorEndpointIndex] = true;
        expectedLoadedEndpoints[replacement.loadEndpointIndex] = true;
        if (distalForceCouple) {
            expectedLoadedEndpoints[replacement.anchorEndpointIndex] = true;
        }
        const double owner = replacement.forceOwnerFraction.x;
        if (std::abs(
                endpointSignedScales[replacement.loadEndpointIndex] - owner) >
                1.0e-6 ||
            std::abs(
                endpointAbsoluteScales[replacement.loadEndpointIndex] - owner) >
                1.0e-6 ||
            std::abs(endpointSignedScales[
                replacement.anchorEndpointIndex]) > 1.0e-6 ||
            std::abs(endpointAbsoluteScales[
                replacement.anchorEndpointIndex] -
                (distalForceCouple ? 2.0 * owner : 0.0)) > 1.0e-6) {
            return false;
        }
    }
    if (anchorCount == 0u ||
        (deferred && runtime.femHumanAttachmentCount() != anchorCount) ||
        std::any_of(
            endpointAbsoluteScales.begin(), endpointAbsoluteScales.end(),
            [](const double scale) {
                return !std::isfinite(scale) || scale > 2.000001;
            }
        ) || (passiveAttachmentOnly
            ? std::any_of(
                endpointAbsoluteScales.begin(), endpointAbsoluteScales.end(),
                [](const double scale) { return scale != 0.0; })
            : std::none_of(
                endpointAbsoluteScales.begin(), endpointAbsoluteScales.end(),
                [](const double scale) { return scale > 0.0; }))) {
        return false;
    }
    for (std::size_t endpointIndex = 0u;
         endpointIndex < endpointAbsoluteScales.size();
         ++endpointIndex) {
        if ((endpointAbsoluteScales[endpointIndex] > 0.0) !=
            expectedLoadedEndpoints[endpointIndex]) {
            return false;
        }
    }
    auto candidate = std::make_unique<State>();
    candidate->runtime = &runtime;
    candidate->nodeLoads.assign(source.nodeLoads.begin(), source.nodeLoads.end());
    candidate->nodeAnchors.assign(
        source.nodeAnchors.begin(), source.nodeAnchors.end()
    );
    candidate->replacements.assign(
        source.endpointReplacements.begin(), source.endpointReplacements.end()
    );
    candidate->contactSamples.assign(
        source.contactSamples.begin(), source.contactSamples.end());
    candidate->contactContributions.assign(
        source.contactContributions.begin(),
        source.contactContributions.end());
    candidate->contactRanges.assign(
        source.contactRanges.begin(), source.contactRanges.end());
    candidate->femBodyContactSamplesStaging.assign(
        source.femBodyContactSamples.begin(),
        source.femBodyContactSamples.end());
    candidate->femBodyContactSamples = candidate->femBodyContactSamplesStaging;
    candidate->femBodyContactNeighborhoodRangesStaging.assign(
        source.femBodyContactNeighborhoodRanges.begin(),
        source.femBodyContactNeighborhoodRanges.end());
    candidate->femBodyContactNeighborhoodRanges = candidate->femBodyContactNeighborhoodRangesStaging;
    candidate->femBodyContactNeighborhoodTrianglesStaging.assign(
        source.femBodyContactNeighborhoodTriangles.begin(),
        source.femBodyContactNeighborhoodTriangles.end());
    candidate->femBodyContactNeighborhoodTriangles = candidate->femBodyContactNeighborhoodTrianglesStaging;
    candidate->femBodyContactNeighborhoodBVHNodesStaging.assign(
        source.femBodyContactNeighborhoodBVHNodes.begin(),
        source.femBodyContactNeighborhoodBVHNodes.end());
    candidate->femBodyContactNeighborhoodBVHNodes = candidate->femBodyContactNeighborhoodBVHNodesStaging;
    candidate->hasMultiMasterTriangleContact =
        hasMultiMasterTriangleContact;
    candidate->femSurfaceAttachments.assign(
        source.femSurfaceAttachments.begin(),
        source.femSurfaceAttachments.end());
    candidate->implicitSpringCount =
        configuration.implicitElasticBodySpringCount;
    {
        const std::uint32_t elasticFlags =
            NM_NUMI_HUMAN_FEM_BODY_CONTACT_ACTIVE |
            NM_NUMI_HUMAN_FEM_BODY_CONTACT_ELASTIC_ATTACHMENT;
        std::vector<bool> selected(candidate->femBodyContactSamples.size(), false);
        for (std::size_t index = 0u;
             index < candidate->femBodyContactSamples.size(); ++index) {
            const auto& sample = candidate->femBodyContactSamples[index];
            if (sample.flags == elasticFlags &&
                candidate->implicitSpringSamples.size() <
                    candidate->implicitSpringCount) {
                selected[index] = true;
                candidate->implicitSpringSamples.push_back(sample);
                MRArticulatedPointImpulseGPU query{};
                query.bodyIndex = sample.bodyIndex;
                query.localPoint = {
                    sample.bodyLocalPointAndArea.x,
                    sample.bodyLocalPointAndArea.y,
                    sample.bodyLocalPointAndArea.z,
                    0.0f,
                };
                candidate->implicitSpringPointQueries.push_back(query);
            }
        }
        if (candidate->implicitSpringSamples.size() != candidate->implicitSpringCount)
            return false;
        if (candidate->implicitSpringCount == 0u) {
            candidate->femBodyContactSolverSamples = candidate->femBodyContactSamples;
            candidate->femBodyContactSolverNeighborhoodRanges = candidate->femBodyContactNeighborhoodRanges;
        } else {
            if (!fem_body_contact_neighborhood::appendUnselectedSolverRows(
                    candidate->femBodyContactSamples, candidate->femBodyContactNeighborhoodRanges,
                    selected, candidate->femBodyContactSolverSamplesStaging,
                    candidate->femBodyContactSolverNeighborhoodRangesStaging)) return false;
            candidate->femBodyContactSolverSamples = candidate->femBodyContactSolverSamplesStaging;
            candidate->femBodyContactSolverNeighborhoodRanges = candidate->femBodyContactSolverNeighborhoodRangesStaging;
        }
        if (candidate->hasMultiMasterTriangleContact) {
            if (fem_body_contact_grouping::contiguousSlaveGroupCounts(
                    candidate->femBodyContactSolverSamples, candidate->femBodyContactSolverGroupCounts)) {
                candidate->femBodyContactGroupedSolverSamples = candidate->femBodyContactSolverSamples;
                candidate->femBodyContactGroupedSolverNeighborhoodRanges = candidate->femBodyContactSolverNeighborhoodRanges;
            } else {
                if (!fem_body_contact_grouping::stableGroupRowsBySlave(
                        candidate->femBodyContactSolverSamples, candidate->femBodyContactSolverNeighborhoodRanges,
                        candidate->femBodyContactGroupedSolverSamplesStaging,
                        candidate->femBodyContactGroupedSolverNeighborhoodRangesStaging,
                        candidate->femBodyContactSolverGroupCounts)) return false;
                candidate->femBodyContactGroupedSolverSamples = candidate->femBodyContactGroupedSolverSamplesStaging;
                candidate->femBodyContactGroupedSolverNeighborhoodRanges = candidate->femBodyContactGroupedSolverNeighborhoodRangesStaging;
            }
        }
    }
    candidate->articularContactSamples.assign(
        source.articularContactSamples.begin(),
        source.articularContactSamples.end());
    candidate->articularContactPairRanges.assign(
        source.articularContactPairRanges.begin(),
        source.articularContactPairRanges.end());
    candidate->passiveLigaments.assign(
        source.passiveLigaments.begin(), source.passiveLigaments.end());
    candidate->passiveRoutedBands.assign(
        source.passiveRoutedBands.begin(), source.passiveRoutedBands.end());
    for (const auto& sample : candidate->articularContactSamples) {
        if (sample.flags == NM_NUMI_HUMAN_ARTICULAR_CONTACT_ACTIVE) {
            ++candidate->articularMechanicalSampleCount;
        } else {
            ++candidate->articularInternalSameBodySampleCount;
        }
    }
    candidate->metallib = configuration.metallib;
    candidate->executionMode = configuration.executionMode;
    candidate->implicitSpringCount =
        configuration.implicitElasticBodySpringCount;
    candidate->acceptedStepExtensionContext =
        configuration.acceptedStepExtensionContext;
    candidate->encodeAcceptedStepExtension =
        configuration.encodeAcceptedStepExtension;
    candidate->acceptedStepExtensionFingerprint =
        configuration.acceptedStepExtensionFingerprint;
    candidate->deferAcceptedControlCursorPublication =
        configuration.deferAcceptedControlCursorPublication;
    candidate->deferAcceptedStepExtensionFinalization =
        configuration.deferAcceptedStepExtensionFinalization;
    candidate->deferAcceptedAuditPublication =
        (configuration.reserved0 &
         kNumiHumanTendonFEMLoadDeferAcceptedAuditPublication) != 0u;
    candidate->expectedMicrotickCount = configuration.expectedMicrotickCount;
    candidate->endpointCount = source.endpointCount;
    candidate->environmentCount = source.environmentCount;
    candidate->activeAnchorCount = anchorCount;
    candidate->runtimeDeviceProgramFingerprint =
        runtime.deviceProgramFingerprint();
    candidate->articularContactPairCount = static_cast<std::uint32_t>(
        candidate->articularContactPairRanges.size());
    const std::size_t acceptedHistoryElements =
        static_cast<std::size_t>(candidate->environmentCount) *
        NM_NUMI_HUMAN_ARTICULAR_CONTACT_AUDIT_MAX_STEPS;
    candidate->anchorReactionAcceptedHistory.resize(
        acceptedHistoryElements);
    if (!candidate->femBodyContactSamples.empty() ||
        !candidate->femSurfaceAttachments.empty()) {
        candidate->femBodyContactAcceptedHistory.resize(
            acceptedHistoryElements);
    }
    if (!candidate->articularContactSamples.empty()) {
        candidate->articularContactAcceptedHistory.resize(
            acceptedHistoryElements);
    }
    if (candidate->articularContactPairCount != 0u) {
        const std::size_t pairStride =
            static_cast<std::size_t>(candidate->articularContactPairCount) + 1u;
        if (acceptedHistoryElements >
            std::numeric_limits<std::size_t>::max() / pairStride) {
            return false;
        }
        candidate->articularContactPairForceAcceptedHistory.resize(
            acceptedHistoryElements * pairStride);
    }
    if (!candidate->passiveLigaments.empty()) {
        candidate->passiveLigamentAcceptedState.resize(
            candidate->environmentCount);
    }
    if (!candidate->passiveRoutedBands.empty()) {
        candidate->passiveRoutedBandAcceptedState.resize(
            candidate->environmentCount);
    }
    std::uint64_t fingerprint = 1469598103934665603ull;
    const std::uint64_t runtimeFingerprint =
        candidate->runtimeDeviceProgramFingerprint;
    fingerprint = appendFingerprint(
        fingerprint, &runtimeFingerprint, sizeof(runtimeFingerprint)
    );
    fingerprint = appendFingerprint(
        fingerprint, &candidate->endpointCount, sizeof(candidate->endpointCount)
    );
    fingerprint = appendFingerprint(
        fingerprint, &candidate->environmentCount,
        sizeof(candidate->environmentCount)
    );
    fingerprint = appendFingerprint(
        fingerprint, &candidate->activeAnchorCount,
        sizeof(candidate->activeAnchorCount)
    );
    fingerprint = appendFingerprint(
        fingerprint, &candidate->executionMode,
        sizeof(candidate->executionMode)
    );
    const bool hasAcceptedStepExtension =
        candidate->encodeAcceptedStepExtension != nullptr;
    fingerprint = appendFingerprint(
        fingerprint, &hasAcceptedStepExtension,
        sizeof(hasAcceptedStepExtension)
    );
    fingerprint = appendFingerprint(
        fingerprint, &candidate->acceptedStepExtensionFingerprint,
        sizeof(candidate->acceptedStepExtensionFingerprint)
    );
    fingerprint = appendFingerprint(
        fingerprint, &candidate->deferAcceptedControlCursorPublication,
        sizeof(candidate->deferAcceptedControlCursorPublication)
    );
    fingerprint = appendFingerprint(
        fingerprint, &candidate->deferAcceptedStepExtensionFinalization,
        sizeof(candidate->deferAcceptedStepExtensionFinalization)
    );
    fingerprint = appendFingerprint(
        fingerprint, &candidate->deferAcceptedAuditPublication,
        sizeof(candidate->deferAcceptedAuditPublication)
    );
    if (candidate->expectedMicrotickCount != 1u) {
        fingerprint = appendFingerprint(fingerprint,
            &candidate->expectedMicrotickCount,
            sizeof(candidate->expectedMicrotickCount));
    }
    fingerprint = appendFingerprint(
        fingerprint, candidate->nodeLoads.data(),
        candidate->nodeLoads.size() * sizeof(candidate->nodeLoads.front())
    );
    fingerprint = appendFingerprint(
        fingerprint, candidate->nodeAnchors.data(),
        candidate->nodeAnchors.size() * sizeof(candidate->nodeAnchors.front())
    );
    fingerprint = appendFingerprint(
        fingerprint, candidate->replacements.data(),
        candidate->replacements.size() * sizeof(candidate->replacements.front())
    );
    fingerprint = appendFingerprint(
        fingerprint, candidate->contactSamples.data(),
        candidate->contactSamples.size() *
            sizeof(NMNumiHumanFEMContactSampleGPU));
    fingerprint = appendFingerprint(
        fingerprint, candidate->contactContributions.data(),
        candidate->contactContributions.size() *
            sizeof(NMNumiHumanFEMContactContributionGPU));
    fingerprint = appendFingerprint(
        fingerprint, candidate->contactRanges.data(),
        candidate->contactRanges.size() * sizeof(NMIncidenceRangeGPU));
    fingerprint = appendFingerprint(
        fingerprint, candidate->femBodyContactSamples.data(),
        candidate->femBodyContactSamples.size() *
            sizeof(NMNumiHumanFEMBodyContactSampleGPU));
    fingerprint = appendFingerprint(
        fingerprint, candidate->femBodyContactNeighborhoodRanges.data(),
        candidate->femBodyContactNeighborhoodRanges.size() *
            sizeof(NMNumiHumanFEMBodyContactNeighborhoodRangeGPU));
    fingerprint = appendFingerprint(
        fingerprint, candidate->femBodyContactNeighborhoodTriangles.data(),
        candidate->femBodyContactNeighborhoodTriangles.size() *
            sizeof(NMNumiHumanFEMBodyContactNeighborhoodTriangleGPU));
    fingerprint = appendFingerprint(
        fingerprint, candidate->femBodyContactNeighborhoodBVHNodes.data(),
        candidate->femBodyContactNeighborhoodBVHNodes.size() *
            sizeof(NMNumiHumanFEMBodyContactBVHNodeGPU));
    fingerprint = appendFingerprint(
        fingerprint, candidate->femSurfaceAttachments.data(),
        candidate->femSurfaceAttachments.size() *
            sizeof(NMNumiHumanFEMSurfaceAttachmentGPU));
    fingerprint = appendFingerprint(
        fingerprint, &candidate->implicitSpringCount,
        sizeof(candidate->implicitSpringCount));
    fingerprint = appendFingerprint(
        fingerprint, candidate->articularContactSamples.data(),
        candidate->articularContactSamples.size() *
            sizeof(NMNumiHumanArticularContactSampleGPU));
    fingerprint = appendFingerprint(
        fingerprint, candidate->articularContactPairRanges.data(),
        candidate->articularContactPairRanges.size() *
            sizeof(NMIncidenceRangeGPU));
    fingerprint = appendFingerprint(
        fingerprint, candidate->passiveLigaments.data(),
        candidate->passiveLigaments.size() *
            sizeof(NMNumiHumanPassiveLigamentGPU));
    fingerprint = appendFingerprint(
        fingerprint, candidate->passiveRoutedBands.data(),
        candidate->passiveRoutedBands.size() *
            sizeof(NMNumiHumanPassiveRoutedBandGPU));
    candidate->fingerprint = fingerprint == 0u ? 1u : fingerprint;
    candidate->message = "initialized";
    state_ = std::move(candidate);
    return true;
}

bool NumiHumanTendonFEMLoadAdapter::encodePreDynamics(
    const metalrobo::MetalNumiHumanTendonLoadPass& pass
) {
    @autoreleasepool {
        if (state_ != nullptr) {
            state_->acceptedWrenchSourceValid = false;
            state_->acceptedWrenchSourceCommandBuffer = nullptr;
            state_->acceptedWrenchSourceBodyPoses = nullptr;
            state_->acceptedWrenchSourcePointJacobians = nullptr;
            state_->acceptedWrenchSourceQ = nullptr;
            state_->acceptedWrenchSourceQCoordinateCount = 0u;
        }
        if (state_ != nullptr && state_->executionMode ==
                NumiHumanTendonFEMLoadExecutionMode::numanXDeferred) {
            state_->deferredExternalForcesAvailable = false;
            state_->deferredCommandBufferIdentity = 0u;
        }
        if (state_ == nullptr || state_->runtime == nullptr ||
            pass.commandBuffer == nullptr || pass.bindings == nullptr ||
            pass.transfers == nullptr || pass.generalizedForces == nullptr ||
            pass.bodyPoses == nullptr || pass.pointJacobians == nullptr ||
            pass.environmentCount != state_->environmentCount ||
            pass.endpointCount != state_->endpointCount ||
            pass.environmentCount == 0u || pass.endpointCount == 0u ||
            pass.dofCount == 0u || pass.muscleCount == 0u ||
            pass.generalizedForceStride < pass.dofCount ||
            pass.pointJacobianStride == 0u ||
            pass.bodyJacobianPointOffset == MR_INVALID_INDEX ||
            pass.bodyPoseStride == 0u ||
            (state_->articularBodyPoseStride != 0u &&
             pass.bodyPoseStride != state_->articularBodyPoseStride) ||
            pass.stepIndex >=
                NM_NUMI_HUMAN_ARTICULAR_CONTACT_AUDIT_MAX_STEPS) {
            if (state_ != nullptr)
                state_->message = "invalid borrowed Human pre-dynamics pass";
            return false;
        }
        id<MTLCommandBuffer> command =
            (__bridge id<MTLCommandBuffer>)pass.commandBuffer;
        id<MTLBuffer> bindings = (__bridge id<MTLBuffer>)pass.bindings;
        id<MTLBuffer> transfers = (__bridge id<MTLBuffer>)pass.transfers;
        id<MTLBuffer> generalizedForces =
            (__bridge id<MTLBuffer>)pass.generalizedForces;
        id<MTLBuffer> bodyPoses = (__bridge id<MTLBuffer>)pass.bodyPoses;
        id<MTLBuffer> pointJacobians =
            (__bridge id<MTLBuffer>)pass.pointJacobians;
        if (command == nil || bindings == nil || transfers == nil ||
            generalizedForces == nil || bodyPoses == nil ||
            pointJacobians == nil) {
            state_->message = "borrowed Human Metal objects are unavailable";
            return false;
        }
        const std::uint64_t muscleRowElements =
            static_cast<std::uint64_t>(pass.environmentCount) *
            pass.muscleCount * pass.dofCount;
        const std::uint64_t reducedForceEnd =
            static_cast<std::uint64_t>(pass.generalizedForceOffset) +
            static_cast<std::uint64_t>(pass.environmentCount - 1u) *
                pass.generalizedForceStride +
            pass.dofCount;
        const std::uint64_t requiredForceElements = std::max(
            muscleRowElements, reducedForceEnd
        );
        if (pass.generalizedForceOffset < muscleRowElements ||
            requiredForceElements > generalizedForces.length / sizeof(float)) {
            state_->message =
                "borrowed Human generalized-force workspace is undersized";
            return false;
        }
        id<MTLDevice> device = transfers.device;
        if (device == nil || bindings.device.registryID != device.registryID ||
            generalizedForces.device.registryID != device.registryID ||
            bodyPoses.device.registryID != device.registryID ||
            pointJacobians.device.registryID != device.registryID) {
            state_->message = "borrowed Human buffers do not share one Metal device";
            return false;
        }
        if (state_->device == nil) {
            state_->device = device;
            NSError* error = nil;
#ifndef NUMI_HUMAN_TENDON_FEM_TEST_SOURCE_PATH
            NSString* path = [NSString
                stringWithUTF8String:state_->metallib.string().c_str()];
            state_->library = path == nil
                ? nil
                : [device newLibraryWithURL:[NSURL fileURLWithPath:path]
                                      error:&error];
#else
            // Test-only current-source compilation for hosts without offline Metal.
            NSString* shaderSource = [NSString
                stringWithContentsOfFile:@(NUMI_HUMAN_TENDON_FEM_TEST_SOURCE_PATH)
                encoding:NSUTF8StringEncoding error:&error];
            NSData* shaderBytes = [NSData
                dataWithContentsOfFile:@(NUMI_HUMAN_TENDON_FEM_TEST_SOURCE_PATH)];
            if (shaderSource == nil || shaderBytes == nil ||
                shaderBytes.length == 0u || shaderBytes.length > UINT32_MAX) {
                state_->message = "pinned test Matter shader source unavailable";
                return false;
            }
            unsigned char digest[CC_SHA256_DIGEST_LENGTH];
            CC_SHA256(shaderBytes.bytes,
                      static_cast<CC_LONG>(shaderBytes.length), digest);
            constexpr char hex[] = "0123456789abcdef";
            std::string actualSHA;
            actualSHA.reserve(2u * CC_SHA256_DIGEST_LENGTH);
            for (const auto byte : digest) {
                actualSHA += hex[byte >> 4u];
                actualSHA += hex[byte & 15u];
            }
            if (actualSHA != NUMI_HUMAN_TENDON_FEM_TEST_SOURCE_SHA256) {
                state_->message = "pinned test Matter shader SHA-256 mismatch";
                return false;
            }
            MTLCompileOptions* shaderOptions = [MTLCompileOptions new];
            shaderOptions.languageVersion = MTLLanguageVersion4_0;
            shaderOptions.mathMode = MTLMathModeSafe;
            shaderOptions.mathFloatingPointFunctions =
                MTLMathFloatingPointFunctionsPrecise;
            state_->library = [device newLibraryWithSource:shaderSource
                options:shaderOptions error:&error];
#endif
            if (state_->library == nil) {
                state_->message = "Numi Matter metallib did not load for Human tendon/FEM assembly";
                return false;
            }
            // ABI 17 marker rejects old hosts before incompatible status scratch
            // or 176-byte triangle bindings can be created.
            id<MTLFunction> contactTriangleABI17Marker = [state_->library
                newFunctionWithName:@"numi_matter_metal::nm_numi_human_contact_triangle_abi17_marker"];
            if (contactTriangleABI17Marker == nil) {
                state_->message =
                    "Numi Matter metallib lacks Human contact triangle ABI 17";
                state_->library = nil;
                return false;
            }
            const auto pipeline = [&](const char* name) {
                const std::string qualified =
                    std::string("numi_matter_metal::") + name;
                id<MTLFunction> function = [state_->library
                    newFunctionWithName:[NSString
                        stringWithUTF8String:qualified.c_str()]];
                if (function == nil) {
                    state_->message = std::string("missing Metal function ") + name;
                    return static_cast<id<MTLComputePipelineState>>(nil);
                }
                error = nil;
                MTLComputePipelineDescriptor* descriptor =
                    [MTLComputePipelineDescriptor new];
                descriptor.computeFunction = function;
                descriptor.label = [NSString stringWithUTF8String:qualified.c_str()];
                id<MTLComputePipelineState> result = [device
                    newComputePipelineStateWithDescriptor:descriptor
                    options:MTLPipelineOptionNone reflection:nil error:&error];
                if (result == nil) {
                    const char* description = error == nil
                        ? "unknown Metal error"
                        : error.localizedDescription.UTF8String;
                    state_->message = std::string("failed to compile pipeline ") +
                        name + ": " + (description == nullptr
                            ? "unknown Metal error"
                            : description);
                }
                return result;
            };
            state_->provisionalStatusPipeline = pipeline(
                "nm_numi_human_prepare_provisional_status");
            if (state_->executionMode ==
                    NumiHumanTendonFEMLoadExecutionMode::standaloneRuntime) {
                state_->statusPipeline = pipeline(
                    state_->deferAcceptedAuditPublication
                        ? "nm_numi_human_adapt_stand_status_v2"
                        : "nm_numi_human_adapt_stand_status");
            }
            state_->forcePipeline = pipeline(
                "nm_numi_human_assemble_tendon_fem_loads");
            state_->forceAuditPipeline = pipeline(
                "nm_numi_human_audit_tendon_fem_loads");

            const char* nodeWork = std::getenv("NUMI_HUMAN_PARALLEL_NODE_WORK");
            const char* sparseAnchors = std::getenv("NUMI_HUMAN_SPARSE_ANCHOR_PROJECTION");
            for (const char* setting : {nodeWork, sparseAnchors}) {
                if (setting != nullptr && std::strcmp(setting, "0") != 0 &&
                    std::strcmp(setting, "1") != 0) {
                    state_->message = "Human node-work settings must be 0 or 1";
                    return false;
                }
            }
            state_->sparseAnchorProjection = sparseAnchors == nullptr ||
                std::strcmp(sparseAnchors, "0") != 0;
            state_->nodeValidationFirstInvalid = [device newBufferWithLength:
                std::max<NSUInteger>(16u, state_->environmentCount*sizeof(std::uint32_t))
                options:MTLResourceStorageModePrivate];
            std::vector<std::uint32_t> activeAnchors;
            activeAnchors.reserve(state_->activeAnchorCount);
            for (std::uint32_t node=0u; node<state_->nodeAnchors.size(); ++node)
                if ((state_->nodeAnchors[node].flags &
                     NM_NUMI_HUMAN_TENDON_FEM_NODE_ANCHOR_ACTIVE) != 0u)
                    activeAnchors.push_back(node);
            if (activeAnchors.size()!=state_->activeAnchorCount) return false;
            state_->activeAnchorIndices = [device newBufferWithLength:
                std::max<NSUInteger>(16u, activeAnchors.size()*sizeof(std::uint32_t))
                options:MTLResourceStorageModeShared];
            if (state_->activeAnchorIndices == nil ||
                state_->nodeValidationFirstInvalid == nil) return false;
            if (!activeAnchors.empty())
                std::memcpy(state_->activeAnchorIndices.contents, activeAnchors.data(),
                    activeAnchors.size()*sizeof(std::uint32_t));
            if ((state_->nodeLoads.size()>256u ||
                 (nodeWork!=nullptr && std::strcmp(nodeWork,"1")==0)) &&
                (nodeWork==nullptr || std::strcmp(nodeWork,"0")!=0)) {
                state_->nodeWorkTiles=static_cast<std::uint32_t>(
                    (state_->nodeLoads.size()+255u)/256u);
                const std::uint64_t tiles=std::uint64_t(state_->environmentCount)*
                    state_->nodeWorkTiles;
                if (tiles>UINT32_MAX/256u ||
                    tiles>std::numeric_limits<NSUInteger>::max()/sizeof(nm_float4))
                    return false;
                state_->nodeValidationPartials=[device newBufferWithLength:
                    tiles*sizeof(std::uint32_t) options:MTLResourceStorageModePrivate];
                state_->nodeForceAuditPartials=[device newBufferWithLength:
                    tiles*sizeof(nm_float4) options:MTLResourceStorageModePrivate];
                state_->nodeValidationPartialPipeline=pipeline("nm_numi_human_validate_node_load_tiles");
                state_->nodeValidationFinishPipeline=pipeline("nm_numi_human_finish_node_load_validation");
                state_->nodeForceAuditPartialPipeline=pipeline("nm_numi_human_node_force_audit_tiles");
                state_->nodeForceAuditFinishPipeline=pipeline("nm_numi_human_finish_node_force_audit");
                for (id<MTLComputePipelineState> pso :
                    {state_->nodeValidationPartialPipeline,state_->nodeValidationFinishPipeline,
                     state_->nodeForceAuditPartialPipeline,state_->nodeForceAuditFinishPipeline}) {
                    if (pso==nil || pso.threadExecutionWidth!=32u ||
                        pso.maxTotalThreadsPerThreadgroup<256u) return false;
                }
                if (state_->nodeValidationPartials==nil ||
                    state_->nodeForceAuditPartials==nil) return false;
            }
            std::fprintf(stderr,"human_node_work_layout tiles=%u nodes=%zu active_anchors=%u sparse=%u\n",
                state_->nodeWorkTiles,state_->nodeLoads.size(),state_->activeAnchorCount,
                state_->sparseAnchorProjection);

            if (!state_->contactSamples.empty()) {
                state_->contactForcePipeline = pipeline(
                    "nm_numi_human_assemble_internal_fem_contact_loads");
            }
            if (state_->hasFEMBodyInteraction()) {
                state_->allocatedArticularBodyPoseStride = pass.bodyPoseStride;
                state_->femBodyContactForcePipeline = pipeline(
                    "nm_numi_human_assemble_fem_body_contact_loads");
                if (state_->hasMultiMasterTriangleContact) {
                    state_->femBodyContactGroupedForcePipeline = pipeline(
                        "nm_numi_human_assemble_fem_body_contact_loads_grouped");
                }
                state_->femBodyContactWrenchPipeline = pipeline(
                    "nm_numi_human_assemble_fem_body_contact_wrenches");
                const char* parallelWrench=std::getenv("NUMI_HUMAN_PARALLEL_CONTACT_WRENCH");
                if(parallelWrench && std::strcmp(parallelWrench,"0")!=0 &&
                    std::strcmp(parallelWrench,"1")!=0) {
                    state_->message="NUMI_HUMAN_PARALLEL_CONTACT_WRENCH must be 0 or 1";
                    return false;
                }
                if(!state_->femBodyContactSolverSamples.empty() &&
                    (state_->femBodyContactSolverSamples.size()>256u ||
                     (parallelWrench && std::strcmp(parallelWrench,"1")==0)) &&
                    (!parallelWrench || std::strcmp(parallelWrench,"0")!=0)) {
                    std::vector<std::uint32_t> counts(pass.bodyPoseStride,0u);
                    for(const auto& sample:state_->femBodyContactSolverSamples) {
                        if(sample.bodyIndex<pass.articulationFirstBody ||
                            sample.bodyIndex-pass.articulationFirstBody>=pass.bodyPoseStride) return false;
                        ++counts[sample.bodyIndex-pass.articulationFirstBody];
                    }
                    std::vector<std::uint32_t> next(pass.bodyPoseStride,0u);
                    std::vector<NMIncidenceRangeGPU> bodyTiles(pass.bodyPoseStride);
                    std::vector<nm_uint4> tiles;
                    std::uint32_t first=0u;
                    for(std::uint32_t body=0;body<pass.bodyPoseStride;++body) {
                        next[body]=first;bodyTiles[body].first=static_cast<std::uint32_t>(tiles.size());
                        for(std::uint32_t local=0u;local<counts[body];) {
                            const std::uint32_t size=std::min(256u,counts[body]-local);
                            tiles.push_back({first+local,size,body,0u});local+=size;
                        }
                        bodyTiles[body].count=static_cast<std::uint32_t>(tiles.size())-bodyTiles[body].first;
                        first+=counts[body];
                    }
                    if(first!=state_->femBodyContactSolverSamples.size() ||
                        tiles.size()>std::numeric_limits<std::uint32_t>::max()) return false;
                    state_->femBodyContactWrenchIndices=[device newBufferWithLength:
                        state_->femBodyContactSolverSamples.size()*sizeof(std::uint32_t)
                        options:MTLResourceStorageModeShared];
                    if(state_->femBodyContactWrenchIndices==nil) return false;
                    auto* indices=static_cast<std::uint32_t*>(state_->femBodyContactWrenchIndices.contents);
                    for(std::uint32_t index=0u;index<state_->femBodyContactSolverSamples.size();++index) {
                        const auto& sample=state_->femBodyContactSolverSamples[index];
                        indices[next[sample.bodyIndex-pass.articulationFirstBody]++]=index;
                    }
                    state_->femBodyContactWrenchTileCount=static_cast<std::uint32_t>(tiles.size());
                    state_->femBodyContactWrenchTiles=[device newBufferWithBytes:tiles.data()
                        length:tiles.size()*sizeof(nm_uint4) options:MTLResourceStorageModeShared];
                    state_->femBodyContactWrenchBodyRanges=[device newBufferWithBytes:bodyTiles.data()
                        length:bodyTiles.size()*sizeof(NMIncidenceRangeGPU) options:MTLResourceStorageModeShared];
                    const std::uint64_t totalTiles=std::uint64_t(state_->environmentCount)*tiles.size();
                    if(totalTiles>std::numeric_limits<std::uint32_t>::max() ||
                        totalTiles>std::numeric_limits<NSUInteger>::max()/sizeof(NMNumiHumanBodyWrenchGPU)) return false;
                    state_->femBodyContactWrenchPartials=[device newBufferWithLength:
                        totalTiles*sizeof(NMNumiHumanBodyWrenchGPU) options:MTLResourceStorageModePrivate];
                    state_->femBodyContactWrenchPartialPipeline=pipeline("nm_numi_human_fem_body_contact_wrench_partial");
                    state_->femBodyContactWrenchFinishPipeline=pipeline("nm_numi_human_fem_body_contact_wrench_finish");
                    if(state_->femBodyContactWrenchTiles==nil || state_->femBodyContactWrenchBodyRanges==nil ||
                        state_->femBodyContactWrenchPartials==nil || state_->femBodyContactWrenchPartialPipeline==nil ||
                        state_->femBodyContactWrenchFinishPipeline==nil ||
                        state_->femBodyContactWrenchPartialPipeline.maxTotalThreadsPerThreadgroup<256u ||
                        state_->femBodyContactWrenchFinishPipeline.maxTotalThreadsPerThreadgroup<256u ||
                        state_->femBodyContactWrenchPartialPipeline.threadExecutionWidth!=32u ||
                        state_->femBodyContactWrenchFinishPipeline.threadExecutionWidth!=32u) return false;
                }

                state_->femBodyContactAuditPipeline = pipeline(
                    "nm_numi_human_audit_fem_body_contact");
                const std::uint64_t auditRows = state_->femBodyContactSamples.size() +
                    state_->femSurfaceAttachments.size();
                const char* parallelAudit = std::getenv("NUMI_HUMAN_PARALLEL_CONTACT_AUDIT");
                if (parallelAudit != nullptr && std::strcmp(parallelAudit,"0") != 0 &&
                    std::strcmp(parallelAudit,"1") != 0) {
                    state_->message="NUMI_HUMAN_PARALLEL_CONTACT_AUDIT must be 0 or 1";
                    return false;
                }
                if (auditRows > std::numeric_limits<std::uint32_t>::max()) {
                    state_->message="Human contact audit row count overflows";
                    return false;
                }
                if (auditRows > 0u && (auditRows > 256u ||
                    (parallelAudit != nullptr && std::strcmp(parallelAudit,"1") == 0)) &&
                    (parallelAudit == nullptr || std::strcmp(parallelAudit,"0") != 0)) {
                    state_->femBodyContactAuditTiles = static_cast<std::uint32_t>(
                        auditRows / 256u + (auditRows % 256u != 0u));
                    state_->femBodyContactAuditPartialPipeline = pipeline(
                        "nm_numi_human_audit_fem_body_contact_partial");
                    state_->femBodyContactAuditFinishPipeline = pipeline(
                        "nm_numi_human_audit_fem_body_contact_finish");
                    const std::uint64_t totalTiles = std::uint64_t(state_->environmentCount) *
                        state_->femBodyContactAuditTiles;
                    if (totalTiles > std::numeric_limits<std::uint32_t>::max() ||
                        totalTiles > std::numeric_limits<NSUInteger>::max() /
                            sizeof(NMNumiHumanArticularContactAuditGPU)) return false;
                    state_->femBodyContactAuditPartialBuffer = [device newBufferWithLength:
                        totalTiles * sizeof(NMNumiHumanArticularContactAuditGPU)
                        options:MTLResourceStorageModePrivate];
                    if (state_->femBodyContactAuditPartialBuffer == nil ||
                        state_->femBodyContactAuditPartialPipeline == nil ||
                        state_->femBodyContactAuditFinishPipeline == nil ||
                        state_->femBodyContactAuditPartialPipeline.maxTotalThreadsPerThreadgroup < 256u ||
                        state_->femBodyContactAuditFinishPipeline.maxTotalThreadsPerThreadgroup < 256u ||
                        state_->femBodyContactAuditPartialPipeline.threadExecutionWidth != 32u ||
                        state_->femBodyContactAuditFinishPipeline.threadExecutionWidth != 32u) {
                        state_->message="Human tiled contact audit pipelines or scratch unavailable";
                        return false;
                    }
                }
                const char* rowCache = std::getenv("NUMI_HUMAN_CONTACT_ROW_CACHE");
                if (rowCache && std::strcmp(rowCache,"0")!=0 && std::strcmp(rowCache,"1")!=0) {
                    state_->message="NUMI_HUMAN_CONTACT_ROW_CACHE must be 0 or 1";
                    return false;
                }
                if (rowCache && std::strcmp(rowCache,"1")==0) {
                    // All consumers must refer to the same immutable rows/ranges.
                    // Filtered or reordered layouts retain the existing path.
                    state_->contactRowCache = state_->hasMultiMasterTriangleContact &&
                        !state_->femBodyContactSamples.empty() &&
                        state_->femBodyContactSolverSamples.data()==state_->femBodyContactSamples.data() &&
                        state_->femBodyContactSolverSamples.size()==state_->femBodyContactSamples.size() &&
                        state_->femBodyContactGroupedSolverSamples.data()==state_->femBodyContactSamples.data() &&
                        state_->femBodyContactGroupedSolverSamples.size()==state_->femBodyContactSamples.size() &&
                        state_->femBodyContactSolverNeighborhoodRanges.data()==state_->femBodyContactNeighborhoodRanges.data() &&
                        state_->femBodyContactGroupedSolverNeighborhoodRanges.data()==state_->femBodyContactNeighborhoodRanges.data() &&
                        state_->femBodyContactAuditTiles!=0u && state_->femBodyContactWrenchTileCount!=0u;
                    if(state_->contactRowCache) {
                        const std::uint64_t rows=std::uint64_t(state_->environmentCount)*state_->femBodyContactSamples.size();
                        if(rows>std::numeric_limits<std::uint32_t>::max() ||
                            rows>std::numeric_limits<NSUInteger>::max()/sizeof(nm_float4)) return false;
                        state_->femBodyContactRowCache=[device newBufferWithLength:rows*sizeof(nm_float4)
                            options:MTLResourceStorageModePrivate];
                        state_->femBodyContactGroupedForcePipeline=pipeline("nm_numi_human_assemble_fem_body_contact_loads_grouped_cached");
                        state_->femBodyContactWrenchPartialPipeline=pipeline("nm_numi_human_fem_body_contact_wrench_partial_cached");
                        state_->femBodyContactAuditPartialPipeline=pipeline("nm_numi_human_audit_fem_body_contact_partial_cached");
                        if(state_->femBodyContactRowCache==nil ||
                            state_->femBodyContactGroupedForcePipeline==nil || state_->femBodyContactWrenchPartialPipeline==nil ||
                            state_->femBodyContactAuditPartialPipeline==nil) return false;
                        for(id<MTLComputePipelineState> pso : {state_->femBodyContactGroupedForcePipeline,state_->femBodyContactWrenchPartialPipeline,
                            state_->femBodyContactAuditPartialPipeline}) {
                            if(pso.threadExecutionWidth!=32u || pso.maxTotalThreadsPerThreadgroup<256u) return false;
                        }
                    }
                    std::fprintf(stderr,"human_contact_row_cache requested=1 admitted=%u rows=%zu bytes=%llu\n",
                        state_->contactRowCache,state_->femBodyContactSamples.size(),
                        static_cast<unsigned long long>(state_->femBodyContactRowCache.length));
                }
                const char* aabbExclusion = std::getenv("NUMI_HUMAN_CONTACT_AABB_EXCLUSION");
                if(aabbExclusion && std::strcmp(aabbExclusion,"0")!=0 &&
                    std::strcmp(aabbExclusion,"1")!=0) {
                    state_->message="NUMI_HUMAN_CONTACT_AABB_EXCLUSION must be 0 or 1";
                    return false;
                }
                state_->contactAABBExclusion=aabbExclusion &&
                    std::strcmp(aabbExclusion,"1")==0;
                if(state_->contactAABBExclusion && !state_->contactRowCache) {
                    state_->message="contact AABB exclusion requires admitted contact row cache";
                    return false;
                }
                std::fprintf(stderr,"human_contact_aabb_exclusion enabled=%u\n",
                    state_->contactAABBExclusion?1u:0u);
                std::fprintf(stderr,"human_contact_audit_layout parallel=%u rows=%llu solver_rows=%zu tiles=%u\n",
                    state_->femBodyContactAuditTiles != 0u,
                    static_cast<unsigned long long>(auditRows),
                    state_->femBodyContactSolverSamples.size(), state_->femBodyContactAuditTiles);

                const char* motionCache = std::getenv("NUMI_HUMAN_CONTACT_EXACT_MOTION_CACHE");
                if (motionCache && std::strcmp(motionCache,"0")!=0 &&
                    std::strcmp(motionCache,"1")!=0) {
                    state_->message="NUMI_HUMAN_CONTACT_EXACT_MOTION_CACHE must be 0 or 1";
                    return false;
                }
                state_->contactExactMotionCache = motionCache && std::strcmp(motionCache,"1")==0;
                if (state_->contactExactMotionCache) {
                    if (!state_->contactRowCache) {
                        state_->message="exact motion cache requires admitted immutable contact row cache";
                        return false;
                    }
                    const std::uint64_t nodeCount = std::uint64_t(state_->environmentCount)*state_->nodeLoads.size();
                    const std::uint64_t poseCount = std::uint64_t(state_->environmentCount)*pass.bodyPoseStride;
                    if (nodeCount+poseCount > std::numeric_limits<std::uint32_t>::max() ||
                        nodeCount > std::numeric_limits<NSUInteger>::max()/sizeof(nm_float4) ||
                        poseCount > std::numeric_limits<NSUInteger>::max()/(2u*sizeof(nm_float4)))
                        return false;
                    std::vector<std::uint32_t> initialFlags(nodeCount+poseCount,0u);
                    state_->contactMotionFlags = [device newBufferWithBytes:initialFlags.data()
                        length:initialFlags.size()*sizeof(std::uint32_t) options:MTLResourceStorageModeShared];
                    state_->contactMotionPositions = [device newBufferWithLength:nodeCount*sizeof(nm_float4)
                        options:MTLResourceStorageModePrivate];
                    state_->contactMotionPoseWords = [device newBufferWithLength:2u*poseCount*sizeof(nm_float4)
                        options:MTLResourceStorageModePrivate];
                    state_->contactMotionPreparePipeline = pipeline("nm_numi_human_prepare_contact_motion_cache");
                    if (state_->contactMotionFlags==nil || state_->contactMotionPositions==nil ||
                        state_->contactMotionPoseWords==nil || state_->contactMotionPreparePipeline==nil)
                        return false;
                    std::fprintf(stderr,"human_contact_exact_motion_cache=1 nodes=%llu bodies=%llu bytes=%llu\n",
                        nodeCount,poseCount,nodeCount*20u+poseCount*36u);
                }
                const char* compactQueries = std::getenv("NUMI_HUMAN_CONTACT_COMPACT_QUERIES");
                if (compactQueries && std::strcmp(compactQueries,"0")!=0 &&
                    std::strcmp(compactQueries,"1")!=0) {
                    state_->message="NUMI_HUMAN_CONTACT_COMPACT_QUERIES must be 0 or 1";
                    return false;
                }
                state_->contactCompactQueries = compactQueries && std::strcmp(compactQueries,"1")==0;
                if (state_->contactCompactQueries) {
                    if (!state_->contactExactMotionCache || !state_->contactAABBExclusion) {
                        state_->message="contact query compaction requires exact motion cache and certified closed-bank AABB exclusion";
                        return false;
                    }
                    const std::uint64_t rows=std::uint64_t(state_->environmentCount)*state_->femBodyContactSamples.size();
                    if(rows==0u || rows>std::numeric_limits<std::uint32_t>::max()-255u) return false;
                    state_->contactQueryTileCount=(rows+255u)/256u;
                    state_->contactQueryBlockCount=(state_->contactQueryTileCount+255u)/256u;
                    state_->contactQueryTiles=[device newBufferWithLength:state_->contactQueryTileCount*2u*sizeof(std::uint32_t) options:MTLResourceStorageModePrivate];
                    state_->contactQueryBlockSums=[device newBufferWithLength:state_->contactQueryBlockCount*sizeof(std::uint32_t) options:MTLResourceStorageModePrivate];
                    state_->contactQueryBlockOffsets=[device newBufferWithLength:state_->contactQueryBlockCount*sizeof(std::uint32_t) options:MTLResourceStorageModePrivate];
                    state_->contactQueryIndices=[device newBufferWithLength:rows*sizeof(std::uint32_t) options:MTLResourceStorageModePrivate];
                    state_->contactQueryWork=[device newBufferWithLength:sizeof(NMIndirectDispatchGPU) options:MTLResourceStorageModePrivate];
                    state_->contactQueryClassify=pipeline("nm_numi_human_classify_contact_queries");
                    state_->contactQueryScanTiles=pipeline("nm_numi_human_scan_contact_query_tiles");
                    state_->contactQueryScanBlocks=pipeline("nm_numi_human_scan_contact_query_blocks");
                    state_->contactQueryScatter=pipeline("nm_numi_human_scatter_contact_queries");
                    if(state_->contactQueryTiles==nil || state_->contactQueryBlockSums==nil ||
                        state_->contactQueryBlockOffsets==nil || state_->contactQueryIndices==nil || state_->contactQueryWork==nil)
                        return false;
                    for(id<MTLComputePipelineState> pso:{state_->contactQueryClassify,
                        state_->contactQueryScanTiles,state_->contactQueryScanBlocks,state_->contactQueryScatter})
                        if(pso==nil || pso.threadExecutionWidth!=32u || pso.maxTotalThreadsPerThreadgroup<256u) return false;
                    std::fprintf(stderr,"human_contact_compact_queries=1 rows=%llu index_bytes=%llu\n",
                        static_cast<unsigned long long>(rows),static_cast<unsigned long long>(rows*sizeof(std::uint32_t)));
                }
                if (!state_->femBodyContactSamples.empty()) {
                    state_->femBodyContactSampleValidationPipeline = pipeline(state_->contactCompactQueries
                        ? "nm_numi_human_validate_fem_body_contact_samples_cached_aabb_compacted"
                        : state_->contactRowCache
                        ? (state_->contactAABBExclusion
                            ? (state_->contactExactMotionCache
                                ? "nm_numi_human_validate_fem_body_contact_samples_cached_aabb_motion"
                                : "nm_numi_human_validate_fem_body_contact_samples_cached_aabb")
                            : (state_->contactExactMotionCache
                                ? "nm_numi_human_validate_fem_body_contact_samples_cached_motion"
                                : "nm_numi_human_validate_fem_body_contact_samples_cached"))
                        : "nm_numi_human_validate_fem_body_contact_samples");
                    state_->femBodyContactSampleValidationReducePipeline = pipeline(
                        "nm_numi_human_reduce_fem_body_contact_sample_validation");
                }
                if (!state_->femSurfaceAttachments.empty()) {
                    state_->femSurfaceAttachmentForcePipeline = pipeline(
                        "nm_numi_human_assemble_fem_surface_attachment_loads");
                    state_->femSurfaceAttachmentWrenchPipeline = pipeline(
                        "nm_numi_human_add_fem_surface_attachment_wrenches");
                }
            }
            if (!state_->articularContactSamples.empty()) {
                state_->allocatedArticularBodyPoseStride = pass.bodyPoseStride;
                state_->articularContactPipeline = pipeline(
                    "nm_numi_human_assemble_articular_contact_wrenches");
                state_->articularContactAuditPipeline = pipeline(
                    "nm_numi_human_audit_articular_contact_wrenches");
            }
            if (state_->articularContactPairCount != 0u) {
                state_->articularContactPairAuditPipeline = pipeline(
                    "nm_numi_human_audit_articular_contact_pairs");
                state_->articularContactPairAuditCommitPipeline = pipeline(
                    "nm_numi_human_commit_articular_contact_pair_audit");
            }
            if (!state_->articularContactSamples.empty() ||
                state_->hasFEMBodyInteraction()) {
                state_->articularContactAuditCommitPipeline = pipeline(
                    "nm_numi_human_commit_articular_contact_audit");
            }
            if (!state_->passiveLigaments.empty()) {
                state_->passiveLigamentAuditPipeline = pipeline(
                    "nm_numi_human_audit_passive_ligaments");
                state_->passiveLigamentAuditCommitPipeline = pipeline(
                    "nm_numi_human_commit_passive_ligament_audit");
                if (state_->deferAcceptedAuditPublication) {
                    state_->passiveLigamentDeferredAuditCommitPipeline = pipeline(
                        "nm_numi_human_commit_passive_ligament_audit_v2");
                }
            }
            if (!state_->passiveRoutedBands.empty()) {
                state_->passiveRoutedBandAuditPipeline = pipeline(
                    "nm_numi_human_audit_passive_routed_bands");
                state_->passiveRoutedBandAuditCommitPipeline = pipeline(
                    "nm_numi_human_commit_passive_routed_band_audit");
                if (state_->deferAcceptedAuditPublication) {
                    state_->passiveRoutedBandDeferredAuditCommitPipeline = pipeline(
                        "nm_numi_human_commit_passive_routed_band_audit_v2");
                }
            }
            if (state_->executionMode ==
                    NumiHumanTendonFEMLoadExecutionMode::standaloneRuntime) {
                state_->targetPipeline = pipeline(
                    "nm_numi_human_assemble_fem_kinematic_targets");
                state_->reactionAuditPipeline = pipeline(
                    "nm_numi_human_audit_fem_anchor_reactions");
                state_->reactionAuditCommitPipeline = pipeline(
                    "nm_numi_human_commit_fem_anchor_reaction_audit");
                state_->reactionPipeline = pipeline(
                    state_->sparseAnchorProjection ?
                        "nm_numi_human_apply_fem_anchor_reactions_sparse" :
                        "nm_numi_human_apply_fem_anchor_reactions");
            } else {
                state_->preSourceCorrectionPipeline = pipeline(
                    "nm_numi_human_apply_pre_source_rigid_corrections");
            }
            const NSUInteger nodeLoadBytes = static_cast<NSUInteger>(
                state_->nodeLoads.size() * sizeof(state_->nodeLoads.front())
            );
            const NSUInteger nodeAnchorBytes = static_cast<NSUInteger>(
                state_->nodeAnchors.size() * sizeof(state_->nodeAnchors.front())
            );
            const NSUInteger replacementBytes = static_cast<NSUInteger>(
                state_->replacements.size() * sizeof(state_->replacements.front())
            );
            const NSUInteger externalForceBytes = static_cast<NSUInteger>(
                state_->environmentCount * state_->nodeLoads.size() *
                sizeof(nm_float4)
            );
            const NSUInteger statusBytes = static_cast<NSUInteger>(
                state_->environmentCount * sizeof(MRMetalWorldStatusGPU)
            );
            state_->nodeLoadBuffer = [device
                newBufferWithBytes:state_->nodeLoads.data()
                length:nodeLoadBytes
                options:MTLResourceStorageModeShared];
            state_->nodeAnchorBuffer = [device
                newBufferWithBytes:state_->nodeAnchors.data()
                length:nodeAnchorBytes
                options:MTLResourceStorageModeShared];
            state_->replacementBuffer = replacementBytes == 0u
                ? [device
                    newBufferWithLength:sizeof(
                        NMNumiHumanTendonFEMEndpointReplacementGPU)
                    options:MTLResourceStorageModeShared]
                : [device
                    newBufferWithBytes:state_->replacements.data()
                    length:replacementBytes
                    options:MTLResourceStorageModeShared];
            if (!state_->contactSamples.empty()) {
                state_->contactSampleBuffer = [device
                    newBufferWithBytes:state_->contactSamples.data()
                    length:state_->contactSamples.size() *
                        sizeof(NMNumiHumanFEMContactSampleGPU)
                    options:MTLResourceStorageModeShared];
                state_->contactContributionBuffer = [device
                    newBufferWithBytes:state_->contactContributions.data()
                    length:state_->contactContributions.size() *
                        sizeof(NMNumiHumanFEMContactContributionGPU)
                    options:MTLResourceStorageModeShared];
                state_->contactRangeBuffer = [device
                    newBufferWithBytes:state_->contactRanges.data()
                    length:state_->contactRanges.size() *
                        sizeof(NMIncidenceRangeGPU)
                    options:MTLResourceStorageModeShared];
            }
            if (state_->hasFEMBodyInteraction()) {
                const NMNumiHumanFEMBodyContactSampleGPU emptyBodySample{};
                state_->femBodyContactSampleBuffer =
                    state_->femBodyContactSamples.empty()
                        ? [device newBufferWithBytes:&emptyBodySample
                            length:sizeof(emptyBodySample)
                            options:MTLResourceStorageModeShared]
                        : [device
                            newBufferWithBytes:state_->femBodyContactSamples.data()
                            length:state_->femBodyContactSamples.size() *
                                sizeof(NMNumiHumanFEMBodyContactSampleGPU)
                            options:MTLResourceStorageModeShared];
                state_->femBodyContactSolverSampleBuffer =
                    state_->implicitSpringCount == 0u
                        ? state_->femBodyContactSampleBuffer
                        : (state_->femBodyContactSolverSamples.empty()
                            ? state_->femBodyContactSampleBuffer
                            : [device newBufferWithBytes:
                                  state_->femBodyContactSolverSamples.data()
                              length:state_->femBodyContactSolverSamples.size() *
                                  sizeof(NMNumiHumanFEMBodyContactSampleGPU)
                             options:MTLResourceStorageModeShared]);
                const NMNumiHumanFEMBodyContactNeighborhoodRangeGPU
                    emptyNeighborhoodRange{};
                const NMNumiHumanFEMBodyContactNeighborhoodTriangleGPU
                    emptyNeighborhoodTriangle{};
                state_->femBodyContactNeighborhoodRangeBuffer =
                    state_->femBodyContactNeighborhoodRanges.empty()
                        ? [device newBufferWithBytes:&emptyNeighborhoodRange
                            length:sizeof(emptyNeighborhoodRange)
                            options:MTLResourceStorageModeShared]
                        : [device newBufferWithBytes:
                            state_->femBodyContactNeighborhoodRanges.data()
                            length:state_->femBodyContactNeighborhoodRanges.size() *
                                sizeof(NMNumiHumanFEMBodyContactNeighborhoodRangeGPU)
                            options:MTLResourceStorageModeShared];
                state_->femBodyContactSolverNeighborhoodRangeBuffer =
                    (state_->femBodyContactSolverNeighborhoodRanges.empty() ||
                     detail::identicalImmutableRows(state_->femBodyContactSolverNeighborhoodRanges,
                         state_->femBodyContactNeighborhoodRanges))
                        ? state_->femBodyContactNeighborhoodRangeBuffer
                        : [device newBufferWithBytes:
                            state_->femBodyContactSolverNeighborhoodRanges.data()
                            length:state_->femBodyContactSolverNeighborhoodRanges.size() *
                                sizeof(NMNumiHumanFEMBodyContactNeighborhoodRangeGPU)
                            options:MTLResourceStorageModeShared];
                if (state_->hasMultiMasterTriangleContact) {
                    state_->femBodyContactGroupedSolverSampleBuffer =
                        detail::identicalImmutableRows(state_->femBodyContactGroupedSolverSamples,
                            state_->femBodyContactSolverSamples)
                        ? state_->femBodyContactSolverSampleBuffer
                        : [device newBufferWithBytes:
                            state_->femBodyContactGroupedSolverSamples.data()
                        length:state_->femBodyContactGroupedSolverSamples.size() *
                            sizeof(NMNumiHumanFEMBodyContactSampleGPU)
                        options:MTLResourceStorageModeShared];
                    state_->femBodyContactGroupedSolverRangeBuffer =
                        (state_->femBodyContactGroupedSolverNeighborhoodRanges.empty() ||
                         detail::identicalImmutableRows(state_->femBodyContactGroupedSolverNeighborhoodRanges,
                             state_->femBodyContactSolverNeighborhoodRanges))
                            ? state_->femBodyContactSolverNeighborhoodRangeBuffer
                            : [device newBufferWithBytes:
                                state_->femBodyContactGroupedSolverNeighborhoodRanges.data()
                            length:state_->femBodyContactGroupedSolverNeighborhoodRanges.size() *
                                sizeof(NMNumiHumanFEMBodyContactNeighborhoodRangeGPU)
                            options:MTLResourceStorageModeShared];
                    state_->femBodyContactSolverGroupCountBuffer =
                        [device newBufferWithBytes:
                            state_->femBodyContactSolverGroupCounts.data()
                        length:state_->femBodyContactSolverGroupCounts.size() *
                            sizeof(std::uint32_t)
                        options:MTLResourceStorageModeShared];
                }
                state_->femBodyContactNeighborhoodTriangleBuffer =
                    state_->femBodyContactNeighborhoodTriangles.empty()
                        ? [device newBufferWithBytes:&emptyNeighborhoodTriangle
                            length:sizeof(emptyNeighborhoodTriangle)
                            options:MTLResourceStorageModeShared]
                        : [device newBufferWithBytes:
                            state_->femBodyContactNeighborhoodTriangles.data()
                            length:state_->femBodyContactNeighborhoodTriangles.size() *
                                sizeof(NMNumiHumanFEMBodyContactNeighborhoodTriangleGPU)
                            options:MTLResourceStorageModeShared];
                const NMNumiHumanFEMBodyContactBVHNodeGPU emptyBVHNode{};
                state_->femBodyContactNeighborhoodBVHNodeBuffer =
                    state_->femBodyContactNeighborhoodBVHNodes.empty()
                        ? [device newBufferWithBytes:&emptyBVHNode
                            length:sizeof(emptyBVHNode)
                            options:MTLResourceStorageModeShared]
                        : [device newBufferWithBytes:
                            state_->femBodyContactNeighborhoodBVHNodes.data()
                            length:state_->femBodyContactNeighborhoodBVHNodes.size() *
                                sizeof(NMNumiHumanFEMBodyContactBVHNodeGPU)
                            options:MTLResourceStorageModeShared];
                if (state_->implicitSpringCount != 0u) {
                    state_->implicitSpringSampleBuffer = [device
                        newBufferWithBytes:state_->implicitSpringSamples.data()
                        length:state_->implicitSpringSamples.size() *
                            sizeof(NMNumiHumanFEMBodyContactSampleGPU)
                        options:MTLResourceStorageModeShared];
                    state_->implicitSpringPointQueryBuffer = [device
                        newBufferWithBytes:
                            state_->implicitSpringPointQueries.data()
                        length:state_->implicitSpringPointQueries.size() *
                            sizeof(MRArticulatedPointImpulseGPU)
                        options:MTLResourceStorageModeShared];
                }
                if (!state_->femSurfaceAttachments.empty()) {
                    state_->femSurfaceAttachmentBuffer = [device
                        newBufferWithBytes:state_->femSurfaceAttachments.data()
                        length:state_->femSurfaceAttachments.size() *
                            sizeof(NMNumiHumanFEMSurfaceAttachmentGPU)
                        options:MTLResourceStorageModeShared];
                }
                state_->femBodyContactWrenchBuffer = [device
                    newBufferWithLength:state_->environmentCount *
                        pass.bodyPoseStride *
                        sizeof(NMNumiHumanBodyWrenchGPU)
                    options:MTLResourceStorageModePrivate];
                state_->femBodyContactAuditBuffer = [device
                    newBufferWithLength:state_->environmentCount *
                        sizeof(NMNumiHumanArticularContactAuditGPU)
                    options:MTLResourceStorageModeShared];
                state_->femBodyContactAuditHistoryBuffer = [device
                    newBufferWithLength:state_->environmentCount *
                        NM_NUMI_HUMAN_ARTICULAR_CONTACT_AUDIT_MAX_STEPS *
                        sizeof(NMNumiHumanArticularContactAuditGPU)
                    options:MTLResourceStorageModeShared];
                if (state_->femBodyContactAuditBuffer != nil) {
                    std::memset(
                        state_->femBodyContactAuditBuffer.contents, 0,
                        state_->femBodyContactAuditBuffer.length);
                }
                if (state_->femBodyContactAuditHistoryBuffer != nil) {
                    std::memcpy(
                        state_->femBodyContactAuditHistoryBuffer.contents,
                        state_->femBodyContactAcceptedHistory.data(),
                        state_->femBodyContactAuditHistoryBuffer.length);
                }
            }
            if (!state_->articularContactSamples.empty()) {
                state_->articularContactSampleBuffer = [device
                    newBufferWithBytes:state_->articularContactSamples.data()
                    length:state_->articularContactSamples.size() *
                        sizeof(NMNumiHumanArticularContactSampleGPU)
                    options:MTLResourceStorageModeShared];
                state_->articularBodyWrenchBuffer = [device
                    newBufferWithLength:state_->environmentCount *
                        pass.bodyPoseStride *
                        sizeof(NMNumiHumanBodyWrenchGPU)
                    options:MTLResourceStorageModePrivate];
                state_->articularContactAuditBuffer = [device
                    newBufferWithLength:state_->environmentCount *
                        sizeof(NMNumiHumanArticularContactAuditGPU)
                    options:MTLResourceStorageModeShared];
                state_->articularContactAuditHistoryBuffer = [device
                    newBufferWithLength:state_->environmentCount *
                        NM_NUMI_HUMAN_ARTICULAR_CONTACT_AUDIT_MAX_STEPS *
                        sizeof(NMNumiHumanArticularContactAuditGPU)
                    options:MTLResourceStorageModeShared];
                if (state_->articularContactAuditBuffer != nil) {
                    std::memset(
                        state_->articularContactAuditBuffer.contents, 0,
                        state_->articularContactAuditBuffer.length);
                }
                if (state_->articularContactAuditHistoryBuffer != nil) {
                    std::memcpy(
                        state_->articularContactAuditHistoryBuffer.contents,
                        state_->articularContactAcceptedHistory.data(),
                        state_->articularContactAuditHistoryBuffer.length);
                }
                if (state_->articularContactPairCount != 0u) {
                    state_->articularContactPairRangeBuffer = [device
                        newBufferWithBytes:
                            state_->articularContactPairRanges.data()
                        length:state_->articularContactPairRanges.size() *
                            sizeof(NMIncidenceRangeGPU)
                        options:MTLResourceStorageModeShared];
                    const std::size_t pairStride =
                        static_cast<std::size_t>(
                            state_->articularContactPairCount) + 1u;
                    state_->articularContactPairAuditBuffer = [device
                        newBufferWithLength:state_->environmentCount *
                            pairStride * sizeof(float)
                        options:MTLResourceStorageModeShared];
                    state_->articularContactPairAuditHistoryBuffer = [device
                        newBufferWithLength:
                            state_->articularContactPairForceAcceptedHistory
                                .size() * sizeof(float)
                        options:MTLResourceStorageModeShared];
                    if (state_->articularContactPairAuditBuffer != nil) {
                        std::memset(
                            state_->articularContactPairAuditBuffer.contents,
                            0,
                            state_->articularContactPairAuditBuffer.length);
                    }
                    if (state_->articularContactPairAuditHistoryBuffer != nil) {
                        std::memcpy(
                            state_->articularContactPairAuditHistoryBuffer
                                .contents,
                            state_->articularContactPairForceAcceptedHistory
                                .data(),
                            state_->articularContactPairAuditHistoryBuffer
                                .length);
                    }
                }
            }
            if (!state_->passiveLigaments.empty()) {
                state_->passiveLigamentBuffer = [device
                    newBufferWithBytes:state_->passiveLigaments.data()
                    length:state_->passiveLigaments.size() *
                        sizeof(NMNumiHumanPassiveLigamentGPU)
                    options:MTLResourceStorageModeShared];
                state_->passiveLigamentAuditBuffer = [device
                    newBufferWithLength:state_->environmentCount *
                        sizeof(NMNumiHumanPassiveLigamentAuditGPU)
                    options:MTLResourceStorageModeShared];
                if (state_->deferAcceptedAuditPublication) {
                    state_->passiveLigamentAcceptedAuditBuffer = [device
                        newBufferWithLength:state_->environmentCount *
                            sizeof(NMNumiHumanPassiveLigamentAuditGPU)
                        options:MTLResourceStorageModeShared];
                }
                if (state_->passiveLigamentAuditBuffer != nil) {
                    std::memcpy(
                        state_->passiveLigamentAuditBuffer.contents,
                        state_->passiveLigamentAcceptedState.data(),
                        state_->passiveLigamentAuditBuffer.length);
                }
                if (state_->passiveLigamentAcceptedAuditBuffer != nil) {
                    std::memcpy(
                        state_->passiveLigamentAcceptedAuditBuffer.contents,
                        state_->passiveLigamentAcceptedState.data(),
                        state_->passiveLigamentAcceptedAuditBuffer.length);
                }
            }
            if (!state_->passiveRoutedBands.empty()) {
                state_->passiveRoutedBandBuffer = [device
                    newBufferWithBytes:state_->passiveRoutedBands.data()
                    length:state_->passiveRoutedBands.size() *
                        sizeof(NMNumiHumanPassiveRoutedBandGPU)
                    options:MTLResourceStorageModeShared];
                state_->passiveRoutedBandAuditBuffer = [device
                    newBufferWithLength:state_->environmentCount *
                        sizeof(NMNumiHumanPassiveRoutedBandAuditGPU)
                    options:MTLResourceStorageModeShared];
                if (state_->deferAcceptedAuditPublication) {
                    state_->passiveRoutedBandAcceptedAuditBuffer = [device
                        newBufferWithLength:state_->environmentCount *
                            sizeof(NMNumiHumanPassiveRoutedBandAuditGPU)
                        options:MTLResourceStorageModeShared];
                }
                if (state_->passiveRoutedBandAuditBuffer != nil) {
                    std::memcpy(
                        state_->passiveRoutedBandAuditBuffer.contents,
                        state_->passiveRoutedBandAcceptedState.data(),
                        state_->passiveRoutedBandAuditBuffer.length);
                }
                if (state_->passiveRoutedBandAcceptedAuditBuffer != nil) {
                    std::memcpy(
                        state_->passiveRoutedBandAcceptedAuditBuffer.contents,
                        state_->passiveRoutedBandAcceptedState.data(),
                        state_->passiveRoutedBandAcceptedAuditBuffer.length);
                }
            }
            state_->externalForceBuffer = [device
                newBufferWithLength:externalForceBytes
                options:MTLResourceStorageModePrivate];
            state_->externalForceAuditBuffer = [device
                newBufferWithLength:state_->environmentCount * sizeof(nm_float4)
                options:MTLResourceStorageModeShared];
            if (state_->executionMode ==
                    NumiHumanTendonFEMLoadExecutionMode::standaloneRuntime) {
                state_->anchorReactionAuditBuffer = [device
                    newBufferWithLength:state_->environmentCount * sizeof(nm_float4)
                    options:MTLResourceStorageModeShared];
                state_->anchorReactionAuditHistoryBuffer = [device
                    newBufferWithLength:state_->environmentCount *
                        NM_NUMI_HUMAN_ARTICULAR_CONTACT_AUDIT_MAX_STEPS *
                        sizeof(nm_float4)
                    options:MTLResourceStorageModeShared];
                if (state_->anchorReactionAuditHistoryBuffer != nil) {
                    std::memcpy(
                        state_->anchorReactionAuditHistoryBuffer.contents,
                        state_->anchorReactionAcceptedHistory.data(),
                        state_->anchorReactionAuditHistoryBuffer.length);
                }
                state_->kinematicTargetBuffer = [device
                    newBufferWithLength:externalForceBytes
                    options:MTLResourceStorageModePrivate];
            }
            state_->worldStatusBuffer = [device
                newBufferWithLength:statusBytes
                options:MTLResourceStorageModeShared];
            if (!state_->femBodyContactSamples.empty()) {
                constexpr std::uint64_t blockSize =
                    NM_NUMI_HUMAN_FEM_BODY_CONTACT_VALIDATION_BLOCK_SIZE;
                const std::uint64_t sampleCount =
                    state_->femBodyContactSamples.size();
                const std::uint64_t blockCount =
                    sampleCount / blockSize +
                    (sampleCount % blockSize != 0u ? 1u : 0u);
                const std::uint64_t sampleFlags =
                    static_cast<std::uint64_t>(state_->environmentCount) *
                    sampleCount;
                const std::uint64_t blockFlags =
                    static_cast<std::uint64_t>(state_->environmentCount) *
                    blockCount;
                const std::uint64_t maxByteLength =
                    std::numeric_limits<NSUInteger>::max();
                if (sampleFlags > maxByteLength / sizeof(std::uint32_t) ||
                    blockFlags > maxByteLength / sizeof(std::uint32_t) ||
                    sampleFlags > std::numeric_limits<std::uint32_t>::max() ||
                    blockFlags > std::numeric_limits<std::uint32_t>::max()) {
                    state_->message =
                        "Human FEM contact validation scratch size overflows";
                    return false;
                }
                state_->femBodyContactSampleValidationBuffer = [device
                    newBufferWithLength:static_cast<NSUInteger>(
                        sampleFlags * sizeof(std::uint32_t))
                    options:MTLResourceStorageModeShared];
                state_->femBodyContactSampleValidationBlockBuffer = [device
                    newBufferWithLength:static_cast<NSUInteger>(
                        blockFlags * sizeof(std::uint32_t))
                    options:MTLResourceStorageModeShared];
            }
            if (state_->provisionalStatusPipeline == nil ||
                state_->forcePipeline == nil ||
                state_->forceAuditPipeline == nil ||
                (!state_->contactSamples.empty() &&
                 state_->contactForcePipeline == nil) ||
                (state_->hasFEMBodyInteraction() &&
                 (state_->femBodyContactForcePipeline == nil ||
                  (state_->hasMultiMasterTriangleContact &&
                   state_->femBodyContactGroupedForcePipeline == nil) ||
                  state_->femBodyContactWrenchPipeline == nil ||
                  state_->femBodyContactAuditPipeline == nil ||
                  (!state_->femBodyContactSamples.empty() &&
                   (state_->femBodyContactSampleValidationPipeline == nil ||
                    state_->femBodyContactSampleValidationReducePipeline == nil)) ||
                  state_->articularContactAuditCommitPipeline == nil ||
                  (!state_->femSurfaceAttachments.empty() &&
                   (state_->femSurfaceAttachmentForcePipeline == nil ||
                    state_->femSurfaceAttachmentWrenchPipeline == nil)))) ||
                (!state_->articularContactSamples.empty() &&
                 (state_->articularContactPipeline == nil ||
                  state_->articularContactAuditPipeline == nil ||
                  state_->articularContactAuditCommitPipeline == nil)) ||
                (state_->articularContactPairCount != 0u &&
                 (state_->articularContactPairAuditPipeline == nil ||
                  state_->articularContactPairAuditCommitPipeline == nil)) ||
                (!state_->passiveLigaments.empty() &&
                 (state_->passiveLigamentAuditPipeline == nil ||
                  state_->passiveLigamentAuditCommitPipeline == nil ||
                  (state_->deferAcceptedAuditPublication &&
                   state_->passiveLigamentDeferredAuditCommitPipeline == nil))) ||
                (!state_->passiveRoutedBands.empty() &&
                 (state_->passiveRoutedBandAuditPipeline == nil ||
                  state_->passiveRoutedBandAuditCommitPipeline == nil ||
                  (state_->deferAcceptedAuditPublication &&
                   state_->passiveRoutedBandDeferredAuditCommitPipeline == nil))) ||
                (state_->executionMode ==
                        NumiHumanTendonFEMLoadExecutionMode::standaloneRuntime &&
                 (state_->targetPipeline == nil ||
                  state_->statusPipeline == nil ||
                  state_->reactionAuditPipeline == nil ||
                  state_->reactionAuditCommitPipeline == nil ||
                  state_->reactionPipeline == nil)) ||
                (state_->executionMode ==
                        NumiHumanTendonFEMLoadExecutionMode::numanXDeferred &&
                 state_->preSourceCorrectionPipeline == nil)) {
                if (state_->message == "initialized") {
                    state_->message = "Human tendon/FEM pipeline is unavailable";
                }
                return false;
            }
            if (state_->nodeLoadBuffer == nil || state_->nodeAnchorBuffer == nil ||
                state_->replacementBuffer == nil) {
                state_->message = "Human tendon/FEM immutable mapping buffer is unavailable";
                return false;
            }
            if (!state_->contactSamples.empty() &&
                (state_->contactSampleBuffer == nil ||
                 state_->contactContributionBuffer == nil ||
                 state_->contactRangeBuffer == nil)) {
                state_->message =
                    "Human FEM contact immutable mapping buffer is unavailable";
                return false;
            }
            if (state_->hasFEMBodyInteraction() &&
                (state_->femBodyContactSampleBuffer == nil ||
                 state_->femBodyContactNeighborhoodRangeBuffer == nil ||
                 state_->femBodyContactSolverNeighborhoodRangeBuffer == nil ||
                 (state_->hasMultiMasterTriangleContact &&
                  (state_->femBodyContactGroupedSolverSampleBuffer == nil ||
                   state_->femBodyContactGroupedSolverRangeBuffer == nil ||
                   state_->femBodyContactSolverGroupCountBuffer == nil)) ||
                 state_->femBodyContactNeighborhoodTriangleBuffer == nil ||
                 (!state_->femBodyContactSamples.empty() &&
                  (state_->femBodyContactSampleValidationBuffer == nil ||
                   state_->femBodyContactSampleValidationBlockBuffer == nil)) ||
                 state_->femBodyContactWrenchBuffer == nil ||
                 state_->femBodyContactAuditBuffer == nil ||
                 state_->femBodyContactAuditHistoryBuffer == nil ||
                 (!state_->femSurfaceAttachments.empty() &&
                  state_->femSurfaceAttachmentBuffer == nil))) {
                state_->message =
                    "Human FEM/body contact buffer is unavailable";
                return false;
            }
            if (!state_->articularContactSamples.empty() &&
                (state_->articularContactSampleBuffer == nil ||
                 state_->articularBodyWrenchBuffer == nil ||
                 state_->articularContactAuditBuffer == nil ||
                 state_->articularContactAuditHistoryBuffer == nil)) {
                state_->message =
                    "Human articular contact buffer is unavailable";
                return false;
            }
            if (state_->articularContactPairCount != 0u &&
                (state_->articularContactPairRangeBuffer == nil ||
                 state_->articularContactPairAuditBuffer == nil ||
                 state_->articularContactPairAuditHistoryBuffer == nil)) {
                state_->message =
                    "Human articular pair-audit buffer is unavailable";
                return false;
            }
            if (!state_->passiveLigaments.empty() &&
                (state_->passiveLigamentBuffer == nil ||
                 state_->passiveLigamentAuditBuffer == nil ||
                 (state_->deferAcceptedAuditPublication &&
                  state_->passiveLigamentAcceptedAuditBuffer == nil))) {
                state_->message =
                    "Human passive ligament buffer is unavailable";
                return false;
            }
            if (!state_->passiveRoutedBands.empty() &&
                (state_->passiveRoutedBandBuffer == nil ||
                 state_->passiveRoutedBandAuditBuffer == nil ||
                 (state_->deferAcceptedAuditPublication &&
                  state_->passiveRoutedBandAcceptedAuditBuffer == nil))) {
                state_->message =
                    "Human passive routed-band buffer is unavailable";
                return false;
            }
            if (state_->externalForceBuffer == nil ||
                state_->externalForceAuditBuffer == nil ||
                (state_->executionMode ==
                        NumiHumanTendonFEMLoadExecutionMode::standaloneRuntime &&
                 (state_->anchorReactionAuditBuffer == nil ||
                  state_->anchorReactionAuditHistoryBuffer == nil ||
                  state_->kinematicTargetBuffer == nil))) {
                state_->message = "Human tendon/FEM force/target buffer is unavailable";
                return false;
            }
            if (state_->femBodyContactNeighborhoodBVHNodeBuffer == nil) {
                state_->message = "Human body-contact BVH node buffer is unavailable";
                return false;
            }
            if (state_->worldStatusBuffer == nil) {
                state_->message = "Human tendon/FEM world-status buffer is unavailable";
                return false;
            }
            std::size_t releasedImmutableContactBytes = 0u;
            // Rebind dependent views first: they may share their source staging.
            if (!detail::retainSharedImmutableRows(state_->femBodyContactGroupedSolverSampleBuffer,
                    state_->femBodyContactGroupedSolverSamplesStaging, state_->femBodyContactGroupedSolverSamples,
                    releasedImmutableContactBytes)) {
                state_->message = "Human immutable contact upload parity failed: femBodyContactGroupedSolverSamples";
                return false;
            }
            if (!detail::retainSharedImmutableRows(state_->femBodyContactGroupedSolverRangeBuffer,
                    state_->femBodyContactGroupedSolverNeighborhoodRangesStaging, state_->femBodyContactGroupedSolverNeighborhoodRanges,
                    releasedImmutableContactBytes)) {
                state_->message = "Human immutable contact upload parity failed: femBodyContactGroupedSolverNeighborhoodRanges";
                return false;
            }
            if (!detail::retainSharedImmutableRows(state_->femBodyContactSolverSampleBuffer,
                    state_->femBodyContactSolverSamplesStaging, state_->femBodyContactSolverSamples,
                    releasedImmutableContactBytes)) {
                state_->message = "Human immutable contact upload parity failed: femBodyContactSolverSamples";
                return false;
            }
            if (!detail::retainSharedImmutableRows(state_->femBodyContactSolverNeighborhoodRangeBuffer,
                    state_->femBodyContactSolverNeighborhoodRangesStaging, state_->femBodyContactSolverNeighborhoodRanges,
                    releasedImmutableContactBytes)) {
                state_->message = "Human immutable contact upload parity failed: femBodyContactSolverNeighborhoodRanges";
                return false;
            }
            if (!detail::retainSharedImmutableRows(state_->femBodyContactSampleBuffer,
                    state_->femBodyContactSamplesStaging, state_->femBodyContactSamples,
                    releasedImmutableContactBytes)) {
                state_->message = "Human immutable contact upload parity failed: femBodyContactSamples";
                return false;
            }
            if (!detail::retainSharedImmutableRows(state_->femBodyContactNeighborhoodRangeBuffer,
                    state_->femBodyContactNeighborhoodRangesStaging, state_->femBodyContactNeighborhoodRanges,
                    releasedImmutableContactBytes)) {
                state_->message = "Human immutable contact upload parity failed: femBodyContactNeighborhoodRanges";
                return false;
            }
            if (!detail::retainSharedImmutableRows(state_->femBodyContactNeighborhoodTriangleBuffer,
                    state_->femBodyContactNeighborhoodTrianglesStaging, state_->femBodyContactNeighborhoodTriangles,
                    releasedImmutableContactBytes)) {
                state_->message = "Human immutable contact upload parity failed: femBodyContactNeighborhoodTriangles";
                return false;
            }
            if (!detail::retainSharedImmutableRows(state_->femBodyContactNeighborhoodBVHNodeBuffer,
                    state_->femBodyContactNeighborhoodBVHNodesStaging, state_->femBodyContactNeighborhoodBVHNodes,
                    releasedImmutableContactBytes)) {
                state_->message = "Human immutable contact upload parity failed: femBodyContactNeighborhoodBVHNodes";
                return false;
            }
            std::fprintf(stderr, "human_immutable_contact_storage=shared_upload_owner cpu_staging_released_bytes=%zu samples=%zu sample_rows_unchanged=1 device_allocated_bytes=%zu recommended_working_set_bytes=%llu\n",
                releasedImmutableContactBytes, state_->femBodyContactSamples.size(),
                static_cast<std::size_t>(device.currentAllocatedSize),
                static_cast<unsigned long long>(device.recommendedMaxWorkingSetSize));
        } else if (state_->device.registryID != device.registryID) {
            state_->message = "Human tendon/FEM adapter changed Metal devices";
            return false;
        }
        // Recheck every encode, including retries after failed admission.
        // Diagnostic admission bound for large native scenes. This stops
        // before submission, never accepts a smaller physical workload.
        const char* workingSetGuard = std::getenv("NUMI_HUMAN_CONTACT_WORKING_SET_GUARD");
        if (workingSetGuard != nullptr && std::strcmp(workingSetGuard, "1") != 0) {
            state_->message = "NUMI_HUMAN_CONTACT_WORKING_SET_GUARD must be exactly 1 when set";
            return false;
        }
        if (workingSetGuard != nullptr && device.currentAllocatedSize >
                device.recommendedMaxWorkingSetSize) {
            state_->message = "Human contact preparation exceeds the device recommended working set; physical segment was not submitted";
            return false;
        }
        if ((!state_->articularContactSamples.empty() ||
             state_->hasFEMBodyInteraction()) &&
            (state_->allocatedArticularBodyPoseStride != pass.bodyPoseStride ||
             (state_->articularBodyPoseStride != 0u &&
              state_->articularBodyPoseStride != pass.bodyPoseStride))) {
            state_->message =
                "Human tendon/FEM adapter changed its bound body-pose stride";
            return false;
        }
        if (state_->articularBodyPoseStride == 0u) {
            state_->articularBodyPoseStride = pass.bodyPoseStride;
        }

        const NMNumiHumanTendonFEMLoadDispatchGPU dispatch{
            .abiVersion = NM_NUMI_HUMAN_TENDON_FEM_LOAD_ABI_VERSION,
            .environmentCount = state_->environmentCount,
            .femNodeCount = static_cast<std::uint32_t>(state_->nodeLoads.size()),
            .endpointCount = state_->endpointCount,
            .transferStride = pass.endpointCount,
            .stepIndex = pass.stepIndex,
            .replacementCount = static_cast<std::uint32_t>(
                state_->replacements.size()),
            .dofCount = pass.dofCount,
            .bodyPoseStride = pass.bodyPoseStride,
            .articulationFirstBody = pass.articulationFirstBody,
            .pointJacobianStride = pass.pointJacobianStride,
            .bodyJacobianPointOffset = pass.bodyJacobianPointOffset,
            .generalizedForceStride = pass.generalizedForceStride,
            .generalizedForceOffset = pass.generalizedForceOffset,
            .muscleCount = pass.muscleCount,
            .femContactSampleCount = static_cast<std::uint32_t>(
                state_->contactSamples.size()),
            .articularContactSampleCount = static_cast<std::uint32_t>(
                state_->articularContactSamples.size()),
            .passiveLigamentCount = static_cast<std::uint32_t>(
                state_->passiveLigaments.size()),
            .femBodyContactSampleCount = static_cast<std::uint32_t>(
                state_->femBodyContactSamples.size()),
            .passiveRoutedBandCount = static_cast<std::uint32_t>(
                state_->passiveRoutedBands.size()),
            .articularContactPairCount =
                state_->articularContactPairCount,
            .femSurfaceAttachmentSampleCount = static_cast<std::uint32_t>(
                state_->femSurfaceAttachments.size()),
            .femBodyContactCandidateTriangleCount = static_cast<std::uint32_t>(
                state_->femBodyContactNeighborhoodTriangles.size()),
        };
        NMNumiHumanTendonFEMLoadDispatchGPU solverDispatch = dispatch;
        solverDispatch.femBodyContactSampleCount = static_cast<std::uint32_t>(
            state_->femBodyContactSolverSamples.size());
        detail::CommandProgress gpuProgress(state_->device,command,pass.stepIndex,"human_adapter");
        const auto encodeKernel = [&](id<MTLComputePipelineState> pipeline,
                                      const NSUInteger count,
                                      const auto& bind) {
            const char* contactTiming = std::getenv("NUMI_HUMAN_CONTACT_GPU_TIMING");
            id<MTLComputeCommandEncoder> encoder =
                contactTiming && std::strcmp(contactTiming,"1")==0
                    ? detail::timedEncoder(command,state_->device,pipeline.label.UTF8String,pass.stepIndex)
                    : [command computeCommandEncoder];
            if (encoder == nil) return false;
            [encoder setComputePipelineState:pipeline];
            [encoder setBytes:&dispatch length:sizeof(dispatch) atIndex:0u];
            bind(encoder);
            const NSUInteger width = std::min(
                count,
                std::min<NSUInteger>(pipeline.maxTotalThreadsPerThreadgroup, 256u)
            );
            [encoder dispatchThreads:MTLSizeMake(count, 1u, 1u)
                threadsPerThreadgroup:MTLSizeMake(std::max<NSUInteger>(width, 1u), 1u, 1u)];
            [encoder endEncoding];
            gpuProgress.signal(command,pipeline.label.UTF8String);
            return true;
        };

        const auto encodeNodeAudit = [&](bool reaction, id<MTLBuffer> forces,
                                        id<MTLBuffer> statuses, id<MTLBuffer> output) {
            if (state_->nodeWorkTiles==0u) {
                return encodeKernel(reaction?state_->reactionAuditPipeline:state_->forceAuditPipeline,
                    state_->environmentCount,[&](id<MTLComputeCommandEncoder> encoder) {
                    if (reaction) {
                        [encoder setBuffer:state_->nodeAnchorBuffer offset:0u atIndex:1u];
                        [encoder setBuffer:forces offset:0u atIndex:2u];
                        [encoder setBuffer:statuses offset:0u atIndex:3u];
                        [encoder setBuffer:output offset:0u atIndex:4u];
                    } else {
                        [encoder setBuffer:forces offset:0u atIndex:1u];
                        [encoder setBuffer:output offset:0u atIndex:2u];
                    }
                });
            }
            const std::uint32_t mode=reaction?1u:0u;
            return encodeKernel(state_->nodeForceAuditPartialPipeline,
                NSUInteger(state_->environmentCount)*state_->nodeWorkTiles*256u,
                [&](id<MTLComputeCommandEncoder> encoder) {
                    [encoder setBuffer:forces offset:0u atIndex:1u];
                    [encoder setBuffer:state_->nodeAnchorBuffer offset:0u atIndex:2u];
                    if (statuses!=nil) [encoder setBuffer:statuses offset:0u atIndex:3u];
                    else { const NMMatterStatusGPU empty{};
                        [encoder setBytes:&empty length:sizeof(empty) atIndex:3u]; }
                    [encoder setBuffer:state_->nodeForceAuditPartials offset:0u atIndex:4u];
                    [encoder setBytes:&mode length:sizeof(mode) atIndex:5u];
                }) && encodeKernel(state_->nodeForceAuditFinishPipeline,
                    NSUInteger(state_->environmentCount)*256u,
                    [&](id<MTLComputeCommandEncoder> encoder) {
                        [encoder setBuffer:state_->nodeForceAuditPartials offset:0u atIndex:1u];
                        [encoder setBuffer:output offset:0u atIndex:2u];
                    });
        };
        id<MTLBuffer> acceptedNodes = nil;
        if (!state_->contactSamples.empty() ||
            state_->hasFEMBodyInteraction()) {
            acceptedNodes = (__bridge id<MTLBuffer>)
                state_->runtime->femAcceptedNodeBuffer();
            const std::uint64_t expectedAcceptedNodeBytes =
                static_cast<std::uint64_t>(state_->environmentCount) *
                state_->nodeLoads.size() * sizeof(NMFEMNodeStateGPU);
            if (acceptedNodes == nil ||
                acceptedNodes.device.registryID != state_->device.registryID ||
                acceptedNodes.length < expectedAcceptedNodeBytes) {
                state_->message =
                    "Human FEM contact accepted-node arena is unavailable";
                return false;
            }
        }
        if (state_->contactExactMotionCache &&
            !encodeKernel(state_->contactMotionPreparePipeline,
                NSUInteger(state_->environmentCount) *
                    (state_->nodeLoads.size()+pass.bodyPoseStride),
                [&](id<MTLComputeCommandEncoder> encoder) {
                    [encoder setBuffer:acceptedNodes offset:0u atIndex:1u];
                    [encoder setBuffer:bodyPoses offset:0u atIndex:2u];
                    [encoder setBuffer:state_->contactMotionPositions offset:0u atIndex:3u];
                    [encoder setBuffer:state_->contactMotionPoseWords offset:0u atIndex:4u];
                    [encoder setBuffer:state_->contactMotionFlags offset:0u atIndex:5u];
                })) {
            state_->message="Human exact contact motion-cache preparation failed";
            return false;
        }
        if (!state_->femBodyContactSamples.empty()) {
            const NSUInteger sampleCount = state_->femBodyContactSamples.size();
            constexpr NSUInteger blockSize =
                NM_NUMI_HUMAN_FEM_BODY_CONTACT_VALIDATION_BLOCK_SIZE;
            const NSUInteger blockCount = sampleCount / blockSize +
                (sampleCount % blockSize != 0u ? 1u : 0u);
            const NSUInteger sampleWork =
                static_cast<NSUInteger>(state_->environmentCount) * sampleCount;
            const NSUInteger blockWork =
                static_cast<NSUInteger>(state_->environmentCount) * blockCount;
            if(state_->contactCompactQueries) {
                if (!encodeKernel(state_->contactQueryClassify,
                    NSUInteger(state_->contactQueryTileCount)*256u,
                    [&](id<MTLComputeCommandEncoder> encoder) {
                        [encoder setBuffer:state_->femBodyContactSampleBuffer offset:0u atIndex:1u];
                        [encoder setBuffer:state_->femBodyContactNeighborhoodRangeBuffer offset:0u atIndex:2u];
                        [encoder setBuffer:state_->femBodyContactNeighborhoodBVHNodeBuffer offset:0u atIndex:3u];
                        [encoder setBuffer:acceptedNodes offset:0u atIndex:4u];
                        [encoder setBuffer:bodyPoses offset:0u atIndex:5u];
                        [encoder setBuffer:state_->contactMotionFlags offset:0u atIndex:6u];
                        [encoder setBuffer:state_->femBodyContactSampleValidationBuffer offset:0u atIndex:7u];
                        [encoder setBuffer:state_->femBodyContactRowCache offset:0u atIndex:8u];
                        [encoder setBuffer:state_->contactQueryTiles offset:0u atIndex:9u];
                    }) ||
                    !encodeKernel(state_->contactQueryScanTiles,
                    NSUInteger(state_->contactQueryBlockCount)*256u,
                    [&](id<MTLComputeCommandEncoder> encoder) {
                        [encoder setBuffer:state_->contactQueryTiles offset:0u atIndex:1u];
                        [encoder setBuffer:state_->contactQueryBlockSums offset:0u atIndex:2u];
                    }) ||
                    !encodeKernel(state_->contactQueryScanBlocks,256u,
                    [&](id<MTLComputeCommandEncoder> encoder) {
                        [encoder setBuffer:state_->contactQueryBlockSums offset:0u atIndex:1u];
                        [encoder setBuffer:state_->contactQueryBlockOffsets offset:0u atIndex:2u];
                        [encoder setBuffer:state_->contactQueryWork offset:0u atIndex:3u];
                    }) ||
                    !encodeKernel(state_->contactQueryScatter,
                    NSUInteger(state_->contactQueryTileCount)*256u,
                    [&](id<MTLComputeCommandEncoder> encoder) {
                        [encoder setBuffer:state_->femBodyContactSampleValidationBuffer offset:0u atIndex:1u];
                        [encoder setBuffer:state_->contactQueryTiles offset:0u atIndex:2u];
                        [encoder setBuffer:state_->contactQueryBlockOffsets offset:0u atIndex:3u];
                        [encoder setBuffer:state_->contactQueryIndices offset:0u atIndex:4u];
                    })) {
                    state_->message="Human contact query compaction failed";
                    return false;
                }
            }
            const auto validateRows = [&](const auto& bind) {
                if(!state_->contactCompactQueries)
                    return encodeKernel(state_->femBodyContactSampleValidationPipeline,sampleWork,bind);
                const char* timing=std::getenv("NUMI_HUMAN_CONTACT_GPU_TIMING");
                auto encoder=timing && std::strcmp(timing,"1")==0
                    ? detail::timedEncoder(command,state_->device,state_->femBodyContactSampleValidationPipeline.label.UTF8String,pass.stepIndex)
                    : [command computeCommandEncoder];
                if(encoder==nil) return false;
                [encoder setComputePipelineState:state_->femBodyContactSampleValidationPipeline];
                [encoder setBytes:&dispatch length:sizeof(dispatch) atIndex:0u];
                bind(encoder);
                [encoder setBuffer:state_->contactQueryIndices offset:0u atIndex:10u];
                [encoder setBuffer:state_->contactQueryWork offset:0u atIndex:11u];
                [encoder dispatchThreadgroupsWithIndirectBuffer:state_->contactQueryWork indirectBufferOffset:0u
                    threadsPerThreadgroup:MTLSizeMake(256u,1u,1u)];
                [encoder endEncoding];
                gpuProgress.signal(command,state_->femBodyContactSampleValidationPipeline.label.UTF8String);
                return true;
            };
            if (!validateRows(
                    [&](id<MTLComputeCommandEncoder> encoder) {
                        [encoder setBuffer:state_->femBodyContactSampleBuffer
                                    offset:0u atIndex:1u];
                        [encoder setBuffer:state_->femBodyContactNeighborhoodRangeBuffer
                                    offset:0u atIndex:2u];
                        [encoder setBuffer:state_->femBodyContactNeighborhoodTriangleBuffer
                                    offset:0u atIndex:3u];
                        [encoder setBuffer:state_->femBodyContactNeighborhoodBVHNodeBuffer
                                    offset:0u atIndex:4u];
                        [encoder setBuffer:acceptedNodes offset:0u atIndex:5u];
                        [encoder setBuffer:bodyPoses offset:0u atIndex:6u];
                        [encoder setBuffer:state_->femBodyContactSampleValidationBuffer
                                    offset:0u atIndex:7u];
                        if(state_->contactRowCache)
                            [encoder setBuffer:state_->femBodyContactRowCache offset:0u atIndex:8u];
                        if(state_->contactExactMotionCache)
                            [encoder setBuffer:state_->contactMotionFlags offset:0u atIndex:9u];
                    }) ||
                !encodeKernel(
                    state_->femBodyContactSampleValidationReducePipeline,
                    blockWork,
                    [&](id<MTLComputeCommandEncoder> encoder) {
                        [encoder setBuffer:state_->femBodyContactSampleValidationBuffer
                                    offset:0u atIndex:1u];
                        [encoder setBuffer:state_->femBodyContactSampleValidationBlockBuffer
                                    offset:0u atIndex:2u];
                    })) {
                state_->message =
                    "Human FEM/body contact validation kernel encoding failed";
                return false;
            }
        }

        if (state_->nodeWorkTiles!=0u &&
            (!encodeKernel(state_->nodeValidationPartialPipeline,
                NSUInteger(state_->environmentCount)*state_->nodeWorkTiles*256u,
                [&](id<MTLComputeCommandEncoder> encoder) {
                    [encoder setBuffer:state_->nodeLoadBuffer offset:0u atIndex:1u];
                    [encoder setBuffer:state_->nodeAnchorBuffer offset:0u atIndex:2u];
                    [encoder setBuffer:transfers offset:0u atIndex:3u];
                    [encoder setBuffer:bodyPoses offset:0u atIndex:4u];
                    [encoder setBuffer:state_->nodeValidationPartials offset:0u atIndex:5u];
                    [encoder setBytes:&state_->nodeWorkTiles length:sizeof(std::uint32_t) atIndex:6u];
                }) || !encodeKernel(state_->nodeValidationFinishPipeline,
                    NSUInteger(state_->environmentCount)*256u,
                    [&](id<MTLComputeCommandEncoder> encoder) {
                        [encoder setBuffer:state_->nodeValidationPartials offset:0u atIndex:1u];
                        [encoder setBuffer:state_->nodeValidationFirstInvalid offset:0u atIndex:2u];
                        [encoder setBytes:&state_->nodeWorkTiles length:sizeof(std::uint32_t) atIndex:3u];
                    }))) {
            state_->message="Human node validation encoding failed";
            return false;
        }

        if (!encodeKernel(
                state_->provisionalStatusPipeline, state_->environmentCount,
                [&](id<MTLComputeCommandEncoder> encoder) {
                    [encoder setBuffer:state_->nodeValidationFirstInvalid offset:0u atIndex:18u];
                    [encoder setBytes:&state_->nodeWorkTiles length:sizeof(std::uint32_t) atIndex:19u];
                    [encoder setBuffer:state_->nodeLoadBuffer offset:0u atIndex:1u];
                    [encoder setBuffer:state_->nodeAnchorBuffer offset:0u atIndex:2u];
                    [encoder setBuffer:state_->replacementBuffer offset:0u atIndex:3u];
                    [encoder setBuffer:bindings offset:0u atIndex:4u];
                    [encoder setBuffer:transfers offset:0u atIndex:5u];
                    [encoder setBuffer:bodyPoses offset:0u atIndex:6u];
                    [encoder setBuffer:state_->worldStatusBuffer
                                offset:0u atIndex:7u];
                    if (state_->articularContactSampleBuffer != nil) {
                        [encoder setBuffer:state_->articularContactSampleBuffer offset:0u atIndex:8u];
                    } else {
                        // Metal requires a typed binding even when the dispatch
                        // count is zero. This is never a physical sample.
                        const NMNumiHumanArticularContactSampleGPU empty{};
                        [encoder setBytes:&empty length:sizeof(empty) atIndex:8u];
                    }
                    if (state_->passiveLigamentBuffer != nil) {
                        [encoder setBuffer:state_->passiveLigamentBuffer offset:0u atIndex:9u];
                    } else {
                        // Metal requires a typed binding even when the dispatch
                        // count is zero. This is never a physical sample.
                        const NMNumiHumanPassiveLigamentGPU empty{};
                        [encoder setBytes:&empty length:sizeof(empty) atIndex:9u];
                    }
                    if (state_->femBodyContactSampleBuffer != nil) {
                        [encoder setBuffer:state_->femBodyContactSampleBuffer offset:0u atIndex:10u];
                    } else {
                        // Metal requires a typed binding even when the dispatch
                        // count is zero. This is never a physical sample.
                        const NMNumiHumanFEMBodyContactSampleGPU empty{};
                        [encoder setBytes:&empty length:sizeof(empty) atIndex:10u];
                    }
                    if (state_->passiveRoutedBandBuffer != nil) {
                        [encoder setBuffer:state_->passiveRoutedBandBuffer offset:0u atIndex:11u];
                    } else {
                        // Metal requires a typed binding even when the dispatch
                        // count is zero. This is never a physical sample.
                        const NMNumiHumanPassiveRoutedBandGPU empty{};
                        [encoder setBytes:&empty length:sizeof(empty) atIndex:11u];
                    }
                    if (state_->femSurfaceAttachmentBuffer != nil) {
                        [encoder setBuffer:state_->femSurfaceAttachmentBuffer
                                    offset:0u atIndex:12u];
                    } else {
                        const NMNumiHumanFEMSurfaceAttachmentGPU empty{};
                        [encoder setBytes:&empty length:sizeof(empty) atIndex:12u];
                    }
                    [encoder setBuffer:state_->femBodyContactNeighborhoodRangeBuffer
                                offset:0u atIndex:14u];
                    [encoder setBuffer:state_->femBodyContactNeighborhoodTriangleBuffer
                                offset:0u atIndex:15u];
                    [encoder setBuffer:state_->femBodyContactNeighborhoodBVHNodeBuffer
                                offset:0u atIndex:16u];
                    if (state_->femBodyContactSampleValidationBlockBuffer != nil) {
                        [encoder setBuffer:state_->femBodyContactSampleValidationBlockBuffer
                                    offset:0u atIndex:17u];
                    } else {
                        const std::uint32_t emptyValidation = MR_INVALID_INDEX;
                        [encoder setBytes:&emptyValidation
                                   length:sizeof(emptyValidation) atIndex:17u];
                    }
                    if (acceptedNodes != nil) {
                        [encoder setBuffer:acceptedNodes offset:0u atIndex:13u];
                    } else {
                        const NMFEMNodeStateGPU empty{};
                        [encoder setBytes:&empty length:sizeof(empty) atIndex:13u];
                    }
                }
            ) || !encodeKernel(
                state_->forcePipeline,
                state_->environmentCount * state_->nodeLoads.size(),
                [&](id<MTLComputeCommandEncoder> encoder) {
                    [encoder setBuffer:state_->nodeLoadBuffer offset:0u atIndex:1u];
                    [encoder setBuffer:transfers offset:0u atIndex:2u];
                    [encoder setBuffer:state_->externalForceBuffer
                                offset:0u atIndex:3u];
                }
            )) {
            state_->message = "Human tendon/FEM assembly kernel encoding failed";
            return false;
        }
        if (!state_->contactSamples.empty() &&
            !encodeKernel(
                    state_->contactForcePipeline,
                    state_->environmentCount * state_->nodeLoads.size(),
                    [&](id<MTLComputeCommandEncoder> encoder) {
                        [encoder setBuffer:state_->contactSampleBuffer
                                    offset:0u atIndex:1u];
                        [encoder setBuffer:state_->contactContributionBuffer
                                    offset:0u atIndex:2u];
                        [encoder setBuffer:state_->contactRangeBuffer
                                    offset:0u atIndex:3u];
                        [encoder setBuffer:acceptedNodes offset:0u atIndex:4u];
                        [encoder setBuffer:state_->externalForceBuffer
                                    offset:0u atIndex:5u];
                    })) {
                state_->message =
                    "Human internal FEM contact kernel encoding failed";
                return false;
        }
        if (!state_->femBodyContactSolverSamples.empty() &&
            !encodeKernel(
                state_->hasMultiMasterTriangleContact
                    ? state_->femBodyContactGroupedForcePipeline
                    : state_->femBodyContactForcePipeline,
                state_->environmentCount * state_->femBodyContactSolverSamples.size(),
                [&](id<MTLComputeCommandEncoder> encoder) {
                    [encoder setBytes:&solverDispatch
                               length:sizeof(solverDispatch) atIndex:0u];
                    id<MTLBuffer> sampleBuffer = state_->hasMultiMasterTriangleContact
                        ? state_->femBodyContactGroupedSolverSampleBuffer
                        : state_->femBodyContactSolverSampleBuffer;
                    id<MTLBuffer> rangeBuffer = state_->hasMultiMasterTriangleContact
                        ? state_->femBodyContactGroupedSolverRangeBuffer
                        : state_->femBodyContactSolverNeighborhoodRangeBuffer;
                    [encoder setBuffer:sampleBuffer offset:0u atIndex:1u];
                    [encoder setBuffer:acceptedNodes offset:0u atIndex:2u];
                    [encoder setBuffer:bodyPoses offset:0u atIndex:3u];
                    [encoder setBuffer:state_->externalForceBuffer
                                offset:0u atIndex:4u];
                    [encoder setBuffer:rangeBuffer offset:0u atIndex:5u];
                    [encoder setBuffer:state_->femBodyContactNeighborhoodTriangleBuffer
                                offset:0u atIndex:6u];
                    [encoder setBuffer:state_->femBodyContactNeighborhoodBVHNodeBuffer
                                offset:0u atIndex:(state_->hasMultiMasterTriangleContact ? 8u : 7u)];
                    if (state_->hasMultiMasterTriangleContact) {
                        [encoder setBuffer:state_->femBodyContactSolverGroupCountBuffer
                                    offset:0u atIndex:9u];
                        if(state_->contactRowCache)
                            [encoder setBuffer:state_->femBodyContactRowCache offset:0u atIndex:10u];
                    }
                })) {
            state_->message = "Human FEM/body contact force encoding failed";
            return false;
        }
        if (state_->hasFEMBodyInteraction()) {
            const bool parallelWrench=state_->femBodyContactWrenchTileCount!=0u;
            if (!encodeKernel(
                parallelWrench?state_->femBodyContactWrenchPartialPipeline:state_->femBodyContactWrenchPipeline,
                parallelWrench?NSUInteger(state_->environmentCount)*state_->femBodyContactWrenchTileCount*256u:
                    NSUInteger(state_->environmentCount)*pass.bodyPoseStride,
                [&](id<MTLComputeCommandEncoder> encoder) {
                    [encoder setBytes:&solverDispatch
                               length:sizeof(solverDispatch) atIndex:0u];
                    [encoder setBuffer:state_->femBodyContactSolverSampleBuffer
                                offset:0u atIndex:1u];
                    [encoder setBuffer:acceptedNodes offset:0u atIndex:2u];
                    [encoder setBuffer:bodyPoses offset:0u atIndex:3u];
                    [encoder setBuffer:parallelWrench?state_->femBodyContactWrenchPartials:state_->femBodyContactWrenchBuffer
                                offset:0u atIndex:4u];
                    [encoder setBuffer:state_->femBodyContactSolverNeighborhoodRangeBuffer
                                offset:0u atIndex:5u];
                    [encoder setBuffer:state_->femBodyContactNeighborhoodTriangleBuffer
                                offset:0u atIndex:6u];
                    [encoder setBuffer:state_->femBodyContactNeighborhoodBVHNodeBuffer
                                offset:0u atIndex:7u];
                    if(parallelWrench) {
                        [encoder setBuffer:state_->femBodyContactWrenchIndices offset:0u atIndex:8u];
                        [encoder setBuffer:state_->femBodyContactWrenchTiles offset:0u atIndex:9u];
                        [encoder setBytes:&state_->femBodyContactWrenchTileCount
                            length:sizeof(std::uint32_t) atIndex:10u];
                        if(state_->contactRowCache)
                            [encoder setBuffer:state_->femBodyContactRowCache offset:0u atIndex:11u];
                    }

                })) {
                state_->message = "Human FEM/body base-wrench encoding failed";
                return false;
            }
            if(parallelWrench && !encodeKernel(state_->femBodyContactWrenchFinishPipeline,
                NSUInteger(state_->environmentCount)*pass.bodyPoseStride*256u,
                [&](id<MTLComputeCommandEncoder> encoder) {
                    [encoder setBytes:&solverDispatch length:sizeof(solverDispatch) atIndex:0u];
                    [encoder setBuffer:state_->femBodyContactWrenchPartials offset:0u atIndex:1u];
                    [encoder setBuffer:state_->femBodyContactWrenchBuffer offset:0u atIndex:2u];
                    [encoder setBuffer:state_->femBodyContactWrenchBodyRanges offset:0u atIndex:3u];
                    [encoder setBytes:&state_->femBodyContactWrenchTileCount length:sizeof(std::uint32_t) atIndex:4u];
                })) {
                state_->message="Human FEM/body wrench reduction encoding failed";
                return false;
            }
        }
        if (!state_->femSurfaceAttachments.empty()) {
            if (!encodeKernel(
                state_->femSurfaceAttachmentForcePipeline,
                state_->environmentCount * state_->nodeLoads.size(),
                [&](id<MTLComputeCommandEncoder> encoder) {
                    [encoder setBuffer:state_->femSurfaceAttachmentBuffer
                                offset:0u atIndex:1u];
                    [encoder setBuffer:acceptedNodes offset:0u atIndex:2u];
                    [encoder setBuffer:bodyPoses offset:0u atIndex:3u];
                    [encoder setBuffer:state_->externalForceBuffer
                                offset:0u atIndex:4u];
                }) || !encodeKernel(
                state_->femSurfaceAttachmentWrenchPipeline,
                state_->environmentCount * pass.bodyPoseStride,
                [&](id<MTLComputeCommandEncoder> encoder) {
                    [encoder setBuffer:state_->femSurfaceAttachmentBuffer
                                offset:0u atIndex:1u];
                    [encoder setBuffer:acceptedNodes offset:0u atIndex:2u];
                    [encoder setBuffer:bodyPoses offset:0u atIndex:3u];
                    [encoder setBuffer:state_->femBodyContactWrenchBuffer
                                offset:0u atIndex:4u];
                })) {
                state_->message = "Human FEM surface attachment force/wrench encoding failed";
                return false;
            }
        }
        if (state_->hasFEMBodyInteraction()) {
            const bool parallel = state_->femBodyContactAuditTiles != 0u;
            if (!encodeKernel(parallel ? state_->femBodyContactAuditPartialPipeline :
                    state_->femBodyContactAuditPipeline,
                    parallel ? NSUInteger(state_->environmentCount) *
                        state_->femBodyContactAuditTiles * 256u : state_->environmentCount,
                [&](id<MTLComputeCommandEncoder> encoder) {
                    [encoder setBuffer:state_->femBodyContactSampleBuffer
                                offset:0u atIndex:1u];
                    [encoder setBuffer:acceptedNodes offset:0u atIndex:2u];
                    [encoder setBuffer:bodyPoses offset:0u atIndex:3u];
                    [encoder setBuffer:parallel ? state_->femBodyContactAuditPartialBuffer : state_->femBodyContactAuditBuffer
                                offset:0u atIndex:4u];
                    [encoder setBuffer:state_->femBodyContactNeighborhoodRangeBuffer
                                offset:0u atIndex:6u];
                    [encoder setBuffer:state_->femBodyContactNeighborhoodTriangleBuffer
                                offset:0u atIndex:7u];
                    [encoder setBuffer:state_->femBodyContactNeighborhoodBVHNodeBuffer
                                offset:0u atIndex:8u];
                    if(state_->contactRowCache)
                        [encoder setBuffer:state_->femBodyContactRowCache offset:0u atIndex:9u];
                    if (state_->femSurfaceAttachmentBuffer != nil) {
                        [encoder setBuffer:state_->femSurfaceAttachmentBuffer
                                    offset:0u atIndex:5u];
                    } else {
                        const NMNumiHumanFEMSurfaceAttachmentGPU empty{};
                        [encoder setBytes:&empty length:sizeof(empty) atIndex:5u];
                    }
                })) {
                state_->message = "Human FEM/body attachment audit encoding failed";
                return false;
            }
            if (parallel && !encodeKernel(state_->femBodyContactAuditFinishPipeline,
                    NSUInteger(state_->environmentCount) * 256u,
                    [&](id<MTLComputeCommandEncoder> encoder) {
                        [encoder setBuffer:state_->femBodyContactAuditPartialBuffer offset:0u atIndex:1u];
                        [encoder setBuffer:state_->femBodyContactAuditBuffer offset:0u atIndex:2u];
                    })) {
                state_->message = "Human FEM/body attachment audit reduction failed";
                return false;
            }
        }
        const bool captureRequested =
            pass.acceptedFEMBodyGeneralizedLoadCapture != nullptr ||
            pass.acceptedFEMBodySourceQCapture != nullptr;
        if (captureRequested && state_->executionMode ==
                NumiHumanTendonFEMLoadExecutionMode::numanXDeferred) {
            state_->message =
                "accepted full FEM load capture requires the standalone Matter pre-dynamics solve";
            return false;
        }
        if (captureRequested) {
            id<MTLBuffer> sourceQ = (__bridge id<MTLBuffer>)pass.sourceQ;
            id<MTLBuffer> loadOutput = (__bridge id<MTLBuffer>)
                pass.acceptedFEMBodyGeneralizedLoadCapture;
            id<MTLBuffer> qOutput = (__bridge id<MTLBuffer>)
                pass.acceptedFEMBodySourceQCapture;
            const std::uint64_t loadElements =
                static_cast<std::uint64_t>(pass.environmentCount) * pass.dofCount;
            const std::uint64_t qElements =
                static_cast<std::uint64_t>(pass.environmentCount) *
                pass.sourceQCoordinateCount;
            if (pass.environmentCount != 1u ||
                sourceQ == nil || loadOutput == nil || qOutput == nil ||
                (state_->hasFEMBodyInteraction() &&
                 (state_->femBodyContactWrenchBuffer == nil ||
                  state_->femBodyContactWrenchBuffer.length <
                    pass.bodyPoseStride * sizeof(NMNumiHumanBodyWrenchGPU))) ||
                pass.sourceQCoordinateCount == 0u ||
                pass.sourceQElementCount < pass.sourceQCoordinateCount ||
                pass.acceptedFEMBodyGeneralizedLoadGPUAddress == 0u ||
                pass.acceptedFEMBodyGeneralizedLoadGPUAddress != loadOutput.gpuAddress ||
                pass.acceptedFEMBodyGeneralizedLoadElementCount < loadElements ||
                pass.acceptedFEMBodySourceQGPUAddress == 0u ||
                pass.acceptedFEMBodySourceQGPUAddress != qOutput.gpuAddress ||
                pass.acceptedFEMBodySourceQElementCount < qElements ||
                sourceQ.device.registryID != state_->device.registryID ||
                loadOutput.device.registryID != state_->device.registryID ||
                qOutput.device.registryID != state_->device.registryID ||
                loadOutput.storageMode != MTLStorageModeShared ||
                qOutput.storageMode != MTLStorageModeShared ||
                loadOutput.contents == nullptr || qOutput.contents == nullptr ||
                sourceQ.length < pass.sourceQCoordinateCount * sizeof(float) ||
                loadOutput.length < loadElements * sizeof(float) ||
                qOutput.length < qElements * sizeof(float)) {
                state_->message =
                    "accepted FEM generalized-load source-q capture is incomplete";
                return false;
            }
            const NSUInteger pendingLoadBytes =
                static_cast<NSUInteger>(loadElements * sizeof(float));
            const NSUInteger pendingQBytes =
                static_cast<NSUInteger>(qElements * sizeof(float));
            if (state_->femBodyContactGeneralizedLoadPendingBuffer == nil ||
                state_->femBodyContactGeneralizedLoadPendingBuffer.length != pendingLoadBytes) {
                state_->femBodyContactGeneralizedLoadPendingBuffer =
                    [state_->device newBufferWithLength:pendingLoadBytes
                                                options:MTLResourceStorageModePrivate];
            }
            if (state_->femBodySourceQPendingBuffer == nil ||
                state_->femBodySourceQPendingBuffer.length != pendingQBytes) {
                state_->femBodySourceQPendingBuffer =
                    [state_->device newBufferWithLength:pendingQBytes
                                                options:MTLResourceStorageModePrivate];
            }
            if (state_->femBodyContactGeneralizedLoadPendingBuffer == nil ||
                state_->femBodySourceQPendingBuffer == nil) {
                state_->message = "accepted FEM source snapshot scratch allocation failed";
                return false;
            }
            if (state_->femBodyContactGeneralizedLoadPreparePipeline == nil) {
                const std::string qualified =
                    "numi_matter_metal::nm_numi_human_prepare_fem_body_generalized_load";
                id<MTLFunction> function = [state_->library newFunctionWithName:
                    [NSString stringWithUTF8String:qualified.c_str()]];
                NSError* pipelineError = nil;
                if (function != nil)
                    state_->femBodyContactGeneralizedLoadPreparePipeline =
                        [state_->device newComputePipelineStateWithFunction:function
                                                                       error:&pipelineError];
                if (state_->femBodyContactGeneralizedLoadPreparePipeline == nil) {
                    const char* description = pipelineError == nil ? "kernel unavailable"
                        : pipelineError.localizedDescription.UTF8String;
                    state_->message = std::string("accepted FEM source snapshot PSO failed: ") +
                        (description == nullptr ? "unknown Metal error" : description);
                    return false;
                }
            }
            if (state_->femAnchorReactionLoadAddPipeline == nil) {
                const std::string qualified =
                    state_->sparseAnchorProjection ?
                    "numi_matter_metal::nm_numi_human_add_fem_anchor_reactions_to_pending_load_sparse" :
                    "numi_matter_metal::nm_numi_human_add_fem_anchor_reactions_to_pending_load";
                id<MTLFunction> function = [state_->library newFunctionWithName:
                    [NSString stringWithUTF8String:qualified.c_str()]];
                NSError* pipelineError = nil;
                if (function != nil)
                    state_->femAnchorReactionLoadAddPipeline =
                        [state_->device newComputePipelineStateWithFunction:function
                                                                       error:&pipelineError];
                if (state_->femAnchorReactionLoadAddPipeline == nil) {
                    const char* description = pipelineError == nil ? "kernel unavailable"
                        : pipelineError.localizedDescription.UTF8String;
                    state_->message = std::string("accepted FEM anchor-load PSO failed: ") +
                        (description == nullptr ? "unknown Metal error" : description);
                    return false;
                }
            }
            NMNumiHumanTendonFEMLoadDispatchGPU snapshotDispatch = dispatch;
            snapshotDispatch.reserved0 = pass.sourceQCoordinateCount;
            id<MTLComputeCommandEncoder> snapshotEncoder =
                [command computeCommandEncoder];
            if (snapshotEncoder == nil) {
                state_->message = "accepted FEM source snapshot encoder unavailable";
                return false;
            }
            [snapshotEncoder setComputePipelineState:
                state_->femBodyContactGeneralizedLoadPreparePipeline];
            [snapshotEncoder setBytes:&snapshotDispatch
                               length:sizeof(snapshotDispatch) atIndex:0u];
            if (state_->femBodyContactWrenchBuffer != nil) {
                [snapshotEncoder setBuffer:state_->femBodyContactWrenchBuffer
                                    offset:0u atIndex:1u];
            } else {
                const NMNumiHumanBodyWrenchGPU emptyWrench{};
                [snapshotEncoder setBytes:&emptyWrench length:sizeof(emptyWrench)
                                  atIndex:1u];
            }
            [snapshotEncoder setBuffer:bodyPoses offset:0u atIndex:2u];
            [snapshotEncoder setBuffer:pointJacobians offset:0u atIndex:3u];
            [snapshotEncoder setBuffer:sourceQ offset:0u atIndex:4u];
            [snapshotEncoder setBuffer:
                state_->femBodyContactGeneralizedLoadPendingBuffer
                                offset:0u atIndex:5u];
            [snapshotEncoder setBuffer:state_->femBodySourceQPendingBuffer
                                offset:0u atIndex:6u];
            const NSUInteger snapshotCount = std::max<NSUInteger>(
                pass.dofCount, pass.sourceQCoordinateCount);
            const NSUInteger snapshotWidth = std::min<NSUInteger>(
                snapshotCount, std::min<NSUInteger>(
                    state_->femBodyContactGeneralizedLoadPreparePipeline
                        .maxTotalThreadsPerThreadgroup, 256u));
            [snapshotEncoder dispatchThreads:
                MTLSizeMake(snapshotCount, 1u, 1u)
                threadsPerThreadgroup:
                    MTLSizeMake(std::max<NSUInteger>(snapshotWidth, 1u), 1u, 1u)];
            [snapshotEncoder endEncoding];
        }
        if (!state_->articularContactSamples.empty() &&
            !encodeKernel(
                state_->articularContactPipeline,
                state_->environmentCount * pass.bodyPoseStride,
                [&](id<MTLComputeCommandEncoder> encoder) {
                    [encoder setBuffer:state_->articularContactSampleBuffer
                                offset:0u atIndex:1u];
                    [encoder setBuffer:bodyPoses offset:0u atIndex:2u];
                    [encoder setBuffer:state_->articularBodyWrenchBuffer
                                offset:0u atIndex:3u];
                })) {
            state_->message =
                "Human articular contact wrench encoding failed";
            return false;
        }
        if (!state_->passiveLigaments.empty() &&
            !encodeKernel(
                state_->passiveLigamentAuditPipeline,
                state_->environmentCount,
                [&](id<MTLComputeCommandEncoder> encoder) {
                    [encoder setBuffer:state_->passiveLigamentBuffer
                                offset:0u atIndex:1u];
                    [encoder setBuffer:bodyPoses offset:0u atIndex:2u];
                    [encoder setBuffer:state_->passiveLigamentAuditBuffer
                                offset:0u atIndex:3u];
                })) {
            state_->message = "Human passive ligament audit encoding failed";
            return false;
        }
        if (!state_->passiveRoutedBands.empty() &&
            !encodeKernel(
                state_->passiveRoutedBandAuditPipeline,
                state_->environmentCount,
                [&](id<MTLComputeCommandEncoder> encoder) {
                    [encoder setBuffer:state_->passiveRoutedBandBuffer
                                offset:0u atIndex:1u];
                    [encoder setBuffer:bodyPoses offset:0u atIndex:2u];
                    [encoder setBuffer:state_->passiveRoutedBandAuditBuffer
                                offset:0u atIndex:3u];
                })) {
            state_->message = "Human passive routed-band audit encoding failed";
            return false;
        }
        if (!state_->articularContactSamples.empty() &&
            !encodeKernel(
                state_->articularContactAuditPipeline,
                state_->environmentCount,
                [&](id<MTLComputeCommandEncoder> encoder) {
                    [encoder setBuffer:state_->articularContactSampleBuffer
                                offset:0u atIndex:1u];
                    [encoder setBuffer:bodyPoses offset:0u atIndex:2u];
                    [encoder setBuffer:state_->articularBodyWrenchBuffer
                                offset:0u atIndex:3u];
                    [encoder setBuffer:state_->articularContactAuditBuffer
                                offset:0u atIndex:4u];
                })) {
            state_->message =
                "Human articular contact audit encoding failed";
            return false;
        }
        if (state_->articularContactPairCount != 0u &&
            !encodeKernel(
                state_->articularContactPairAuditPipeline,
                state_->environmentCount,
                [&](id<MTLComputeCommandEncoder> encoder) {
                    [encoder setBuffer:state_->articularContactSampleBuffer
                                offset:0u atIndex:1u];
                    [encoder setBuffer:state_->articularContactPairRangeBuffer
                                offset:0u atIndex:2u];
                    [encoder setBuffer:bodyPoses offset:0u atIndex:3u];
                    [encoder setBuffer:state_->articularContactPairAuditBuffer
                                offset:0u atIndex:4u];
                })) {
            state_->message =
                "Human articular contact pair audit encoding failed";
            return false;
        }
        if (!encodeNodeAudit(false,state_->externalForceBuffer,nil,
                             state_->externalForceAuditBuffer)) {
            state_->message = "Human tendon/FEM force audit encoding failed";
            return false;
        }
        if (state_->executionMode ==
                NumiHumanTendonFEMLoadExecutionMode::numanXDeferred) {
            if (!encodeKernel(
                    state_->preSourceCorrectionPipeline,
                    state_->environmentCount * pass.dofCount,
                    [&](id<MTLComputeCommandEncoder> encoder) {
                        [encoder setBuffer:state_->replacementBuffer
                                    offset:0u atIndex:1u];
                        [encoder setBuffer:bindings offset:0u atIndex:2u];
                        [encoder setBuffer:transfers offset:0u atIndex:3u];
                        [encoder setBuffer:bodyPoses offset:0u atIndex:4u];
                        [encoder setBuffer:pointJacobians offset:0u atIndex:5u];
                        [encoder setBuffer:generalizedForces offset:0u atIndex:6u];
                        if (state_->articularBodyWrenchBuffer != nil) {
                            [encoder setBuffer:state_->articularBodyWrenchBuffer
                                        offset:0u atIndex:7u];
                        } else {
                            const NMNumiHumanBodyWrenchGPU empty{};
                            [encoder setBytes:&empty length:sizeof(empty)
                                      atIndex:7u];
                        }
                        if (state_->passiveLigamentBuffer != nil) {
                            [encoder setBuffer:state_->passiveLigamentBuffer
                                        offset:0u atIndex:8u];
                        } else {
                            const NMNumiHumanPassiveLigamentGPU empty{};
                            [encoder setBytes:&empty length:sizeof(empty)
                                      atIndex:8u];
                        }
                        if (state_->femBodyContactWrenchBuffer != nil) {
                            [encoder setBuffer:state_->femBodyContactWrenchBuffer
                                        offset:0u atIndex:9u];
                        } else {
                            const NMNumiHumanBodyWrenchGPU empty{};
                            [encoder setBytes:&empty length:sizeof(empty)
                                      atIndex:9u];
                        }
                        if (state_->passiveRoutedBandBuffer != nil) {
                            [encoder setBuffer:state_->passiveRoutedBandBuffer
                                        offset:0u atIndex:10u];
                        } else {
                            const NMNumiHumanPassiveRoutedBandGPU empty{};
                            [encoder setBytes:&empty length:sizeof(empty)
                                      atIndex:10u];
                        }
                        [encoder setBuffer:state_->worldStatusBuffer
                                    offset:0u atIndex:11u];
                    })) {
                state_->message =
                    "Human tendon/FEM pre-source correction encoding failed";
                return false;
            }
            ++state_->preSourceCorrectionEncodeCount;
            state_->deferredCommandBufferIdentity =
                reinterpret_cast<std::uintptr_t>(pass.commandBuffer);
            state_->deferredStepIndex = pass.stepIndex;
            state_->deferredExternalForcesAvailable = true;
            state_->articularAttemptedStepCount = std::max(
                state_->articularAttemptedStepCount, pass.stepIndex + 1u);
            state_->acceptedWrenchSourceCommandBuffer = pass.commandBuffer;
            state_->acceptedWrenchSourceBodyPoses = pass.bodyPoses;
            state_->acceptedWrenchSourcePointJacobians = pass.pointJacobians;
            state_->acceptedWrenchSourceQ = pass.sourceQ;
            state_->acceptedWrenchSourceQCoordinateCount =
                pass.sourceQCoordinateCount;
            state_->acceptedWrenchSourceStepIndex = pass.stepIndex;
            state_->acceptedWrenchSourceDofCount = pass.dofCount;
            state_->acceptedWrenchSourceBodyPoseStride = pass.bodyPoseStride;
            state_->acceptedWrenchSourcePointJacobianStride =
                pass.pointJacobianStride;
            state_->acceptedWrenchSourceBodyJacobianPointOffset =
                pass.bodyJacobianPointOffset;
            state_->acceptedWrenchSourceArticulationFirstBody =
                pass.articulationFirstBody;
            state_->acceptedWrenchSourceValid = true;
            state_->message = "deferred pre-source loads encoded";
            return true;
        }
        if (!encodeKernel(
                state_->targetPipeline,
                state_->environmentCount * state_->nodeAnchors.size(),
                [&](id<MTLComputeCommandEncoder> encoder) {
                    [encoder setBuffer:state_->nodeAnchorBuffer offset:0u atIndex:1u];
                    [encoder setBuffer:bodyPoses offset:0u atIndex:2u];
                    [encoder setBuffer:state_->kinematicTargetBuffer
                                offset:0u atIndex:3u];
                })) {
            state_->message = "Human tendon/FEM target encoding failed";
            return false;
        }

        EncodeRequest request{};
        request.commandBuffer = pass.commandBuffer;
        request.environmentStatuses =
            (__bridge void*)state_->worldStatusBuffer;
        request.femExternalForces =
            (__bridge void*)state_->externalForceBuffer;
        request.femExternalForceCount = static_cast<std::uint32_t>(
            state_->environmentCount * state_->nodeLoads.size()
        );
        request.femKinematicTargets =
            (__bridge void*)state_->kinematicTargetBuffer;
        request.femKinematicTargetCount = request.femExternalForceCount;
        request.controlStep = pass.stepIndex;
        request.physicsSubstep = 0u;
        request.physicsSubsteps = 1u;
        request.timestepSeconds = state_->runtime->timestepSeconds();
        request.phase = EncodePhase::preDynamics;
        request.vascularPressureLoadScale = pass.vascularPressureLoadScale;
        if ((pass.coupledCandidateContext == nullptr) !=
            (pass.encodeCoupledCandidate == nullptr)) {
            state_->message = "transaction candidate bridge is partially configured";
            return false;
        }
        if (pass.encodeCoupledCandidate != nullptr) {
            request.coupledCandidateContext = const_cast<
                metalrobo::MetalNumiHumanTendonLoadPass*>(&pass);
            request.encodeCoupledCandidate =
                &encodeTransactionCoupledCandidateBridge;
            request.coupledCandidateSourceMassOperationsAvailable =
                pass.sourceMassOperationsAvailable;
            request.coupledCandidateBorrowedComputeEncoderAvailable =
                pass.sourceMassOperationsAvailable &&
                exactEnvironmentOptIn(
                    "NM_FGMRES_COUPLED_BORROWED_ENCODER");
            request.coupledCandidateIndirectMassActionDispatchAvailable =
                pass.sourceMassOperationsAvailable &&
                exactEnvironmentOptIn(
                    "NM_FGMRES_COUPLED_MASS_ACTION_INDIRECT");
            request.coupledCandidateIndirectDispatchTransactionFingerprint =
                pass.candidateTransactionFingerprint;
            request.coupledCandidateIndirectDispatchLinearizationEpoch =
                pass.candidateLinearizationEpoch;
            request.coupledCandidateIndirectDispatchSlotGeneration =
                pass.candidateSlotGeneration;
        }
        if (state_->implicitSpringCount != 0u) {
            id<MTLBuffer> sourceQ = (__bridge id<MTLBuffer>)pass.sourceQ;
            id<MTLBuffer> sourceV = (__bridge id<MTLBuffer>)pass.sourceV;
            const std::uint64_t qRequired =
                std::uint64_t(pass.environmentCount) * pass.sourceQStride;
            const std::uint64_t vRequired =
                std::uint64_t(pass.environmentCount) * pass.sourceVStride;
            if (state_->executionMode !=
                    NumiHumanTendonFEMLoadExecutionMode::standaloneRuntime ||
                request.encodeCoupledCandidate == nullptr ||
                request.coupledCandidateContext == nullptr ||
                sourceQ == nil || sourceV == nil ||
                sourceQ.device.registryID != state_->device.registryID ||
                sourceV.device.registryID != state_->device.registryID ||
                sourceQ.gpuAddress == 0u || sourceV.gpuAddress == 0u ||
                pass.sourceQCoordinateCount == 0u ||
                pass.sourceVStride < pass.dofCount ||
                pass.sourceQStride < pass.sourceQCoordinateCount ||
                pass.sourceQElementCount < qRequired ||
                pass.sourceVElementCount < vRequired ||
                sourceQ.length < qRequired * sizeof(float) ||
                sourceV.length < vRequired * sizeof(float) ||
                pass.candidateBodyCount == 0u ||
                pass.bodyPoseStride < pass.candidateBodyCount ||
                state_->implicitSpringSampleBuffer == nil ||
                state_->implicitSpringPointQueryBuffer == nil) {
                state_->message =
                    "standalone implicit springs lack the exact transaction q/v, candidate callback, or point inputs";
                return false;
            }
            request.rigid.q = pass.sourceQ;
            request.rigid.qStride = pass.sourceQStride;
            request.rigid.v = pass.sourceV;
            request.rigid.vStride = pass.sourceVStride;
            request.rigid.currentBodyCount = pass.candidateBodyCount;
            request.rigid.currentBodyStride = pass.bodyPoseStride;
            request.humanImplicitSpringSamples =
                (__bridge void*)state_->implicitSpringSampleBuffer;
            request.humanImplicitSpringPointQueries =
                (__bridge void*)state_->implicitSpringPointQueryBuffer;
            request.humanImplicitSpringCount = state_->implicitSpringCount;
            id<MTLBuffer> stagedGeneralizedForce =
                (__bridge id<MTLBuffer>)pass.stagedGeneralizedForce;
            const std::uint64_t stagedExpectedElements =
                std::uint64_t(pass.environmentCount) * pass.stagedGeneralizedForceStride;
            if (pass.stagedGeneralizedForce == nullptr ||
                stagedGeneralizedForce == nil ||
                stagedGeneralizedForce.device.registryID != state_->device.registryID ||
                pass.stagedGeneralizedForceGPUAddress == 0u ||
                pass.stagedGeneralizedForceStride != pass.dofCount ||
                stagedExpectedElements != pass.stagedGeneralizedForceElementCount ||
                stagedExpectedElements > std::numeric_limits<std::uint64_t>::max() /
                    sizeof(float) ||
                stagedGeneralizedForce.length <
                    stagedExpectedElements * sizeof(float)) {
                state_->message =
                    "ABI-9 implicit springs require the exact borrowed Stand reaction arena";
                return false;
            }
            request.humanImplicitSpringStagedGeneralizedForce =
                (__bridge void*)stagedGeneralizedForce;
            request.humanImplicitSpringStagedGeneralizedForceElementCount =
                pass.stagedGeneralizedForceElementCount;
            request.humanImplicitSpringStagedGeneralizedForceStride =
                pass.stagedGeneralizedForceStride;
            request.humanImplicitSpringOwnerStatusRecords =
                pass.standStatuses;
        }
        request.acceptedStepExtensionContext =
            state_->acceptedStepExtensionContext;
        request.encodeAcceptedStepExtension =
            state_->encodeAcceptedStepExtension;
        request.deferAcceptedControlCursorPublication =
            state_->deferAcceptedControlCursorPublication;
        request.deferAcceptedStepExtensionFinalization =
            state_->deferAcceptedStepExtensionFinalization;
        const auto pre = state_->runtime->encodeWithGravityScale(
            request, pass.matterGravityScale);
        ++state_->runtimePreDynamicsEncodeCount;
        if (!pre.encoded) {
            state_->message = "Human tendon/FEM Matter pre-dynamics failed: " + pre.message;
            return false;
        }
        id<MTLBuffer> reactions = (__bridge id<MTLBuffer>)
            state_->runtime->femConstraintReactionBuffer();
        id<MTLBuffer> matterStatuses =
            (__bridge id<MTLBuffer>)state_->runtime->statusBuffer();
        if (captureRequested) {
            const NSUInteger reactionBytes = state_->nodeAnchors.size() * sizeof(nm_float4);
            if (reactions == nil || matterStatuses == nil ||
                state_->nodeAnchorBuffer == nil ||
                state_->nodeAnchors.size() != state_->nodeLoads.size() ||
                state_->nodeAnchorBuffer.device.registryID != state_->device.registryID ||
                reactions.device.registryID != state_->device.registryID ||
                reactions.length < reactionBytes ||
                state_->nodeAnchorBuffer.length < state_->nodeAnchors.size() *
                    sizeof(NMNumiHumanTendonFEMNodeAnchorGPU)) {
                state_->message = "accepted FEM anchor reaction source is unavailable";
                return false;
            }
            id<MTLComputeCommandEncoder> anchorLoadEncoder =
                [command computeCommandEncoder];
            if (anchorLoadEncoder == nil) {
                state_->message = "accepted FEM anchor-load encoder unavailable";
                return false;
            }
            [anchorLoadEncoder setComputePipelineState:
                state_->femAnchorReactionLoadAddPipeline];
            [anchorLoadEncoder setBytes:&dispatch length:sizeof(dispatch) atIndex:0u];
            [anchorLoadEncoder setBuffer:state_->nodeAnchorBuffer
                                  offset:0u atIndex:1u];
            [anchorLoadEncoder setBuffer:reactions offset:0u atIndex:2u];
            [anchorLoadEncoder setBuffer:bodyPoses offset:0u atIndex:3u];
            [anchorLoadEncoder setBuffer:pointJacobians offset:0u atIndex:4u];
            [anchorLoadEncoder setBuffer:
                state_->femBodyContactGeneralizedLoadPendingBuffer
                                  offset:0u atIndex:5u];
            [anchorLoadEncoder setBuffer:matterStatuses offset:0u atIndex:6u];
            if (state_->sparseAnchorProjection) {
                [anchorLoadEncoder setBuffer:state_->activeAnchorIndices offset:0u atIndex:7u];
                [anchorLoadEncoder setBytes:&state_->activeAnchorCount length:sizeof(std::uint32_t) atIndex:8u];
            }

            const NSUInteger width = std::min<NSUInteger>(pass.dofCount,
                std::min<NSUInteger>(state_->femAnchorReactionLoadAddPipeline
                    .maxTotalThreadsPerThreadgroup, 256u));
            [anchorLoadEncoder dispatchThreads:MTLSizeMake(pass.dofCount, 1u, 1u)
                threadsPerThreadgroup:MTLSizeMake(std::max<NSUInteger>(width, 1u), 1u, 1u)];
            [anchorLoadEncoder endEncoding];
        }
        if (reactions == nil || matterStatuses == nil ||
            !encodeNodeAudit(true,reactions,matterStatuses,
                             state_->anchorReactionAuditBuffer) || !encodeKernel(
                state_->reactionPipeline,
                state_->environmentCount * pass.dofCount,
                [&](id<MTLComputeCommandEncoder> encoder) {
                    if (state_->sparseAnchorProjection) {
                        [encoder setBuffer:state_->activeAnchorIndices offset:0u atIndex:14u];
                        [encoder setBytes:&state_->activeAnchorCount length:sizeof(std::uint32_t) atIndex:15u];
                    }
                    [encoder setBuffer:state_->nodeAnchorBuffer offset:0u atIndex:1u];
                    [encoder setBuffer:state_->replacementBuffer offset:0u atIndex:2u];
                    [encoder setBuffer:bindings offset:0u atIndex:3u];
                    [encoder setBuffer:transfers offset:0u atIndex:4u];
                    [encoder setBuffer:reactions offset:0u atIndex:5u];
                    [encoder setBuffer:matterStatuses offset:0u atIndex:6u];
                    [encoder setBuffer:bodyPoses offset:0u atIndex:7u];
                    [encoder setBuffer:pointJacobians offset:0u atIndex:8u];
                    [encoder setBuffer:generalizedForces offset:0u atIndex:9u];
                    if (state_->articularBodyWrenchBuffer != nil) {
                        [encoder setBuffer:state_->articularBodyWrenchBuffer offset:0u atIndex:10u];
                    } else {
                        const NMNumiHumanBodyWrenchGPU empty{};
                        [encoder setBytes:&empty length:sizeof(empty) atIndex:10u];
                    }
                    if (state_->passiveLigamentBuffer != nil) {
                        [encoder setBuffer:state_->passiveLigamentBuffer offset:0u atIndex:11u];
                    } else {
                        const NMNumiHumanPassiveLigamentGPU empty{};
                        [encoder setBytes:&empty length:sizeof(empty) atIndex:11u];
                    }
                    if (state_->femBodyContactWrenchBuffer != nil) {
                        [encoder setBuffer:state_->femBodyContactWrenchBuffer offset:0u atIndex:12u];
                    } else {
                        const NMNumiHumanBodyWrenchGPU empty{};
                        [encoder setBytes:&empty length:sizeof(empty) atIndex:12u];
                    }
                    if (state_->passiveRoutedBandBuffer != nil) {
                        [encoder setBuffer:state_->passiveRoutedBandBuffer offset:0u atIndex:13u];
                    } else {
                        const NMNumiHumanPassiveRoutedBandGPU empty{};
                        [encoder setBytes:&empty length:sizeof(empty) atIndex:13u];
                    }
                }
            )) {
            state_->message = "Human tendon/FEM anchor-reaction encoding failed";
            return false;
        }
        state_->articularAttemptedStepCount = std::max(
            state_->articularAttemptedStepCount, pass.stepIndex + 1u);
        state_->acceptedWrenchSourceCommandBuffer = pass.commandBuffer;
        state_->acceptedWrenchSourceBodyPoses = pass.bodyPoses;
        state_->acceptedWrenchSourcePointJacobians = pass.pointJacobians;
        state_->acceptedWrenchSourceQ = pass.sourceQ;
        state_->acceptedWrenchSourceQCoordinateCount =
            pass.sourceQCoordinateCount;
        state_->acceptedWrenchSourceStepIndex = pass.stepIndex;
        state_->acceptedWrenchSourceDofCount = pass.dofCount;
        state_->acceptedWrenchSourceBodyPoseStride = pass.bodyPoseStride;
        state_->acceptedWrenchSourcePointJacobianStride =
            pass.pointJacobianStride;
        state_->acceptedWrenchSourceBodyJacobianPointOffset =
            pass.bodyJacobianPointOffset;
        state_->acceptedWrenchSourceArticulationFirstBody =
            pass.articulationFirstBody;
        state_->acceptedWrenchSourceValid = true;
        state_->message = "pre-dynamics encoded";
        return true;
    }
}

bool NumiHumanTendonFEMLoadAdapter::encodePostValidation(
    const metalrobo::MetalNumiHumanTendonLoadPass& pass
) {
    @autoreleasepool {
        if (state_ == nullptr || state_->runtime == nullptr ||
            state_->device == nil ||
            (state_->executionMode ==
                 NumiHumanTendonFEMLoadExecutionMode::standaloneRuntime &&
             state_->statusPipeline == nil) ||
            pass.commandBuffer == nullptr || pass.standStatuses == nullptr ||
            pass.environmentCount != state_->environmentCount ||
            pass.endpointCount != state_->endpointCount ||
            pass.dofCount == 0u || pass.muscleCount == 0u ||
            pass.stepIndex >=
                NM_NUMI_HUMAN_ARTICULAR_CONTACT_AUDIT_MAX_STEPS) {
            if (state_ != nullptr)
                state_->message = "invalid borrowed Human post-validation pass";
            return false;
        }
        if (state_->deferAcceptedAuditPublication &&
            state_->acceptedAuditPendingCommandBufferIdentity != 0u) {
            state_->message =
                "a prior accepted-audit publication is still pending";
            return false;
        }
        const bool deferred = state_->executionMode ==
            NumiHumanTendonFEMLoadExecutionMode::numanXDeferred;
        if (deferred &&
            (!state_->deferredExternalForcesAvailable ||
             state_->deferredCommandBufferIdentity !=
                reinterpret_cast<std::uintptr_t>(pass.commandBuffer) ||
             state_->deferredStepIndex != pass.stepIndex)) {
            state_->message =
                "deferred tendon/FEM post-validation lost its exact pre-source pass";
            return false;
        }
        id<MTLCommandBuffer> command =
            (__bridge id<MTLCommandBuffer>)pass.commandBuffer;
        id<MTLBuffer> standStatuses =
            (__bridge id<MTLBuffer>)pass.standStatuses;
        id<MTLBuffer> matterStatuses = deferred ? nil :
            (__bridge id<MTLBuffer>)state_->runtime->statusBuffer();
        if (command == nil || standStatuses == nil ||
            standStatuses.device.registryID != state_->device.registryID ||
            (!deferred &&
             (matterStatuses == nil ||
              matterStatuses.device.registryID != state_->device.registryID))) {
            state_->message =
                "borrowed Human or Matter status is unavailable";
            return false;
        }
        const NMNumiHumanTendonFEMLoadDispatchGPU dispatch{
            .abiVersion = NM_NUMI_HUMAN_TENDON_FEM_LOAD_ABI_VERSION,
            .environmentCount = state_->environmentCount,
            .femNodeCount = static_cast<std::uint32_t>(state_->nodeLoads.size()),
            .endpointCount = state_->endpointCount,
            .transferStride = pass.endpointCount,
            .stepIndex = pass.stepIndex,
            .replacementCount = static_cast<std::uint32_t>(
                state_->replacements.size()),
            .dofCount = pass.dofCount,
            .bodyPoseStride = pass.bodyPoseStride,
            .articulationFirstBody = pass.articulationFirstBody,
            .pointJacobianStride = pass.pointJacobianStride,
            .bodyJacobianPointOffset = pass.bodyJacobianPointOffset,
            .generalizedForceStride = pass.generalizedForceStride,
            .generalizedForceOffset = pass.generalizedForceOffset,
            .muscleCount = pass.muscleCount,
            .femContactSampleCount = static_cast<std::uint32_t>(
                state_->contactSamples.size()),
            .articularContactSampleCount = static_cast<std::uint32_t>(
                state_->articularContactSamples.size()),
            .passiveLigamentCount = static_cast<std::uint32_t>(
                state_->passiveLigaments.size()),
            .femBodyContactSampleCount = static_cast<std::uint32_t>(
                state_->femBodyContactSamples.size()),
            .passiveRoutedBandCount = static_cast<std::uint32_t>(
                state_->passiveRoutedBands.size()),
            .articularContactPairCount =
                state_->articularContactPairCount,
            .femSurfaceAttachmentSampleCount = static_cast<std::uint32_t>(
                state_->femSurfaceAttachments.size()),
            .femBodyContactCandidateTriangleCount = static_cast<std::uint32_t>(
                state_->femBodyContactNeighborhoodTriangles.size()),
        };
        const NSUInteger count = state_->environmentCount;
        if (!deferred) {
            id<MTLComputeCommandEncoder> encoder =
                [command computeCommandEncoder];
            if (encoder == nil) {
                state_->message =
                    "Human tendon/FEM status encoder is unavailable";
                return false;
            }
            [encoder setComputePipelineState:state_->statusPipeline];
            auto statusDispatch = dispatch;
            if (state_->deferAcceptedAuditPublication)
                statusDispatch.reserved0 = state_->expectedMicrotickCount;
            [encoder setBytes:&statusDispatch length:sizeof(statusDispatch) atIndex:0u];
            [encoder setBuffer:standStatuses offset:0u atIndex:1u];
            [encoder setBuffer:state_->worldStatusBuffer offset:0u atIndex:2u];
            [encoder setBuffer:matterStatuses offset:0u atIndex:3u];
            const NSUInteger width = std::min<NSUInteger>(
                count, std::min<NSUInteger>(
                    state_->statusPipeline.maxTotalThreadsPerThreadgroup,
                    256u));
            [encoder dispatchThreads:MTLSizeMake(count, 1u, 1u)
                threadsPerThreadgroup:MTLSizeMake(
                    std::max<NSUInteger>(width, 1u), 1u, 1u)];
            [encoder endEncoding];

            EncodeRequest request{};
            request.commandBuffer = pass.commandBuffer;
            request.environmentStatuses =
                (__bridge void*)state_->worldStatusBuffer;
            request.femExternalForces =
                (__bridge void*)state_->externalForceBuffer;
            request.femExternalForceCount = static_cast<std::uint32_t>(
                state_->environmentCount * state_->nodeLoads.size());
            request.femKinematicTargets =
                (__bridge void*)state_->kinematicTargetBuffer;
            request.femKinematicTargetCount = request.femExternalForceCount;
            request.controlStep = pass.stepIndex;
            request.physicsSubstep = 0u;
            request.physicsSubsteps = 1u;
            request.timestepSeconds = state_->runtime->timestepSeconds();
            request.phase = EncodePhase::postCommit;
            request.vascularPressureLoadScale = 1.0f;
            request.acceptedStepExtensionContext =
                state_->acceptedStepExtensionContext;
            request.encodeAcceptedStepExtension =
                state_->encodeAcceptedStepExtension;
            request.deferAcceptedControlCursorPublication =
                state_->deferAcceptedControlCursorPublication;
            request.deferAcceptedStepExtensionFinalization =
                state_->deferAcceptedStepExtensionFinalization;
            const auto post = state_->runtime->encodeWithGravityScale(
                request, pass.matterGravityScale);
            ++state_->runtimePostCommitEncodeCount;
            if (!post.encoded) {
                state_->message =
                    "Human tendon/FEM Matter post-commit failed: " +
                    post.message;
                return false;
            }
        }
        if (state_->deferAcceptedAuditPublication) {
            state_->acceptedAuditPendingCommandBufferIdentity =
                reinterpret_cast<std::uintptr_t>(pass.commandBuffer);
            state_->acceptedAuditPendingStandStatuses = pass.standStatuses;
            state_->acceptedAuditPendingStepIndex = pass.stepIndex;
            state_->message =
                "Runtime post-commit encoded; audit publication awaits final owner gate";
            return true;
        }
        return encodeAcceptedAuditCommit(pass);
    }
}

bool NumiHumanTendonFEMLoadAdapter::finalizeAcceptedAudits(
    const metalrobo::MetalNumiHumanTendonLoadPass& pass
) {
    if (state_ == nullptr ||
        !state_->deferAcceptedAuditPublication ||
        state_->acceptedAuditPendingCommandBufferIdentity == 0u ||
        pass.commandBuffer == nullptr ||
        state_->acceptedAuditPendingCommandBufferIdentity !=
            reinterpret_cast<std::uintptr_t>(pass.commandBuffer) ||
        state_->acceptedAuditPendingStepIndex != pass.stepIndex ||
        state_->acceptedAuditPendingStandStatuses != pass.standStatuses) {
        if (state_ != nullptr)
            state_->message =
                "final accepted-audit gate lost its exact command/step/status lease";
        return false;
    }
    if (!encodeAcceptedAuditCommit(pass)) return false;
    AcceptedStepFinalizationGate solverGate;
    solverGate.statusRecords = pass.standStatuses;
    solverGate.recordCount = pass.environmentCount;
    solverGate.recordStrideBytes = sizeof(MRNumiHumanStandStatusGPU);
    solverGate.acceptedStatusCode = MR_NUMI_HUMAN_STAND_SUCCESS;
    solverGate.completedCountOffsetBytes =
        offsetof(MRNumiHumanStandStatusGPU, completedSteps);
    solverGate.expectedCompletedCount = pass.stepIndex + 1u;
    solverGate.environmentIndexOffsetBytes =
        offsetof(MRNumiHumanStandStatusGPU, environment);
    solverGate.expectedEnvironmentBase = 0u;
    const auto recycle = state_->runtime->encodeAcceptedFEMSolverZ0Promotion(
        pass.commandBuffer, pass.stepIndex, 0u, solverGate);
    if (!recycle.encoded) {
        state_->message = "accepted FEM solver recycle publication failed: " +
            recycle.message;
        return false;
    }
    state_->acceptedAuditPendingCommandBufferIdentity = 0u;
    state_->acceptedAuditPendingStandStatuses = nullptr;
    state_->acceptedAuditPendingStepIndex = 0u;
    return true;
}

bool NumiHumanTendonFEMLoadAdapter::encodeAcceptedAuditCommit(
    const metalrobo::MetalNumiHumanTendonLoadPass& pass
) {

    @autoreleasepool {    if (state_ == nullptr || state_->runtime == nullptr ||
        state_->device == nil || pass.commandBuffer == nullptr ||
        pass.standStatuses == nullptr ||
        pass.environmentCount != state_->environmentCount ||
        pass.endpointCount != state_->endpointCount ||
        pass.dofCount == 0u || pass.muscleCount == 0u ||
        pass.stepIndex >= NM_NUMI_HUMAN_ARTICULAR_CONTACT_AUDIT_MAX_STEPS) {
        if (state_ != nullptr)
            state_->message = "invalid accepted-audit commit pass";
        return false;
    }
    const bool deferred = state_->executionMode ==
        NumiHumanTendonFEMLoadExecutionMode::numanXDeferred;
    id<MTLCommandBuffer> command =
        (__bridge id<MTLCommandBuffer>)pass.commandBuffer;
    id<MTLBuffer> standStatuses =
        (__bridge id<MTLBuffer>)pass.standStatuses;
    if (command == nil || standStatuses == nil ||
        standStatuses.device.registryID != state_->device.registryID) {
        state_->message = "accepted-audit commit buffers are unavailable";
        return false;
    }
    const NMNumiHumanTendonFEMLoadDispatchGPU dispatch{
        .abiVersion = NM_NUMI_HUMAN_TENDON_FEM_LOAD_ABI_VERSION,
        .environmentCount = state_->environmentCount,
        .femNodeCount = static_cast<std::uint32_t>(state_->nodeLoads.size()),
        .endpointCount = state_->endpointCount,
        .transferStride = pass.endpointCount,
        .stepIndex = pass.stepIndex,
        .replacementCount = static_cast<std::uint32_t>(
            state_->replacements.size()),
        .dofCount = pass.dofCount,
        .bodyPoseStride = pass.bodyPoseStride,
        .articulationFirstBody = pass.articulationFirstBody,
        .pointJacobianStride = pass.pointJacobianStride,
        .bodyJacobianPointOffset = pass.bodyJacobianPointOffset,
        .generalizedForceStride = pass.generalizedForceStride,
        .generalizedForceOffset = pass.generalizedForceOffset,
        .muscleCount = pass.muscleCount,
        .femContactSampleCount = static_cast<std::uint32_t>(
            state_->contactSamples.size()),
        .articularContactSampleCount = static_cast<std::uint32_t>(
            state_->articularContactSamples.size()),
        .passiveLigamentCount = static_cast<std::uint32_t>(
            state_->passiveLigaments.size()),
        .femBodyContactSampleCount = static_cast<std::uint32_t>(
            state_->femBodyContactSamples.size()),
        .passiveRoutedBandCount = static_cast<std::uint32_t>(
            state_->passiveRoutedBands.size()),
        .articularContactPairCount = state_->articularContactPairCount,
        .femSurfaceAttachmentSampleCount = static_cast<std::uint32_t>(
            state_->femSurfaceAttachments.size()),
        .femBodyContactCandidateTriangleCount = static_cast<std::uint32_t>(
            state_->femBodyContactNeighborhoodTriangles.size()),
    };
    const NSUInteger count = state_->environmentCount;
    id<MTLComputeCommandEncoder> commitEncoder =
        [command computeCommandEncoder];
    if (commitEncoder == nil) {
        state_->message =
            "Human FEM audit commit encoder is unavailable";
        return false;
    }
    id<MTLBuffer> acceptedGeneralizedLoadCapture =
        (__bridge id<MTLBuffer>)pass.acceptedFEMBodyGeneralizedLoadCapture;
    const bool captureAcceptedGeneralizedLoad =
        acceptedGeneralizedLoadCapture != nil;
    const bool captureAcceptedSourcePair =
        acceptedGeneralizedLoadCapture != nil ||
        pass.acceptedFEMBodySourceQCapture != nullptr;
    if (captureAcceptedSourcePair) {
        id<MTLBuffer> acceptedSourceQCapture =
            (__bridge id<MTLBuffer>)pass.acceptedFEMBodySourceQCapture;
        const std::uint64_t requiredQElements =
            static_cast<std::uint64_t>(state_->environmentCount) *
            pass.sourceQCoordinateCount;
        const std::uint64_t requiredQBytes = requiredQElements * sizeof(float);
        if (!captureAcceptedGeneralizedLoad ||
            acceptedSourceQCapture == nil ||
            !state_->acceptedWrenchSourceValid ||
            pass.commandBuffer != state_->acceptedWrenchSourceCommandBuffer ||
            pass.bodyPoses != state_->acceptedWrenchSourceBodyPoses ||
            pass.pointJacobians != state_->acceptedWrenchSourcePointJacobians ||
            pass.sourceQ != state_->acceptedWrenchSourceQ ||
            pass.sourceQCoordinateCount !=
                state_->acceptedWrenchSourceQCoordinateCount ||
            pass.stepIndex != state_->acceptedWrenchSourceStepIndex ||
            pass.dofCount != state_->acceptedWrenchSourceDofCount ||
            pass.bodyPoseStride != state_->acceptedWrenchSourceBodyPoseStride ||
            pass.pointJacobianStride !=
                state_->acceptedWrenchSourcePointJacobianStride ||
            pass.bodyJacobianPointOffset !=
                state_->acceptedWrenchSourceBodyJacobianPointOffset ||
            pass.articulationFirstBody !=
                state_->acceptedWrenchSourceArticulationFirstBody ||
            state_->femBodyContactGeneralizedLoadPendingBuffer == nil ||
            state_->femBodySourceQPendingBuffer == nil ||
            pass.acceptedFEMBodyGeneralizedLoadGPUAddress == 0u ||
            pass.acceptedFEMBodyGeneralizedLoadGPUAddress !=
                acceptedGeneralizedLoadCapture.gpuAddress ||
            pass.acceptedFEMBodyGeneralizedLoadElementCount <
                static_cast<std::uint64_t>(state_->environmentCount) *
                    pass.dofCount ||
            acceptedGeneralizedLoadCapture.device.registryID !=
                state_->device.registryID ||
            acceptedGeneralizedLoadCapture.storageMode != MTLStorageModeShared ||
            acceptedGeneralizedLoadCapture.contents == nullptr ||
            acceptedGeneralizedLoadCapture.length <
                static_cast<NSUInteger>(state_->environmentCount) *
                    pass.dofCount * sizeof(float) ||
            pass.acceptedFEMBodySourceQGPUAddress == 0u ||
            pass.acceptedFEMBodySourceQGPUAddress != acceptedSourceQCapture.gpuAddress ||
            pass.acceptedFEMBodySourceQElementCount < requiredQElements ||
            acceptedSourceQCapture.device.registryID != state_->device.registryID ||
            acceptedSourceQCapture.storageMode != MTLStorageModeShared ||
            acceptedSourceQCapture.contents == nullptr ||
            acceptedSourceQCapture.length < requiredQBytes) {
            state_->message =
                "accepted FEM source snapshot does not match the pre-dynamics transaction";
            return false;
        }
        if (state_->femBodyContactGeneralizedLoadCommitPipeline == nil) {
            const std::string qualified =
                "numi_matter_metal::nm_numi_human_commit_fem_body_generalized_load";
            id<MTLFunction> function = [state_->library newFunctionWithName:
                [NSString stringWithUTF8String:qualified.c_str()]];
            NSError* pipelineError = nil;
            if (function != nil)
                state_->femBodyContactGeneralizedLoadCommitPipeline =
                    [state_->device newComputePipelineStateWithFunction:function
                                                                   error:&pipelineError];
            if (state_->femBodyContactGeneralizedLoadCommitPipeline == nil) {
                const char* description = pipelineError == nil ? "kernel unavailable"
                    : pipelineError.localizedDescription.UTF8String;
                state_->message = std::string("accepted FEM snapshot commit PSO failed: ") +
                    (description == nullptr ? "unknown Metal error" : description);
                [commitEncoder endEncoding];
                return false;
            }
        }
        NMNumiHumanTendonFEMLoadDispatchGPU commitDispatch = dispatch;
        commitDispatch.reserved0 = pass.sourceQCoordinateCount;
        [commitEncoder setComputePipelineState:
            state_->femBodyContactGeneralizedLoadCommitPipeline];
        [commitEncoder setBytes:&commitDispatch
                         length:sizeof(commitDispatch) atIndex:0u];
        [commitEncoder setBuffer:standStatuses offset:0u atIndex:1u];
        [commitEncoder setBuffer:state_->femBodyContactGeneralizedLoadPendingBuffer
                          offset:0u atIndex:2u];
        [commitEncoder setBuffer:state_->femBodySourceQPendingBuffer
                          offset:0u atIndex:3u];
        [commitEncoder setBuffer:acceptedGeneralizedLoadCapture
                          offset:0u atIndex:4u];
        [commitEncoder setBuffer:acceptedSourceQCapture offset:0u atIndex:5u];
        const NSUInteger captureCount = std::max<NSUInteger>(
            pass.dofCount, pass.sourceQCoordinateCount);
        const NSUInteger captureWidth = std::min<NSUInteger>(
            captureCount, std::min<NSUInteger>(
                state_->femBodyContactGeneralizedLoadCommitPipeline
                    .maxTotalThreadsPerThreadgroup, 256u));
        [commitEncoder dispatchThreads:MTLSizeMake(captureCount, 1u, 1u)
            threadsPerThreadgroup:MTLSizeMake(
                std::max<NSUInteger>(captureWidth, 1u), 1u, 1u)];
    } else if (pass.acceptedFEMBodyGeneralizedLoadGPUAddress != 0u ||
               pass.acceptedFEMBodyGeneralizedLoadElementCount != 0u ||
               pass.acceptedFEMBodySourceQGPUAddress != 0u ||
               pass.acceptedFEMBodySourceQElementCount != 0u) {
        state_->message = "unbound accepted FEM source snapshot metadata";
        return false;
    }
    if (!deferred) {
        [commitEncoder setComputePipelineState:
            state_->reactionAuditCommitPipeline];
        [commitEncoder setBytes:&dispatch length:sizeof(dispatch) atIndex:0u];
        [commitEncoder setBuffer:standStatuses offset:0u atIndex:1u];
        [commitEncoder setBuffer:state_->anchorReactionAuditBuffer
                          offset:0u atIndex:2u];
        [commitEncoder setBuffer:state_->anchorReactionAuditHistoryBuffer
                          offset:0u atIndex:3u];
        const NSUInteger reactionCommitWidth = std::min<NSUInteger>(
            count, std::min<NSUInteger>(
                state_->reactionAuditCommitPipeline
                    .maxTotalThreadsPerThreadgroup,
                256u));
        [commitEncoder dispatchThreads:MTLSizeMake(count, 1u, 1u)
            threadsPerThreadgroup:MTLSizeMake(
                std::max<NSUInteger>(reactionCommitWidth, 1u), 1u, 1u)];
    }
    if (!state_->articularContactSamples.empty()) {
        [commitEncoder setComputePipelineState:
            state_->articularContactAuditCommitPipeline];
        [commitEncoder setBytes:&dispatch length:sizeof(dispatch) atIndex:0u];
        [commitEncoder setBuffer:standStatuses offset:0u atIndex:1u];
        [commitEncoder setBuffer:state_->articularContactAuditBuffer
                          offset:0u atIndex:2u];
        [commitEncoder setBuffer:state_->articularContactAuditHistoryBuffer
                          offset:0u atIndex:3u];
        const NSUInteger commitWidth = std::min<NSUInteger>(
            count, std::min<NSUInteger>(
                state_->articularContactAuditCommitPipeline
                    .maxTotalThreadsPerThreadgroup,
                256u));
        [commitEncoder dispatchThreads:MTLSizeMake(count, 1u, 1u)
            threadsPerThreadgroup:MTLSizeMake(
                std::max<NSUInteger>(commitWidth, 1u), 1u, 1u)];
    }
    if (state_->articularContactPairCount != 0u) {
        [commitEncoder setComputePipelineState:
            state_->articularContactPairAuditCommitPipeline];
        [commitEncoder setBytes:&dispatch length:sizeof(dispatch) atIndex:0u];
        [commitEncoder setBuffer:standStatuses offset:0u atIndex:1u];
        [commitEncoder setBuffer:state_->articularContactPairAuditBuffer
                          offset:0u atIndex:2u];
        [commitEncoder setBuffer:
            state_->articularContactPairAuditHistoryBuffer
                          offset:0u atIndex:3u];
        const NSUInteger pairCommitWidth = std::min<NSUInteger>(
            count, std::min<NSUInteger>(
                state_->articularContactPairAuditCommitPipeline
                    .maxTotalThreadsPerThreadgroup,
                256u));
        [commitEncoder dispatchThreads:MTLSizeMake(count, 1u, 1u)
            threadsPerThreadgroup:MTLSizeMake(
                std::max<NSUInteger>(pairCommitWidth, 1u), 1u, 1u)];
    }
    if (state_->hasFEMBodyInteraction()) {
        [commitEncoder setComputePipelineState:
            state_->articularContactAuditCommitPipeline];
        [commitEncoder setBytes:&dispatch length:sizeof(dispatch) atIndex:0u];
        [commitEncoder setBuffer:standStatuses offset:0u atIndex:1u];
        [commitEncoder setBuffer:state_->femBodyContactAuditBuffer
                          offset:0u atIndex:2u];
        [commitEncoder setBuffer:state_->femBodyContactAuditHistoryBuffer
                          offset:0u atIndex:3u];
        const NSUInteger contactCommitWidth = std::min<NSUInteger>(
            count, std::min<NSUInteger>(
                state_->articularContactAuditCommitPipeline
                    .maxTotalThreadsPerThreadgroup,
                256u));
        [commitEncoder dispatchThreads:MTLSizeMake(count, 1u, 1u)
            threadsPerThreadgroup:MTLSizeMake(
                std::max<NSUInteger>(contactCommitWidth, 1u), 1u, 1u)];
    }
    if (!state_->passiveLigaments.empty()) {
        [commitEncoder setComputePipelineState:
            state_->deferAcceptedAuditPublication
                ? state_->passiveLigamentDeferredAuditCommitPipeline
                : state_->passiveLigamentAuditCommitPipeline];
        [commitEncoder setBytes:&dispatch length:sizeof(dispatch) atIndex:0u];
        [commitEncoder setBuffer:standStatuses offset:0u atIndex:1u];
        [commitEncoder setBuffer:state_->passiveLigamentAuditBuffer
                      offset:0u atIndex:2u];
        if (state_->deferAcceptedAuditPublication) {
            [commitEncoder setBuffer:state_->passiveLigamentAcceptedAuditBuffer
                          offset:0u atIndex:3u];
        }
        id<MTLComputePipelineState> passiveCommitPipeline =
            state_->deferAcceptedAuditPublication
                ? state_->passiveLigamentDeferredAuditCommitPipeline
                : state_->passiveLigamentAuditCommitPipeline;
        const NSUInteger passiveWidth = std::min<NSUInteger>(
            count, std::min<NSUInteger>(
                passiveCommitPipeline.maxTotalThreadsPerThreadgroup,
                256u));
        [commitEncoder dispatchThreads:MTLSizeMake(count, 1u, 1u)
            threadsPerThreadgroup:MTLSizeMake(
                std::max<NSUInteger>(passiveWidth, 1u), 1u, 1u)];
    }
    if (!state_->passiveRoutedBands.empty()) {
        [commitEncoder setComputePipelineState:
            state_->deferAcceptedAuditPublication
                ? state_->passiveRoutedBandDeferredAuditCommitPipeline
                : state_->passiveRoutedBandAuditCommitPipeline];
        [commitEncoder setBytes:&dispatch length:sizeof(dispatch) atIndex:0u];
        [commitEncoder setBuffer:standStatuses offset:0u atIndex:1u];
        [commitEncoder setBuffer:state_->passiveRoutedBandAuditBuffer
                      offset:0u atIndex:2u];
        if (state_->deferAcceptedAuditPublication) {
            [commitEncoder setBuffer:state_->passiveRoutedBandAcceptedAuditBuffer
                          offset:0u atIndex:3u];
        }
        id<MTLComputePipelineState> routedCommitPipeline =
            state_->deferAcceptedAuditPublication
                ? state_->passiveRoutedBandDeferredAuditCommitPipeline
                : state_->passiveRoutedBandAuditCommitPipeline;
        const NSUInteger routedWidth = std::min<NSUInteger>(
            count, std::min<NSUInteger>(
                routedCommitPipeline.maxTotalThreadsPerThreadgroup,
                256u));
        [commitEncoder dispatchThreads:MTLSizeMake(count, 1u, 1u)
            threadsPerThreadgroup:MTLSizeMake(
                std::max<NSUInteger>(routedWidth, 1u), 1u, 1u)];
    }
    [commitEncoder endEncoding];
    ++state_->encodedPassCount;
    if (deferred) {
        state_->deferredExternalForcesAvailable = false;
        state_->deferredCommandBufferIdentity = 0u;
        state_->message = "deferred audit reconciliation encoded";
    } else {
        state_->message = "two-way transaction encoded";
    }
    return true;
    }
}

void NumiHumanTendonFEMLoadAdapter::abort(void* commandBuffer) noexcept {
    if (state_ != nullptr && state_->runtime != nullptr &&
        commandBuffer != nullptr) {
        ++state_->abortCount;
        if (state_->acceptedAuditPendingCommandBufferIdentity ==
                reinterpret_cast<std::uintptr_t>(commandBuffer)) {
            state_->acceptedAuditPendingCommandBufferIdentity = 0u;
            state_->acceptedAuditPendingStandStatuses = nullptr;
            state_->acceptedAuditPendingStepIndex = 0u;
        }
        if (state_->executionMode ==
                NumiHumanTendonFEMLoadExecutionMode::numanXDeferred) {
            if (state_->deferredCommandBufferIdentity ==
                    reinterpret_cast<std::uintptr_t>(commandBuffer)) {
                state_->deferredExternalForcesAvailable = false;
                state_->deferredCommandBufferIdentity = 0u;
            }
        } else {
            state_->runtime->cancel(commandBuffer);
        }
    }
}

bool NumiHumanTendonFEMLoadAdapter::borrowDeferredExternalForces(
    void* commandBuffer,
    const std::uint32_t stepIndex,
    const std::uint32_t environmentCount,
    NumiHumanTendonFEMDeferredExternalForceView& output
) noexcept {
    @autoreleasepool {
        if (state_ == nullptr || state_->runtime == nullptr ||
            state_->executionMode !=
                NumiHumanTendonFEMLoadExecutionMode::numanXDeferred ||
            !state_->deferredExternalForcesAvailable ||
            commandBuffer == nullptr ||
            state_->deferredCommandBufferIdentity !=
                reinterpret_cast<std::uintptr_t>(commandBuffer) ||
            stepIndex != state_->deferredStepIndex ||
            environmentCount != state_->environmentCount ||
            state_->fingerprint == 0u ||
            state_->runtimeDeviceProgramFingerprint == 0u ||
            state_->runtime->deviceProgramFingerprint() !=
                state_->runtimeDeviceProgramFingerprint ||
            state_->runtime->environmentCount() != state_->environmentCount ||
            state_->runtime->femNodeCount() != state_->nodeLoads.size() ||
            state_->runtime->femHumanAttachmentCount() !=
                state_->activeAnchorCount) {
            return false;
        }
        __unsafe_unretained id<MTLCommandBuffer> command =
            (__bridge id<MTLCommandBuffer>)commandBuffer;
        __unsafe_unretained id<MTLBuffer> forces =
            state_->externalForceBuffer;
        __unsafe_unretained id<MTLBuffer> statuses =
            state_->worldStatusBuffer;
        const std::uint64_t forceElements =
            static_cast<std::uint64_t>(state_->environmentCount) *
            state_->nodeLoads.size();
        const std::uint64_t forceBytes =
            forceElements * sizeof(nm_float4);
        const std::uint64_t statusBytes =
            static_cast<std::uint64_t>(state_->environmentCount) *
            sizeof(MRMetalWorldStatusGPU);
        if (command == nil || command.commandQueue == nil ||
            command.status != MTLCommandBufferStatusNotEnqueued ||
            forces == nil || statuses == nil || state_->device == nil ||
            command.commandQueue.device.registryID !=
                state_->device.registryID ||
            forces.device.registryID != state_->device.registryID ||
            statuses.device.registryID != state_->device.registryID ||
            forces.gpuAddress == 0u || statuses.gpuAddress == 0u ||
            forces.length < forceBytes || statuses.length < statusBytes ||
            state_->nodeLoads.size() >
                std::numeric_limits<std::uint32_t>::max() ||
            (state_->implicitSpringCount != 0u &&
             (state_->implicitSpringSampleBuffer == nil ||
              state_->implicitSpringPointQueryBuffer == nil ||
              state_->implicitSpringSampleBuffer.device.registryID !=
                  state_->device.registryID ||
              state_->implicitSpringPointQueryBuffer.device.registryID !=
                  state_->device.registryID ||
              state_->implicitSpringSampleBuffer.gpuAddress == 0u ||
              state_->implicitSpringPointQueryBuffer.gpuAddress == 0u ||
              state_->implicitSpringSampleBuffer.length <
                  state_->implicitSpringSamples.size() *
                      sizeof(NMNumiHumanFEMBodyContactSampleGPU) ||
              state_->implicitSpringPointQueryBuffer.length <
                  state_->implicitSpringPointQueries.size() *
                      sizeof(MRArticulatedPointImpulseGPU)))) {
            return false;
        }
        NumiHumanTendonFEMDeferredExternalForceView result;
        result.externalForces = (__bridge void*)forces;
        result.validationStatuses = (__bridge void*)statuses;
        result.externalForcesGPUAddress = forces.gpuAddress;
        result.validationStatusesGPUAddress = statuses.gpuAddress;
        result.externalForceElementCount = forceElements;
        result.validationStatusElementCount = state_->environmentCount;
        result.deviceRegistryID = state_->device.registryID;
        result.programFingerprint = state_->fingerprint;
        result.environmentCount = state_->environmentCount;
        result.femNodeCount = static_cast<std::uint32_t>(
            state_->nodeLoads.size());
        result.externalForceStride = result.femNodeCount;
        result.validationStatusStride = 1u;
        result.stepIndex = stepIndex;
        if (state_->implicitSpringCount != 0u) {
            result.implicitSpringSamples =
                (__bridge void*)state_->implicitSpringSampleBuffer;
            result.implicitSpringPointQueries =
                (__bridge void*)state_->implicitSpringPointQueryBuffer;
            result.implicitSpringSamplesGPUAddress =
                state_->implicitSpringSampleBuffer.gpuAddress;
            result.implicitSpringPointQueriesGPUAddress =
                state_->implicitSpringPointQueryBuffer.gpuAddress;
            result.implicitSpringSampleElementCount =
                state_->implicitSpringCount;
            result.implicitSpringPointQueryElementCount =
                state_->implicitSpringCount;
            result.implicitSpringCount = state_->implicitSpringCount;
        }
        output = result;
        ++state_->deferredExternalForceBorrowCount;
        return true;
    }
}

NumiHumanTendonFEMDeferredLoadProgram
NumiHumanTendonFEMLoadAdapter::deferredProgram() noexcept {
    NumiHumanTendonFEMDeferredLoadProgram result{};
    if (state_ == nullptr || state_->executionMode !=
            NumiHumanTendonFEMLoadExecutionMode::numanXDeferred ||
        state_->fingerprint == 0u ||
        state_->runtimeDeviceProgramFingerprint == 0u) {
        return result;
    }
    result.context = this;
    result.encodePreSourceCorrections = [](
        void* context,
        const metalrobo::MetalNumiHumanTendonLoadPass& pass
    ) {
        return context != nullptr &&
            static_cast<NumiHumanTendonFEMLoadAdapter*>(context)->
                encodePreDynamics(pass);
    };
    result.borrowExternalForces = [](
        void* context,
        void* commandBuffer,
        const std::uint32_t stepIndex,
        const std::uint32_t environmentCount,
        NumiHumanTendonFEMDeferredExternalForceView& output
    ) noexcept {
        return context != nullptr &&
            static_cast<NumiHumanTendonFEMLoadAdapter*>(context)->
                borrowDeferredExternalForces(
                    commandBuffer, stepIndex, environmentCount, output);
    };
    result.fingerprint = state_->fingerprint;
    result.runtimeDeviceProgramFingerprint =
        state_->runtimeDeviceProgramFingerprint;
    result.environmentCount = state_->environmentCount;
    result.femNodeCount = static_cast<std::uint32_t>(
        state_->nodeLoads.size());
    result.activeAnchorCount = state_->activeAnchorCount;
    result.implicitSpringCount = state_->implicitSpringCount;
    return result;
}

metalrobo::MetalNumiHumanTendonLoadProgram
NumiHumanTendonFEMLoadAdapter::program() noexcept {
    metalrobo::MetalNumiHumanTendonLoadProgram result{};
    if (state_ == nullptr || state_->fingerprint == 0u) return result;
    result.context = this;
    if (state_->executionMode ==
            NumiHumanTendonFEMLoadExecutionMode::numanXDeferred) {
        const auto deferred = deferredProgram();
        if (!deferred.valid()) return {};
        result.encodePreDynamics = deferred.encodePreSourceCorrections;
    } else {
        result.encodePreDynamics = [](
            void* context,
            const metalrobo::MetalNumiHumanTendonLoadPass& pass
        ) {
            return context != nullptr &&
                static_cast<NumiHumanTendonFEMLoadAdapter*>(context)->
                    encodePreDynamics(pass);
        };
    }
    result.encodePostValidation = [](
        void* context,
        const metalrobo::MetalNumiHumanTendonLoadPass& pass
    ) {
        return context != nullptr &&
            static_cast<NumiHumanTendonFEMLoadAdapter*>(context)->
                encodePostValidation(pass);
    };
    result.abort = [](void* context, void* commandBuffer) {
        if (context != nullptr) {
            static_cast<NumiHumanTendonFEMLoadAdapter*>(context)->abort(
                commandBuffer
            );
        }
    };
    result.fingerprint = state_->fingerprint;
    return result;
}

NumiHumanTendonFEMLoadAdapterSnapshotV1
NumiHumanTendonFEMLoadAdapter::snapshot() const noexcept {
    NumiHumanTendonFEMLoadAdapterSnapshotV1 result;
    try {
        if (state_ == nullptr || state_->runtime == nullptr ||
            state_->fingerprint == 0u || !state_->runtime->valid()) {
            result.message =
                "Numi Human tendon/FEM adapter is not initialized";
            return result;
        }
        if (state_->deferAcceptedAuditPublication &&
            state_->acceptedAuditPendingCommandBufferIdentity != 0u) {
            result.message =
                "Numi Human tendon/FEM adapter snapshot requires a completed accepted-audit boundary";
            return result;
        }
        result.adapterFingerprint = state_->fingerprint;
        result.runtimeDeviceProgramFingerprint =
            state_->runtime->deviceProgramFingerprint();
        result.environmentCount = state_->environmentCount;
        result.endpointCount = state_->endpointCount;
        result.femNodeCount = static_cast<std::uint32_t>(
            state_->nodeLoads.size());
        result.contactSampleCount = static_cast<std::uint32_t>(
            state_->contactSamples.size());
        result.femBodyContactSampleCount = static_cast<std::uint32_t>(
            state_->femBodyContactSamples.size());
        result.articularContactSampleCount = static_cast<std::uint32_t>(
            state_->articularContactSamples.size());
        result.articularContactPairCount =
            state_->articularContactPairCount;
        result.passiveLigamentCount = static_cast<std::uint32_t>(
            state_->passiveLigaments.size());
        result.passiveRoutedBandCount = static_cast<std::uint32_t>(
            state_->passiveRoutedBands.size());
        result.boundBodyPoseStride = state_->articularBodyPoseStride;
        result.encodedPassCount = state_->encodedPassCount;
        result.abortCount = state_->abortCount;
        result.articularAttemptedStepCount =
            state_->articularAttemptedStepCount;
        result.anchorReactionAcceptedHistory =
            state_->anchorReactionAcceptedHistory;
        result.femBodyContactAcceptedHistory =
            state_->femBodyContactAcceptedHistory;
        result.articularContactAcceptedHistory =
            state_->articularContactAcceptedHistory;
        result.articularContactPairForceAcceptedHistory =
            state_->articularContactPairForceAcceptedHistory;
        result.passiveLigamentAcceptedState =
            state_->passiveLigamentAcceptedState;
        result.passiveRoutedBandAcceptedState =
            state_->passiveRoutedBandAcceptedState;

        const auto readAuthority = [&](id<MTLBuffer> buffer, auto& values) {
            using Value = typename std::decay_t<decltype(values)>::value_type;
            const std::size_t expectedBytes = values.size() * sizeof(Value);
            if (buffer == nil) return true;
            if (buffer.contents == nullptr || buffer.length != expectedBytes) {
                return false;
            }
            if (expectedBytes != 0u) {
                std::memcpy(values.data(), buffer.contents, expectedBytes);
            }
            return true;
        };
        if (!readAuthority(
                state_->anchorReactionAuditHistoryBuffer,
                result.anchorReactionAcceptedHistory) ||
            !readAuthority(
                state_->femBodyContactAuditHistoryBuffer,
                result.femBodyContactAcceptedHistory) ||
            !readAuthority(
                state_->articularContactAuditHistoryBuffer,
                result.articularContactAcceptedHistory) ||
            !readAuthority(
                state_->articularContactPairAuditHistoryBuffer,
                result.articularContactPairForceAcceptedHistory) ||
            !readAuthority(
                state_->deferAcceptedAuditPublication
                    ? state_->passiveLigamentAcceptedAuditBuffer
                    : state_->passiveLigamentAuditBuffer,
                result.passiveLigamentAcceptedState) ||
            !readAuthority(
                state_->deferAcceptedAuditPublication
                    ? state_->passiveRoutedBandAcceptedAuditBuffer
                    : state_->passiveRoutedBandAuditBuffer,
                result.passiveRoutedBandAcceptedState)) {
            result.message =
                "Numi Human tendon/FEM adapter authority buffer is unavailable";
            return result;
        }
        result.available = true;
        std::string error;
        if (!digestNumiHumanTendonFEMLoadAdapterSnapshotV1(
                result, result.authoritySHA256, error)) {
            result.available = false;
            result.message = std::move(error);
            return result;
        }
        result.message = "authoritative adapter snapshot captured";
        return result;
    } catch (const std::exception& exception) {
        result.available = false;
        result.message = std::string(
            "Numi Human tendon/FEM adapter snapshot failed: ") +
            exception.what();
        return result;
    } catch (...) {
        result.available = false;
        result.message = "Numi Human tendon/FEM adapter snapshot failed";
        return result;
    }
}

NumiHumanTendonFEMLoadAdapterRestoreDiagnostics
NumiHumanTendonFEMLoadAdapter::restore(
    const NumiHumanTendonFEMLoadAdapterSnapshotV1& snapshotValue
) noexcept {
    NumiHumanTendonFEMLoadAdapterRestoreDiagnostics result;
    const auto reject = [&](std::string message) {
        result.message = std::move(message);
        return result;
    };
    try {
        if (state_ == nullptr || state_->runtime == nullptr ||
            state_->fingerprint == 0u || !state_->runtime->valid()) {
            return reject(
                "Numi Human tendon/FEM adapter restore requires an initialized adapter");
        }
        if (state_->deferAcceptedAuditPublication &&
            state_->acceptedAuditPendingCommandBufferIdentity != 0u) {
            return reject(
                "Numi Human tendon/FEM adapter restore requires a completed accepted-audit boundary");
        }
        if (!snapshotValue.available ||
            snapshotValue.formatVersion !=
                kNumiHumanTendonFEMLoadAdapterSnapshotVersionV1) {
            return reject(
                "Numi Human tendon/FEM adapter restore rejected an unavailable or unsupported snapshot");
        }
        if (snapshotValue.adapterFingerprint != state_->fingerprint ||
            snapshotValue.runtimeDeviceProgramFingerprint !=
                state_->runtime->deviceProgramFingerprint() ||
            snapshotValue.environmentCount != state_->environmentCount ||
            snapshotValue.endpointCount != state_->endpointCount ||
            snapshotValue.femNodeCount != state_->nodeLoads.size() ||
            snapshotValue.contactSampleCount !=
                state_->contactSamples.size() ||
            snapshotValue.femBodyContactSampleCount !=
                state_->femBodyContactSamples.size() ||
            snapshotValue.articularContactSampleCount !=
                state_->articularContactSamples.size() ||
            snapshotValue.articularContactPairCount !=
                state_->articularContactPairCount ||
            snapshotValue.passiveLigamentCount !=
                state_->passiveLigaments.size() ||
            snapshotValue.passiveRoutedBandCount !=
                state_->passiveRoutedBands.size()) {
            return reject(
                "Numi Human tendon/FEM adapter restore identity does not match this adapter");
        }
        if (snapshotValue.articularAttemptedStepCount >
                NM_NUMI_HUMAN_ARTICULAR_CONTACT_AUDIT_MAX_STEPS ||
            ((!state_->articularContactSamples.empty() ||
              state_->hasFEMBodyInteraction()) &&
             state_->allocatedArticularBodyPoseStride != 0u &&
             snapshotValue.boundBodyPoseStride != 0u &&
             snapshotValue.boundBodyPoseStride !=
                state_->allocatedArticularBodyPoseStride)) {
            return reject(
                "Numi Human tendon/FEM adapter restore cursor or body-pose binding is invalid");
        }
        const std::size_t historyElements =
            static_cast<std::size_t>(state_->environmentCount) *
            NM_NUMI_HUMAN_ARTICULAR_CONTACT_AUDIT_MAX_STEPS;
        const std::size_t femBodyHistoryElements =
            state_->hasFEMBodyInteraction() ? historyElements : 0u;
        const std::size_t articularHistoryElements =
            state_->articularContactSamples.empty() ? 0u : historyElements;
        const std::size_t articularPairHistoryElements =
            state_->articularContactPairCount == 0u
                ? 0u
                : historyElements *
                    (static_cast<std::size_t>(
                         state_->articularContactPairCount) + 1u);
        const std::size_t passiveLigamentElements =
            state_->passiveLigaments.empty()
                ? 0u : state_->environmentCount;
        const std::size_t passiveRoutedBandElements =
            state_->passiveRoutedBands.empty()
                ? 0u : state_->environmentCount;
        if (snapshotValue.anchorReactionAcceptedHistory.size() !=
                historyElements ||
            snapshotValue.femBodyContactAcceptedHistory.size() !=
                femBodyHistoryElements ||
            snapshotValue.articularContactAcceptedHistory.size() !=
                articularHistoryElements ||
            snapshotValue.articularContactPairForceAcceptedHistory.size() !=
                articularPairHistoryElements ||
            snapshotValue.passiveLigamentAcceptedState.size() !=
                passiveLigamentElements ||
            snapshotValue.passiveRoutedBandAcceptedState.size() !=
                passiveRoutedBandElements) {
            return reject(
                "Numi Human tendon/FEM adapter restore vector extent is invalid");
        }
        NumiHumanTendonFEMLoadAdapterDigest computedDigest{};
        std::string digestError;
        if (!digestNumiHumanTendonFEMLoadAdapterSnapshotV1(
                snapshotValue, computedDigest, digestError) ||
            computedDigest != snapshotValue.authoritySHA256) {
            return reject(digestError.empty()
                ? "Numi Human tendon/FEM adapter restore digest mismatch"
                : std::move(digestError));
        }

        // All fallible allocations and all buffer-shape checks complete before
        // the first state byte is changed.
        auto stagedAnchor = snapshotValue.anchorReactionAcceptedHistory;
        auto stagedFEMBody = snapshotValue.femBodyContactAcceptedHistory;
        auto stagedArticular = snapshotValue.articularContactAcceptedHistory;
        auto stagedArticularPairs =
            snapshotValue.articularContactPairForceAcceptedHistory;
        auto stagedLigament = snapshotValue.passiveLigamentAcceptedState;
        auto stagedRouted = snapshotValue.passiveRoutedBandAcceptedState;
        const auto writable = [&](id<MTLBuffer> buffer,
                                  const std::size_t expectedBytes) {
            if (buffer == nil) {
                return expectedBytes == 0u || state_->device == nil;
            }
            return buffer.contents != nullptr &&
                buffer.length == expectedBytes;
        };
        if ((state_->executionMode !=
                    NumiHumanTendonFEMLoadExecutionMode::numanXDeferred &&
             !writable(
                 state_->anchorReactionAuditHistoryBuffer,
                 stagedAnchor.size() * sizeof(stagedAnchor.front()))) ||
            !writable(
                state_->femBodyContactAuditHistoryBuffer,
                stagedFEMBody.size() *
                    sizeof(NMNumiHumanArticularContactAuditGPU)) ||
            !writable(
                state_->articularContactAuditHistoryBuffer,
                stagedArticular.size() *
                    sizeof(NMNumiHumanArticularContactAuditGPU)) ||
            !writable(
                state_->articularContactPairAuditHistoryBuffer,
                stagedArticularPairs.size() * sizeof(float)) ||
            !writable(
                state_->passiveLigamentAuditBuffer,
                stagedLigament.size() *
                    sizeof(NMNumiHumanPassiveLigamentAuditGPU)) ||
            (state_->deferAcceptedAuditPublication && !writable(
                state_->passiveLigamentAcceptedAuditBuffer,
                stagedLigament.size() *
                    sizeof(NMNumiHumanPassiveLigamentAuditGPU))) ||
            !writable(
                state_->passiveRoutedBandAuditBuffer,
                stagedRouted.size() *
                    sizeof(NMNumiHumanPassiveRoutedBandAuditGPU)) ||
            (state_->deferAcceptedAuditPublication && !writable(
                state_->passiveRoutedBandAcceptedAuditBuffer,
                stagedRouted.size() *
                    sizeof(NMNumiHumanPassiveRoutedBandAuditGPU)))) {
            return reject(
                "Numi Human tendon/FEM adapter restore target buffer is unavailable");
        }
        const auto writeAuthority = [](id<MTLBuffer> buffer,
                                       const auto& values) {
            using Value = typename std::decay_t<decltype(values)>::value_type;
            const std::size_t bytes = values.size() * sizeof(Value);
            if (buffer != nil && bytes != 0u) {
                std::memcpy(buffer.contents, values.data(), bytes);
            }
        };
        writeAuthority(
            state_->anchorReactionAuditHistoryBuffer, stagedAnchor);
        writeAuthority(
            state_->femBodyContactAuditHistoryBuffer, stagedFEMBody);
        writeAuthority(
            state_->articularContactAuditHistoryBuffer, stagedArticular);
        writeAuthority(
            state_->articularContactPairAuditHistoryBuffer,
            stagedArticularPairs);
        writeAuthority(state_->passiveLigamentAuditBuffer, stagedLigament);
        if (state_->deferAcceptedAuditPublication)
            writeAuthority(state_->passiveLigamentAcceptedAuditBuffer, stagedLigament);
        writeAuthority(state_->passiveRoutedBandAuditBuffer, stagedRouted);
        if (state_->deferAcceptedAuditPublication)
            writeAuthority(state_->passiveRoutedBandAcceptedAuditBuffer, stagedRouted);
        state_->anchorReactionAcceptedHistory = std::move(stagedAnchor);
        state_->femBodyContactAcceptedHistory = std::move(stagedFEMBody);
        state_->articularContactAcceptedHistory = std::move(stagedArticular);
        state_->articularContactPairForceAcceptedHistory =
            std::move(stagedArticularPairs);
        state_->passiveLigamentAcceptedState = std::move(stagedLigament);
        state_->passiveRoutedBandAcceptedState = std::move(stagedRouted);
        state_->articularBodyPoseStride =
            snapshotValue.boundBodyPoseStride;
        state_->encodedPassCount = snapshotValue.encodedPassCount;
        state_->abortCount = snapshotValue.abortCount;
        state_->articularAttemptedStepCount =
            snapshotValue.articularAttemptedStepCount;
        state_->message = "authoritative adapter state restored";
        result.restored = true;
        result.message = state_->message;
        return result;
    } catch (const std::exception& exception) {
        return reject(std::string(
            "Numi Human tendon/FEM adapter restore failed before mutation: ") +
            exception.what());
    } catch (...) {
        return reject(
            "Numi Human tendon/FEM adapter restore failed before mutation");
    }
}

NumiHumanTendonFEMLoadDiagnostics
NumiHumanTendonFEMLoadAdapter::diagnostics() const noexcept {
    NumiHumanTendonFEMLoadDiagnostics result{};
    if (state_ == nullptr) return result;
    // Preserve the active owner diagnostic even when a later validation
    // branch returns early (for example, an uninitialized provisional audit).
    result.message = state_->message;
    result.initialized = state_->runtime != nullptr && state_->fingerprint != 0u;
    result.encodedPassCount = state_->encodedPassCount;
    result.abortCount = state_->abortCount;
    result.preSourceCorrectionEncodeCount =
        state_->preSourceCorrectionEncodeCount;
    result.deferredExternalForceBorrowCount =
        state_->deferredExternalForceBorrowCount;
    result.runtimePreDynamicsEncodeCount =
        state_->runtimePreDynamicsEncodeCount;
    result.runtimePostCommitEncodeCount =
        state_->runtimePostCommitEncodeCount;
    result.executionMode = state_->executionMode;
    result.fingerprint = state_->fingerprint;
    result.contactSampleCount = static_cast<std::uint32_t>(
        state_->contactSamples.size());
    result.femBodyContactSampleCount = static_cast<std::uint32_t>(
        state_->femBodyContactSamples.size());
    result.femSurfaceAttachmentSampleCount = static_cast<std::uint32_t>(
        state_->femSurfaceAttachments.size());
    result.articularContactSampleCount = static_cast<std::uint32_t>(
        state_->articularContactSamples.size());
    result.articularContactPairCount =
        state_->articularContactPairCount;
    result.articularMechanicalSampleCount =
        state_->articularMechanicalSampleCount;
    result.articularInternalSameBodySampleCount =
        state_->articularInternalSameBodySampleCount;
    result.passiveLigamentCount = static_cast<std::uint32_t>(
        state_->passiveLigaments.size());
    if (state_->passiveLigamentAuditBuffer != nil) {
        const auto* audits =
            static_cast<const NMNumiHumanPassiveLigamentAuditGPU*>(
                state_->passiveLigamentAuditBuffer.contents);
        double forceX = 0.0;
        double forceY = 0.0;
        double forceZ = 0.0;
        double momentX = 0.0;
        double momentY = 0.0;
        double momentZ = 0.0;
        double minimumStretch = std::numeric_limits<double>::infinity();
        bool accepted = true;
        for (std::uint32_t environment = 0u;
             environment < state_->environmentCount; ++environment) {
            const auto& audit = audits[environment];
            const nm_float4 force = audit.forceResidualAndL1;
            const nm_float4 moment = audit.momentResidualAndMaximumTension;
            const nm_float4 stretch = audit.stretchCountAndAccepted;
            if (!finiteScale(force) || !finiteScale(moment) ||
                !finiteScale(stretch) || force.w < 0.0f || moment.w < 0.0f ||
                stretch.x <= 0.0f || stretch.y < stretch.x ||
                static_cast<std::uint32_t>(stretch.z) !=
                    state_->passiveLigaments.size() ||
                (stretch.w != 0.0f && stretch.w != 1.0f)) {
                const double nan = std::numeric_limits<double>::quiet_NaN();
                result.passiveLigamentEndpointForceL1Newtons = nan;
                result.passiveLigamentMaximumTensionNewtons = nan;
                result.passiveLigamentMinimumEffectiveStretch = nan;
                result.passiveLigamentMaximumEffectiveStretch = nan;
                result.passiveLigamentForceResidualNewtons = nan;
                result.passiveLigamentMomentResidualNewtonMeters = nan;
                return result;
            }
            accepted = accepted && stretch.w == 1.0f;
            forceX += force.x;
            forceY += force.y;
            forceZ += force.z;
            momentX += moment.x;
            momentY += moment.y;
            momentZ += moment.z;
            result.passiveLigamentEndpointForceL1Newtons += force.w;
            result.passiveLigamentMaximumTensionNewtons = std::max(
                result.passiveLigamentMaximumTensionNewtons,
                static_cast<double>(moment.w));
            minimumStretch = std::min(
                minimumStretch, static_cast<double>(stretch.x));
            result.passiveLigamentMaximumEffectiveStretch = std::max(
                result.passiveLigamentMaximumEffectiveStretch,
                static_cast<double>(stretch.y));
        }
        result.passiveLigamentMinimumEffectiveStretch = minimumStretch;
        result.passiveLigamentForceResidualNewtons = std::sqrt(
            forceX * forceX + forceY * forceY + forceZ * forceZ);
        result.passiveLigamentMomentResidualNewtonMeters = std::sqrt(
            momentX * momentX + momentY * momentY + momentZ * momentZ);
        result.passiveLigamentLatestTransactionAccepted = accepted;
    }
    result.passiveRoutedBandCount = static_cast<std::uint32_t>(
        state_->passiveRoutedBands.size());
    if (state_->passiveRoutedBandAuditBuffer != nil) {
        const auto* audits =
            static_cast<const NMNumiHumanPassiveRoutedBandAuditGPU*>(
                state_->passiveRoutedBandAuditBuffer.contents);
        double forceX = 0.0;
        double forceY = 0.0;
        double forceZ = 0.0;
        double momentX = 0.0;
        double momentY = 0.0;
        double momentZ = 0.0;
        double minimumStrain = std::numeric_limits<double>::infinity();
        bool accepted = true;
        for (std::uint32_t environment = 0u;
             environment < state_->environmentCount; ++environment) {
            const auto& audit = audits[environment];
            const nm_float4 force = audit.forceResidualAndL1;
            const nm_float4 moment = audit.momentResidualAndMaximumTension;
            const nm_float4 strain = audit.strainCountAndAccepted;
            const nm_float4 energy = audit.energyAndMaximumExtension;
            if (!finiteScale(force) || !finiteScale(moment) ||
                !finiteScale(strain) || !finiteScale(energy) ||
                force.w < 0.0f || moment.w < 0.0f ||
                strain.y < strain.x ||
                static_cast<std::uint32_t>(strain.z) !=
                    state_->passiveRoutedBands.size() ||
                (strain.w != 0.0f && strain.w != 1.0f) ||
                energy.x < 0.0f || energy.y < 0.0f ||
                energy.z != 0.0f || energy.w != 0.0f) {
                const double nan = std::numeric_limits<double>::quiet_NaN();
                result.passiveRoutedBandEndpointForceL1Newtons = nan;
                result.passiveRoutedBandMaximumTensionNewtons = nan;
                result.passiveRoutedBandMinimumStrain = nan;
                result.passiveRoutedBandMaximumStrain = nan;
                result.passiveRoutedBandForceResidualNewtons = nan;
                result.passiveRoutedBandMomentResidualNewtonMeters = nan;
                result.passiveRoutedBandStoredEnergyJoules = nan;
                result.passiveRoutedBandMaximumExtensionMeters = nan;
                return result;
            }
            accepted = accepted && strain.w == 1.0f;
            forceX += force.x;
            forceY += force.y;
            forceZ += force.z;
            momentX += moment.x;
            momentY += moment.y;
            momentZ += moment.z;
            result.passiveRoutedBandEndpointForceL1Newtons += force.w;
            result.passiveRoutedBandMaximumTensionNewtons = std::max(
                result.passiveRoutedBandMaximumTensionNewtons,
                static_cast<double>(moment.w));
            minimumStrain = std::min(
                minimumStrain, static_cast<double>(strain.x));
            result.passiveRoutedBandMaximumStrain = std::max(
                result.passiveRoutedBandMaximumStrain,
                static_cast<double>(strain.y));
            result.passiveRoutedBandStoredEnergyJoules += energy.x;
            result.passiveRoutedBandMaximumExtensionMeters = std::max(
                result.passiveRoutedBandMaximumExtensionMeters,
                static_cast<double>(energy.y));
        }
        result.passiveRoutedBandMinimumStrain = minimumStrain;
        result.passiveRoutedBandForceResidualNewtons = std::sqrt(
            forceX * forceX + forceY * forceY + forceZ * forceZ);
        result.passiveRoutedBandMomentResidualNewtonMeters = std::sqrt(
            momentX * momentX + momentY * momentY + momentZ * momentZ);
        result.passiveRoutedBandLatestTransactionAccepted = accepted;
    }
    if (state_->externalForceAuditBuffer != nil) {
        const auto* audits = static_cast<const nm_float4*>(
            state_->externalForceAuditBuffer.contents);
        double resultantX = 0.0;
        double resultantY = 0.0;
        double resultantZ = 0.0;
        for (std::uint32_t environment = 0u;
             environment < state_->environmentCount; ++environment) {
            const nm_float4 audit = audits[environment];
            if (!finiteScale(audit) || audit.w < 0.0f) {
                result.assembledExternalForceL1Newtons =
                    std::numeric_limits<double>::quiet_NaN();
                result.assembledExternalForceResultantNewtons =
                    std::numeric_limits<double>::quiet_NaN();
                break;
            }
            resultantX += audit.x;
            resultantY += audit.y;
            resultantZ += audit.z;
            result.assembledExternalForceL1Newtons += audit.w;
            result.assembledExternalForceResultantNewtons = std::sqrt(
                resultantX * resultantX + resultantY * resultantY +
                resultantZ * resultantZ);
        }
    }
    if (state_->anchorReactionAuditBuffer != nil) {
        const auto* audits = static_cast<const nm_float4*>(
            state_->anchorReactionAuditBuffer.contents);
        double resultantX = 0.0;
        double resultantY = 0.0;
        double resultantZ = 0.0;
        for (std::uint32_t environment = 0u;
             environment < state_->environmentCount; ++environment) {
            const nm_float4 audit = audits[environment];
            if (!finiteScale(audit) || audit.w < 0.0f) {
                result.anchorReactionL1Newtons =
                    std::numeric_limits<double>::quiet_NaN();
                result.anchorReactionResultantNewtons =
                    std::numeric_limits<double>::quiet_NaN();
                break;
            }
            resultantX += audit.x;
            resultantY += audit.y;
            resultantZ += audit.z;
            result.anchorReactionL1Newtons += audit.w;
            result.anchorReactionResultantNewtons = std::sqrt(
                resultantX * resultantX + resultantY * resultantY +
                resultantZ * resultantZ);
        }
    }
    if (state_->anchorReactionAuditHistoryBuffer != nil) {
        const auto* history = static_cast<const nm_float4*>(
            state_->anchorReactionAuditHistoryBuffer.contents);
        const std::uint32_t attemptedSteps = std::min(
            state_->articularAttemptedStepCount,
            static_cast<std::uint32_t>(
                NM_NUMI_HUMAN_ARTICULAR_CONTACT_AUDIT_MAX_STEPS));
        result.anchorReactionAuditedStepCount = attemptedSteps;
        double minimumL1 = std::numeric_limits<double>::infinity();
        for (std::uint32_t step = 0u; step < attemptedSteps; ++step) {
            double l1 = 0.0;
            double resultantX = 0.0;
            double resultantY = 0.0;
            double resultantZ = 0.0;
            for (std::uint32_t environment = 0u;
                 environment < state_->environmentCount; ++environment) {
                const nm_float4 audit = history[
                    environment *
                        NM_NUMI_HUMAN_ARTICULAR_CONTACT_AUDIT_MAX_STEPS + step];
                if (!finiteScale(audit) || audit.w < 0.0f) {
                    const double nan =
                        std::numeric_limits<double>::quiet_NaN();
                    result.anchorReactionTrajectoryMinimumL1Newtons = nan;
                    result.anchorReactionTrajectoryMaximumL1Newtons = nan;
                    result.anchorReactionTrajectoryMaximumResultantNewtons = nan;
                    return result;
                }
                resultantX += audit.x;
                resultantY += audit.y;
                resultantZ += audit.z;
                l1 += audit.w;
            }
            minimumL1 = std::min(minimumL1, l1);
            result.anchorReactionTrajectoryMaximumL1Newtons = std::max(
                result.anchorReactionTrajectoryMaximumL1Newtons, l1);
            result.anchorReactionTrajectoryMaximumResultantNewtons = std::max(
                result.anchorReactionTrajectoryMaximumResultantNewtons,
                std::sqrt(resultantX * resultantX +
                          resultantY * resultantY +
                          resultantZ * resultantZ));
        }
        if (attemptedSteps > 0u) {
            result.anchorReactionTrajectoryMinimumL1Newtons = minimumL1;
        }
    }
    if (state_->femBodyContactAuditHistoryBuffer != nil) {
        const auto* history =
            static_cast<const NMNumiHumanArticularContactAuditGPU*>(
                state_->femBodyContactAuditHistoryBuffer.contents);
        const std::uint32_t attemptedSteps = std::min(
            state_->articularAttemptedStepCount,
            NM_NUMI_HUMAN_ARTICULAR_CONTACT_AUDIT_MAX_STEPS);
        for (std::uint32_t step = 0u; step < attemptedSteps; ++step) {
            double forceX = 0.0;
            double forceY = 0.0;
            double forceZ = 0.0;
            double momentX = 0.0;
            double momentY = 0.0;
            double momentZ = 0.0;
            double maximumTangentialSlip = 0.0;
            double maximumPressure = 0.0;
            double normalForce = 0.0;
            double contactArea = 0.0;
            double storedEnergy = 0.0;
            double maximumNormalStrain = 0.0;
            double maximumClosure = 0.0;
            std::uint32_t closedSamples = 0u;
            bool accepted = true;
            bool malformed = false;
            for (std::uint32_t environment = 0u;
                 environment < state_->environmentCount; ++environment) {
                const auto& audit = history[
                    environment *
                        NM_NUMI_HUMAN_ARTICULAR_CONTACT_AUDIT_MAX_STEPS +
                    step];
                const nm_float4 force = audit.forceResidualAndL1;
                const nm_float4 moment =
                    audit.momentResidualAndMaximumPressure;
                const nm_float4 contact = audit.normalForceAreaAndCounts;
                const nm_float4 energy =
                    audit.energyStrainClosureAndAccepted;
                if (energy.w == 0.0f) {
                    accepted = false;
                    break;
                }
                malformed = !finiteScale(force) || !finiteScale(moment) ||
                    !finiteScale(contact) || !finiteScale(energy) ||
                    energy.w != 1.0f || force.w < 0.0f || moment.w < 0.0f ||
                    contact.x < 0.0f || contact.y < 0.0f || contact.z < 0.0f ||
                    static_cast<std::uint32_t>(contact.w) !=
                        state_->femBodyContactSamples.size() +
                            state_->femSurfaceAttachments.size() ||
                    energy.x < 0.0f || energy.y < 0.0f || energy.z < 0.0f;
                if (malformed) break;
                forceX += force.x;
                forceY += force.y;
                forceZ += force.z;
                momentX += moment.x;
                momentY += moment.y;
                momentZ += moment.z;
                maximumTangentialSlip = std::max(
                    maximumTangentialSlip, static_cast<double>(force.w));
                maximumPressure = std::max(
                    maximumPressure, static_cast<double>(moment.w));
                normalForce += contact.x;
                contactArea += contact.y;
                closedSamples += static_cast<std::uint32_t>(contact.z);
                storedEnergy += energy.x;
                maximumNormalStrain = std::max(
                    maximumNormalStrain, static_cast<double>(energy.y));
                maximumClosure = std::max(
                    maximumClosure, static_cast<double>(energy.z));
            }
            if (malformed) {
                const double nan =
                    std::numeric_limits<double>::quiet_NaN();
                result.femBodyContactAreaSquareMeters = nan;
                result.femBodyContactNormalForceNewtons = nan;
                result.femBodyContactMaximumPressurePascals = nan;
                result.femBodyContactForceResidualNewtons = nan;
                result.femBodyContactMomentResidualNewtonMeters = nan;
                result.femBodyContactStoredEnergyJoules = nan;
                result.femBodyContactMaximumNormalStrain = nan;
                result.femBodyContactMaximumClosureMeters = nan;
                result.femBodyContactMaximumTangentialSlipMeters = nan;
                result.femBodyContactTrajectoryMinimumNormalForceNewtons = nan;
                result.femBodyContactTrajectoryMaximumNormalForceNewtons = nan;
                result.femBodyContactTrajectoryMaximumForceResidualNewtons = nan;
                result.femBodyContactTrajectoryMaximumMomentResidualNewtonMeters = nan;
                result.femBodyContactTrajectoryMaximumTangentialSlipMeters = nan;
                break;
            }
            if (!accepted) break;
            const double forceResidual = std::sqrt(
                forceX * forceX + forceY * forceY + forceZ * forceZ);
            const double momentResidual = std::sqrt(
                momentX * momentX + momentY * momentY + momentZ * momentZ);
            result.femBodyContactClosedSampleCount = closedSamples;
            result.femBodyContactAreaSquareMeters = contactArea;
            result.femBodyContactNormalForceNewtons = normalForce;
            result.femBodyContactMaximumPressurePascals = maximumPressure;
            result.femBodyContactForceResidualNewtons = forceResidual;
            result.femBodyContactMomentResidualNewtonMeters = momentResidual;
            result.femBodyContactStoredEnergyJoules = storedEnergy;
            result.femBodyContactMaximumNormalStrain = maximumNormalStrain;
            result.femBodyContactMaximumClosureMeters = maximumClosure;
            result.femBodyContactMaximumTangentialSlipMeters =
                maximumTangentialSlip;
            if (result.femBodyContactAuditedStepCount == 0u) {
                result.femBodyContactTrajectoryMinimumNormalForceNewtons =
                    normalForce;
            } else {
                result.femBodyContactTrajectoryMinimumNormalForceNewtons =
                    std::min(
                        result.femBodyContactTrajectoryMinimumNormalForceNewtons,
                        normalForce);
            }
            ++result.femBodyContactAuditedStepCount;
            result.femBodyContactTrajectoryMaximumNormalForceNewtons =
                std::max(
                    result.femBodyContactTrajectoryMaximumNormalForceNewtons,
                    normalForce);
            result.femBodyContactTrajectoryMaximumForceResidualNewtons =
                std::max(
                    result.femBodyContactTrajectoryMaximumForceResidualNewtons,
                    forceResidual);
            result.femBodyContactTrajectoryMaximumMomentResidualNewtonMeters =
                std::max(
                    result.femBodyContactTrajectoryMaximumMomentResidualNewtonMeters,
                    momentResidual);
            result.femBodyContactTrajectoryMaximumTangentialSlipMeters =
                std::max(
                    result.femBodyContactTrajectoryMaximumTangentialSlipMeters,
                    maximumTangentialSlip);
        }
    }
    if (state_->articularContactAuditHistoryBuffer != nil) {
        const auto* history =
            static_cast<const NMNumiHumanArticularContactAuditGPU*>(
                state_->articularContactAuditHistoryBuffer.contents);
        const auto poisonArticularDiagnostics = [&]() {
            const double nan = std::numeric_limits<double>::quiet_NaN();
            result.articularContactAreaSquareMeters = nan;
            result.articularNormalForceNewtons = nan;
            result.articularMaximumPressurePascals = nan;
            result.articularBodyForceL1Newtons = nan;
            result.articularForceResidualNewtons = nan;
            result.articularMomentResidualNewtonMeters = nan;
            result.articularStoredEnergyJoules = nan;
            result.articularMaximumNormalStrain = nan;
            result.articularMaximumClosureMeters = nan;
            result.articularTrajectoryMinimumNormalForceNewtons = nan;
            result.articularTrajectoryMaximumNormalForceNewtons = nan;
            result.articularTrajectoryMaximumPressurePascals = nan;
            result.articularTrajectoryMaximumStoredEnergyJoules = nan;
            result.articularTrajectoryMaximumNormalStrain = nan;
            result.articularTrajectoryMaximumClosureMeters = nan;
            result.articularTrajectoryMaximumForceResidualNewtons = nan;
            result.articularTrajectoryMaximumMomentResidualNewtonMeters = nan;
        };
        const std::uint32_t attemptedSteps = std::min(
            state_->articularAttemptedStepCount,
            NM_NUMI_HUMAN_ARTICULAR_CONTACT_AUDIT_MAX_STEPS);
        for (std::uint32_t step = 0u; step < attemptedSteps; ++step) {
            double forceX = 0.0;
            double forceY = 0.0;
            double forceZ = 0.0;
            double momentX = 0.0;
            double momentY = 0.0;
            double momentZ = 0.0;
            double bodyForceL1 = 0.0;
            double maximumPressure = 0.0;
            double normalForce = 0.0;
            double contactArea = 0.0;
            double storedEnergy = 0.0;
            double maximumNormalStrain = 0.0;
            double maximumClosure = 0.0;
            std::uint32_t closedSamples = 0u;
            bool accepted = true;
            bool malformed = false;
            for (std::uint32_t environment = 0u;
                 environment < state_->environmentCount; ++environment) {
                const auto& audit = history[
                    environment *
                        NM_NUMI_HUMAN_ARTICULAR_CONTACT_AUDIT_MAX_STEPS +
                    step];
                const nm_float4 force = audit.forceResidualAndL1;
                const nm_float4 moment = audit.momentResidualAndMaximumPressure;
                const nm_float4 contact = audit.normalForceAreaAndCounts;
                const nm_float4 energy =
                    audit.energyStrainClosureAndAccepted;
                if (energy.w == 0.0f) {
                    accepted = false;
                    break;
                }
                malformed = !finiteScale(force) || !finiteScale(moment) ||
                    !finiteScale(contact) || !finiteScale(energy) ||
                    energy.w != 1.0f || force.w < 0.0f || moment.w < 0.0f ||
                    contact.x < 0.0f || contact.y < 0.0f || contact.z < 0.0f ||
                    contact.w < 0.0f || energy.x < 0.0f || energy.y < 0.0f ||
                    energy.z < 0.0f ||
                    static_cast<std::uint32_t>(contact.w) !=
                        state_->articularInternalSameBodySampleCount;
                if (malformed) break;
                forceX += force.x;
                forceY += force.y;
                forceZ += force.z;
                momentX += moment.x;
                momentY += moment.y;
                momentZ += moment.z;
                bodyForceL1 += force.w;
                maximumPressure = std::max(
                    maximumPressure, static_cast<double>(moment.w));
                normalForce += contact.x;
                contactArea += contact.y;
                closedSamples += static_cast<std::uint32_t>(contact.z);
                storedEnergy += energy.x;
                maximumNormalStrain = std::max(
                    maximumNormalStrain, static_cast<double>(energy.y));
                maximumClosure = std::max(
                    maximumClosure, static_cast<double>(energy.z));
            }
            if (malformed) {
                poisonArticularDiagnostics();
                break;
            }
            // Only a contiguous prefix of wholly accepted multi-environment
            // steps is trajectory evidence. A rejected step terminates it.
            if (!accepted) break;
            const double forceResidual = std::sqrt(
                forceX * forceX + forceY * forceY + forceZ * forceZ);
            const double momentResidual = std::sqrt(
                momentX * momentX + momentY * momentY + momentZ * momentZ);
            result.articularClosedSampleCount = closedSamples;
            result.articularContactAreaSquareMeters = contactArea;
            result.articularNormalForceNewtons = normalForce;
            result.articularMaximumPressurePascals = maximumPressure;
            result.articularBodyForceL1Newtons = bodyForceL1;
            result.articularForceResidualNewtons = forceResidual;
            result.articularMomentResidualNewtonMeters = momentResidual;
            result.articularStoredEnergyJoules = storedEnergy;
            result.articularMaximumNormalStrain = maximumNormalStrain;
            result.articularMaximumClosureMeters = maximumClosure;
            if (result.articularAuditedStepCount == 0u) {
                result.articularTrajectoryMinimumClosedSampleCount =
                    closedSamples;
                result.articularTrajectoryMinimumNormalForceNewtons =
                    normalForce;
            } else {
                result.articularTrajectoryMinimumClosedSampleCount = std::min(
                    result.articularTrajectoryMinimumClosedSampleCount,
                    closedSamples);
                result.articularTrajectoryMinimumNormalForceNewtons = std::min(
                    result.articularTrajectoryMinimumNormalForceNewtons,
                    normalForce);
            }
            ++result.articularAuditedStepCount;
            result.articularTrajectoryMaximumClosedSampleCount = std::max(
                result.articularTrajectoryMaximumClosedSampleCount,
                closedSamples);
            result.articularTrajectoryMaximumNormalForceNewtons = std::max(
                result.articularTrajectoryMaximumNormalForceNewtons,
                normalForce);
            result.articularTrajectoryMaximumPressurePascals = std::max(
                result.articularTrajectoryMaximumPressurePascals,
                maximumPressure);
            result.articularTrajectoryMaximumStoredEnergyJoules = std::max(
                result.articularTrajectoryMaximumStoredEnergyJoules,
                storedEnergy);
            result.articularTrajectoryMaximumNormalStrain = std::max(
                result.articularTrajectoryMaximumNormalStrain,
                maximumNormalStrain);
            result.articularTrajectoryMaximumClosureMeters = std::max(
                result.articularTrajectoryMaximumClosureMeters,
                maximumClosure);
            result.articularTrajectoryMaximumForceResidualNewtons = std::max(
                result.articularTrajectoryMaximumForceResidualNewtons,
                forceResidual);
            result.articularTrajectoryMaximumMomentResidualNewtonMeters =
                std::max(
                    result.articularTrajectoryMaximumMomentResidualNewtonMeters,
                    momentResidual);
        }
    }
    result.message = state_->message;
    return result;
}

} // namespace numi::matter

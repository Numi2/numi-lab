
#include NPZ_HEADER
#include <iostream>
int main(int argc,char**argv) {
    using namespace metalrobo::human::coarse_tissue::current_fractional_support_npz_detail;
    if(argc!=2)return 2;
    const std::set<std::string> wanted{
        "cell_group_offsets","cell_group_ids","cell_group_p1_score_numerators",
        "cell_group_p1_score_denominators","group_tuples","cell_admissible_region_offsets",
        "cell_admissible_region_ids","admissibility_max_source_region_hops",
        "current_state_sha256","geometry_sha256","volume_sha256","source330_mass_sha256",
        "admissibility_source_support_sha256"};
    std::map<std::string,NpyArray> arrays;std::string error;
    if(!readRequestedArrays(argv[1],wanted,arrays,error)){std::cerr<<error;return 1;}
    std::uint64_t hash=14695981039346656037ull,bytes=0u;
    for(const auto& [name,a]:arrays) {
        for(auto v:a.bytes){hash^=v;hash*=1099511628211ull;}
        bytes+=a.bytes.size();
    }
    std::cout<<arrays.size()<<" "<<bytes<<" "<<hash<<"\n";
}

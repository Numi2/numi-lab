#!/bin/bash
set -u
here=/Users/numi/suture-archive-search-20261107/fresh-approach-20261108/witness-device-roundtrip-001
cd "$here" || exit 1
shasum -a 256 -c inputs.sha256 > precheck.log || exit 2
printf "positive_start=%s\n" "$(date -u +%FT%TZ)" > receipt.log
./roundtrip input.bin positive.bin exact > positive.log 2>&1
positive_exit=$?
printf "positive_end=%s\npositive_exit=%s\n" "$(date -u +%FT%TZ)" "$positive_exit" >> receipt.log
if [ "$positive_exit" -ne 0 ]; then exit 3; fi
cmp input.bin positive.bin || exit 4
printf "negative_start=%s\n" "$(date -u +%FT%TZ)" >> receipt.log
./roundtrip input.bin negative.bin corrupt > negative.log 2>&1
negative_exit=$?
printf "negative_end=%s\nnegative_exit=%s\n" "$(date -u +%FT%TZ)" "$negative_exit" >> receipt.log
shasum -a 256 -c inputs.sha256 > postcheck.log
postcheck_exit=$?
printf "postcheck_exit=%s\n" "$postcheck_exit" >> receipt.log
shasum -a 256 positive.bin > outputs.sha256
if [ "$negative_exit" -ne 6 ] || [ -e negative.bin ] || [ "$postcheck_exit" -ne 0 ]; then exit 5; fi
printf "transport_gate=PASS\n" >> receipt.log

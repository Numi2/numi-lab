#!/bin/bash
set -u
here=/Users/numi/suture-archive-search-20261107/fresh-approach-20261108/convex-owner-capture-001
repo=/Users/numi/numi-lab-skin-suture-restoration
checkpoint="$here/tissue-robot-first-bite-approach.tsv"
cd "$here" || exit 1
mkdir results || exit 1
shasum -a 256 -c checkpoint-inputs.sha256 > checkpoint-precheck.log || exit 2
shasum -a 256 -c inputs.sha256 > runtime-precheck.log || exit 3
[ "$(git -C "$repo" rev-parse HEAD)" = 2af9a0288d721f135b7712c0619dc5889febb11d ] || { echo source_identity_mismatch; exit 4; }
export DYLD_LIBRARY_PATH="$here/candidate-lib"
bin="$here/candidate-bin/metalrobo_dual_psm_suture_handoff_probe"
printf "restore_start=%s\n" "$(date -u +%FT%TZ)" > receipt.log
"$bin" --tissue-checkpoint-restore-only --synthetic-skin --resume-tissue-checkpoint tissue-robot-first-bite-approach "$checkpoint" > restore.log 2>&1
restore_exit=$?
printf "restore_end=%s\nrestore_exit=%s\n" "$(date -u +%FT%TZ)" "$restore_exit" >> receipt.log
if [ "$restore_exit" -ne 0 ] || ! grep -q "authority_byte_exact=yes physics_advanced=no" restore.log; then
  printf "restore_gate=FAILED\n" >> receipt.log; exit 5
fi
printf "restore_gate=PASS\ncontinue_start=%s\n" "$(date -u +%FT%TZ)" >> receipt.log
"$bin" --tissue-robot-first-bite-entry-only --same-resident-control --capture-partial-owner-capsule --capture-owner-boundary-evidence --synthetic-skin --resume-tissue-checkpoint tissue-robot-first-bite-approach "$checkpoint" --state-output-dir "$here/results" > continue.log 2>&1
continue_exit=$?
printf "continue_end=%s\ncontinue_exit=%s\n" "$(date -u +%FT%TZ)" "$continue_exit" >> receipt.log
shasum -a 256 -c inputs.sha256 > runtime-postcheck.log; runtime_exit=$?
shasum -a 256 -c checkpoint-inputs.sha256 > checkpoint-postcheck.log; checkpoint_exit=$?
printf "runtime_postcheck=%s\ncheckpoint_postcheck=%s\n" "$runtime_exit" "$checkpoint_exit" >> receipt.log
find results -type f -print0 | sort -z | xargs -0 shasum -a 256 > outputs.sha256
if [ "$continue_exit" -ne 0 ] || [ "$runtime_exit" -ne 0 ] || [ "$checkpoint_exit" -ne 0 ]; then printf "native_gate=FAILED\n" >> receipt.log; exit 6; fi
if ! grep -q "same_resident_entry_accepted=1" continue.log || ! grep -q "same_resident_continuation=ok" continue.log || [ "$(grep -c "rod_witness_boundary.*identity_valid=1 impulses_finite=1" continue.log)" -ne 2 ]; then printf "physical_gate=FAILED\n" >> receipt.log; exit 7; fi
verify="$repo/numi/evidence/fresh-robot-approach-20261108/verify_partial_capsule.py"
python3 "$verify" results/entry/partial-owner-capsule "$checkpoint" > verify-entry.log 2>&1; entry_exit=$?
python3 "$verify" results/advance/partial-owner-capsule "$checkpoint" > verify-advance.log 2>&1; advance_exit=$?
printf "entry_verifier_exit=%s\nadvance_verifier_exit=%s\n" "$entry_exit" "$advance_exit" >> receipt.log
[ "$entry_exit" -eq 0 ] && [ "$advance_exit" -eq 0 ] || exit 8
entry_fp=$(awk -F "\t" '$1=="compiled_world_fingerprint" {print $2}' results/entry/partial-owner-capsule/manifest.tsv)
advance_fp=$(awk -F "\t" '$1=="compiled_world_fingerprint" {print $2}' results/advance/partial-owner-capsule/manifest.tsv)
[ -n "$entry_fp" ] && [ "$entry_fp" = "$advance_fp" ] || { echo fingerprint_gate=FAILED >> receipt.log; exit 9; }
printf "fingerprint_gate=PASS\ncompiled_world_fingerprint=%s\ncapsule_restorable=0\n" "$entry_fp" >> receipt.log

boundary_verify="$repo/numi/evidence/fresh-robot-approach-20261108/verify_owner_boundary.py"
python3 "$boundary_verify" results/entry "$checkpoint" > verify-boundary-entry.log 2>&1; entry_boundary_exit=$?
python3 "$boundary_verify" results/advance "$checkpoint" > verify-boundary-advance.log 2>&1; advance_boundary_exit=$?
printf "entry_boundary_exit=%s\nadvance_boundary_exit=%s\n" "$entry_boundary_exit" "$advance_boundary_exit" >> receipt.log
[ "$entry_boundary_exit" -eq 0 ] && [ "$advance_boundary_exit" -eq 0 ] || exit 10
[ "$(grep -c 'owner_boundary_evidence=ok complete=0 restorable=0' continue.log)" -eq 2 ] || exit 11
printf "boundary_evidence_gate=PASS\n" >> receipt.log

#!/bin/bash
set -u
root=/Users/numi/suture-archive-search-20261107/fresh-approach-20261108
here="$root/rod-witness-readback-001"
repo=/Users/numi/numi-lab-skin-suture-restoration
cd "$here" || exit 1
mkdir results || exit 1
shasum -a 256 -c checkpoint-inputs.sha256 > checkpoint-precheck.log || exit 2
shasum -a 256 -c "$here/inputs.sha256" > runtime-precheck.log || exit 3
git -C "$repo" diff --quiet c01c2f2ea987e5e6c3e221a4f0a0e1c71e6931f6 HEAD -- apps src include matter CMakeLists.txt || exit 4
export DYLD_LIBRARY_PATH="$here/candidate-lib"
bin="$here/candidate-bin/metalrobo_dual_psm_suture_handoff_probe"
printf "restore_start=%s\n" "$(date -u +%FT%TZ)" > receipt.log
"$bin" --tissue-checkpoint-restore-only --synthetic-skin --resume-tissue-checkpoint tissue-robot-first-bite-approach "$here/tissue-robot-first-bite-approach.tsv" > restore.log 2>&1
restore_exit=$?
printf "restore_end=%s\nrestore_exit=%s\n" "$(date -u +%FT%TZ)" "$restore_exit" >> receipt.log
if [ "$restore_exit" -ne 0 ] || ! grep -q "authority_byte_exact=yes physics_advanced=no" restore.log; then
  printf "restore_gate=FAILED\n" >> receipt.log
  exit 5
fi
printf "restore_gate=PASS\ncontinue_start=%s\n" "$(date -u +%FT%TZ)" >> receipt.log
"$bin" --tissue-robot-first-bite-entry-only --same-resident-control --synthetic-skin --resume-tissue-checkpoint tissue-robot-first-bite-approach "$here/tissue-robot-first-bite-approach.tsv" --state-output-dir "$here/results" > continue.log 2>&1
continue_exit=$?
printf "continue_end=%s\ncontinue_exit=%s\n" "$(date -u +%FT%TZ)" "$continue_exit" >> receipt.log
shasum -a 256 -c "$here/inputs.sha256" > runtime-postcheck.log
runtime_exit=$?
shasum -a 256 -c checkpoint-inputs.sha256 > checkpoint-postcheck.log
checkpoint_exit=$?
printf "runtime_postcheck=%s\ncheckpoint_postcheck=%s\n" "$runtime_exit" "$checkpoint_exit" >> receipt.log
find results -type f -print0 | sort -z | xargs -0 shasum -a 256 > outputs.sha256
if ! grep -q "same_resident_entry_accepted=1" continue.log || ! grep -q "same_resident_continuation=ok" continue.log; then printf "same_resident_gate=FAILED\n" >> receipt.log; exit 7; fi
printf "same_resident_gate=PASS\n" >> receipt.log
if [ "$(grep -c "rod_witness_boundary.*identity_valid=1 impulses_finite=1" continue.log)" -ne 2 ]; then printf "witness_gate=FAILED\n" >> receipt.log; exit 8; fi
printf "witness_gate=PASS\n" >> receipt.log
if [ "$continue_exit" -ne 0 ] || [ "$runtime_exit" -ne 0 ] || [ "$checkpoint_exit" -ne 0 ]; then exit 6; fi

#!/bin/bash
cd /Users/numi/numi-lab-ccd-thin-evidence-20261107/cold-four-sliding-broad-v1 || exit 1
date -u +%FT%TZ > timestamps.txt
for variant in main candidate; do
  for probe in revolute revolute_friction jointed mixed_rod; do
    ./$probe "$variant.metallib" > "$variant-$probe.json" 2> "$variant-$probe.stderr"
    printf "%s %s exit=%s\n" "$variant" "$probe" "$?" >> statuses.txt
  done
done
date -u +%FT%TZ >> timestamps.txt
cat timestamps.txt statuses.txt

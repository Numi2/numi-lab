# Guarded mixed-cone test preregistration

Against the unchanged research branch, add final mixed wave admission requiring finite, nonnegative normal cap and effective friction, with effective U/V both zero or both positive. Continue returning nonfinite status for nonfinite data and unsupported for finite invalid coefficients; retain the existing residual certificate. This is a bounded research containment, not physical friction qualification.

Replay the previous test-only low-speed cone injections, requiring negative friction and NaN to reject twice, restore captured state, and match an independent neutral continuation. The cap and stationary controls must preserve their prior outcomes; compare emitted contact and state data to prior runs, allowing only changes caused by rejected invalid cases. The NaN input and finite invalid coefficients are injected downstream, and no claim is made they are reachable from public generated contacts.

Run all 18 prior explicit-zero-gravity frictionless resident controls on the non-instrumented guard shader and compare their common emitted fields and statuses with the previously pinned candidate. Record any mismatch as a failure. Retain prior failed experiments; do not alter the normal acceptance tolerance, CCD options, the augmented-Lagrangian option, or the population and replay captures.

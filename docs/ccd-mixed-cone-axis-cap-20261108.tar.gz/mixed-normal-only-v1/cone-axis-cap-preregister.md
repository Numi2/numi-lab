# One-axis and invalid-cap cone control preregistration

Using the same zero-gravity populated-cache three-node mixed island, inject into the evaluated ground cone: no change at speed 0, (U,V)=(0.5,0) at speed 0.00003 m/s, normal impulse cap -0.1 N s at 0.00006 m/s, and NaN normal cap at 0.00009 m/s. These small speeds keep the unrelated normal residual below its unchanged absolute tolerance, so invalid input handling is isolated. Values are test-only downstream injections; host validation and generated-contact reachability are separate questions.

Check the actual evaluated cone at each attempt. The control must accept. Each invalid cone must reject twice, captured state must restore, and subsequent neutral continuation must match a separately initialized resident. Missing injection or setup is a failure; retained JSON, source, shader and executable identities are required. The research candidate remains unpromoted.

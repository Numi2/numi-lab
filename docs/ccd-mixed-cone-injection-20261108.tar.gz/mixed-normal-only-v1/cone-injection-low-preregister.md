# Low-speed evaluated-cone isolation preregistration

Repeat the prior zero-gravity populated-cache fixture with ground speeds 0, 0.0001, 0.0002 and 0.0003 m/s. Test-only ground-row evaluated-cone injection is respectively none, normal cap 0.00001 N s, negative U friction -0.5, and NaN U friction. Record actual cone, status, residual and tolerance. This reduces the unrelated normal residual so it can fall within the unchanged 1e-4 m/s plus 1% scale certificate; no tolerance changes are permitted.

Require invalid cone steps to reject even if normal complementarity passes. A rejected step must restore the captured q/v, scene, rod and manifold state and then match the independent neutral resident. A capped cone may only be accepted if normal impulse is within cap and capped complementarity passes. A missing observed injection is a setup failure. Test-only injection does not establish public-path reachability. Preserve all first-run high-speed results and identities.

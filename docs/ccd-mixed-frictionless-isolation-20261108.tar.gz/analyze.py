#!/usr/bin/env python3
import json
from pathlib import Path
p=Path(__file__).parent
ref=json.loads((p/"reference.json").read_text())["cases"]
out={}
for name in ("main","containment","priority"):
 cases=json.loads((p/(name+".json")).read_text())["cases"];result=[]
 for c,r in zip(cases,ref):
  if not c["accepted"]:
   result.append({"initial_vn":c["initial_vn"],"accepted":False,"status":c["status"],"restored":c["restored"],"replay":c["replay"]});continue
  x=[z["impulse"][0] for z in c["rows"]]; tang=max(abs(t) for z in c["rows"] for t in z["impulse"][1:])
  W=r["W"];pre=r["pre"];target=r["target"]
  post=[pre[i]+sum(W[i][j]*x[j] for j in range(3)) for i in range(3)]
  residual=[post[i]-target[i] for i in range(3)]
  normal=max(abs(residual[i]) if x[i]>1e-8 else max(-residual[i],0.) for i in range(3))
  rigid=abs(x[0]-r["reference"]["impulses_ns"][0]); rod=abs(sum(x[1:])-sum(r["reference"]["impulses_ns"][1:]))
  w=sum(x[i]*pre[i] for i in range(3))+.5*sum(x[i]*W[i][j]*x[j] for i in range(3) for j in range(3))
  wd=abs(w-r["reference"]["work_j"])
  actual=[z["post_all"][0] for z in c["rows"]]
  # Main and clean containment do not include the research readback; do not treat zero placeholders as measurements.
  action=max(abs(post[i]-actual[i]) for i in range(3)) if name=="priority" else None
  original=normal<=1e-3 and tang<=1e-6 and rigid<=1e-4 and rod<=1e-4 and wd<=1e-4 and (action is None or action<=1e-3) and c["replay"] and c["accepted_momentum_error_ns"]<=1e-5
  strict=normal<=1e-4 and rigid<=1e-7+.01*abs(r["reference"]["impulses_ns"][0]) and rod<=1e-7+.01*abs(sum(r["reference"]["impulses_ns"][1:])) and wd<=1e-6+.01*abs(r["reference"]["work_j"])
  result.append({"initial_vn":c["initial_vn"],"accepted":True,"normal_complementarity_mps":normal,"tangent_impulse_ns":tang,"rigid_impulse_error_ns":rigid,"rod_impulse_error_ns":rod,"work_j":w,"reference_work_j":r["reference"]["work_j"],"work_error_j":wd,"normal_operator_action_error_mps":action,"original_gates_pass":original,"stricter_gates_pass":strict,"replay":c["replay"]})
 out[name]=result
print(json.dumps(out,indent=2))

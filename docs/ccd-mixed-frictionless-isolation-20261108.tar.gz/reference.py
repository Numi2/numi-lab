#!/usr/bin/env python3
"""FP64 frictionless normal reference for retained fixed mixed-geometry operator."""
import itertools,json,math
from pathlib import Path
data=json.loads(Path(__file__).with_name("operator-axis0.json").read_text())["cases"]
out=[]
for c in data:
 rows=c["rows"]
 W=[[rows[i]["operator_rows"][j] for j in range(3)] for i in range(3)]
 W=[[(W[i][j]+W[j][i])/2 for j in range(3)] for i in range(3)]
 pre=[r["pre"] for r in rows];target=[r["target"] for r in rows]; b=[pre[i]-target[i] for i in range(3)]
 M=[[W[0][0],.5*(W[0][1]+W[0][2])],[.5*(W[1][0]+W[2][0]),.25*(W[1][1]+W[1][2]+W[2][1]+W[2][2])]]
 B=[b[0],.5*(b[1]+b[2])]
 solutions=[]
 for active in itertools.product([False,True],repeat=2):
  a,d=active;p=[0.,0.]
  if a and d:
   det=M[0][0]*M[1][1]-M[0][1]*M[1][0]
   p=[(-B[0]*M[1][1]+M[0][1]*B[1])/det,(M[1][0]*B[0]-M[0][0]*B[1])/det]
  elif a:p[0]=-B[0]/M[0][0]
  elif d:p[1]=-B[1]/M[1][1]
  x=[p[0],p[1]*.5,p[1]*.5]
  r=[b[i]+sum(W[i][j]*x[j] for j in range(3)) for i in range(3)]
  if min(x)>=-1e-12 and all(abs(r[i])<1e-6 if x[i]>1e-10 else r[i]>=-1e-6 for i in range(3)):
   work=sum(x[i]*pre[i] for i in range(3))+.5*sum(x[i]*W[i][j]*x[j] for i in range(3) for j in range(3))
   solutions.append({"impulses_ns":x,"normal_residual_mps":r,"post_normal_mps":[r[i]+target[i] for i in range(3)],"work_j":work})
 assert len(solutions)==1,(c["initial_vn"],solutions)
 out.append({"initial_vn":c["initial_vn"],"W":W,"pre":pre,"target":target,"reference":solutions[0]})
print(json.dumps({"assumptions":"captured symmetrized factorized normal operator; equal split of redundant rod normal rows, zero tangential impulse, same geometry and target","cases":out},indent=2))

#!/usr/bin/env python3
"""FP64 row check for captured frictionless sphere fixture; no solver code reused."""
import json, math, pathlib
base=pathlib.Path(__file__).parent
cases=json.loads((base/"result.json").read_text())["cases"]
groups={}
for line in (base/"rows.stderr").read_text().splitlines():
    v=line.split()
    if not v or v[0] != "row": continue
    it,i=map(int,v[1:3])
    x,y,z,g,nx,ny,nz,target,pre,reg,jn,ju,jv=map(float,v[3:])
    assert i==len(groups.setdefault(it,[]))
    assert abs(nx)<1e-7 and abs(ny-1)<1e-7 and abs(nz)<1e-7
    assert abs(target)<1e-7 and abs(pre+0.08175)<1e-7 and reg==0
    assert abs(ju)<1e-7 and abs(jv)<1e-7 and jn>=0
    groups[it].append((x,target,pre,reg,jn))
out=[]
for it,rows in sorted(groups.items()):
    assert len(rows)==257
    j=sum(row[4] for row in rows)
    xj=sum(row[0]*row[4] for row in rows)
    residual=[pre+j+10*x*xj-target+reg*imp for x,target,pre,reg,imp in rows]
    violation=max(abs(v) if row[4]>1e-8 else max(0.,-v) for v,row in zip(residual,rows))
    c=next(c for c in cases if c["contacts"]==257 and c["iterations"]==it)
    assert abs(violation-c["normal_residual"])<5e-6
    out.append(dict(sweeps=it,sum_j=j,first_row_velocity=residual[0],last_row_velocity=residual[-1],max_complementarity_error=violation,gpu_error=c["normal_residual"]))
# At x=0, j0=|v| stops COM motion with no moment; nonnegative impulses at x>=0 and zero moment make all j_i>0 impossible for x_i>0.
print(json.dumps(dict(reference_j0=0.08175,reference_work_j=-0.5*0.08175**2,rows=out),indent=2))

#pragma once

// Transactional file-level import for the existing combined TetGen,
// registered node-map, and facet-ancestry CSV assets. The caller supplies
// already pinned parent and registered-surface state; this helper does not
// admit a physical child volume or start a simulation.
#include "NumiHumanPhysicalSkinChildTetGen.hpp"
#include "NumiHumanConformingTissueRefinementAssets.hpp"
#include "NumiHumanPhysicalSkinChildRegisteredVolumeCSV.hpp"
#include "NumiHumanPhysicalSkinChildRegisteredFacetMaps.hpp"
#include "NumiHumanParentReferenceMassTransfer.hpp"
#include "NumiHumanFractionalSemanticSupportImport.hpp"
#include "NumiHumanSourceCarrierQuadratureImport.hpp"
#include "NumiHumanP1SupportedReferenceAnchorImport.hpp"
#include "NumiHumanRecordedCarrierAllocationImport.hpp"

#include <algorithm>
#include <array>
#include <cctype>
#include <cmath>
#include <iterator>
#include <limits>
#include <numeric>
#include <optional>
#include <filesystem>
#include <fstream>
#include <span>
#include <string>
#include <string_view>

namespace metalrobo::human::coarse_tissue {

struct PhysicalSkinOperationalReferencePullbackAssets {
    std::filesystem::path sourceParentPacketCSV;
    std::filesystem::path sourceTetgenNode,sourceTetgenElements,sourceLabels;
    std::array<std::string,3> sourceTetGenSHA256{};
    std::filesystem::path sourceVolumeAsset,sourceProducerReceipt,sourceSelfAuditReceipt;
    std::string sourceVolumeSHA256,sourceProducerReceiptSHA256,sourceSelfAuditReceiptSHA256;
    std::filesystem::path candidateVolumeAsset,candidateProducerReceipt,candidateSelfAuditReceipt;
    std::string candidateVolumeSHA256,candidateProducerReceiptSHA256,candidateSelfAuditReceiptSHA256;
    // Optional verified source 002 -> exact 530 refinement -> fitted candidate chain.
    std::optional<PhysicalSkinConformingTissueRefinementAssets> conformingTissueRefinement;
    // Authenticate geometry/source receipts, then solve and certify the existing
    // conservative spatial mass problem for arbitrary repaired cell topology.
    // This is not a same-topology pullback or a conforming-refinement claim.
    bool conservativeSpatialReference=false;
    bool fractionalSemanticMassRouteRequired=false;
};

struct PhysicalSkinRegisteredVolumeAssetFiles {
    std::filesystem::path tetgenNode;
    std::filesystem::path tetgenElements;
    std::filesystem::path childLabels;
    std::filesystem::path combinedNodeMapCSV; // existing plain CSV after one-time decompression
    std::filesystem::path facetAncestryCSV;   // existing quoted-ancestry CSV
    // Order: node, elements, labels, combined node map, facet ancestry.
    std::array<std::string,5> expectedSHA256{};
    std::optional<PhysicalSkinFractionalSemanticSupportAssets> fractionalSemanticSupport;
    std::optional<PhysicalSkinSourceCarrierQuadratureAssets> sourceCarrierQuadrature;
    std::optional<PhysicalSkinP1SupportedReferenceAnchorAssets> p1SupportedReferenceAnchor;
    std::optional<std::array<PhysicalSkinRecordedCarrierAllocationCSVAssets,2>> recordedCarrierAllocationCSV;
    PhysicalSkinRegisteredVolumeRegistrationDomain registrationDomain=
        PhysicalSkinRegisteredVolumeRegistrationDomain::sourceMassParent;
    std::optional<PhysicalSkinOperationalReferencePullbackAssets> operationalReferencePullback;
};

struct PhysicalSkinRegisteredVolumeFileImportReport {
    PhysicalSkinChildTetGenImportReport tetgen;
    PhysicalSkinCombinedNodeMapCSVReport nodeMap;
    PhysicalSkinRegisteredFacetCSVReport facetAncestry;
    PhysicalSkinRegisteredVolumeImportReport registeredVolume;
    PhysicalSkinRegisteredFacetMapReport facetMaps;
    std::array<std::string,5> inputSHA256{};
    PhysicalSkinRegisteredVolumeRegistrationDomain registrationDomain=
        PhysicalSkinRegisteredVolumeRegistrationDomain::sourceMassParent;
    std::string operationalReferenceDomainSHA256;
    bool operationalReferencePullbackVerified=false;
    std::string operationalReferencePullbackSHA256;
    bool conformingTissueRefinementVerified=false;
    std::string conformingTissueRefinementVerificationSHA256;
    bool operationalReferenceSpatialTransportVerified=false;
    std::string operationalReferenceSpatialTransportVerificationSHA256;
    double maximumSpatialMassTransportDistanceM=0.0;
    double maximumSourceParentRegistrationDistanceM=0.0;
    double maximumSourceToCandidateReferenceDistanceM=0.0;
    bool fractionalSemanticSupportVerified=false;
    std::string fractionalSemanticSupportVerificationSHA256;
    PhysicalSkinFractionalSemanticSupportImportReport fractionalSemanticSupportImport;
    bool sourceCarrierQuadratureVerified=false;
    PhysicalSkinSourceCarrierQuadratureImportReport sourceCarrierQuadratureImport;
    std::string sourceCarrierTransportTraceSHA256;
    bool p1SupportedReferenceAnchorVerified=false;
    PhysicalSkinP1SupportedReferenceAnchorImportReport p1SupportedReferenceAnchorImport;
    std::array<PhysicalSkinRecordedCarrierAllocationCSVImportReport,2> recordedCarrierAllocationCSVImport{};
    bool recordedCarrierAllocationCSVVerified=false;
    bool physicalAdmission=false;
};

namespace physical_skin_registered_volume_integration_detail {
inline std::string operationalReferenceDomainSHA256(
        const PhysicalSkinChildTetGenImportReport& tetgen,const std::string_view coordinateFrameSHA256) {
    spatial_mass_transport_detail::SHA256Builder hash;
    hash.string("physical-skin-operational-reference-domain.v1");
    hash.string(tetgen.nodeFileSHA256);hash.string(tetgen.elementFileSHA256);
    hash.string(tetgen.labelFileSHA256);hash.string(coordinateFrameSHA256);
    hash.string("positive-f32-tetgen-reference-with-explicit-cell-labels");
    return hash.finish();
}
struct PhysicalSkinRuntimeMeshQualityPreflightReport {
    std::size_t childTetrahedra=0u;
    std::size_t normalizedDeterminantBelowFloor=0u;
    std::size_t signedVolumeAtOrBelowFloor=0u;
    std::array<std::size_t,2> normalizedDeterminantBelowFloorByRole{};
    std::array<std::size_t,2> signedVolumeAtOrBelowFloorByRole{};
    std::array<std::uint32_t,2> firstNormalizedDeterminantFailureByRole{
        NM_INVALID_INDEX,NM_INVALID_INDEX};
    std::array<std::uint32_t,2> firstSignedVolumeFailureByRole{
        NM_INVALID_INDEX,NM_INVALID_INDEX};
    std::array<double,2> minimumNormalizedDeterminantByRole{
        std::numeric_limits<double>::infinity(),std::numeric_limits<double>::infinity()};
    std::array<double,2> minimumSignedVolumeM3ByRole{
        std::numeric_limits<double>::infinity(),std::numeric_limits<double>::infinity()};
};

[[nodiscard]] inline bool preflightPhysicalSkinRuntimeMeshQuality(
        const PhysicalSkinChildMassMappingBundle& bundle,
        PhysicalSkinRuntimeMeshQualityPreflightReport& report,std::string& error) {
    const auto fail=[&](std::string message){error=std::move(message);return false;};
    report={};
    const auto& points=bundle.referenceWorldPoints;
    const auto& tets=bundle.childTetrahedra;
    const auto& materials=bundle.childMaterialIndices;
    if(points.empty()||tets.empty()||materials.size()!=tets.size()||
       points.size()>std::numeric_limits<std::uint32_t>::max()||
       tets.size()>std::numeric_limits<std::uint32_t>::max())
        return fail("physical runtime mesh quality preflight has incomplete point/tet/material domains");
    report.childTetrahedra=tets.size();
    constexpr double minimumNormalizedDeterminant=1.0e-5;
    constexpr double minimumSignedTetVolumeM3=1.0e-18;
    for(std::size_t child=0;child<tets.size();++child){
        const auto material=materials[child];
        const std::size_t role=material==15u?0u:(material==16u?1u:2u);
        std::array<V3,4> emitted{};
        for(unsigned corner=0;corner<4u;++corner){
            const auto node=tets[child][corner];
            if(node>=points.size())return fail("physical runtime mesh quality preflight found an out-of-range tet node");
            for(unsigned axis=0;axis<3u;++axis){
                const double coordinate=points[node][axis];
                if(!std::isfinite(coordinate))return fail("physical runtime mesh quality preflight found a nonfinite node coordinate");
                emitted[corner][axis]=static_cast<double>(static_cast<float>(coordinate));
            }
        }
        double longest=0.0;
        for(unsigned a=0;a<4u;++a)for(unsigned b=a+1u;b<4u;++b){
            const double dx=emitted[a][0]-emitted[b][0];
            const double dy=emitted[a][1]-emitted[b][1];
            const double dz=emitted[a][2]-emitted[b][2];
            longest=std::max(longest,std::sqrt(dx*dx+dy*dy+dz*dz));
        }
        const double signedVolume=tetVolume(emitted[0],emitted[1],emitted[2],emitted[3]);
        const double normalizedDeterminant=longest>0.0&&std::isfinite(longest)?
            6.0*signedVolume/(longest*longest*longest):-std::numeric_limits<double>::infinity();
        if(role<2u){
            report.minimumNormalizedDeterminantByRole[role]=std::min(
                report.minimumNormalizedDeterminantByRole[role],normalizedDeterminant);
            report.minimumSignedVolumeM3ByRole[role]=std::min(
                report.minimumSignedVolumeM3ByRole[role],signedVolume);
        }
        if(!std::isfinite(normalizedDeterminant)||normalizedDeterminant<minimumNormalizedDeterminant){
            ++report.normalizedDeterminantBelowFloor;
            if(role<2u){
                ++report.normalizedDeterminantBelowFloorByRole[role];
                if(report.firstNormalizedDeterminantFailureByRole[role]==NM_INVALID_INDEX)
                    report.firstNormalizedDeterminantFailureByRole[role]=static_cast<std::uint32_t>(child);
            }
        }
        if(!std::isfinite(signedVolume)||signedVolume<=minimumSignedTetVolumeM3){
            ++report.signedVolumeAtOrBelowFloor;
            if(role<2u){
                ++report.signedVolumeAtOrBelowFloorByRole[role];
                if(report.firstSignedVolumeFailureByRole[role]==NM_INVALID_INDEX)
                    report.firstSignedVolumeFailureByRole[role]=static_cast<std::uint32_t>(child);
            }
        }
    }
    if(report.normalizedDeterminantBelowFloor||report.signedVolumeAtOrBelowFloor){
        const auto witness=[](const std::uint32_t row){
            return row==NM_INVALID_INDEX?std::string("none"):std::to_string(row);
        };
        error="geometry-not-ready: Float32 runtime quality preflight found normalizedDet<1e-5="+
            std::to_string(report.normalizedDeterminantBelowFloor)+" (Skin="+
            std::to_string(report.normalizedDeterminantBelowFloorByRole[0])+", Fat="+
            std::to_string(report.normalizedDeterminantBelowFloorByRole[1])+
            "; first Skin/Fat rows="+witness(report.firstNormalizedDeterminantFailureByRole[0])+"/"+
            witness(report.firstNormalizedDeterminantFailureByRole[1])+") and signedVolume<=1e-18m3="+
            std::to_string(report.signedVolumeAtOrBelowFloor)+" (Skin="+
            std::to_string(report.signedVolumeAtOrBelowFloorByRole[0])+", Fat="+
            std::to_string(report.signedVolumeAtOrBelowFloorByRole[1])+
            "; first Skin/Fat rows="+witness(report.firstSignedVolumeFailureByRole[0])+"/"+
            witness(report.firstSignedVolumeFailureByRole[1])+")";
        return false;
    }
    error.clear();return true;
}

inline bool sameImmutableParentPacket(const PhysicalSkinParentMassPacket& a,
                                      const PhysicalSkinParentMassPacket& b) {
    return a.currentWorldPoints==b.currentWorldPoints&&a.referenceWorldPoints==b.referenceWorldPoints&&
        a.compiledLumpedNodeMassKg==b.compiledLumpedNodeMassKg&&
        a.compiledGlobalNodeIndices==b.compiledGlobalNodeIndices&&
        a.nodeFrameOwnerBodyIndices==b.nodeFrameOwnerBodyIndices&&
        a.nodeFrameOwnerLocalPoints==b.nodeFrameOwnerLocalPoints&&a.tetrahedra==b.tetrahedra&&
        a.referenceTetVolumeM3==b.referenceTetVolumeM3&&a.tetrahedronMassKg==b.tetrahedronMassKg&&
        a.materialIndices==b.materialIndices&&a.donorBodyIndices==b.donorBodyIndices&&
        a.anatomicalRegionIndices==b.anatomicalRegionIndices&&
        a.stableSourceFaceIdentities==b.stableSourceFaceIdentities&&
        a.sourceMassContributions.size()==b.sourceMassContributions.size()&&
        std::equal(a.sourceMassContributions.begin(),a.sourceMassContributions.end(),
            b.sourceMassContributions.begin(),[](const auto& x,const auto& y){
                return x.parentNodeIndex==y.parentNodeIndex&&x.materialIndex==y.materialIndex&&
                    x.donorBodyIndex==y.donorBodyIndex&&x.massKg==y.massKg&&
                    x.donorLocalPosition==y.donorLocalPosition;
            })&&
        a.parentMassPacketSHA256==b.parentMassPacketSHA256&&
        a.parentSourceContributionSHA256==b.parentSourceContributionSHA256&&
        a.parentTopologySHA256==b.parentTopologySHA256&&a.parentLabelSHA256==b.parentLabelSHA256&&
        a.totalMassKg==b.totalMassKg&&
        a.maximumNodalMassClosureErrorKg==b.maximumNodalMassClosureErrorKg&&
        a.maximumNodalMassClosureRelativeError==b.maximumNodalMassClosureRelativeError;
}
inline bool pinnedFile(const std::filesystem::path& path,const std::string& expected,
                       std::string& actual,std::string& error) {
    if(path.empty()||!physical_skin_child_mass_detail::validSHA256(expected)){
        error="registered volume import requires an explicit path and lowercase SHA-256 pin";
        return false;
    }
    if(!physical_skin_child_mass_detail::sha256File(path,actual,error))return false;
    if(actual!=expected){
        error="registered volume import file hash differs from its declared pin: "+path.string();
        return false;
    }
    return true;
}
inline bool readPinnedText(const std::filesystem::path& path,const std::string& expected,
                           std::string& text,std::string& error) {
    std::string actual;
    if(!pinnedFile(path,expected,actual,error))return false;
    std::error_code sizeError;
    const auto bytes=std::filesystem::file_size(path,sizeError);
    if(sizeError||bytes>4u*1024u*1024u){error="operational-reference receipt is unreadable or oversized";return false;}
    std::ifstream input(path,std::ios::binary);
    if(!input){error="cannot open pinned operational-reference receipt: "+path.string();return false;}
    text.assign(std::istreambuf_iterator<char>(input),std::istreambuf_iterator<char>());
    if(input.bad()){error="failed while reading pinned operational-reference receipt";return false;}
    std::string after;
    if(!pinnedFile(path,expected,after,error)||after!=actual){
        if(error.empty())error="pinned operational-reference receipt changed while it was being read";
        return false;
    }
    return true;
}
inline bool jsonValueDelimiter(const std::string_view json,const std::size_t pos) {
    return pos<json.size()&&
        (std::isspace(static_cast<unsigned char>(json[pos]))||json[pos]==','||
         json[pos]=='}'||json[pos]==']');
}
inline bool jsonStringFieldMatches(const std::string_view json,const std::string_view key,
                                   const std::string_view expected,const std::size_t expectedCount,
                                   std::string& error) {
    const std::string token="\""+std::string(key)+"\"";
    std::size_t count=0u,pos=0u;
    while((pos=json.find(token,pos))!=std::string_view::npos){
        ++count;pos+=token.size();
        while(pos<json.size()&&std::isspace(static_cast<unsigned char>(json[pos])))++pos;
        if(pos>=json.size()||json[pos++]!=':'){error="malformed JSON receipt field "+std::string(key);return false;}
        while(pos<json.size()&&std::isspace(static_cast<unsigned char>(json[pos])))++pos;
        if(pos>=json.size()||json[pos++]!='\"'){error="JSON receipt field is not a string: "+std::string(key);return false;}
        std::string value;
        bool closed=false;
        while(pos<json.size()){
            const char c=json[pos++];
            if(c=='\\'){
                if(pos>=json.size()){error="truncated JSON escape in "+std::string(key);return false;}
                value.push_back(json[pos++]);
            }else if(c=='\"'){closed=true;break;}
            else value.push_back(c);
        }
        if(!closed||!jsonValueDelimiter(json,pos)||value!=expected){
            error="JSON receipt field differs from its pin or is not a complete token: "+std::string(key);return false;
        }
    }
    if(count!=expectedCount){error="JSON receipt field count differs from its contract: "+std::string(key);return false;}
    return true;
}
inline bool jsonBooleanFieldMatches(const std::string_view json,const std::string_view key,
                                    const bool expected,std::string& error,
                                    const std::size_t expectedCount=1u) {
    const std::string token="\""+std::string(key)+"\"";
    std::size_t count=0u,pos=0u;
    while((pos=json.find(token,pos))!=std::string_view::npos){
        ++count;auto cursor=pos+token.size();
        while(cursor<json.size()&&std::isspace(static_cast<unsigned char>(json[cursor])))++cursor;
        if(cursor>=json.size()||json[cursor++]!=':'){error="malformed JSON receipt boolean field";return false;}
        while(cursor<json.size()&&std::isspace(static_cast<unsigned char>(json[cursor])))++cursor;
        const auto literal=expected?std::string_view("true"):std::string_view("false");
        if(json.substr(cursor,literal.size())!=literal){error="JSON receipt boolean field differs from its contract: "+std::string(key);return false;}
        cursor+=literal.size();
        if(!jsonValueDelimiter(json,cursor)){
            error="JSON receipt boolean is not a complete token: "+std::string(key);return false;
        }
        pos=cursor;
    }
    if(count!=expectedCount){error="JSON receipt boolean field count differs from its contract: "+std::string(key)+
        " actual="+std::to_string(count)+" expected="+std::to_string(expectedCount);return false;}
    return true;
}
inline bool jsonExactlyZeroFields(const std::string_view json,const std::string_view key,
                                  const std::size_t expectedCount,std::string& error) {
    const std::string token="\""+std::string(key)+"\"";
    std::size_t count=0u,pos=0u;
    while((pos=json.find(token,pos))!=std::string_view::npos){
        ++count;pos+=token.size();
        while(pos<json.size()&&std::isspace(static_cast<unsigned char>(json[pos])))++pos;
        if(pos>=json.size()||json[pos++]!=':'){error="malformed JSON receipt numeric field "+std::string(key);return false;}
        while(pos<json.size()&&std::isspace(static_cast<unsigned char>(json[pos])))++pos;
        if(pos>=json.size()||json[pos++]!='0'||!jsonValueDelimiter(json,pos)){
            error="self-intersection receipt contains a nonzero or malformed integer pair count";return false;
        }
    }
    if(count!=expectedCount){error="self-intersection receipt does not contain the expected exact layer counts";return false;}
    return true;
}
inline bool authenticateSelfReceipt(const std::filesystem::path& path,const std::string& receiptSHA,
                                    const std::string& volumeSHA,std::string& error,
                                    const bool allowRefinedSelfAudit=false) {
    std::string text;
    if(!readPinnedText(path,receiptSHA,text,error))return false;
    if(!jsonStringFieldMatches(text,"status","exact_coarse_material_boundary_self_audit",1u,error)){
        error.clear();
        if(!allowRefinedSelfAudit||
           !jsonStringFieldMatches(text,"status","exact_refined_material_boundary_self_audit",1u,error))
            return false;
    }
    return jsonStringFieldMatches(text,"candidate_sha256",volumeSHA,1u,error)&&
        jsonBooleanFieldMatches(text,"physical_admission",false,error)&&
        jsonExactlyZeroFields(text,"self_intersection_pairs",2u,error);
}
inline bool authenticateOperationalReferenceReceipts(
        const PhysicalSkinOperationalReferencePullbackAssets& proof,
        const std::array<std::string,3>& sourceFileSHA256,
        const std::array<std::string,3>& candidateFileSHA256,
        const std::string& candidateNodeMapSHA256,
        const std::string& candidateFacetMapSHA256,
        const std::string_view coordinateFrameSHA256,
        const PhysicalSkinParentMassPacket& parent,std::string& error) {
    std::string actual;
    if(!pinnedFile(proof.sourceParentPacketCSV,parent.parentMassPacketSHA256,actual,error))return false;
    if(!pinnedFile(proof.sourceVolumeAsset,proof.sourceVolumeSHA256,actual,error))return false;
    if(!pinnedFile(proof.candidateVolumeAsset,proof.candidateVolumeSHA256,actual,error))return false;
    std::string sourceReceipt,candidateReceipt;
    if(!readPinnedText(proof.sourceProducerReceipt,proof.sourceProducerReceiptSHA256,sourceReceipt,error)||
       !readPinnedText(proof.candidateProducerReceipt,proof.candidateProducerReceiptSHA256,candidateReceipt,error))return false;
    const std::array<std::string_view,3> sourceOutputKeys{
        "parent-reduced-boundary.node","parent-reduced-boundary.ele","parent-reduced-boundary.labels.csv"};
    if(sourceReceipt.find(R"json("schema": "NumiHuman.reduced-parent-boundary-candidate.v1")json")==std::string::npos||
       !jsonStringFieldMatches(sourceReceipt,"status","bounded_reduced_boundary_candidate_not_physical_admission",1u,error)||
       !jsonBooleanFieldMatches(sourceReceipt,"physical_admission",false,error)||
       !jsonBooleanFieldMatches(sourceReceipt,"all_child_rows_match_parent_row",true,error)||
       !jsonStringFieldMatches(sourceReceipt,"candidate.npz",proof.sourceVolumeSHA256,1u,error))return false;
    for(unsigned i=0u;i<sourceOutputKeys.size();++i)
        if(!jsonStringFieldMatches(sourceReceipt,sourceOutputKeys[i],sourceFileSHA256[i],1u,error))return false;
    if(candidateReceipt.find(R"json("schema": "numi-human.registered-volume-parent-identity-source-control.v1")json")==std::string::npos||
       !jsonBooleanFieldMatches(candidateReceipt,"physical_admission",false,error,2u)||
       !jsonStringFieldMatches(candidateReceipt,"registration_domain","candidateOperationalReference",1u,error)||
       !jsonStringFieldMatches(candidateReceipt,"candidate_npz_sha256",proof.candidateVolumeSHA256,2u,error)||
       !jsonStringFieldMatches(candidateReceipt,"candidate_node_sha256",candidateFileSHA256[0],1u,error)||
       !jsonStringFieldMatches(candidateReceipt,"candidate_element_sha256",candidateFileSHA256[1],1u,error)||
       !jsonStringFieldMatches(candidateReceipt,"candidate_labels_sha256",candidateFileSHA256[2],1u,error)||
       !jsonStringFieldMatches(candidateReceipt,"node_map_sha256",candidateNodeMapSHA256,1u,error)||
       !jsonStringFieldMatches(candidateReceipt,(proof.candidateProducerReceipt.parent_path()/"volume/facet-ancestry.csv").string(),
                               candidateFacetMapSHA256,1u,error)||
       !jsonStringFieldMatches(candidateReceipt,"coordinate_frame_sha256",coordinateFrameSHA256,2u,error)||
       !jsonStringFieldMatches(candidateReceipt,"immutable_source_parent_packet_sha256",
                               parent.parentMassPacketSHA256,1u,error))return false;
    return authenticateSelfReceipt(proof.sourceSelfAuditReceipt,proof.sourceSelfAuditReceiptSHA256,
                                   proof.sourceVolumeSHA256,error)&&
        authenticateSelfReceipt(proof.candidateSelfAuditReceipt,proof.candidateSelfAuditReceiptSHA256,
                                proof.candidateVolumeSHA256,error,proof.conformingTissueRefinement.has_value());
}
inline bool sameOperationalReferenceCellDomain(
        const PhysicalSkinChildMassMappingBundle& a,
        const PhysicalSkinChildMassMappingBundle& b) {
    return a.referenceWorldPoints.size()==b.referenceWorldPoints.size()&&
        a.childTetrahedra==b.childTetrahedra&&
        a.childMaterialIndices==b.childMaterialIndices&&
        a.childDonorBodyIndices==b.childDonorBodyIndices&&
        a.childAnatomicalRegionIndices==b.childAnatomicalRegionIndices&&
        a.childStableSourceFaceIdentities==b.childStableSourceFaceIdentities;
}
inline bool sameOperationalReferenceCellDomain(
        const PhysicalSkinChildMassMappingBundle& bundle,
        const PhysicalSkinVerifiedConformingReference& refined) {
    return bundle.referenceWorldPoints.size()==refined.referenceWorldPoints.size()&&
        bundle.childTetrahedra==refined.tetrahedra&&
        bundle.childMaterialIndices==refined.materialIndices&&
        bundle.childDonorBodyIndices==refined.geometricDonorBodyIndices&&
        bundle.childAnatomicalRegionIndices==refined.anatomicalRegionIndices&&
        bundle.childStableSourceFaceIdentities==refined.stableSourceFaceIds;
}

inline bool verifyOperationalReferencePullback(
        const PhysicalSkinOperationalReferencePullbackAssets& proof,
        const std::string_view coordinateFrameSHA256,const std::size_t sourceBodyCount,
        const double maximumMassTransportDistanceM,const PhysicalSkinChildMassMappingBundle& candidate,
        const std::span<const PhysicalSkinRegisteredVolumeNodeRow> candidateNodeRows,
        const std::array<std::string,3>& candidateFileSHA256,
        const std::string& candidateNodeMapSHA256,const std::string& candidateFacetMapSHA256,
        SameTopologyReferencePullbackResult& result,double& maximumSourceParentRegistrationDistanceM,
        std::string& conformingTissueVerificationSHA256,
        PhysicalSkinVerifiedConformingMassRoute& verifiedMassRoute,
        ConservativeSpatialMassTransportResult& verifiedSpatialTransport,
        SourceCellCarrierTransportTrace& verifiedSourceCarrierTrace,
        std::string& spatialReferenceVerificationSHA256,std::string& error) {
    PhysicalSkinChildMassMappingBundle source;source.parent=candidate.parent;
    PhysicalSkinChildTetGenImportReport sourceReport;
    if(!loadPhysicalSkinChildTetGenReference(proof.sourceTetgenNode,proof.sourceTetgenElements,
            proof.sourceLabels,coordinateFrameSHA256,sourceBodyCount,maximumMassTransportDistanceM,
            source,sourceReport,error))return false;
    if(sourceReport.nodeFileSHA256!=proof.sourceTetGenSHA256[0]||
       sourceReport.elementFileSHA256!=proof.sourceTetGenSHA256[1]||
       sourceReport.labelFileSHA256!=proof.sourceTetGenSHA256[2])
        {error="operational-reference source TetGen file pins differ from the producer receipt";return false;}
    const auto& parent=candidate.parent;
    if(!authenticateOperationalReferenceReceipts(proof,
            {sourceReport.nodeFileSHA256,sourceReport.elementFileSHA256,sourceReport.labelFileSHA256},
            candidateFileSHA256,candidateNodeMapSHA256,candidateFacetMapSHA256,
            coordinateFrameSHA256,parent,error))return false;
    if(source.referenceWorldPoints.size()!=parent.referenceWorldPoints.size()||
       source.childTetrahedra!=parent.tetrahedra||source.childMaterialIndices!=parent.materialIndices||
       source.childDonorBodyIndices!=parent.donorBodyIndices||
       source.childAnatomicalRegionIndices!=parent.anatomicalRegionIndices||
       source.childStableSourceFaceIdentities!=parent.stableSourceFaceIdentities)
        {error="operational-reference source volume requires exact immutable-parent cell and label correspondence";return false;}
    maximumSourceParentRegistrationDistanceM=0.0;
    for(std::size_t node=0u;node<source.referenceWorldPoints.size();++node){
        V3 f32Parent{};
        for(unsigned axis=0u;axis<3u;++axis)
            f32Parent[axis]=static_cast<double>(static_cast<float>(parent.referenceWorldPoints[node][axis]));
        maximumSourceParentRegistrationDistanceM=std::max(maximumSourceParentRegistrationDistanceM,
            norm(sub(source.referenceWorldPoints[node],f32Parent)));
    }
    if(maximumSourceParentRegistrationDistanceM>0.0004){
        error="operational-reference source registration exceeds the unchanged 0.4 mm source gate";return false;
    }
    if(proof.conservativeSpatialReference&&proof.conformingTissueRefinement){
        error="operational-reference routes are mutually exclusive";return false;
    }
    if(proof.fractionalSemanticMassRouteRequired&&!proof.conservativeSpatialReference){
        error="fractional semantic support is available only on the authenticated conservative spatial-reference route";return false;
    }
    if(proof.fractionalSemanticMassRouteRequired&&!candidate.fractionalSemanticMassRouteRequired){
        error="fractional semantic support was required but not imported into the candidate mass bundle";return false;
    }
    if(proof.conformingTissueRefinement){
        PhysicalSkinVerifiedConformingReference refined;
        if(!verifyPhysicalSkinConformingTissueRefinementAssets(
                *proof.conformingTissueRefinement,source,proof.sourceVolumeSHA256,sourceBodyCount,refined,error))
            return false;
        if(!sameOperationalReferenceCellDomain(candidate,refined)){
            error="candidate operational reference is not the exact node/cell/label row domain produced by the authenticated 530 refinement";
            return false;
        }
        std::vector<std::uint32_t> identityNodes(candidate.referenceWorldPoints.size());
        std::vector<std::uint32_t> identityTets(candidate.childTetrahedra.size());
        std::iota(identityNodes.begin(),identityNodes.end(),0u);
        std::iota(identityTets.begin(),identityTets.end(),0u);
        std::vector<double> densityLower(17u,0.0),densityUpper(17u,0.0);
        densityLower[15u]=900.0;densityUpper[15u]=1100.0;
        densityLower[16u]=850.0;densityUpper[16u]=950.0;
        for(const auto material:refined.materialIndices)
            if(material!=15u&&material!=16u){error="530 refined pullback has no authoritative material density bounds";return false;}
        SameTopologyReferencePullbackInput refinedInput{
            .sourceReferencePoints=refined.referenceWorldPoints,
            .candidateReferencePoints=candidate.referenceWorldPoints,
            .candidateToSourceNodeRows=identityNodes,
            .sourceTetrahedra=refined.tetrahedra,
            .candidateTetrahedra=candidate.childTetrahedra,
            .candidateToSourceTetRows=identityTets,
            .sourceMaterialIds=refined.materialIndices,
            .candidateMaterialIds=candidate.childMaterialIndices,
            .sourceGeometricDonorIds=refined.geometricDonorBodyIndices,
            .candidateGeometricDonorIds=candidate.childDonorBodyIndices,
            .sourceRegionIds=refined.anatomicalRegionIndices,
            .candidateRegionIds=candidate.childAnatomicalRegionIndices,
            .sourceStableFaceIds=refined.stableSourceFaceIds,
            .candidateStableFaceIds=candidate.childStableSourceFaceIdentities,
            .sourceCellMassKg=refined.refinement.childMassKg,
            .materialDensityLowerKgM3=densityLower,.materialDensityUpperKgM3=densityUpper,
            .sourceVolumeSHA256=refined.refinedVolumeSHA256,
            .candidateVolumeSHA256=proof.candidateVolumeSHA256,
            .parentMassPacketSHA256=parent.parentMassPacketSHA256,
            .parentSourceContributionSHA256=parent.parentSourceContributionSHA256,
            .sourceBoundarySelfAuditSHA256=proof.conformingTissueRefinement->selfAuditReceiptSHA256,
            .candidateBoundarySelfAuditSHA256=proof.candidateSelfAuditReceiptSHA256,
            .sourceBoundarySelfIntersectionPairs=0u,.candidateBoundarySelfIntersectionPairs=0u};
        if(!verifySameTopologyReferencePullback(refinedInput,result,error))return false;
        spatial_mass_transport_detail::SHA256Builder chainHash;
        chainHash.string("physical-skin-operational-reference-conforming-chain.v1");
        chainHash.string(refined.refinement.verificationSHA256);
        chainHash.string(refined.sourceDonorLedgerVerificationSHA256);
        chainHash.string(result.verificationSHA256);
        chainHash.string(proof.sourceVolumeSHA256);chainHash.string(proof.candidateVolumeSHA256);
        conformingTissueVerificationSHA256=chainHash.finish();
        PhysicalSkinVerifiedConformingMassRoute nextRoute;
        nextRoute.authenticated=true;
        nextRoute.refinedSourceCellCount=refined.tetrahedra.size();
        nextRoute.childRefinedSourceRows.resize(candidate.childTetrahedra.size());
        nextRoute.childImmutableParentRows.resize(candidate.childTetrahedra.size());
        nextRoute.childImmutableParentFractions.resize(candidate.childTetrahedra.size());
        nextRoute.childImmutableParentReferenceMeasureM3.resize(candidate.childTetrahedra.size());
        nextRoute.childMassKg.resize(candidate.childTetrahedra.size());
        nextRoute.childSourceDonorOffsets.reserve(candidate.childTetrahedra.size()+1u);
        nextRoute.childSourceDonorOffsets.push_back(0u);
        for(std::size_t child=0u;child<candidate.childTetrahedra.size();++child){
            const auto begin=result.childParentAncestryOffsets[child];
            const auto end=result.childParentAncestryOffsets[child+1u];
            if(end!=begin+1u||end>result.childParentAncestryTetrahedra.size()||
               end>result.childParentAncestryVolumeFractions.size()||
               result.childParentAncestryVolumeFractions[begin]!=1.0){
                error="verified 530-to-candidate reference pullback is not a single exact row ancestry";return false;
            }
            const auto refinedRow=result.childParentAncestryTetrahedra[begin];
            if(refinedRow>=refined.refinement.childParentRows.size()||
               refinedRow>=refined.refinement.childSourceMeasureFractions.size()||
               refinedRow>=refined.refinement.childParentImmutableReferenceMeasureM3.size()||
               refinedRow>=refined.refinement.childMassKg.size()||
               refinedRow+1u>=refined.sourceDonorOffsets.size()||
               result.childMassKg[child]!=refined.refinement.childMassKg[refinedRow]){
                error="verified 530-to-candidate child mass differs from the immutable-330 refinement ledger";return false;
            }
            nextRoute.childRefinedSourceRows[child]=refinedRow;
            nextRoute.childImmutableParentRows[child]=refined.refinement.childParentRows[refinedRow];
            nextRoute.childImmutableParentFractions[child]=refined.refinement.childSourceMeasureFractions[refinedRow];
            nextRoute.childImmutableParentReferenceMeasureM3[child]=
                refined.refinement.childParentImmutableReferenceMeasureM3[refinedRow];
            nextRoute.childMassKg[child]=result.childMassKg[child];
            const auto donorBegin=refined.sourceDonorOffsets[refinedRow];
            const auto donorEnd=refined.sourceDonorOffsets[refinedRow+1u];
            if(donorBegin>=donorEnd||donorEnd>refined.sourceDonorBodyIndices.size()||
               donorEnd>refined.sourceDonorMassKg.size()){
                error="verified 534 source-donor ledger has an empty or invalid refined child row";return false;
            }
            nextRoute.childSourceDonorBodyIndices.insert(nextRoute.childSourceDonorBodyIndices.end(),
                refined.sourceDonorBodyIndices.begin()+donorBegin,
                refined.sourceDonorBodyIndices.begin()+donorEnd);
            nextRoute.childSourceDonorMassKg.insert(nextRoute.childSourceDonorMassKg.end(),
                refined.sourceDonorMassKg.begin()+donorBegin,
                refined.sourceDonorMassKg.begin()+donorEnd);
            nextRoute.childSourceDonorOffsets.push_back(
                static_cast<std::uint32_t>(nextRoute.childSourceDonorBodyIndices.size()));
        }
        nextRoute.parentMassPacketSHA256=parent.parentMassPacketSHA256;
        nextRoute.parentSourceContributionSHA256=parent.parentSourceContributionSHA256;
        nextRoute.sourceVolumeSHA256=proof.sourceVolumeSHA256;
        nextRoute.refinedVolumeSHA256=refined.refinedVolumeSHA256;
        nextRoute.candidateVolumeSHA256=proof.candidateVolumeSHA256;
        nextRoute.refinementVerificationSHA256=refined.refinement.verificationSHA256;
        nextRoute.sourceDonorLedgerVerificationSHA256=refined.sourceDonorLedgerVerificationSHA256;
        nextRoute.pullbackVerificationSHA256=result.verificationSHA256;
        nextRoute.chainVerificationSHA256=conformingTissueVerificationSHA256;
        nextRoute.verificationSHA256=physical_skin_child_mass_mapping_detail::
            verifiedConformingMassRouteSHA256(nextRoute);
        verifiedMassRoute=std::move(nextRoute);
        return true;
    }
    if(proof.conservativeSpatialReference){
        auto mapped=candidate;
        mapped.operationalSpatialMassRouteRequired=false;
        mapped.operationalSpatialReferenceVerificationSHA256.clear();
        mapped.operationalSpatialTransportReceiptSHA256.clear();
        mapped.conformingLineageMassRouteRequired=false;
        mapped.conformingLineageMassTransportUsed=false;
        mapped.conformingLineageMassRoute={};
        std::vector<double> lower(17u,0.0),upper(17u,0.0);
        lower[15u]=900.0;upper[15u]=1100.0;
        lower[16u]=850.0;upper[16u]=950.0;
        if(!preparePhysicalSkinChildMassMapping(mapped,lower,upper,
                maximumMassTransportDistanceM,sourceBodyCount,error)){
            error="operational-reference conservative transport rejected: "+error;return false;
        }
        spatial_mass_transport_detail::SHA256Builder chain;
        chain.string("physical-skin-operational-spatial-reference.v1");
        chain.string(proof.sourceVolumeSHA256);chain.string(proof.candidateVolumeSHA256);
        chain.string(proof.sourceProducerReceiptSHA256);chain.string(proof.candidateProducerReceiptSHA256);
        chain.string(proof.sourceSelfAuditReceiptSHA256);chain.string(proof.candidateSelfAuditReceiptSHA256);
        chain.string(candidateNodeMapSHA256);chain.string(candidateFacetMapSHA256);
        chain.string(coordinateFrameSHA256);
        chain.string(mapped.spatialMassTransportResult.receiptSHA256);
        if(mapped.sourceCarrierQuadrature.importedAndVerified&&mapped.sourceCarrierQuadrature.hasCarriers()){
            if(!physical_skin_child_mass_detail::validSHA256(mapped.sourceCarrierQuadrature.transportTrace.receiptSHA256)){
                error="source-carrier transport trace lacks a current-input feasibility receipt";return false;
            }
            chain.string(mapped.sourceCarrierQuadrature.verificationSHA256);
            chain.string(mapped.sourceCarrierQuadrature.transportTrace.receiptSHA256);
            const auto& recorded=mapped.sourceCarrierQuadrature.recordedAllocation;
            if(recorded.importedAndPinned){
                if(!physical_skin_child_mass_detail::validSHA256(recorded.allocationReceiptSHA256)||
                   !physical_skin_child_mass_detail::validSHA256(recorded.sourceCarrierFlowTraceSHA256)){
                    error="recorded role allocation receipt or producer flow trace pin is missing";return false;
                }
                chain.string(recorded.allocationReceiptSHA256);
                chain.string(recorded.sourceCarrierFlowTraceSHA256);
                for(const auto& sha:recorded.roleReceiptSHA256)chain.string(sha);
            }
            verifiedSourceCarrierTrace=mapped.sourceCarrierQuadrature.transportTrace;
        }
        spatialReferenceVerificationSHA256=chain.finish();
        verifiedSpatialTransport=std::move(mapped.spatialMassTransportResult);
        result={}; // No same-topology correspondence is asserted for this route.
        error.clear();return true;
    }
    // The legacy route still requires the source and candidate to share one
    // exact node/cell/label domain. The explicit refinement route above instead
    // binds the candidate to the separately authenticated 530 domain.
    if(!sameOperationalReferenceCellDomain(candidate,source))
        {error="legacy operational-reference pullback requires exact source/candidate cell and label correspondence";return false;}
    std::vector<std::uint32_t> candidateToSourceNodeRows(candidate.referenceWorldPoints.size(),NM_INVALID_INDEX);
    for(const auto& row:candidateNodeRows){
        if(row.volumeNodeRow>=candidateToSourceNodeRows.size()||
           row.sourceParentNodeRow>=source.referenceWorldPoints.size()||
           candidateToSourceNodeRows[row.volumeNodeRow]!=NM_INVALID_INDEX){
            error="operational-reference node map lacks a unique retained source-node correspondence";return false;
        }
        candidateToSourceNodeRows[row.volumeNodeRow]=row.sourceParentNodeRow;
    }
    if(std::any_of(candidateToSourceNodeRows.begin(),candidateToSourceNodeRows.end(),
                   [](auto row){return row==NM_INVALID_INDEX;})){
        error="operational-reference node map does not cover every source node";return false;
    }
    std::vector<std::uint32_t> candidateToSourceTetRows(candidate.childTetrahedra.size());
    std::iota(candidateToSourceTetRows.begin(),candidateToSourceTetRows.end(),0u);
    std::vector<double> densityLower(17u,0.0),densityUpper(17u,0.0);
    densityLower[15u]=900.0;densityUpper[15u]=1100.0;
    densityLower[16u]=850.0;densityUpper[16u]=950.0;
    for(const auto material:parent.materialIndices)
        if(material!=15u&&material!=16u){error="operational-reference pullback has no authoritative material density bounds";return false;}
    SameTopologyReferencePullbackInput input{
        .sourceReferencePoints=source.referenceWorldPoints,
        .candidateReferencePoints=candidate.referenceWorldPoints,
        .candidateToSourceNodeRows=candidateToSourceNodeRows,
        .sourceTetrahedra=source.childTetrahedra,
        .candidateTetrahedra=candidate.childTetrahedra,
        .candidateToSourceTetRows=candidateToSourceTetRows,
        .sourceMaterialIds=source.childMaterialIndices,
        .candidateMaterialIds=candidate.childMaterialIndices,
        .sourceGeometricDonorIds=source.childDonorBodyIndices,
        .candidateGeometricDonorIds=candidate.childDonorBodyIndices,
        .sourceRegionIds=source.childAnatomicalRegionIndices,
        .candidateRegionIds=candidate.childAnatomicalRegionIndices,
        .sourceStableFaceIds=source.childStableSourceFaceIdentities,
        .candidateStableFaceIds=candidate.childStableSourceFaceIdentities,
        .sourceCellMassKg=parent.tetrahedronMassKg,
        .materialDensityLowerKgM3=densityLower,.materialDensityUpperKgM3=densityUpper,
        .sourceVolumeSHA256=proof.sourceVolumeSHA256,
        .candidateVolumeSHA256=proof.candidateVolumeSHA256,
        .parentMassPacketSHA256=parent.parentMassPacketSHA256,
        .parentSourceContributionSHA256=parent.parentSourceContributionSHA256,
        .sourceBoundarySelfAuditSHA256=proof.sourceSelfAuditReceiptSHA256,
        .candidateBoundarySelfAuditSHA256=proof.candidateSelfAuditReceiptSHA256,
        .sourceBoundarySelfIntersectionPairs=0u,.candidateBoundarySelfIntersectionPairs=0u};
    return verifySameTopologyReferencePullback(input,result,error);
}
}

[[nodiscard]] inline bool importPhysicalSkinRegisteredVolumeFiles(
        const PhysicalSkinRegisteredVolumeAssetFiles& files,
        const std::string_view coordinateFrameSHA256,
        const std::size_t sourceBodyCount,
        const double maximumMassTransportDistanceM,
        const double maximumParentRegistrationDistanceM,
        const std::string_view canonicalDetailedSourceDomain,
        const std::size_t detailedSourceVertexCount,
        const std::size_t detailedSourceFaceCount,
        const PhysicalSkinRegisteredSurfaceCSVSet& registered,
        const std::span<const PhysicalSkinStableDeepAttachmentRequest> deepAttachments,
        const std::span<const PhysicalSkinRegisteredBodyPose> allBodyCurrentPoses,
        PhysicalSkinChildMassMappingBundle& outputBundle,
        PhysicalSkinRegisteredVolumeImportSidecars& outputSidecars,
        PhysicalSkinRegisteredVolumeFileImportReport& outputReport,
        std::string& error,
        const std::span<const PhysicalSkinSourceDomainRegistration> sourceDomains={}) {
    using namespace physical_skin_registered_volume_integration_detail;
    const auto fail=[&](std::string message){error=std::move(message);return false;};
    if(files.combinedNodeMapCSV.extension()==".gz"||files.facetAncestryCSV.extension()==".gz")
        return fail("registered volume import accepts plain existing CSV files after one-time decompression");
    if(sourceBodyCount==0u||!std::isfinite(maximumParentRegistrationDistanceM)||
       maximumParentRegistrationDistanceM<=0.0)
        return fail("registered volume import has an invalid body domain or parent registration bound");

    // All parsing and compilation happens in local state. No caller output is
    // changed unless TetGen, node maps, O/I/D import, and facet maps all pass.
    PhysicalSkinChildMassMappingBundle nextBundle=outputBundle;
    PhysicalSkinChildTetGenImportReport tetgenReport;
    if(!loadPhysicalSkinChildTetGenReference(files.tetgenNode,files.tetgenElements,files.childLabels,
            coordinateFrameSHA256,sourceBodyCount,maximumMassTransportDistanceM,
            nextBundle,tetgenReport,error))
        return false;
    PhysicalSkinRuntimeMeshQualityPreflightReport runtimeQuality;
    if(!preflightPhysicalSkinRuntimeMeshQuality(nextBundle,runtimeQuality,error))return false;
    nextBundle.fractionalSemanticMassRouteRequired=false;
    nextBundle.fractionalSemanticSupport={};
    nextBundle.sourceCarrierQuadrature={};
    const std::array<std::string,3> tetgenHashes{
        tetgenReport.nodeFileSHA256,tetgenReport.elementFileSHA256,tetgenReport.labelFileSHA256};
    const bool currentFractionalReference=files.registrationDomain==
        PhysicalSkinRegisteredVolumeRegistrationDomain::currentFractionalReference;
    const bool ancestryOperationalReference=files.registrationDomain==
        PhysicalSkinRegisteredVolumeRegistrationDomain::candidateOperationalReference;
    const bool separatedOperationalReference=ancestryOperationalReference||currentFractionalReference;
    if(currentFractionalReference&&(sourceDomains.size()!=3u||
       std::any_of(registered.surfaces.begin(),registered.surfaces.end(),[](const auto& s){return s.worldPoints.empty();})))
        return fail("current fractional reference requires all three explicit source domains and registered surfaces");
    if(ancestryOperationalReference&&!files.operationalReferencePullback)
        return fail("candidate operational-reference import requires authenticated source and candidate receipts plus a same-topology pullback proof");
    if(!ancestryOperationalReference&&files.operationalReferencePullback)
        return fail("source-parent import cannot carry an operational-reference pullback packet");
    auto operationalDomainHash=separatedOperationalReference?
        operationalReferenceDomainSHA256(tetgenReport,coordinateFrameSHA256):std::string{};
    if(separatedOperationalReference&&
       !physical_skin_child_mass_detail::validSHA256(operationalDomainHash))
        return fail("candidate operational-reference hash could not be derived from its pinned geometry/label inputs");
    if(separatedOperationalReference!=registered.parentRegistrationIsHistoricalProvenanceOnly)
        return fail("surface source-parent registration mode differs from the declared operational-reference split");
    const bool fractionalRequired=ancestryOperationalReference&&
        files.operationalReferencePullback->fractionalSemanticMassRouteRequired;
    if(fractionalRequired!=files.fractionalSemanticSupport.has_value())
        return fail("fractional semantic route flag and its two-role support assets must be supplied together");
    PhysicalSkinFractionalSemanticSupportImportReport fractionalSupportReport;
    PhysicalSkinSourceCarrierQuadratureImportReport sourceCarrierImportReport;
    PhysicalSkinP1SupportedReferenceAnchorImportReport p1AnchorImportReport;
    std::array<PhysicalSkinRecordedCarrierAllocationCSVImportReport,2> recordedAllocationCSVReports{};
    if(fractionalRequired){
        if(!files.operationalReferencePullback->conservativeSpatialReference)
            return fail("fractional semantic support cannot be attached to a non-spatial operational-reference route");
        if(!loadPhysicalSkinFractionalSemanticSupport090(*files.fractionalSemanticSupport,nextBundle,
                nextBundle.fractionalSemanticSupport,fractionalSupportReport,error))
            return fail("authenticated fractional semantic support rejected: "+error);
        nextBundle.fractionalSemanticMassRouteRequired=true;
    }
    if(files.sourceCarrierQuadrature){
        if(!fractionalRequired)
            return fail("source-carrier quadrature requires the authenticated paired fractional semantic route");
        if(!loadPhysicalSkinSourceCarrierQuadrature090(*files.sourceCarrierQuadrature,
                *files.fractionalSemanticSupport,fractionalSupportReport,nextBundle,
                {files.expectedSHA256[0],files.expectedSHA256[1],files.expectedSHA256[2]},
                nextBundle.sourceCarrierQuadrature,sourceCarrierImportReport,error))
            return fail("authenticated source-carrier quadrature rejected: "+error);
    }
    if(files.p1SupportedReferenceAnchor){
        if(!fractionalRequired)
            return fail("P1 supported reference anchors require the authenticated paired fractional semantic route");
        if(!loadPhysicalSkinP1SupportedReferenceAnchor(*files.p1SupportedReferenceAnchor,nextBundle,
                fractionalSupportReport,{files.expectedSHA256[0],files.expectedSHA256[1],files.expectedSHA256[2]},
                files.childLabels,files.expectedSHA256[2],p1AnchorImportReport,error))
            return fail("authenticated P1 supported reference anchors rejected: "+error);
    }
    if(files.recordedCarrierAllocationCSV){
        if(!fractionalRequired||!files.sourceCarrierQuadrature||
           !nextBundle.sourceCarrierQuadrature.importedAndVerified||
           !nextBundle.sourceCarrierQuadrature.hasCarriers())
            return fail("recorded role flow CSVs require the authenticated paired semantic and source-carrier packets");
        for(unsigned role=0;role<2u;++role){
            const std::uint32_t material=role==0u?15u:16u;
            auto assets=(*files.recordedCarrierAllocationCSV)[role];
            if(assets.materialIndex!=material)
                return fail("recorded role allocation assets must be ordered Skin 15 then Fat 16");
            const auto parentRows=static_cast<std::size_t>(std::count(
                nextBundle.parent.materialIndices.begin(),nextBundle.parent.materialIndices.end(),material));
            const auto childRows=static_cast<std::size_t>(std::count(
                nextBundle.childMaterialIndices.begin(),nextBundle.childMaterialIndices.end(),material));
            const std::vector<std::string> expectedPins{
                nextBundle.parent.parentMassPacketSHA256,nextBundle.parent.parentSourceContributionSHA256,
                nextBundle.childMeshSHA256,nextBundle.regionLabelSHA256,nextBundle.coordinateFrameSHA256,
                files.expectedSHA256[0],files.expectedSHA256[1],files.expectedSHA256[2],
                files.fractionalSemanticSupport->roles[role].binarySHA256,
                files.sourceCarrierQuadrature->roles[role].binarySHA256};
            if(!assets.expectedInputSHA256.empty()&&assets.expectedInputSHA256!=expectedPins)
                return fail("recorded role allocation expected-input pins differ from the current authenticated import inputs");
            assets.expectedInputSHA256=expectedPins;
            if(!recorded_carrier_allocation_import_detail::loadPhysicalSkinRecordedCarrierAllocationCSVs(assets,material,parentRows,childRows,
                    nextBundle.sourceCarrierQuadrature.recordedAllocation.roles[role],
                    recordedAllocationCSVReports[role],error))
                return fail("recorded source-carrier role allocation rejected: "+error);
            if(nextBundle.sourceCarrierQuadrature.recordedAllocation.roles[role].sourceCarrierPacketSHA256!=
                   files.sourceCarrierQuadrature->roles[role].binarySHA256)
                return fail("recorded role allocation does not bind its exact authenticated source-carrier packet");

        }
    }
    for(unsigned i=0;i<3u;++i)
        if(!physical_skin_child_mass_detail::validSHA256(tetgenHashes[i])||tetgenHashes[i]!=files.expectedSHA256[i])
            return fail("registered volume import TetGen file hash differs from its declared pin: "+
                std::array<std::filesystem::path,3>{files.tetgenNode,files.tetgenElements,files.childLabels}[i].string());

    nextBundle.operationalSpatialMassRouteRequired=false;
    nextBundle.operationalSpatialReferenceVerificationSHA256.clear();
    nextBundle.operationalSpatialTransportReceiptSHA256.clear();
    nextBundle.usesSeparatedOperationalReference=separatedOperationalReference;
    nextBundle.conformingLineageMassRouteRequired=ancestryOperationalReference&&
        files.operationalReferencePullback->conformingTissueRefinement.has_value();
    std::string mapHashBefore,mapHashAfter;
    if(!pinnedFile(files.combinedNodeMapCSV,files.expectedSHA256[3],mapHashBefore,error))return false;
    std::ifstream nodeMapInput(files.combinedNodeMapCSV);
    if(!nodeMapInput)return fail("cannot open plain combined TetGen node-map CSV");
    PhysicalSkinCombinedNodeMapCSVReport nodeMapReport;
    std::vector<PhysicalSkinRegisteredVolumeNodeRow> nodeRows;
    if(!readPhysicalSkinCombinedNodeMapCSV(nodeMapInput,nextBundle.referenceWorldPoints.size(),
            sourceBodyCount,nodeRows,nodeMapReport,error,separatedOperationalReference))
        return false;
    if(!pinnedFile(files.combinedNodeMapCSV,files.expectedSHA256[3],mapHashAfter,error)||
       mapHashAfter!=mapHashBefore)
        return fail("combined TetGen node-map CSV changed while it was being imported");
    SameTopologyReferencePullbackResult pullbackProof;
    double maximumSourceParentRegistrationDistance=0.0;
    std::string conformingTissueVerificationSHA256;
    PhysicalSkinVerifiedConformingMassRoute verifiedMassRoute;
    ConservativeSpatialMassTransportResult verifiedSpatialTransport;
    SourceCellCarrierTransportTrace verifiedSourceCarrierTrace;
    std::string spatialReferenceVerificationSHA256;
    if(ancestryOperationalReference&&
       !verifyOperationalReferencePullback(*files.operationalReferencePullback,coordinateFrameSHA256,
           sourceBodyCount,maximumMassTransportDistanceM,nextBundle,nodeRows,tetgenHashes,
           mapHashAfter,files.expectedSHA256[4],pullbackProof,maximumSourceParentRegistrationDistance,
           conformingTissueVerificationSHA256,verifiedMassRoute,
           verifiedSpatialTransport,verifiedSourceCarrierTrace,spatialReferenceVerificationSHA256,error))
        return fail("authenticated operational-reference pullback rejected: "+error);
    if(separatedOperationalReference){
        if(!conformingTissueVerificationSHA256.empty()){
            spatial_mass_transport_detail::SHA256Builder domainHash;
            domainHash.string("physical-skin-operational-reference-domain-with-conforming-proof.v1");
            domainHash.string(operationalDomainHash);domainHash.string(conformingTissueVerificationSHA256);
            domainHash.string(pullbackProof.verificationSHA256);
            operationalDomainHash=domainHash.finish();
        }
        if(!spatialReferenceVerificationSHA256.empty()){
            spatial_mass_transport_detail::SHA256Builder hash;
            hash.string("physical-skin-operational-reference-domain-with-spatial-proof.v1");
            hash.string(operationalDomainHash);hash.string(spatialReferenceVerificationSHA256);
            operationalDomainHash=hash.finish();
            nextBundle.operationalSpatialMassRouteRequired=true;
            nextBundle.operationalSpatialReferenceVerificationSHA256=spatialReferenceVerificationSHA256;
            nextBundle.operationalSpatialTransportReceiptSHA256=verifiedSpatialTransport.receiptSHA256;
            nextBundle.spatialMassTransportResult=std::move(verifiedSpatialTransport);
            if(nextBundle.sourceCarrierQuadrature.importedAndVerified&&nextBundle.sourceCarrierQuadrature.hasCarriers())
                nextBundle.sourceCarrierQuadrature.transportTrace=std::move(verifiedSourceCarrierTrace);
        }else{
            nextBundle.operationalSpatialMassRouteRequired=false;
            nextBundle.operationalSpatialReferenceVerificationSHA256.clear();
            nextBundle.operationalSpatialTransportReceiptSHA256.clear();
        }
        nextBundle.operationalReferenceDomainSHA256=operationalDomainHash;
        if(nextBundle.conformingLineageMassRouteRequired){
            if(!verifiedMassRoute.authenticated){
                error="conforming operational-reference route did not produce an authenticated immutable-mass lineage";return false;
            }
            verifiedMassRoute.candidateOperationalReferenceDomainSHA256=operationalDomainHash;
            verifiedMassRoute.candidateCompiledDataSHA256=physical_skin_child_mass_mapping_detail::
                operationalChildCompiledDataSHA256(nextBundle);
            verifiedMassRoute.verificationSHA256=physical_skin_child_mass_mapping_detail::
                verifiedConformingMassRouteSHA256(verifiedMassRoute);
            nextBundle.conformingLineageMassRoute=std::move(verifiedMassRoute);
        }
    }

    std::string facetHashBefore,facetHashAfter;
    if(!pinnedFile(files.facetAncestryCSV,files.expectedSHA256[4],facetHashBefore,error))return false;
    std::ifstream facetInput(files.facetAncestryCSV);
    if(!facetInput)return fail("cannot open existing registered facet-ancestry CSV");
    PhysicalSkinRegisteredFacetCSVReport facetCSVReport;
    std::vector<PhysicalSkinAuthoredHeadWallRow> authoredWalls;
    if(!readPhysicalSkinAuthoredHeadWallsCSV(facetInput,nextBundle.childTetrahedra.size(),
            nextBundle.referenceWorldPoints.size(),authoredWalls,facetCSVReport,error,currentFractionalReference))
        return false;
    if(!pinnedFile(files.facetAncestryCSV,files.expectedSHA256[4],facetHashAfter,error)||
       facetHashAfter!=facetHashBefore)
        return fail("facet-ancestry CSV changed while it was being imported");
    const auto& surfaces=registered.surfaces;
    const auto expectedRegisteredFacetRows=surfaces[0].faces.size()+
        2u*surfaces[1].faces.size()+surfaces[2].faces.size();
    if(facetCSVReport.registeredRows!=expectedRegisteredFacetRows)
        return fail("facet-ancestry CSV registered O/I/D row count differs from exact registered surfaces");

    PhysicalSkinRegisteredVolumeImportSidecars nextSidecars;
    PhysicalSkinRegisteredVolumeImportReport registeredReport;
    if(!compilePhysicalSkinRegisteredVolumeImport(nextBundle,registered,nodeRows,deepAttachments,
            allBodyCurrentPoses,sourceBodyCount,maximumParentRegistrationDistanceM,
            canonicalDetailedSourceDomain,detailedSourceVertexCount,detailedSourceFaceCount,
            nextSidecars,registeredReport,error,sourceDomains,files.registrationDomain,operationalDomainHash))
        return false;
    PhysicalSkinRegisteredFacetMapReport facetMapReport;
    if(!preparePhysicalSkinRegisteredFacetMaps(nextBundle,authoredWalls,15u,16u,facetMapReport,error,currentFractionalReference))
        return false;
    if(!sameImmutableParentPacket(outputBundle.parent,nextBundle.parent))
        return fail("registered operational-reference import mutated the immutable source-mass parent packet");
    PhysicalSkinRegisteredVolumeFileImportReport measured;
    measured.tetgen=std::move(tetgenReport);measured.nodeMap=nodeMapReport;
    measured.facetAncestry=facetCSVReport;measured.registeredVolume=registeredReport;
    measured.facetMaps=facetMapReport;
    measured.inputSHA256={measured.tetgen.nodeFileSHA256,measured.tetgen.elementFileSHA256,
        measured.tetgen.labelFileSHA256,mapHashAfter,facetHashAfter};
    measured.registrationDomain=files.registrationDomain;
    measured.operationalReferenceDomainSHA256=operationalDomainHash;
    measured.operationalReferencePullbackVerified=ancestryOperationalReference&&
        spatialReferenceVerificationSHA256.empty();
    measured.operationalReferenceSpatialTransportVerified=!spatialReferenceVerificationSHA256.empty();
    measured.operationalReferenceSpatialTransportVerificationSHA256=spatialReferenceVerificationSHA256;
    if(measured.operationalReferenceSpatialTransportVerified)
        measured.maximumSpatialMassTransportDistanceM=nextBundle.spatialMassTransportResult.maximumTransportDistanceUsedM;
    if(ancestryOperationalReference){
        measured.operationalReferencePullbackSHA256=pullbackProof.verificationSHA256;
        measured.conformingTissueRefinementVerified=!conformingTissueVerificationSHA256.empty();
        measured.conformingTissueRefinementVerificationSHA256=conformingTissueVerificationSHA256;
        measured.maximumSourceParentRegistrationDistanceM=maximumSourceParentRegistrationDistance;
        measured.maximumSourceToCandidateReferenceDistanceM=pullbackProof.maximumNodeDisplacementM;
    }
    if(files.sourceCarrierQuadrature){
        measured.sourceCarrierQuadratureVerified=sourceCarrierImportReport.verified;
        measured.sourceCarrierQuadratureImport=sourceCarrierImportReport;
        if(nextBundle.sourceCarrierQuadrature.hasCarriers())
            measured.sourceCarrierTransportTraceSHA256=nextBundle.sourceCarrierQuadrature.transportTrace.receiptSHA256;
    }
    if(files.p1SupportedReferenceAnchor){
        measured.p1SupportedReferenceAnchorVerified=p1AnchorImportReport.verified;
        measured.p1SupportedReferenceAnchorImport=p1AnchorImportReport;
    }
    if(files.recordedCarrierAllocationCSV){
        measured.recordedCarrierAllocationCSVImport=recordedAllocationCSVReports;
        measured.recordedCarrierAllocationCSVVerified=
            recordedAllocationCSVReports[0].verified&&recordedAllocationCSVReports[1].verified;
    }
    if(fractionalRequired){
        spatial_mass_transport_detail::SHA256Builder supportChain;
        supportChain.string("physical-skin-fractional-semantic-support-import.v1");
        supportChain.string(fractionalSupportReport.binarySHA256[0]);
        supportChain.string(fractionalSupportReport.receiptSHA256[0]);
        supportChain.string(fractionalSupportReport.binarySHA256[1]);
        supportChain.string(fractionalSupportReport.receiptSHA256[1]);
        supportChain.string(fractionalSupportReport.compositeTypedSupportSHA256);
        supportChain.string(fractionalSupportReport.compositeAdmissibilitySourceSHA256);
        measured.fractionalSemanticSupportVerified=fractionalSupportReport.verified;
        measured.fractionalSemanticSupportVerificationSHA256=supportChain.finish();
        measured.fractionalSemanticSupportImport=fractionalSupportReport;
    }
    measured.physicalAdmission=false;
    outputBundle=std::move(nextBundle);outputSidecars=std::move(nextSidecars);
    outputReport=std::move(measured);error.clear();return true;
}


// Explicit installation of a verified conservative operational reference.
// Configuration permits this route; the prepared-bundle check below is still
// mandatory before replacing any physical object. preparationOnly describes
// the tissue owner preparing the shared world; it must not create a second
// Runtime. The separate sourceOnly setting determines the zero-step exit.
inline bool validateOperationalSpatialInstallationMode(
        const bool requested,const bool install,const bool separated,
        const bool spatial,const bool conforming,const bool sourceOnly,
        const bool preflight,const bool preparationOnly,std::string& error) {
    if(requested&&(!install||!separated||!spatial||conforming||sourceOnly||
                  !preflight||!preparationOnly)){
        error="operational spatial installation requires physical registered install, "
              "separated conservative reference, preflight, and shared-world preparation";
        return false;
    }
    error.clear();return true;
}

inline bool validatePreparedOperationalSpatialInstallation(
        PhysicalSkinChildMassMappingBundle& bundle,
        const PhysicalSkinRegisteredVolumeFileImportReport& report,
        const double maximumTransportDistanceM,const std::size_t sourceBodyCount,
        std::string& error) {
    using physical_skin_child_mass_detail::validSHA256;
    if(!bundle.usesSeparatedOperationalReference||
       !bundle.operationalSpatialMassRouteRequired||
       bundle.conformingLineageMassRouteRequired||bundle.conformingLineageMassTransportUsed||
       bundle.exactTopologyIdentityTransportUsed||
       !report.operationalReferenceSpatialTransportVerified||
       report.operationalReferencePullbackVerified||report.conformingTissueRefinementVerified||
       report.physicalAdmission||
       !validSHA256(report.operationalReferenceSpatialTransportVerificationSHA256)||
       report.operationalReferenceSpatialTransportVerificationSHA256!=
           bundle.operationalSpatialReferenceVerificationSHA256||
       !std::isfinite(report.maximumSourceParentRegistrationDistanceM)||
       report.maximumSourceParentRegistrationDistanceM<0.0||
       report.maximumSourceParentRegistrationDistanceM>0.0004||
       !std::isfinite(maximumTransportDistanceM)||maximumTransportDistanceM<=0.0||
       !std::isfinite(report.maximumSpatialMassTransportDistanceM)||
       report.maximumSpatialMassTransportDistanceM<0.0||
       bundle.maximumSpatialMassTransportDistanceM!=maximumTransportDistanceM||
       report.maximumSpatialMassTransportDistanceM>maximumTransportDistanceM||
       report.maximumSpatialMassTransportDistanceM!=
           bundle.spatialMassTransportResult.maximumTransportDistanceUsedM){
        error="physical operational-reference installation lacks its current authenticated "
              "conservative mass, source registration, and candidate reference proofs";
        return false;
    }
    if(!physical_skin_child_mass_mapping_detail::
            validatePreparedPhysicalSkinChildMassMappingPath(bundle,error))return false;
    // The path hash binds the transport receipt identity. Reverify its actual
    // current flow/mass arrays through the existing owner as well; a stale
    // receipt string must never authorize mutated cached transport values.
    std::array<double,17> lower{},upper{};
    lower[15]=900.0;upper[15]=1100.0;
    lower[16]=850.0;upper[16]=950.0;
    return preparePhysicalSkinChildMassMapping(bundle,lower,upper,
        maximumTransportDistanceM,sourceBodyCount,error);
}

// The legacy parent is built for immutable material/mass identity only.
// This authorizes no physical execution: mandatory registered replacement and
// complete mass admission still have to succeed before scene compilation.
[[nodiscard]] inline bool currentFractionalParentPreparationReady(
        const bool installRequested,const bool fractionalRequested,
        const PhysicalSkinChildMassMappingBundle& bundle,
        const PhysicalSkinRegisteredVolumeFileImportReport& report) {
    using physical_skin_child_mass_detail::validSHA256;
    return installRequested&&fractionalRequested&&!report.physicalAdmission&&
        report.registrationDomain==PhysicalSkinRegisteredVolumeRegistrationDomain::currentFractionalReference&&
        bundle.usesSeparatedOperationalReference&&
        validSHA256(bundle.operationalReferenceDomainSHA256)&&
        report.operationalReferenceDomainSHA256==bundle.operationalReferenceDomainSHA256&&
        !report.operationalReferencePullbackVerified&&
        !report.operationalReferenceSpatialTransportVerified&&
        !report.conformingTissueRefinementVerified&&
        report.registeredVolume.typedSourceDomainMapPopulated&&
        report.registeredVolume.sourceDomainCount==3u&&bundle.sourceDomains.size()==3u&&
        report.tetgen.nodeCount==bundle.referenceWorldPoints.size()&&
        report.tetgen.cellCount==bundle.childTetrahedra.size()&&report.tetgen.cellCount>0u;
}

} // namespace metalrobo::human::coarse_tissue

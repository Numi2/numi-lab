import json
from pathlib import Path
x=json.loads(Path(__file__).with_name('result.json').read_text())['cases']
for c in x:
    w0=c['initial_joint_v'];w1=(c['child_v']-c['parent_v'])/.2
    measured=.05*(w1-w0); expected=.2*c['normal_impulse']
    c['derived_child_omega']=w1
    c['derived_angular_impulse_nms']=measured
    c['contact_angular_impulse_nms']=expected
    c['angular_impulse_error_nms']=abs(measured-expected)
    assert abs(measured-expected)<1e-7
print(json.dumps({'derivation':'reconstruct omega=(contact velocity-parent velocity)/0.2, compare I_child*delta omega with arm*normal impulse; assumes stated initial identity and revolute axis', 'cases':x},indent=2))

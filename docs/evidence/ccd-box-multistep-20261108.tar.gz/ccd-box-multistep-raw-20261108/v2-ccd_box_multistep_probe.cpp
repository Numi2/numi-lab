#include "metalrobo/MetalWorld.hpp"
#include "metalrobo/EngineModel.hpp"
#include <algorithm>
#include <cmath>
#include <cstring>
#include <filesystem>
#include <iomanip>
#include <iostream>
#include <vector>
template<class T> bool eq(const std::vector<T>&a,const std::vector<T>&b){return a.size()==b.size()&&(a.empty()||std::memcmp(a.data(),b.data(),a.size()*sizeof(T))==0);}
int main(int argc,char**argv){
 if((argc!=2&&argc!=3)||!std::filesystem::is_regular_file(argv[1]))return 2; bool warm=argc==2||std::string(argv[2])!="cold";
 std::cout<<std::setprecision(10)<<"{\"cases\":[";
 for(int k=0;k<3;++k){
  auto m=metalrobo::makeFreeSphereEngineModel();m.world.gravityAndTimestep={0,0,0,.01f};
  for(auto& x:m.materials){x.friction.x=.5f;x.friction.y=.5f;x.response.x=0;x.response.y=0;}
  auto& sh=m.shapes[1];sh.shapeType=MR_SHAPE_BOX;sh.dimensions={.02f,.01f,.015f,0};sh.contactRestAndBoundingRadius={.001f,0,.027f,0};
  m.defaultQ[1]=.01f+(k==0?-.0001f:k==1?0.f:.0015f);m.defaultV[0]=1.f;m.defaultV[1]=k==2?0.f:-1.f;
  metalrobo::CompiledWorld w;auto c=metalrobo::compileMetalWorld(m,0,w);if(!c.succeeded())return 3;
  std::vector<float> effort(w.nv(),0);MRBodyStateGPU ground{};ground.position.w=1;ground.orientation.w=1;ground.flagsAndIndices[0]=MR_MOTION_STATIC;ground.flagsAndIndices[1]=MR_INVALID_INDEX;
  std::vector<MRBodyStateGPU> scene{ground};
  const metalrobo::MetalWorldBatch initial{.environmentCount=1,.controlStepCount=1,.initialQ=m.defaultQ,.initialV=m.defaultV,.efforts=effort,.initialSceneBodies=scene};
  const metalrobo::MetalWorldBatch next{.environmentCount=1,.controlStepCount=1,.efforts=effort};
  metalrobo::MetalWorldStepConfig cfg;cfg.timestepSeconds=.01f;cfg.physicsSubsteps=1;cfg.velocityIterations=2;cfg.finalVelocityIterations=0;cfg.ccdMode=metalrobo::MetalWorldCCDMode::disabled;cfg.applyBodyDamping=false;cfg.captureContactEvidence=true;cfg.warmStart=warm;
  metalrobo::MetalWorldConfig o;o.metallibPath=argv[1];metalrobo::MetalWorldContext a(o),b(o);metalrobo::MetalWorldResidentState sa,sb;metalrobo::MetalWorldSubmission ta,tb;metalrobo::MetalWorldResult ra,rb;
  if(k)std::cout<<",";std::cout<<"{\"near_miss\":"<<(k==2?"true":"false")<<",\"initial_gap\":"<<(k==0?-.0001:k==1?0:.0015)<<",\"steps\":[";
  for(int i=0;i<10;++i){auto da=i?a.submitResident(w,next,cfg,sa,ta):a.initializeResidentState(w,initial,cfg,sa,ta);auto db=i?b.submitResident(w,next,cfg,sb,tb):b.initializeResidentState(w,initial,cfg,sb,tb);if(!da.succeeded()||!db.succeeded())return 4;
   auto xa=ta.wait(ra),xb=tb.wait(rb);if(ra.finalV.size()<6||ra.finalQ.size()<7||ra.contactStatuses.empty())return 5;
   bool replay=eq(ra.finalQ,rb.finalQ)&&eq(ra.finalV,rb.finalV)&&eq(ra.finalSceneBodies,rb.finalSceneBodies)&&eq(ra.contactEvidence.manifoldCounts,rb.contactEvidence.manifoldCounts)&&eq(ra.contactEvidence.manifoldHeaders,rb.contactEvidence.manifoldHeaders)&&eq(ra.contactEvidence.manifoldPoints,rb.contactEvidence.manifoldPoints)&&xa.firstGPUStatusCode==xb.firstGPUStatusCode;
   auto st=ra.contactStatuses[0];double j=0;for(std::size_t z=0;z<std::min<std::size_t>(st.activeContacts,ra.contactEvidence.contacts.size());++z)j+=ra.contactEvidence.contacts[z].impulses.x;
   double energy=0;for(int z=0;z<3;++z){energy+=.5*double(ra.finalV[z])*ra.finalV[z]+.05*double(ra.finalV[z+3])*ra.finalV[z+3];}
   if(i)std::cout<<",";std::cout<<"{\"accepted\":"<<(xa.succeeded()?"true":"false")<<",\"status\":"<<xa.firstGPUStatusCode<<",\"contacts\":"<<st.activeContacts<<",\"residual\":"<<st.residuals.y<<",\"normal_impulse\":"<<j<<",\"energy\":"<<energy<<",\"replay\":"<<(replay?"true":"false")<<",\"q\":[";
   for(std::size_t z=0;z<ra.finalQ.size();++z){if(z)std::cout<<",";std::cout<<ra.finalQ[z];}std::cout<<"],\"v\":[";for(std::size_t z=0;z<ra.finalV.size();++z){if(z)std::cout<<",";std::cout<<ra.finalV[z];}std::cout<<"],\"rows\":[";for(std::size_t z=0;z<std::min<std::size_t>(st.activeContacts,ra.contactEvidence.contacts.size());++z){if(z)std::cout<<",";const auto& p=ra.contactEvidence.contacts[z];const auto& row=ra.contactEvidence.evaluatedRows.at(3*z);std::cout<<"{\"impulse\":"<<p.impulses.x<<",\"target\":"<<row.targetVelocity<<",\"pre\":"<<row.preSolveVelocity<<",\"gap\":"<<p.pointAndSeparation.w<<"}";}std::cout<<"]}";
  }std::cout<<"]}";
 }std::cout<<"]}\n";
}

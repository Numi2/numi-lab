import subprocess,json
from pathlib import Path
root=Path('/Users/numi/numi-lab-contact-onset-evidence-20261107')
r=Path('/Users/numi/numi-lab-ccd-20261107')
subprocess.run(['python3',str(r/'tests/ccd/world/regression.py'),'/Users/numi/numi-lab-ccd-world-build-20261107/metalrobo_ccd_world_step_probe','/Users/numi/numi-lab-ccd-world-build-20261107/shaders/MetalRobo.metallib',str(root/'ccd-useful-motion002')])
rows=[]
for name,h,n in [('n2-h3',.00000390625,2560),('n2-h1',.000001953125,5120)]:
 cmd=['/Users/numi/numi-lab-contact-build-20261107/metalrobo_plane_contact_probe','/Users/numi/numi-lab-contact-build-20261107/NumiMatter.metallib',str(h),str(n),'2','ipc','.0002','physical','contact','reference']
 with (root/'reference003'/(name+'.json')).open('w') as o,(root/'reference003'/(name+'.stderr')).open('w') as e:
  result=subprocess.run(cmd,stdout=o,stderr=e)
 rows.append({'name':name,'cmd':cmd,'exit':result.returncode})
 (root/'reference003'/'attempt-ledger.json').write_text(json.dumps(rows,indent=2))

from pathlib import Path
import subprocess,json,time
root=Path('/Users/numi/numi-lab-contact-onset-evidence-20261107')
while True:
 try:
  if len(json.loads((root/'reference003/attempt-ledger.json').read_text()))==2:break
 except (FileNotFoundError,json.JSONDecodeError):pass
 time.sleep(1)
rows=[]
for arm in ['ipc','al']:
 for label,gap in [('50um',5e-5),('0p5um',5e-7)]:
  name=arm+'-'+label
  cmd=['/Users/numi/numi-lab-contact-build-20261107/metalrobo_plane_contact_probe','/Users/numi/numi-lab-contact-build-20261107/NumiMatter.metallib','.0005','20','2',arm,str(gap),'physical','contact','reference']
  with (root/'near-contact003'/(name+'.json')).open('w') as o,(root/'near-contact003'/(name+'.stderr')).open('w') as e:
   result=subprocess.run(cmd,stdout=o,stderr=e)
  rows.append({'name':name,'cmd':cmd,'exit':result.returncode})
  (root/'near-contact003'/'attempt-ledger.json').write_text(json.dumps(rows,indent=2))

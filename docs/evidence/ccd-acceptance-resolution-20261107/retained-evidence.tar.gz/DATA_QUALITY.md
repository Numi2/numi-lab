# Retained diagnostic evidence

The historical reports at30ee40e are not overwritten. No physical/performance promotion.
ccd-polynomial*, ccd-timewarp-band and the early event/frame revisions are failed/superseded. In particular, ccd-anchor-frame has INVALID_BUILD.md; frame002 preceded a fail-closed stack bookkeeping correction and is not qualification. ccd-useful-motion001 had tracing disabled by a too-large capacity guard. 002/003/004 retain the failed all-impact completion assertion.
ccd-useful-motion005 is the final native CCD snapshot;004 is retained before the small-angle norm-limit and actual-radius correction. Its 174 accepted observations pass the independent segment enclosure; thinner true impacts still reject/restore. The subsequent CTest analysis separates required original/unused impacts and clear controls from the explicitly failed broader all-impact gate.

physical001 contains an instrument free-fall crash. physical002 fails local residual gates. physical003 still fails onset at fine h. reference001 (reference displacement alone) also fails. reference002/003 complete under the scoped gap-precision repair, but temporal-refinement.json rejects the force reference. n4 at h15 is sensitivity only, since temporal error is not qualified.
onset-captures contains the final nonzero-correction IPC/AL operators. ipc-iter5 is latched zero correction: do not infer nontrivial Jv agreement from it. Full traces include deterministic replay duplicates; analysis uses only the first iteration/stage record.
Near-contact003 IPC work includes initially stored barrier potential; AL never accepts a nonzero multiplier in these strict runs.
Some native correctness diagnostics overlapped. Times, dispatch counts and iterations are retained observations, not a speed comparison.

Per-attempt source.patch files describe tracked differences from977eb61. New offline instruments were untracked during some snapshots; their final source/hash is retained in the repository and analysis-source-sha256.json. Early exploratory failed capture attempts do not all have complete standalone build provenance and cannot be used as benchmark results.

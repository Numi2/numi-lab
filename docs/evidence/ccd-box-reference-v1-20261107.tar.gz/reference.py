import json
from pathlib import Path
source=Path('/Users/numi/numi-lab-ccd-thin-evidence-20261107/normal-first-v1/geometry.json')
cases=json.loads(source.read_text())['cases']
case=next(x for x in cases if x['geometry']==2 and x['friction']==0 and x['initial_vn']==-1 and not x['far'])
rows=case['rows']
a=[r['anchor_b'] for r in rows]
lambda_candidate=[r['normal_impulse'] for r in rows]
W=[[1.0+10.0*(u[0]*v[0]+u[2]*v[2]) for v in a] for u in a]
def velocities(lam): return [-1.0+sum(w*l for w,l in zip(row,lam)) for row in W]
reference=[.5,0.,0.,.5]
print(json.dumps({'method':'FP64 point-Jacobian W_ij = 1 + 10*(x_i*x_j + z_i*z_j), zero target and regularization; 1kg, I=0.1kg*m^2','W':W,'candidate_impulses_ns':lambda_candidate,'candidate_normal_velocity_mps':velocities(lambda_candidate),'opposing_corner_reference_impulses_ns':reference,'reference_normal_velocity_mps':velocities(reference),'candidate_torque_z_impulse_nms':sum(l*anchor[0] for l,anchor in zip(lambda_candidate,a)),'candidate_torque_x_impulse_nms':-sum(l*anchor[2] for l,anchor in zip(lambda_candidate,a)),'reference_normal_impulse_ns':sum(reference)},indent=2))

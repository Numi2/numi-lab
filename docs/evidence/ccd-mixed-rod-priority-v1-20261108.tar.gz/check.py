import json, math
from pathlib import Path
p=Path(__file__).parent
root=p.parent
runs=json.loads((p/'candidate.json').read_text())['cases']
refs=json.loads((p/'reference.json').read_text())
mats=[json.loads((root/'mixed-rod-operator-v1'/('axis%d.json'%k)).read_text())['cases'] for k in range(3)]
results=[]
for c,ref,idx in zip(runs,refs,range(3)):
    if not c['accepted']:
        results.append({'initial_vn':c['initial_vn'],'status':c['status'],'accepted':False,'restored':c['restored'],'replay':c['replay'],'physical_gate':'not evaluated on rejected state'})
        continue
    rows=c['rows']
    imp=[v for r in rows for v in r['impulse']]
    pre=[v for r in rows for v in r['pre_all']]
    post=[v for r in rows for v in r['post_all']]
    normal_errors=[];cone_errors=[];friction_errors=[]
    for r in rows:
        n,u,v=r['impulse']; vel=r['post_all']; t=r['target']
        gap=vel[0]-t
        normal_errors.append(abs(gap) if n>1e-7 else max(-gap,0))
        cone_errors.append(max(math.hypot(u,v)-.5*n,0))
        slip=math.hypot(vel[1],vel[2])
        if slip>1e-5:
            friction_errors.append(math.hypot(u+.5*n*vel[1]/slip,v+.5*n*vel[2]/slip))
    W=[[0.]*9 for _ in range(9)]
    for axis in range(3):
        for i,row in enumerate(mats[axis][idx]['rows']):
            for sa in range(3):
                for j in range(3): W[3*i+axis][3*j+sa]=row['operator_rows'][3*sa+j]
    action_error=max(abs(post[i]-(pre[i]+sum(W[i][j]*imp[j] for j in range(9)))) for i in range(9))
    work=sum(.5*(pre[i]+post[i])*imp[i] for i in range(9))
    ref_post=[ref['row_equation'][i]+ref['target'][i] for i in range(9)]
    ref_work=sum(.5*(ref['pre'][i]+ref_post[i])*ref['impulse'][i] for i in range(9))
    ref_n=ref['impulse']; normal_impulse_error=max(abs(imp[0]-ref_n[0]),abs(imp[3]+imp[6]-ref_n[3]-ref_n[6]))
    checks={'normal_error_m_s':max(normal_errors),'cone_error_ns':max(cone_errors),'friction_error_ns':max(friction_errors,default=0),'action_error_m_s':action_error,'work_j':work,'reference_work_j':ref_work,'work_error_j':abs(work-ref_work),'normal_impulse_error_ns':normal_impulse_error}
    checks['pass']=checks['normal_error_m_s']<=1e-3 and checks['cone_error_ns']<=1e-6 and checks['friction_error_ns']<=1e-6 and checks['action_error_m_s']<=1e-3 and checks['work_error_j']<=1e-4 and checks['normal_impulse_error_ns']<=1e-3 and c['replay']
    results.append({'initial_vn':c['initial_vn'],'status':c['status'],'accepted':True,'checks':checks})
print(json.dumps(results,indent=2,allow_nan=False))

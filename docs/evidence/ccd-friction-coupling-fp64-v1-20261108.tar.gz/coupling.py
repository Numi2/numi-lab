import importlib.util,json,math
from pathlib import Path
p=Path(__file__);spec=importlib.util.spec_from_file_location('metric',p.with_name('metric_reference.py'));metric=importlib.util.module_from_spec(spec);spec.loader.exec_module(metric)
source=Path('/Users/numi/numi-lab-ccd-thin-evidence-20261107/friction-sweeps-v1/result-2.json')
c=next(x for x in json.loads(source.read_text())['cases'] if x['geometry']==2 and x['initial_vn']==-1 and x['initial_vt']==1 and not x['far'])
def dot(a,b):return sum(x*y for x,y in zip(a,b))
def cross(a,b):return [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]
# Directions ordered normal, tangent U=z, tangent V=x; plane static, mass 1, isotropic inertia .1.
D=[[0,1,0],[0,0,1],[1,0,0]];R=[r['anchor_b'] for r in c['rows']]
W=[[[[dot(D[a],D[b])+10*dot(cross(R[i],D[a]),cross(R[j],D[b])) for b in range(3)] for j in range(4)] for a in range(3)] for i in range(4)]
p=[[0.,0.,0.] for _ in range(4)]
history=[]
for sweep in range(2):
 nxt=[]
 for i in range(4):
  v=[(-1 if a==0 else 0 if a==1 else 1)+sum(W[i][a][j][b]*p[j][b] for j in range(4) for b in range(3)) for a in range(3)]
  H=[[W[i][a][i][b] for b in range(3)] for a in range(3)]
  scale=max(abs(x) for row in H for x in row)
  for a in range(3):H[a][a]+=.01*scale
  rhs=[-x for x in v]; n=max(p[i][0]+rhs[0]/H[0][0],0); dn=n-p[i][0]
  gu=rhs[1]-H[1][0]*dn;gv=rhs[2]-H[2][0]*dn
  det=H[1][1]*H[2][2]-H[1][2]*H[2][1]
  u=p[i][1]+(H[2][2]*gu-H[1][2]*gv)/det
  t=p[i][2]+(-H[2][1]*gu+H[1][1]*gv)/det
  if n>0: target,_=metric.solve((H[1][1],H[1][2],H[2][2]),(u,t),(.5*n,.5*n))
  else:target=(0.,0.)
  relaxation=W[i][0][i][0]/sum(abs(W[i][0][j][0]) for j in range(4))
  nxt.append([p[i][a]+relaxation*(q-p[i][a]) for a,q in enumerate((n,*target))])
 p=nxt;history.append(p)
actual=[[r['normal_impulse'],*r['tangent_impulses']] for r in c['rows']]
print(json.dumps({'explanation':'FP64 simultaneous contact-block iteration; W from witnesses, mass and inertia; 1% local factor regularization and normal coupling relaxation','relaxations':[W[i][0][i][0]/sum(abs(W[i][0][j][0]) for j in range(4)) for i in range(4)],'history':history,'native_two_sweep':actual,'max_component_difference':max(abs(p[i][a]-actual[i][a]) for i in range(4) for a in range(3))},indent=2))

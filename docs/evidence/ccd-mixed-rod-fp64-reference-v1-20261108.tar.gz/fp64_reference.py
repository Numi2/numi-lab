import json
import numpy as np
from scipy.optimize import least_squares
from pathlib import Path

root = Path('/Users/numi/numi-lab-ccd-thin-evidence-20261107')
matrices = [json.loads((root / 'mixed-rod-operator-v1' / f'axis{k}.json').read_text())['cases'] for k in range(3)]
states = json.loads((root / 'mixed-rod-action-v1' / 'normal-plus.json').read_text())['cases']
results=[]
for case in range(3):
    W=np.zeros((9,9))
    for axis in range(3):
        for i,row in enumerate(matrices[axis][case]['rows']):
            for sourceaxis in range(3):
                for j in range(3):
                    W[3*i+axis,3*j+sourceaxis]=row['operator_rows'][3*sourceaxis+j]
    W=(W+W.T)*0.5
    u=np.array([v for row in states[case]['rows'] for v in row['action_pre']],float)
    target=np.array([x for row in states[case]['rows'] for x in (row['target'],0,0)],float)
    b=u-target
    invscale=np.diag(W).copy()
    def residual(j):
        v=W@j+b
        ans=np.zeros(9)
        for i in range(3):
            k=3*i;n=j[k];normal_scale=invscale[k]
            ans[k]=min(n,v[k]/normal_scale)
            tang=j[k+1:k+3]-v[k+1:k+3]/max(invscale[k+1:k+3])
            radius=max(0.,0.5*n)
            mag=np.linalg.norm(tang)
            projection=tang if mag<=radius else tang*(radius/mag)
            ans[k+1:k+3]=j[k+1:k+3]-projection
        return ans
    guesses=[np.zeros(9),np.array([1,0,0,0,0,0,0,0,0.]),np.array([1,0,-.5,.001,0,0,.001,0,0.])]
    trials=[least_squares(residual,x,xtol=1.e-14,ftol=1.e-14,gtol=1.e-14,max_nfev=20000) for x in guesses]
    sol=min(trials,key=lambda q: np.linalg.norm(residual(q.x)))
    j=sol.x;v=W@j+b
    ev=np.linalg.eigvalsh(W)
    results.append({'initial_vn':states[case]['initial_vn'],'pre':u.tolist(),'target':target.tolist(),'impulse':j.tolist(),'row_equation':v.tolist(),'normal_fb_residual':max(abs(min(j[3*i],v[3*i]/invscale[3*i])) for i in range(3)),'fixed_point_residual':float(np.linalg.norm(residual(j),np.inf)),'min_eigenvalue':float(ev.min()),'max_eigenvalue':float(ev.max()),'rank':int(np.linalg.matrix_rank(W,tol=1.e-4)),'least_squares_termination':int(sol.status),'least_squares_evaluations':int(sol.nfev)})
print(json.dumps(results,indent=2))

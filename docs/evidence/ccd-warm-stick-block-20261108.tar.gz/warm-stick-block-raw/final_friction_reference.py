#!/usr/bin/env python3
import json,math,sys
d=json.load(open(sys.argv[1]));s=d['cases'][4]['steps'];q=s[4]['q'];v=s[5]['v'];out=[]
for row in s[5]['rows']:
 p=[row['point'][i]-q[i] for i in range(3)];w=v[3:];vel=[v[0]+w[1]*p[2]-w[2]*p[1],v[1]+w[2]*p[0]-w[0]*p[2],v[2]+w[0]*p[1]-w[1]*p[0]];dirs=row['directions'];vt=[sum(a*b for a,b in zip(dirs[k],vel))-row['tangent_targets'][k-1] for k in (1,2)];pn=row['impulse'];pt=row['tangent_impulses'];speed=math.hypot(*vt);err=math.hypot(pt[0]+.5*pn*vt[0]/speed,pt[1]+.5*pn*vt[1]/speed) if speed>1e-12 else None
 out.append({'normal_impulse':pn,'final_tangent_velocity':vt,'tangent_impulse':pt,'max_dissipation_error':err,'impulse_dot_velocity':sum(x*y for x,y in zip(vt,pt))})
print(json.dumps(out,indent=2))

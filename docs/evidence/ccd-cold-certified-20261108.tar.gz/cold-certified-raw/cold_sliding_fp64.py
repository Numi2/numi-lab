#!/usr/bin/env python3
"""FP64 symmetric sliding reference for cold-supported fixture step 4."""
import json,sys
D=json.load(open(sys.argv[1]));S=D['cases'][4]['steps'];q=S[2]['q'];v=S[2]['v'][:];v[1]-=.0981;R=S[3]['rows'];n=[0.,1.,0.];f=[-.5,1.,0.]
def dot(a,b):return sum(x*y for x,y in zip(a,b))
def cross(a,b):return [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]
def add(a,b):return [x+y for x,y in zip(a,b)]
def mul(a,s):return [x*s for x in a]
r=[[x-y for x,y in zip(row['point'],q[:3])] for row in R];groups=((0,2),(1,3))
def coeff(i,j):return dot(n,f)+10*dot(cross(r[i],n),cross(r[j],f))
A=[[sum(coeff(i,j) for j in group)*.5 for group in groups] for i in (0,1)];b=[R[i]['pre']-R[i]['target'] for i in (0,1)];det=A[0][0]*A[1][1]-A[0][1]*A[1][0];assert abs(det)>1e-9
L=[(-b[0]*A[1][1]+A[0][1]*b[1])/det,(-A[0][0]*b[1]+A[1][0]*b[0])/det];assert min(L)>=0
J=mul(f,sum(L));torque=[0.,0.,0.]
for group,lam in zip(groups,L):
 for i in group:torque=add(torque,cross(r[i],mul(f,.5*lam)))
vpost=add(v[:3],J)+add(v[3:],mul(torque,10));work=.5*(dot(J,add(v[:3],vpost[:3]))+dot(torque,add(v[3:],vpost[3:])))
res=[R[i]['pre']-R[i]['target']+sum(.5*L[g]*sum(coeff(i,j) for j in groups[g]) for g in (0,1)) for i in range(4)]
slip=[]
for i in range(4):
 pointvelocity=add(vpost[:3],cross(vpost[3:],r[i]));slip.append(pointvelocity[0])
assert min(slip)>1e-5 and max(abs(x) for x in res)<1e-9
print(json.dumps({'normal_groups':L,'normal_total':sum(L),'tangent_total':-.5*sum(L),'normal_residuals':res,'final_slips':slip,'final_velocity':vpost,'work':work,'matrix':A},indent=2))

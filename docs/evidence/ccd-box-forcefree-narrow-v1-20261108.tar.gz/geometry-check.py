import json,sys
c=json.load(open(sys.argv[1]))['cases'];issues=[]
if len(c)!=25:issues.append('expected 25 cases')
for x in c:
 label=(x['geometry'],x['friction'],x['initial_vn'],x['far'],x['near_miss'])
 if not x['accepted'] or not x['replay']:issues.append((label,'status or replay'))
 if not x['accepted']:continue
 if x['linear_momentum_error']>1e-6 or x['angular_momentum_error']>1e-6:issues.append((label,'momentum'))
 if x['far'] and (abs(x['normal_impulse_ns'])>1e-8 or abs(x['kinetic_work_j'])>1e-8):issues.append((label,'far force'))
 if x['geometry']==2 and not x['far'] and x['friction']==0 and x['initial_vn']==-1:
  if abs(x['normal_impulse_ns']-1)>2e-4 or abs(x['kinetic_work_j']+.5)>1e-5:issues.append((label,'normal impact'))
 if x['geometry']==2 and x['friction']==.5 and x['initial_vn']==0 and (not x['far'] or x['near_miss']):
  if abs(x['normal_impulse_ns'])>1e-8 or abs(x['kinetic_work_j'])>1e-8 or abs(x['final_vn'])>1e-7 or abs(x['final_vt']-1)>1e-7:issues.append((label,'force free sliding'))
print(json.dumps({'passed':not issues,'count':len(c),'issues':issues},indent=2))

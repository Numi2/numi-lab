#!/usr/bin/env python3
"""Build a pinned, no-step parent-identity control for the registered-volume importer.

This exports the existing captured parent tetrahedra as TetGen tables, then
extracts O/I/D surfaces from exact parent cell facets using the captured
parent-layer role rows. It is a source-control fixture, not a repaired skin
candidate and not a physical admission.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import pathlib
import struct
import sys
from collections import defaultdict
from typing import Any


ROLE_ORDER = ("O", "I", "D")
ROLE_DOMAIN = {
    "O": "parent_capture_A_O_role_control",
    "I": "D37_coarse_parent",
    "D": "D37_coarse_parent",
}
MATERIAL = {"O": 15, "I": 15, "D": 16}
CORNER_FACES = ((1, 2, 3), (0, 3, 2), (0, 1, 3), (0, 2, 1))
IDENTITY_KIND = "source_parent_tet_reference_registration"
FRAME_METHOD = "captured_native_current_rest_local_to_world_f32"


def digest(path: pathlib.Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def read_csv(path: pathlib.Path) -> list[dict[str, str]]:
    with path.open(newline="") as f:
        return list(csv.DictReader(f))


def write_csv(path: pathlib.Path, header: list[str], rows: list[list[Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="") as f:
        writer = csv.writer(f, lineterminator="\n")
        writer.writerow(header)
        writer.writerows(rows)


def f32(x: float) -> float:
    try:
        y = struct.unpack("<f", struct.pack("<f", x))[0]
    except (OverflowError, struct.error) as exc:
        raise ValueError(f"coordinate is not representable as Float32: {x}") from exc
    if not math.isfinite(y):
        raise ValueError(f"coordinate is not finite Float32: {x}")
    return y


def norm(v: tuple[float, float, float]) -> float:
    return math.sqrt(sum(x * x for x in v))


def sub(a: tuple[float, float, float], b: tuple[float, float, float]):
    return (a[0] - b[0], a[1] - b[1], a[2] - b[2])


def cross(a: tuple[float, float, float], b: tuple[float, float, float]):
    return (a[1] * b[2] - a[2] * b[1],
            a[2] * b[0] - a[0] * b[2],
            a[0] * b[1] - a[1] * b[0])


def dot(a: tuple[float, float, float], b: tuple[float, float, float]) -> float:
    return sum(a[i] * b[i] for i in range(3))


def orient_sign(tri: tuple[int, int, int]) -> int:
    inversions = sum(tri[i] > tri[j] for i in range(3) for j in range(i + 1, 3))
    return -1 if inversions & 1 else 1


def v3(row: dict[str, str], names: tuple[str, str, str]) -> tuple[float, float, float]:
    return tuple(float(row[k]) for k in names)


def f32op(value: float) -> float:
    return struct.unpack("<f", struct.pack("<f", float(value)))[0]


def f32_add(a: float, b: float) -> float:
    return f32op(a + b)


def f32_sub(a: float, b: float) -> float:
    return f32op(a - b)


def f32_mul(a: float, b: float) -> float:
    return f32op(a * b)


def inverse3_row_major(matrix: tuple[float, ...]) -> tuple[float, ...]:
    if len(matrix) != 9 or any(not math.isfinite(value) for value in matrix):
        raise ValueError("captured native frame matrix is incomplete or nonfinite")
    a, b, c, d, e, f, g, h, i = matrix
    determinant = a * (e * i - f * h) - b * (d * i - f * g) + c * (d * h - e * g)
    if not math.isfinite(determinant) or determinant == 0.0:
        raise ValueError("captured native frame matrix is singular")
    inverse = (
        (e * i - f * h) / determinant,
        (c * h - b * i) / determinant,
        (b * f - c * e) / determinant,
        (f * g - d * i) / determinant,
        (a * i - c * g) / determinant,
        (c * d - a * f) / determinant,
        (d * h - e * g) / determinant,
        (b * g - a * h) / determinant,
        (a * e - b * d) / determinant,
    )
    if any(not math.isfinite(value) for value in inverse):
        raise ValueError("captured native frame inverse is nonfinite")
    return inverse


def matrix_vector3(matrix: tuple[float, ...], vector: tuple[float, float, float]):
    return tuple(sum(matrix[3 * row + column] * vector[column] for column in range(3))
                 for row in range(3))


def rotate_point_native(q, point):
    x, y, z, w = q
    px, py, pz = point
    twice = (
        f32_mul(2.0, f32_sub(f32_mul(y, pz), f32_mul(z, py))),
        f32_mul(2.0, f32_sub(f32_mul(z, px), f32_mul(x, pz))),
        f32_mul(2.0, f32_sub(f32_mul(x, py), f32_mul(y, px))),
    )
    correction = (
        f32_sub(f32_add(f32_mul(w, twice[0]), f32_mul(y, twice[2])), f32_mul(z, twice[1])),
        f32_sub(f32_add(f32_mul(w, twice[1]), f32_mul(z, twice[0])), f32_mul(x, twice[2])),
        f32_sub(f32_add(f32_mul(w, twice[2]), f32_mul(x, twice[1])), f32_mul(y, twice[0])),
    )
    return tuple(f32_add(point[i], correction[i]) for i in range(3))


def load_frame_table(poses):
    by_body = {}
    body_to_binding = {}
    for binding, pose_row in enumerate(poses["bodies"]):
        body = int(pose_row["body_index"])
        if body in by_body:
            raise ValueError("native pose table repeats a bound body")
        native_pose = poses["all_bodies"][body]
        current = native_pose["current"]
        rest = native_pose["rest"]
        current_R = tuple(float(x) for x in current.get("local_to_world_row_major_f32", []))
        rest_R = tuple(float(x) for x in rest.get("local_to_world_row_major_f32", []))
        if len(current_R) != 9 or len(rest_R) != 9:
            raise ValueError("capture pose snapshot lacks native current/rest local_to_world_row_major_f32 matrices")
        if any(not math.isfinite(x) or f32op(x) != x for x in (*current_R, *rest_R)):
            raise ValueError("captured native local-to-world matrix contains a non-Float32 or nonfinite value")
        by_body[body] = {
            "binding": binding,
            "origin": tuple(f32op(x) for x in current["position_world_m"]),
            "current_R": current_R,
            "current_invR": inverse3_row_major(current_R),
            "rest_origin": tuple(f32op(x) for x in rest["position_world_m"]),
            "rest_R": rest_R,
        }
        body_to_binding[body] = binding
    if len(by_body) != 86 or int(poses["binding_count"]) != 86:
        raise ValueError(f"expected exact parent capture A native 86-binding pose table, got {len(by_body)}")
    return by_body, body_to_binding

def write_frame_table(path: pathlib.Path, frames_by_body):
    header = ["binding", "donor", "current_x", "current_y", "current_z"]
    header += [f"current_R{i}{j}" for i in range(3) for j in range(3)]
    header += ["rest_x", "rest_y", "rest_z"]
    header += [f"rest_R{i}{j}" for i in range(3) for j in range(3)]
    rows = []
    for body, frame in sorted(frames_by_body.items(), key=lambda item: item[1]["binding"]):
        rows.append([frame["binding"], body,
                     *[format(x, ".17g") for x in frame["origin"]],
                     *[format(x, ".17g") for x in frame["current_R"]],
                     *[format(x, ".17g") for x in frame["rest_origin"]],
                     *[format(x, ".17g") for x in frame["rest_R"]]])
    write_csv(path, header, rows)

def export(args: argparse.Namespace) -> dict[str, Any]:
    capture = args.capture.resolve()
    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=False)

    packet = capture / "compiled-parent-cell-mass.csv"
    nodes_path = capture / "compiled-parent-cell-mass.csv.nodes.csv"
    tets_path = capture / "compiled-parent-cell-mass.csv.tets.csv"
    labels_path = capture / "compiled-parent-cell-mass.csv.labels.csv"
    weights_path = capture / "compiled-parent-cell-mass.csv.weights.csv"
    layer_path = capture / "parent-layer-rows.csv"
    pose_path = capture / "registered-skin-poses-100.json"
    inputs = [packet, nodes_path, tets_path, labels_path, weights_path, layer_path, pose_path]
    for p in inputs:
        if not p.is_file():
            raise FileNotFoundError(p)
    input_hashes = {str(p): digest(p) for p in inputs}
    poses = json.loads(pose_path.read_text())
    if len(poses.get("all_bodies", [])) != 157 or len(poses.get("bodies", [])) != 86:
        raise ValueError("parent capture must contain all 157 body poses and native 86 bindings")
    frame_by_body, binding_by_body = load_frame_table(poses)

    node_rows = read_csv(nodes_path)
    tets = read_csv(tets_path)
    labels = read_csv(labels_path)
    weights = read_csv(weights_path)
    layer_rows = read_csv(layer_path)
    if len(node_rows) != 7233 or len(tets) != 28632 or len(labels) != len(tets):
        raise ValueError("source-control capture dimensions differ from the exact 7233/28632 parent packet")
    if len(weights) != len(node_rows) or len(layer_rows) != len(node_rows):
        raise ValueError("parent layer or full86 weight rows do not cover all captured volume nodes")

    points = []
    for i, row in enumerate(node_rows):
        if int(row["parent_node_index"]) != i or int(row["compiled_global_node"]) < 0:
            raise ValueError(f"parent node row identity is invalid at {i}")
        p = tuple(f32(float(row[k])) for k in ("current_x_m", "current_y_m", "current_z_m"))
        points.append(p)
    owner_by_node = [int(row["node_frame_owner_body"]) for row in node_rows]
    if max(owner_by_node) >= len(poses["all_bodies"]):
        raise ValueError("parent node frame owner exceeds all-body pose domain")

    role_rows: dict[str, list[dict[str, str]]] = {}
    role_by_node: dict[int, tuple[str, int]] = {}
    local_points_by_node: dict[int, tuple[float, float, float]] = {}
    for role in ROLE_ORDER:
        rr = sorted((r for r in layer_rows if r["role"] == role), key=lambda r: int(r["role_row"]))
        if len(rr) != 2411:
            raise ValueError(f"parent source-control role {role} has {len(rr)} rows; expected 2411")
        for local, row in enumerate(rr):
            node = int(row["volume_node_row"])
            if int(row["role_row"]) != local or node < 0 or node >= len(points) or node in role_by_node:
                raise ValueError(f"role {role} has duplicate or invalid node identity at row {local}")
            if int(row["compiled_global_node"]) != int(node_rows[node]["compiled_global_node"]):
                raise ValueError(f"role {role} global node differs from the captured parent at row {local}")
            captured = v3(row, ("current_x_m", "current_y_m", "current_z_m"))
            if captured != points[node]:
                raise ValueError(f"role {role} point differs from exact parent current node at row {local}")
            body = int(row["frame_owner_body"])
            frame = frame_by_body.get(body)
            if frame is None:
                raise ValueError(f"role {role} node {local} has no pinned donor frame for body {body}")
            captured_local = v3(row, ("donor_local_x_m", "donor_local_y_m", "donor_local_z_m"))
            delta = sub(captured, frame["origin"])
            local_point = matrix_vector3(frame["current_invR"],delta)
            local_points_by_node[node] = local_point
            role_by_node[node] = (role, local)
        role_rows[role] = rr
    if len(role_by_node) != len(points) or set(role_by_node) != set(range(len(points))):
        raise ValueError("captured role rows must assign every parent node once across O/I/D")

    # Preserve the actual parent row identity. The exact canonical node set is
    # also recorded for future producers that re-order the same cells.
    parent_cell_by_nodes = {}
    cell_tets = []
    cell_material = []
    cell_labels = []
    incident: list[list[int]] = [[] for _ in points]
    for i, (tetrow, label) in enumerate(zip(tets, labels)):
        if int(tetrow["parent_tet_row"]) != i or int(label["parent_tet_row"]) != i:
            raise ValueError(f"parent tet/label row identity differs at {i}")
        nodes = tuple(int(tetrow[f"parent_node{k}"]) for k in range(4))
        if min(nodes) < 0 or max(nodes) >= len(points) or len(set(nodes)) != 4:
            raise ValueError(f"parent tetrahedron has invalid nodes at {i}")
        material = int(tetrow["material_index"])
        if material not in (15, 16) or int(label["material_index"]) != material:
            raise ValueError(f"parent material label mismatch at cell {i}")
        key = tuple(sorted(nodes))
        if key in parent_cell_by_nodes:
            raise ValueError(f"parent contains duplicate cell topology at row {i}")
        parent_cell_by_nodes[key] = i
        a, b, c, d = (points[n] for n in nodes)
        six = dot(sub(b, a), cross(sub(c, a), sub(d, a)))
        if not math.isfinite(six) or six <= 0.0:
            raise ValueError(f"parent cell is nonpositive in the captured Float32 target at row {i}")
        cell_tets.append(nodes)
        cell_material.append(material)
        cell_labels.append(label)
        for node in nodes:
            incident[node].append(i)

    face_uses: dict[tuple[int, int, int], list[tuple[int, tuple[int, int, int], int]]] = defaultdict(list)
    for cell, tet in enumerate(cell_tets):
        for corner in CORNER_FACES:
            tri = tuple(tet[j] for j in corner)
            face_uses[tuple(sorted(tri))].append((cell, tri, cell_material[cell]))
    role_faces = {r: [] for r in ROLE_ORDER}
    walls: list[tuple[str, int, tuple[int, int, int], int]] = []
    classified_boundary = 0
    i_interface = 0
    for key, uses in face_uses.items():
        role_pattern = tuple(role_by_node[n][0] for n in key)
        if len(uses) == 2:
            if uses[0][2] != uses[1][2]:
                skin = next(u for u in uses if u[2] == 15)
                fat = next(u for u in uses if u[2] == 16)
                if tuple(sorted(role_pattern)) != ("I", "I", "I"):
                    raise ValueError("material interface does not use exactly three captured I nodes")
                if orient_sign(skin[1]) + orient_sign(fat[1]) != 0:
                    raise ValueError("parent skin/fat I interface triangles do not have reversed orientation")
                role_faces["I"].append((skin[1], skin[0], fat[0]))
                i_interface += 1
            continue
        if len(uses) != 1:
            raise ValueError("parent source-control volume has a nonmanifold face")
        cell, tri, material = uses[0]
        classified_boundary += 1
        if material == 15:
            if set(role_pattern) == {"O"}:
                role_faces["O"].append((tri, cell, cell_labels[cell]))
            elif set(role_pattern) <= {"O", "I"} and "O" in role_pattern and "I" in role_pattern:
                walls.append(("skin", cell, tri, 15))
            else:
                raise ValueError(f"skin boundary face has unsupported role pattern {role_pattern}")
        else:
            if set(role_pattern) == {"D"}:
                role_faces["D"].append((tri, cell, cell_labels[cell]))
            elif set(role_pattern) <= {"I", "D"} and "I" in role_pattern and "D" in role_pattern:
                walls.append(("fat", cell, tri, 16))
            else:
                raise ValueError(f"fat boundary face has unsupported role pattern {role_pattern}")

    for role in ROLE_ORDER:
        role_faces[role].sort(key=lambda x: tuple(sorted(x[0] if role != "I" else x[0])))
        if len(role_faces[role]) != 4777:
            raise ValueError(f"source-control surface {role} has {len(role_faces[role])} faces; expected 4777")
        used_nodes = {n for face in role_faces[role] for n in face[0]}
        expected_nodes = {int(row["volume_node_row"]) for row in role_rows[role]}
        if used_nodes != expected_nodes:
            raise ValueError(f"parent facet extraction does not exactly cover {role} role nodes")
    if classified_boundary != 9734 or i_interface != 4777 or len(walls) != 180:
        raise ValueError(f"parent boundary extraction counts differ: boundary={classified_boundary}, I={i_interface}, walls={len(walls)}")

    # Select one exact same-material parent tet per node for the semantic tuple.
    # Every I row uses its skin-side anchor, while both node-map copies retain
    # the same O/I/D source identity and current target.
    selected_parent = []
    for node, role in enumerate(role_by_node[n][0] for n in range(len(points))):
        wanted = 16 if role == "D" else 15
        cell = next((c for c in incident[node] if cell_material[c] == wanted), None)
        if cell is None:
            raise ValueError(f"role node {node} has no incident parent cell in its selected material")
        corner = cell_tets[cell].index(node)
        beta = tuple(1.0 if i == corner else 0.0 for i in range(4))
        selected_parent.append((cell, beta))

    # Exact TetGen parent identity files.
    volume_dir = out / "volume"
    volume_dir.mkdir()
    with (volume_dir / "mesh.node").open("w") as f:
        f.write(f"{len(points)} 3 0 0\n")
        for i, p in enumerate(points):
            f.write(f"{i+1} " + " ".join(format(x, ".17g") for x in p) + "\n")
    with (volume_dir / "mesh.ele").open("w") as f:
        f.write(f"{len(cell_tets)} 4 1\n")
        for i, (tet, material) in enumerate(zip(cell_tets, cell_material)):
            f.write(f"{i+1} " + " ".join(str(n+1) for n in tet) + f" {material}\n")
    label_header = ["child_tet_row", "material_index", "geometric_donor_body",
                    "anatomical_region_id", "stable_source_face_id"]
    label_rows = []
    for i, label in enumerate(cell_labels):
        label_rows.append([i, label["material_index"], label["geometric_donor_body"],
                           label["anatomical_region_id"], label["stable_source_face_id"]])
    write_csv(volume_dir / "child.labels.csv", label_header, label_rows)
    write_csv(volume_dir / "cell-parent-map.csv",
              ["child_tet_row", "parent_tet_row", "match_method", "parent_node0", "parent_node1",
               "parent_node2", "parent_node3", "material_index", "geometric_donor_body",
               "anatomical_region_id", "stable_source_face_id"],
              [[i, i, "exact_parent_row_and_canonical_node_identity", *cell_tets[i],
                cell_material[i], cell_labels[i]["geometric_donor_body"],
                cell_labels[i]["anatomical_region_id"], cell_labels[i]["stable_source_face_id"]]
               for i in range(len(cell_tets))])

    # Role assets and exact extracted registered surfaces.
    role_dir = out / "roles"
    registered_dir = out / "registered"
    role_dir.mkdir()
    registered_dir.mkdir()
    weights_by_node = {}
    for i, row in enumerate(weights):
        if int(row["vertex"]) != i:
            raise ValueError(f"parent full86 row index differs at {i}")
        vals = [float(row[f"w{k}"]) for k in range(86)]
        if any(not math.isfinite(x) or x < 0.0 for x in vals) or abs(sum(vals) - 1.0) > 1.0e-5:
            raise ValueError(f"parent full86 weights are invalid at node {i}")
        weights_by_node[i] = vals

    sidecar_face_maps: dict[str, dict[tuple[int, int, int], int]] = {}
    source_asset_records = []
    surface_face_entries = {}
    for role in ROLE_ORDER:
        local_for_node = {int(row["volume_node_row"]): i for i, row in enumerate(role_rows[role])}
        face_entries = []
        sidecar_faces = []
        parent_face_info = []
        for face_row, entry in enumerate(role_faces[role]):
            tri, cell, label_or_fat = entry
            local_tri = tuple(local_for_node[n] for n in tri)
            sidecar_faces.append((face_row, *local_tri, face_row))
            face_entries.append({"face_row": face_row, "surface_vertex_rows": list(local_tri),
                                 "parent_node_rows": list(tri), "parent_tet_row": cell,
                                 "parent_material": cell_material[cell],
                                 "parent_stable_source_face_id": cell_labels[cell]["stable_source_face_id"]})
            parent_face_info.append((face_row, tri, cell, cell_labels[cell]))
        source_asset = role_dir / f"{role}-source.json"
        source_doc = {
            "schema": "numi-human.parent-capture-identity-role-source-control.v1",
            "control_only": True,
            "role": role,
            "source_domain": ROLE_DOMAIN[role],
            "parent_capture": str(capture),
            "parent_packet_sha256": input_hashes[str(packet)],
            "parent_nodes_sha256": input_hashes[str(nodes_path)],
            "parent_tets_sha256": input_hashes[str(tets_path)],
            "parent_labels_sha256": input_hashes[str(labels_path)],
            "vertices": [
                {"source_vertex_row": i, "parent_volume_node_row": int(row["volume_node_row"]),
                 "compiled_global_node": int(row["compiled_global_node"]),
                 "current_world_m": list(points[int(row["volume_node_row"])]),
                 "captured_frame_owner_body": int(row["frame_owner_body"]),
                 "captured_donor_local_m": list(v3(row, ("donor_local_x_m", "donor_local_y_m", "donor_local_z_m"))),
                 "registered_donor_local_m": list(local_points_by_node[int(row["volume_node_row"])]),
                 "registered_frame_owner_body": int(row["frame_owner_body"])}
                for i, row in enumerate(role_rows[role])
            ],
            "faces": face_entries,
            "physical_admission": False,
        }
        source_asset.write_text(json.dumps(source_doc, indent=2, sort_keys=True) + "\n")
        weights_out = role_dir / f"{role}-full86.csv"
        wrows = []
        for i, row in enumerate(role_rows[role]):
            node = int(row["volume_node_row"])
            wrows.append([i, *[format(v, ".17g") for v in weights_by_node[node]]])
        write_csv(weights_out, ["vertex", *[f"w{i}" for i in range(86)]], wrows)

        domain = ROLE_DOMAIN[role]
        nodes_out = registered_dir / f"registered-{role}.csv"
        faces_out = registered_dir / f"registered-{role}-faces.csv"
        nheader = ["vertex", "donor", "wx", "wy", "wz", "nx", "ny", "nz",
                   "lx", "ly", "lz", "m00", "m01", "m02", "m10", "m11",
                   "m12", "m20", "m21", "m22"]
        if role == "O":
            nheader += ["d37_source_vertex_row", "d37_source_face_row",
                        "beta0", "beta1", "beta2", "projection_distance_m",
                        "source_vertex_row", "source_face_row", "source_bary0",
                        "source_bary1", "source_bary2", "source_residual_x_m",
                        "source_residual_y_m", "source_residual_z_m",
                        "source_domain", "frame_owner_method"]
            face_header = ["face", "v0", "v1", "v2", "baseline806_source_face_row"]
        else:
            nheader += ["source_domain", "d37_parent_node_row",
                        "d37_parent_surface_face_row", "beta0", "beta1", "beta2",
                        "source_residual_x_m", "source_residual_y_m",
                        "source_residual_z_m", "frame_owner_method"]
            face_header = ["face", "v0", "v1", "v2", "d37_parent_surface_face_row",
                           "d37_parent_tet_row", "material_index", "source_role"]
        nrows = []
        normals = [[0.0, 0.0, 0.0] for _ in role_rows[role]]
        for face_row, tri, _, _ in parent_face_info:
            p0, p1, p2 = (points[n] for n in tri)
            fn = cross(sub(p1, p0), sub(p2, p0))
            for node in tri:
                local = local_for_node[node]
                normals[local] = [normals[local][a] + fn[a] for a in range(3)]
        for i, row in enumerate(role_rows[role]):
            node = int(row["volume_node_row"])
            body = int(row["frame_owner_body"])
            frame = frame_by_body[body]
            nn = tuple(normals[i])
            nnorm = norm(nn)
            if nnorm <= 1.0e-20:
                raise ValueError(f"role {role} has an unused/degenerate node normal at row {i}")
            normal = tuple(x / nnorm for x in nn)
            p = points[node]
            local = local_points_by_node[node]
            inv = frame["current_invR"]
            prefix = [i, body, *p, *normal, *local, *inv]
            if role == "O":
                nrows.append([*prefix, i, -1, 1, 0, 0, 0, i, -1, 0, 0, 0,
                              0, 0, 0, domain, FRAME_METHOD])
            else:
                nrows.append([*prefix, domain, i, -1, 0, 0, 0, 0, 0, 0, FRAME_METHOD])
        write_csv(nodes_out, nheader, nrows)

        frows = []
        face_source_map = {}
        for face_row, tri, cell, label in parent_face_info:
            local = [local_for_node[n] for n in tri]
            if role == "O":
                frows.append([face_row, *local, face_row])
            else:
                frows.append([face_row, *local, face_row, cell,
                              cell_material[cell], f"parent-capture-A-{role}-exact-facet"])
            face_source_map[tuple(sorted(tri))] = face_row
        write_csv(faces_out, face_header, frows)
        sidecar_face_maps[role] = face_source_map
        surface_face_entries[role] = parent_face_info
        source_asset_records.append({
            "role": role, "source_domain": domain, "source_asset": str(source_asset),
            "source_asset_sha256": digest(source_asset),
            "source_vertex_count": len(role_rows[role]),
            "source_face_count": len(parent_face_info),
            "full86_csv": str(weights_out), "full86_sha256": digest(weights_out),
            "full86_row_count": len(wrows),
            "registered_nodes_csv": str(nodes_out), "registered_nodes_sha256": digest(nodes_out),
            "registered_faces_csv": str(faces_out), "registered_faces_sha256": digest(faces_out),
        })

    # Exact donor-frame table stays in its original native producer encoding.
    frames_out = registered_dir / "donor-frames.csv"
    write_frame_table(frames_out, frame_by_body)

    # Surface-to-parent registration uses exact captured parent nodes, with
    # one-hot parent barycentrics and zero current residuals.
    reg_header = ["layer", "surface_vertex_row", "parent_registration_kind", "parent_tet_row",
                  "parent_bary0", "parent_bary1", "parent_bary2", "parent_bary3",
                  "parent_residual_x_m", "parent_residual_y_m", "parent_residual_z_m",
                  "parent_registration_distance_m", "parent_registration_tie_count",
                  "frame_owner_method", "source_domain", "source_vertex_row",
                  "source_face_row", "source_bary0", "source_bary1", "source_bary2",
                  "source_residual_x_m", "source_residual_y_m", "source_residual_z_m"]
    registration_rows = []
    for role in ROLE_ORDER:
        for local, row in enumerate(role_rows[role]):
            node = int(row["volume_node_row"])
            cell, beta = selected_parent[node]
            registration_rows.append([role, local, IDENTITY_KIND, cell, *beta,
                                      0, 0, 0, 0, 0, FRAME_METHOD,
                                      ROLE_DOMAIN[role], local, -1, 0, 0, 0, 0, 0, 0])
    node_registration = registered_dir / "node-parent-registration.csv"
    write_csv(node_registration, reg_header, registration_rows)

    # O-face ancestry preserves exact parent cell and source-face identity.
    outer_rows = []
    for face_row, tri, cell, label in surface_face_entries["O"]:
        outer_rows.append([face_row, -1, label["stable_source_face_id"], face_row,
                           "parent_capture_A_exact_parent_cell_facet"])
    outer_ancestry = registered_dir / "outer-face-ancestry.csv"
    write_csv(outer_ancestry,
              ["output_face_row", "parent_face_row", "source_original_id",
               "source_face_row", "ancestry_role"], outer_rows)

    # Semantic child labels remain exact parent rows. The combined node map
    # preserves frame-owner, geometric donor, region and source namespace as
    # distinct typed fields.
    map_header = ["joint_node_id", "source_partition", "source_tetgen_node_id",
                  "registered_I_source_vertex_row", "merge_peer_partition",
                  "merge_peer_tetgen_node_id", "registered_surface_layer",
                  "registered_surface_vertex_row", "role", "current_x_m", "current_y_m",
                  "current_z_m", "donor_body", "donor_binding", "donor_local_x_m",
                  "donor_local_y_m", "donor_local_z_m", "source_domain",
                  "source_mapping_kind", "source_vertex_row", "source_face_row",
                  "source_bary0", "source_bary1", "source_bary2", "source_residual_x_m",
                  "source_residual_y_m", "source_residual_z_m", "frame_owner_method",
                  "parent_registration_kind", "parent_tet_row", "parent_bary0",
                  "parent_bary1", "parent_bary2", "parent_bary3",
                  "parent_current_residual_x_m", "parent_current_residual_y_m",
                  "parent_current_residual_z_m", "parent_registration_distance_m",
                  "parent_registration_tie_count", "incident_material_mask",
                  "geometric_donor_body", "anatomical_region_id"]
    map_rows = []
    for node in range(len(points)):
        role, local = role_by_node[node]
        cell, beta = selected_parent[node]
        layer_row = role_rows[role][local]
        label = cell_labels[cell]
        mask = 0
        for incident_cell in incident[node]:
            mask |= 1 << cell_material[incident_cell]
        body = int(layer_row["frame_owner_body"])
        # TetGen node IDs are partition-local. Skin combines its disjoint O
        # and I role rows; fat combines its I and D role rows. Keep those IDs
        # unique within each partition while preserving reciprocal I peers.
        p = points[node]
        world_delta = sub(p, frame_by_body[body]["origin"])
        local_point = matrix_vector3(frame_by_body[body]["current_invR"],world_delta)
        common = [node + 1, None, None, local if role == "I" else -1,
                  None, None, role, local, role, *p, body, binding_by_body[body],
                  *local_point, ROLE_DOMAIN[role], "vertex", local, -1, 0, 0, 0,
                  0, 0, 0, FRAME_METHOD, IDENTITY_KIND, cell, *beta, 0, 0, 0, 0, 0,
                  mask, int(label["geometric_donor_body"]), int(label["anatomical_region_id"])]
        if role == "O":
            common[1] = "skin"; common[2] = local + 1
            map_rows.append(common)
        elif role == "D":
            fat_source_id = len(role_rows["I"]) + local + 1
            common[1] = "fat"; common[2] = fat_source_id
            map_rows.append(common)
        else:
            skin_source_id = len(role_rows["O"]) + local + 1
            fat_source_id = local + 1
            skin = list(common)
            skin[1] = "skin"; skin[2] = skin_source_id; skin[4] = "fat"; skin[5] = fat_source_id
            fat = list(common)
            fat[1] = "fat"; fat[2] = fat_source_id; fat[4] = "skin"; fat[5] = skin_source_id
            map_rows.extend([skin, fat])
    node_map = volume_dir / "combined-node-map.csv"
    write_csv(node_map, map_header, map_rows)

    # All registered faces come from extracted parent tet facets. Mixed
    # O/I and I/D boundaries are explicit retained parent head-wall faces.
    facet_header = ["source_partition", "shell_face_row", "face_marker", "face_source_role",
                    "face_source_row", "face_exact_source_row", "face_source_original_id",
                    "face_source_layer", "face_source_body", "face_source_bone",
                    "face_ancestry_kind", "face_run_original_id", "face_source_face_id",
                    "face_ancestry_source_rows", "face_parent_tet_row",
                    "face_parent_material_index", "parent_source_node_rows",
                    "joint_element_id", "child_tet_row", "joint_node0", "joint_node1",
                    "joint_node2", "face_ancestry_source_original_ids",
                    "face_ancestry_parent_face_rows"]
    facet_rows = []
    shell_face_row = defaultdict(int)
    registered_counts = 0
    for role, partition, marker, face_role in [
        ("O", "skin", 1, "outer_O"),
        ("I", "skin", 2, "inner_I"),
        ("I", "fat", 4, "outer_I"),
        ("D", "fat", 5, "inner_D"),
    ]:
        for face_row, tri, cell, label_or_fat in surface_face_entries[role]:
            if role == "I":
                info = face_uses[tuple(sorted(tri))]
                cell_use = next(u for u in info if cell_material[u[0]] == (15 if partition == "skin" else 16))
                cell = cell_use[0]
                tri = cell_use[1]
            label = cell_labels[cell]
            fields = ["-1"] * 24
            fields[0] = partition
            fields[1] = shell_face_row[partition]
            shell_face_row[partition] += 1
            fields[2] = marker
            fields[3] = face_role
            fields[4] = face_row
            fields[5] = face_row
            fields[6] = label["stable_source_face_id"]
            fields[7] = role
            fields[10] = -1
            fields[12] = label["stable_source_face_id"]
            fields[13] = json.dumps([face_row])
            fields[14] = cell
            fields[15] = cell_material[cell]
            fields[16] = json.dumps(list(tri), separators=(",", ":"))
            fields[17] = cell + 1
            fields[18] = cell
            fields[19:22] = [n + 1 for n in tri]
            fields[22] = json.dumps([label["stable_source_face_id"]])
            fields[23] = json.dumps([face_row])
            facet_rows.append(fields)
            registered_counts += 1

    wall_ids = []
    for index, (partition, cell, tri, material) in enumerate(walls):
        label = cell_labels[cell]
        role = "donor_skin_OI_headwall" if partition == "skin" else "donor_fat_ID_headwall"
        stable_wall = 1_000_000 + index
        wall_ids.append(stable_wall)
        fields = ["-1"] * 24
        fields[0] = partition
        fields[1] = shell_face_row[partition]
        shell_face_row[partition] += 1
        fields[2] = 3 if material == 15 else 6
        fields[3] = role
        fields[4] = stable_wall
        fields[10] = 5
        fields[13] = json.dumps([label["stable_source_face_id"]])
        fields[14] = cell
        fields[15] = material
        fields[16] = json.dumps(list(tri), separators=(",", ":"))
        fields[17] = cell + 1
        fields[18] = cell
        fields[19:22] = [n + 1 for n in tri]
        fields[22] = json.dumps([label["stable_source_face_id"]])
        fields[23] = json.dumps([cell])
        facet_rows.append(fields)
    facet_csv = volume_dir / "facet-ancestry.csv"
    write_csv(facet_csv, facet_header, facet_rows)

    role_registry = {
        "schema": "numi-human.registered-volume-role-source-registry.v1",
        "control_only": True,
        "roles": source_asset_records,
        "typed_role_domain_indices": {"O": 0, "I": 1, "D": 2},
        "physical_admission": False,
    }
    registry_path = out / "source-domain-registry.json"
    registry_path.write_text(json.dumps(role_registry, indent=2, sort_keys=True) + "\n")

    all_outputs = [volume_dir / "mesh.node", volume_dir / "mesh.ele",
                   volume_dir / "child.labels.csv", volume_dir / "cell-parent-map.csv",
                   node_map, facet_csv, node_registration, outer_ancestry, frames_out,
                   registry_path]
    all_outputs += [pathlib.Path(r[k]) for r in source_asset_records
                    for k in ("source_asset", "full86_csv", "registered_nodes_csv", "registered_faces_csv")]
    output_hashes = {str(p): digest(p) for p in all_outputs}
    receipt = {
        "schema": "numi-human.registered-volume-parent-identity-source-control.v1",
        "method": "exact captured parent nodes/tetrahedra with boundary faces classified by captured O/I/D layer row sets",
        "parent_capture": str(capture),
        "input_sha256": input_hashes,
        "output_sha256": output_hashes,
        "parent_nodes": len(points),
        "parent_tetrahedra": len(cell_tets),
        "role_nodes": {r: len(role_rows[r]) for r in ROLE_ORDER},
        "role_faces": {r: len(role_faces[r]) for r in ROLE_ORDER},
        "registered_facet_rows": registered_counts,
        "authored_parent_headwall_faces": len(walls),
        "node_map_rows": len(map_rows),
        "node_map_shared_I_pairs": len(role_rows["I"]),
        "parent_maximum_registration_distance_m": 0.0,
        "mass_mapping_maximum_transport_distance_m": args.maximum_mass_transport_distance_m,
        "coordinate_frame_sha256": input_hashes[str(pose_path)],
        "source_body_count": len(poses["all_bodies"]),
        "native_frame_source": "registered-skin-poses-100.json current/rest local_to_world_row_major_f32",
        "role_source_registry": str(registry_path),
        "physical_admission": False,
        "native_steps": 0,
        "claim": "parent identity source-control only; not a repaired candidate and not physical skin qualification",
        "rejected_alternative_preserved": str(capture.parent.parent / "coarse-transfer-mass-assets-299" / "mass-preflight.log"),
    }
    receipt_path = out / "receipt.json"
    receipt_path.write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n")
    return receipt


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--capture", type=pathlib.Path, required=True)
    parser.add_argument("--out", type=pathlib.Path, required=True)
    parser.add_argument("--maximum-mass-transport-distance-m", type=float, default=0.02)
    args = parser.parse_args()
    if not math.isfinite(args.maximum_mass_transport_distance_m) or args.maximum_mass_transport_distance_m <= 0:
        parser.error("mass transport distance must be positive and finite")
    try:
        receipt = export(args)
    except Exception as exc:
        print(f"parent_identity_control=FAIL reason={exc}", file=sys.stderr)
        return 1
    print(json.dumps(receipt, sort_keys=True))
    print("parent_identity_control=PASS physical_admission=0 native_steps=0")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())


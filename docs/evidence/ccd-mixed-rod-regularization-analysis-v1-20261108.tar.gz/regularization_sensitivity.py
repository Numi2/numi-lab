import json, numpy as np
from scipy.optimize import least_squares
from pathlib import Path
root=Path(__file__).parent.parent
runs=json.loads((root/'mixed-rod-priority-v1/candidate.json').read_text())['cases']
ref=json.loads((root/'mixed-rod-priority-v1/reference.json').read_text())[2]
axes=[json.loads((root/'mixed-rod-operator-v1'/('axis%d.json'%k)).read_text())['cases'] for k in range(3)]
W=np.zeros((9,9))
for a in range(3):
 for i,row in enumerate(axes[a][2]['rows']):
  for sa in range(3):
   for j in range(3):W[3*i+a,3*j+sa]=row['operator_rows'][3*sa+j]
W=(W+W.T)*.5;u=np.array(ref['pre']);target=np.array(ref['target']);b=u-target
starts=[np.array(ref['impulse']),np.array([x for r in runs[2]['rows'] for x in r['impulse']])]
res=[]
for stiffness in (0.,.001,.01,.1,1.,10.,100.):
 M=W.copy();M[3,3]+=stiffness;M[6,6]+=stiffness;diag=np.diag(M)
 def F(j):
  v=M@j+b;ans=np.zeros(9)
  for i in range(3):
   k=3*i;n=j[k];ans[k]=min(n,v[k]/diag[k])
   t=j[k+1:k+3]-v[k+1:k+3]/max(diag[k+1:k+3]);rad=max(0.,.5*n);mag=np.linalg.norm(t)
   if mag>rad:t*=rad/mag
   ans[k+1:k+3]=j[k+1:k+3]-t
  return ans
 roots=[]
 for x in starts:
  q=least_squares(F,x,xtol=1e-15,ftol=1e-15,gtol=1e-15,max_nfev=30000)
  roots.append({'impulse':q.x.tolist(),'residual_ns':float(np.linalg.norm(F(q.x),np.inf)),'physical_post':(W@q.x+u).tolist(),'physical_work_j':float(.5*q.x@(2*u+W@q.x))})
 res.append({'normal_reg_m_s_per_ns':stiffness,'roots':roots,'physical_velocity_difference_m_s':float(np.linalg.norm(np.array(roots[0]['physical_post'])-np.array(roots[1]['physical_post'])))})
print(json.dumps(res,indent=2))

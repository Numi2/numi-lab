import json,numpy as np
from pathlib import Path
root=Path(__file__).parent.parent
ref=json.loads((root/'mixed-rod-priority-v1/reference.json').read_text())[2]
axes=[json.loads((root/'mixed-rod-operator-v1'/('axis%d.json'%k)).read_text())['cases'] for k in range(3)]
W=np.zeros((9,9))
for a in range(3):
 for i,row in enumerate(axes[a][2]['rows']):
  for sa in range(3):
   for j in range(3):W[3*i+a,3*j+sa]=row['operator_rows'][3*sa+j]
W=(W+W.T)*.5;u=np.array(ref['pre']);target=np.array(ref['target']);out=[]
for e in (1e-5,.001,.1):
 for ratio in (1.,4.):
  e1=e;e2=e*ratio
  f=e2/(e1+e2)
  z=np.zeros(9);z[3]=f;z[4]=-.5*f;z[6]=1-f;z[7]=-.5*(1-f)
  total=(target[3]-u[3])/((W@z)[3]+e1*f)
  impulse=z*total;vel=W@impulse+u;g=vel-target
  out.append({'reg1':e1,'reg2':e2,'row1_share':f,'normal_total_ns':float(total),'normal_equations_m_s':[float(g[3]+e1*impulse[3]),float(g[6]+e2*impulse[6])],'rod_slips_m_s':[float(vel[4]),float(vel[7])],'physical_work_j':float(.5*impulse@(2*u+W@impulse))})
print(json.dumps(out,indent=2))

#!/usr/bin/env python3
"""FP64 symmetric two-normal-group sticking hypothesis; fixed fixture only."""
import json,math,sys
D=json.load(open(sys.argv[1]));steps=D['cases'][4]['steps'];Q=steps[4]['q'];V=steps[4]['v'];R=steps[5]['rows']
def dot(a,b):return sum(x*y for x,y in zip(a,b))
def cross(a,b):return [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]
def add(a,b):return [x+y for x,y in zip(a,b)]
def mul(a,s):return [x*s for x in a]
def solve(A,b):
 a=[row[:] + [z] for row,z in zip(A,b)]
 for j in range(len(a)):
  k=max(range(j,len(a)),key=lambda i:abs(a[i][j]));a[j],a[k]=a[k],a[j];assert abs(a[j][j])>1.e-10
  z=a[j][j];a[j]=[v/z for v in a[j]]
  for k in range(len(a)):
   if k!=j:
    z=a[k][j];a[k]=[x-z*y for x,y in zip(a[k],a[j])]
 return [row[-1] for row in a]
r=[[x-y for x,y in zip(row['point'],Q[:3])] for row in R];n=[0.,1.,0.];t=[1.,0.,0.]
# Two normal group totals and a tangential total; the latter is shared by the right contacts.
cols=[[(0,.5,n),(2,.5,n)],[(1,.5,n),(3,.5,n)],[(1,.5,t),(3,.5,t)]]
rows=[(0,n),(1,n),(1,t)]
def coeff(target_idx, direction, col):return sum(w*(dot(direction,f)+10*dot(cross(r[target_idx],direction),cross(r[j],f))) for j,w,f in col)
A=[[coeff(i,d,c) for c in cols] for i,d in rows]
b=[-(R[0]['pre']-R[0]['target']),-(R[1]['pre']-R[1]['target']),-R[1]['tangent_pre'][1]]
x=solve(A,b);J=[0.,0.,0.];L=[0.,0.,0.]
for z,col in zip(x,cols):
 for i,w,f in col:J=add(J,mul(f,z*w));L=add(L,cross(r[i],mul(f,z*w)))
Vpre=V[:];Vpre[1]-=.0981;Vpost=add(Vpre[:3],J)+add(Vpre[3:],mul(L,10));work=.5*(dot(J,add(Vpre[:3],Vpost[:3]))+dot(L,add(Vpre[3:],Vpost[3:])))
normal=[R[i]['pre']-R[i]['target']+sum(coeff(i,n,col)*z for col,z in zip(cols,x)) for i in range(4)]
tangent=[R[i]['tangent_pre'][1]+sum(coeff(i,t,col)*z for col,z in zip(cols,x)) for i in range(4)]
print(json.dumps({'normal_group_impulses':x[:2],'tangential_impulse':x[2],'normal_residuals':normal,'tangent_residuals':tangent,'right_cone_limit':.5*x[1],'cone_satisfied':abs(x[2])<=.5*x[1],'final_velocity':Vpost,'contact_work_j':work,'normal_nonnegative':min(x[:2])>=0,'matrix':A},indent=2))
# Complementarity requires the negative right group to be inactive. Solve the
# left normal and tangent pair instead and check the other normals and cone.
cols2=[cols[0],[(0,.5,t),(2,.5,t)]];rows2=[(0,n),(0,t)]
A2=[[coeff(i,d,c) for c in cols2] for i,d in rows2]; b2=[-(R[0]['pre']-R[0]['target']),-R[0]['tangent_pre'][1]];x2=solve(A2,b2)
N2=[R[i]['pre']-R[i]['target']+sum(coeff(i,n,col)*z for col,z in zip(cols2,x2)) for i in range(4)]
T2=[R[i]['tangent_pre'][1]+sum(coeff(i,t,col)*z for col,z in zip(cols2,x2)) for i in range(4)]
J2=[0.,0.,0.];L2=[0.,0.,0.]
for z,col in zip(x2,cols2):
 for i,w,f in col:J2=add(J2,mul(f,z*w));L2=add(L2,cross(r[i],mul(f,z*w)))
V2=add(Vpre[:3],J2)+add(Vpre[3:],mul(L2,10));work2=.5*(dot(J2,add(Vpre[:3],V2[:3]))+dot(L2,add(Vpre[3:],V2[3:])))
print(json.dumps({'active':'left-pair-only','normal_impulse':x2[0],'tangent_impulse':x2[1],'normal_residuals':N2,'tangent_residuals':T2,'friction_limit':.5*x2[0],'cone_satisfied':abs(x2[1])<=.5*x2[0],'final_velocity':V2,'contact_work_j':work2},indent=2))

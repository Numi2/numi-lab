#!/usr/bin/env python3
"""FP64 two-active-corner sliding reference for pinned warm-row capture."""
import json,sys
D=json.load(open(sys.argv[1]));C=D['cases'][1];S=C['steps'][0];R=C['steps'][1]['rows'];q=S['q'];v=S['v']
def dot(a,b):return sum(x*y for x,y in zip(a,b))
def cross(a,b):return [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]
def add(a,b):return [x+y for x,y in zip(a,b)]
def mul(a,s):return [x*s for x in a]
n=[0.,1.,0.];force=[-.5,1.,0.];r=[[x-y for x,y in zip(row['point'],q[:3])] for row in R]
A=[[dot(n,force)+10*dot(cross(x,n),cross(y,force)) for y in r] for x in r];b=[row['pre']-row['target'] for row in R];i,j=1,3;det=A[i][i]*A[j][j]-A[i][j]*A[j][i];assert abs(det)>1e-8
l=[0.,(-b[i]*A[j][j]+A[i][j]*b[j])/det,0.,(-A[i][i]*b[j]+A[j][i]*b[i])/det];assert min(l)>=0
res=[b[k]+sum(A[k][z]*l[z] for z in range(4)) for k in range(4)];assert res[0]>0 and res[2]>0 and abs(res[1])<1e-12 and abs(res[3])<1e-12
J=mul(force,sum(l));L=[0.,0.,0.]
for point,imp in zip(r,l):L=add(L,cross(point,mul(force,imp)))
vf=add(v[:3],J)+add(v[3:],mul(L,10));work=.5*(dot(J,add(v[:3],vf[:3]))+dot(L,add(v[3:],vf[3:])))
print(json.dumps({'normal_impulses':l,'total_normal_impulse':sum(l),'normal_residuals':res,'final_velocity':vf,'contact_work_j':work,'normal_operator':A,'pre_minus_target':b},sort_keys=True,indent=2))

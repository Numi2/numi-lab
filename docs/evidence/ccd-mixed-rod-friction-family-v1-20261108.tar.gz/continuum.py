import json, numpy as np
from pathlib import Path
root=Path(__file__).parent.parent
refs=json.loads((root/'mixed-rod-priority-v1/reference.json').read_text())
axes=[json.loads((root/'mixed-rod-operator-v1'/('axis%d.json'%k)).read_text())['cases'] for k in range(3)]
ci=2; ref=refs[ci];W=np.zeros((9,9))
for a in range(3):
 for i,row in enumerate(axes[a][ci]['rows']):
  for sa in range(3):
   for j in range(3):W[3*i+a,3*j+sa]=row['operator_rows'][3*sa+j]
W=(W+W.T)*.5
u=np.array(ref['pre']); target=np.array(ref['target']);b=u-target
result=[]
for f in np.linspace(0,1,11):
 unit=np.zeros(9);unit[3]=f;unit[4]=-.5*f;unit[6]=1-f;unit[7]=-.5*(1-f)
 S=-b[3]/(W@unit)[3];j=S*unit;v=W@j+u;g=v-target
 result.append({'row1_share':float(f),'rod_normal_total_ns':float(S),'work_j':float(.5*j@(2*u+W@j)),'normal_residual_m_s':float(max(abs(g[3]),abs(g[6]),max(-g[0],0))),'rod_slip_m_s':[float(v[4]),float(v[7])],'cone_violation_ns':float(max(0,np.linalg.norm(j[4:6])-.5*j[3],np.linalg.norm(j[7:9])-.5*j[6]))})
print(json.dumps(result,indent=2))

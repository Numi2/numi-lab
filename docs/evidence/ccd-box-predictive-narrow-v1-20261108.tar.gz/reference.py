import contextlib, importlib.util, io, json, math
from pathlib import Path
P=Path(__file__);spec=importlib.util.spec_from_file_location('metric',P.with_name('metric_reference.py'));metric=importlib.util.module_from_spec(spec)
with contextlib.redirect_stdout(io.StringIO()):spec.loader.exec_module(metric)
source=P.with_name('reference_input.json')
c=next(x for x in json.loads(source.read_text())['cases'] if x['geometry']==2 and x['initial_vn']==-1 and x['initial_vt']==1 and not x['far'])
def dot(a,b):return sum(x*y for x,y in zip(a,b))
def cross(a,b):return [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]
D=[[0,1,0],[0,0,1],[1,0,0]];R=[r['anchor_b'] for r in c['rows']]
W=[[[[dot(D[a],D[b])+10*dot(cross(R[i],D[a]),cross(R[j],D[b])) for b in range(3)] for j in range(4)] for a in range(3)] for i in range(4)]
p=[[0.,0.,0.] for _ in range(4)];history=[]
for sweep in range(2):
 v=[[-1 if a==0 else 0 if a==1 else 1 for a in range(3)] for i in range(4)]
 for i in range(4):
  for a in range(3):v[i][a]+=sum(W[i][a][j][b]*p[j][b] for j in range(4) for b in range(3))
 relax=[W[i][0][i][0]/sum(abs(W[i][0][j][0]) for j in range(4)) for i in range(4)]
 H=[[[W[i][a][i][b]+(.01*max(abs(W[i][aa][i][bb]) for aa in range(3) for bb in range(3)) if a==b else 0) for b in range(3)] for a in range(3)] for i in range(4)]
 dn=[relax[i]*(max(p[i][0]-v[i][0]/H[i][0][0],0)-p[i][0]) for i in range(4)]
 nxt=[]
 for i in range(4):
  g=[-v[i][a]-sum(W[i][a][j][0]*dn[j] for j in range(4)) for a in (1,2)]
  A,B,C=H[i][1][1],H[i][1][2],H[i][2][2];det=A*C-B*B
  proposed=(p[i][1]+relax[i]*(C*g[0]-B*g[1])/det,p[i][2]+relax[i]*(-B*g[0]+A*g[1])/det)
  n=p[i][0]+dn[i]
  tangent=metric.solve((A,B,C),proposed,(.5*n,.5*n))[0] if n>0 else (0.,0.)
  nxt.append([n,*tangent])
 p=nxt;history.append(p)
v=[[-1 if a==0 else 0 if a==1 else 1 for a in range(3)] for i in range(4)]
for i in range(4):
 for a in range(3):v[i][a]+=sum(W[i][a][j][b]*p[j][b] for j in range(4) for b in range(3))
errors=[]
for i in range(4):
 slip=math.hypot(v[i][1],v[i][2]);lim=.5*p[i][0];errors.append(math.hypot(p[i][1]+lim*v[i][1]/slip,p[i][2]+lim*v[i][2]/slip))
print(json.dumps({'scope':'FP64 diagnostic only; predicts all simultaneous normal impulses before the tangent update, keeps two sweeps','history':history,'final_relative_velocities':v,'maximum_dissipation_errors_ns':errors,'gate_ns':[1e-5+.001*.5*r[0] for r in p]},indent=2))

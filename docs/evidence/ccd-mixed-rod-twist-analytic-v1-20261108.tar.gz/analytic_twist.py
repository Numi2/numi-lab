"""Independent two-edge axial angular-impulse check, SI units."""
import json, math
from pathlib import Path
root=Path(__file__).parent
radius_m=0.003
edge_length_m=0.02
density_kg_m3=1000.0
young_pa=100000.0
poisson=0.35
timestep_s=0.001
twist_damping_per_s=0.02
impulse_ns=1.e-5
polar_m4=math.pi*radius_m**4/2
inertia_kg_m2=density_kg_m3*polar_m4*edge_length_m
shear_pa=young_pa/(2*(1+poisson))
coupling_kg_m2=timestep_s**2*shear_pa*polar_m4/edge_length_m
a=inertia_kg_m2*(1+timestep_s*twist_damping_per_s)+coupling_kg_m2
b=-coupling_kg_m2
applied_angular_impulse_nms=radius_m*impulse_ns
det=a*a-b*b
expected=[applied_angular_impulse_nms*a/det,-applied_angular_impulse_nms*b/det]
plus=json.loads((root/'plus.json').read_text())['cases'][0]['rows'][0]['twist_rate_after']
minus=json.loads((root/'minus.json').read_text())['cases'][0]['rows'][0]['twist_rate_after']
check={'edge_inertia_kg_m2':inertia_kg_m2,'angular_impulse_n_m_s':applied_angular_impulse_nms,
       'expected_twist_rates_rad_s':expected,'measured_plus_rad_s':plus,'measured_minus_rad_s':minus,
       'plus_abs_error_rad_s':[abs(x-y) for x,y in zip(plus,expected)],
       'damped_measured_total_angular_impulse_n_m_s':inertia_kg_m2*(1+timestep_s*twist_damping_per_s)*sum(plus)}
print(json.dumps(check,indent=2))

import json
import numpy as np
from pathlib import Path
from scipy.optimize import least_squares
root=Path(__file__).parent.parent
runs=json.loads((root/'mixed-rod-priority-v1/candidate.json').read_text())['cases']
refs=json.loads((root/'mixed-rod-priority-v1/reference.json').read_text())
mats=[json.loads((root/'mixed-rod-operator-v1'/('axis%d.json'%k)).read_text())['cases'] for k in range(3)]
ci=2
W=np.zeros((9,9))
for a in range(3):
 for i,row in enumerate(mats[a][ci]['rows']):
  for sa in range(3):
   for j in range(3):W[3*i+a,3*j+sa]=row['operator_rows'][3*sa+j]
W=(W+W.T)*.5
b=np.array(refs[ci]['pre'])-np.array(refs[ci]['target'])
diag=np.diag(W)
def residual(j):
 v=W@j+b;ans=np.zeros(9)
 for i in range(3):
  k=3*i;n=j[k];ans[k]=min(n,v[k]/diag[k])
  t=j[k+1:k+3]-v[k+1:k+3]/max(diag[k+1:k+3])
  rad=max(0.,.5*n);mag=np.linalg.norm(t)
  if mag>rad:t*=rad/mag
  ans[k+1:k+3]=j[k+1:k+3]-t
 return ans
starts=[np.array(refs[ci]['impulse']),np.array([x for r in runs[ci]['rows'] for x in r['impulse']])]
sol=[]
for start in starts:
 q=least_squares(residual,start,xtol=1e-15,ftol=1e-15,gtol=1e-15,max_nfev=20000)
 sol.append({'impulse':q.x.tolist(),'fixed_point_max_ns':float(np.linalg.norm(residual(q.x),np.inf)),'post_velocity':(W@q.x+np.array(refs[ci]['pre'])).tolist(),'work_j':float(.5*q.x@(2*np.array(refs[ci]['pre'])+W@q.x)),'nfev':q.nfev,'termination':q.status})
print(json.dumps({'solutions':sol,'post_difference_norm_m_s':float(np.linalg.norm(np.array(sol[0]['post_velocity'])-np.array(sol[1]['post_velocity'])))},indent=2))

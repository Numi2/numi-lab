import json
import numpy as np
from pathlib import Path
root=Path(__file__).parent.parent
runs=json.loads((root/'mixed-rod-priority-v1/candidate.json').read_text())['cases']
refs=json.loads((root/'mixed-rod-priority-v1/reference.json').read_text())
mats=[json.loads((root/'mixed-rod-operator-v1'/('axis%d.json'%k)).read_text())['cases'] for k in range(3)]
out=[]
for ci in range(3):
 W=np.zeros((9,9))
 for a in range(3):
  for i,row in enumerate(mats[a][ci]['rows']):
   for sa in range(3):
    for j in range(3):W[3*i+a,3*j+sa]=row['operator_rows'][3*sa+j]
 W=(W+W.T)*.5
 ref=refs[ci];jr=np.array(ref['impulse']);jc=np.array([x for row in runs[ci]['rows'] for x in row['impulse']]);u=np.array(ref['pre']);target=np.array(ref['target']);b=u-target
 sv=np.linalg.svd(W,compute_uv=False)
 def describe(j):
  q=W@j+b; normals=[];diss=[];conev=[];vel=[]
  for i in range(3):
   k=i*3;n=j[k];t=j[k+1:k+3];v=q[k+1:k+3];slip=np.linalg.norm(v)
   normals.append(abs(q[k]) if n>1e-9 else max(0,-q[k]))
   conev.append(max(np.linalg.norm(t)-.5*n,0))
   diss.append(np.linalg.norm(t+.5*n*v/slip) if slip>1e-5 else 0)
  return {'normal_residual_m_s':max(normals),'cone_violation_ns':max(conev),'sliding_error_ns':max(diss),'operator_post_velocity':(q+target).tolist(),'work_j':float(.5*j@(2*u+W@j))}
 delta=jc-jr
 out.append({'initial_vn':runs[ci]['initial_vn'],'singular_values':sv.tolist(),'candidate':describe(jc),'reference':describe(jr),'impulse_difference_norm_ns':float(np.linalg.norm(delta)),'induced_velocity_difference_norm_m_s':float(np.linalg.norm(W@delta)),'null_fraction_velocity_over_impulse':float(np.linalg.norm(W@delta)/max(np.linalg.norm(delta),1e-30)),'delta_impulse_ns':delta.tolist()})
print(json.dumps(out,indent=2))

import json,math
from pathlib import Path
c=next(x for x in json.loads(Path(__file__).with_name('result.json').read_text())['cases'] if x['geometry']==2 and x['initial_vn']==-1 and x['initial_vt']==1 and not x['far'])
assert c['accepted'] and c['contacts']==4
vx,vy,vz,wx,wy,wz=c['final_v'];out=[]
for row in c['rows']:
 assert row['body_a']==0 and row['body_b']==1
 assert row['normal']==[0,1,0] and row['tangent']==[0,0,1]
 x,y,z=row['anchor_b'];sx=vx+wy*z-wz*y;sz=vz+wx*y-wy*x;v=math.hypot(sx,sz)
 J=row['normal_impulse']; jz,jx=row['tangent_impulses'];limit=.5*J
 expected=(-limit*sz/v,-limit*sx/v);error=math.hypot(jz-expected[0],jx-expected[1]);tol=1e-5+.001*limit
 out.append({'anchor':row['anchor_b'],'final_slip_xz':[sx,sz],'impulse_zx':[jz,jx],'expected_zx':expected,'error_ns':error,'tolerance_ns':tol,'pass':error<=tol})
print(json.dumps({'initial_pose':'identity; static plane, dynamic witness local anchor at pre-step pose','case':out},indent=2))

#!/bin/bash
set -eu
out=/Users/numi/numi-lab-ccd-thin-evidence-20261107/mixed-clean-containment-v1
repo=/Users/numi/numi-lab-ccd-mixed-island-containment-20261108
lib=/Users/numi/numi-lab-ccd-warm-containment-build-20261108/libnumi_ccd_world_owner.a
for target in resident-target-v2 probe-detail; do
 /usr/bin/clang++ -O2 -std=gnu++23 -arch arm64 -I"$repo/include" -I"$repo/matter/include" "$out/$target.cpp" "$lib" -Wl,-dead_strip -framework Foundation -framework Metal -framework QuartzCore -framework Accelerate -framework CoreGraphics -framework CoreImage -framework ImageIO -framework MetalKit -framework ModelIO /Library/Developer/CommandLineTools/SDKs/MacOSX.sdk/usr/lib/libxml2.tbd /Library/Developer/CommandLineTools/SDKs/MacOSX.sdk/usr/lib/libsqlite3.tbd -o "$out/$target"
done
cd "$out"
shasum -a 256 resident-target-v2 resident-target-v2.cpp probe-detail probe-detail.cpp build-v2.sh >> SHA256SUMS

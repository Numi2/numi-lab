#!/bin/bash
cd /Users/numi/numi-lab-ccd-thin-evidence-20261107/mixed-clean-containment-v1 || exit 1
date -u +%FT%TZ > v2-times.txt
for variant in main candidate; do
 for probe in resident-target-v2 probe-detail; do
  ./"$probe" "$variant.metallib" > "$probe-$variant.json" 2> "$probe-$variant.stderr"
  printf "%s %s exit=%s\n" "$variant" "$probe" "$?" >> v2-status.txt
 done
done
date -u +%FT%TZ >> v2-times.txt
cat v2-times.txt v2-status.txt

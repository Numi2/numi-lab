#!/bin/bash
cd /Users/numi/numi-lab-ccd-thin-evidence-20261107/mixed-clean-containment-v1 || exit 1
date -u +%FT%TZ > timestamps.txt
for variant in main candidate; do
 for probe in probe-failures probe-controls geometry rollback; do
  ./$probe "$variant.metallib" > "$variant-$probe.json" 2> "$variant-$probe.stderr"
  printf "%s %s exit=%s\n" "$variant" "$probe" "$?" >> statuses.txt
 done
done
date -u +%FT%TZ >> timestamps.txt
cat timestamps.txt statuses.txt

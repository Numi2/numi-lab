#include "metalrobo/HeterogeneousWorld.hpp"
#include "metalrobo/MetalWorld.hpp"
#include <algorithm>
#include <cstring>
#include <filesystem>
#include <iostream>
#include <vector>
template<class T> bool eq(const std::vector<T>&a,const std::vector<T>&b) {
 return a.size()==b.size()&&(a.empty()||std::memcmp(a.data(),b.data(),a.size()*sizeof(T))==0);
}
bool stateeq(const metalrobo::MetalWorldResult&a,const metalrobo::MetalWorldResult&b) {
 return eq(a.finalQ,b.finalQ)&&eq(a.finalV,b.finalV)&&eq(a.finalSceneBodies,b.finalSceneBodies)&&
  eq(a.finalRodNodes,b.finalRodNodes)&&eq(a.finalRodEdges,b.finalRodEdges)&&
  eq(a.contactEvidence.manifoldCounts,b.contactEvidence.manifoldCounts)&&
  eq(a.contactEvidence.manifoldHeaders,b.contactEvidence.manifoldHeaders)&&
  eq(a.contactEvidence.manifoldPoints,b.contactEvidence.manifoldPoints);
}
int main(int argc,char**argv) {
 if(argc!=2||!std::filesystem::is_regular_file(argv[1]))return 2;
 auto m=metalrobo::makeFreeSphereEngineModel();
 m.world.gravityAndTimestep={0,0,0,.001f};m.defaultQ[1]=.01f;
 m.bodies[0].motionType=MR_MOTION_KINEMATIC;
 m.shapes[1].dimensions={.01f,0,0,0};m.shapes[1].contactRestAndBoundingRadius={.001f,0,.01f,0};
 for(auto& x:m.materials){x.friction={.5f,.5f,0,0};x.response={0,0,0,0};}
 MRBodyStateGPU ground{};ground.position.w=1;ground.orientation.w=1;
 ground.flagsAndIndices[0]=MR_MOTION_KINEMATIC;ground.flagsAndIndices[1]=MR_INVALID_INDEX;
 std::vector<MRBodyStateGPU> scene{ground};
 metalrobo::DiscreteRodMaterial mat;mat.radius=.003;mat.density=1000;mat.youngModulus=1.e5;
 metalrobo::HeterogeneousRodProgram rod;rod.instanceId="mixed_resident";
 rod.model=metalrobo::makeStraightSutureRod(3,.04,mat);
 rod.defaultState=metalrobo::makeDiscreteElasticRodDefaultState(rod.model);
 for(auto& p:rod.defaultState.positions){p[0]-=.02;p[1]=.023;}
 rod.collision.enableCCD=false;rod.collision.contactOffset=.001;
 rod.stepConfig.gravity={0,0,0};rod.stepConfig.timestep=.001;
 const std::vector<metalrobo::HeterogeneousWorldComponent> components{{&m,"body",scene}};
 const std::vector<metalrobo::HeterogeneousRodProgram> rods{rod};
 metalrobo::HeterogeneousWorld hw;auto hd=metalrobo::composeHeterogeneousWorld(components,rods,hw);
 if(!hd.succeeded()){std::cerr<<"compose: "<<hd.message<<"\n";return 3;}
 metalrobo::CompiledWorld world;auto cd=metalrobo::compileMetalWorld(hw,world);
 if(!cd.succeeded()){std::cerr<<"compile: "<<cd.message<<"\n";return 4;}
 std::vector<float> zero(world.nv(),0.f);
 MRBodyStateGPU driven=ground;driven.linearVelocityAndInverseMass.y=1.f;
 const std::vector<MRBodyStateGPU> targets{driven};
 metalrobo::MetalWorldBatch initial{.environmentCount=1,.controlStepCount=1,.initialQ=hw.model.defaultQ,
  .initialV=hw.model.defaultV,.efforts=zero,.initialSceneBodies=hw.defaultSceneBodies};
 metalrobo::MetalWorldBatch rejected{.environmentCount=1,.controlStepCount=1,.efforts=zero,.kinematicTargets=targets};
 metalrobo::MetalWorldBatch neutral{.environmentCount=1,.controlStepCount=1,.efforts=zero};
 metalrobo::MetalWorldStepConfig cfg;cfg.timestepSeconds=.001f;cfg.physicsSubsteps=1;
 cfg.velocityIterations=2;cfg.finalVelocityIterations=0;cfg.ccdMode=metalrobo::MetalWorldCCDMode::disabled;
 cfg.applyBodyDamping=false;cfg.captureContactEvidence=true;
 metalrobo::MetalWorldConfig owner;owner.metallibPath=argv[1];
 metalrobo::MetalWorldContext ctx(owner),control(owner);metalrobo::MetalWorldResidentState a,b;
 metalrobo::MetalWorldSubmission t,u;metalrobo::MetalWorldResult before,refBefore,failed,repeat,after,refAfter;
 auto a0=ctx.initializeResidentState(world,initial,cfg,a,t);
 auto b0=control.initializeResidentState(world,initial,cfg,b,u);
 if(!a0.succeeded()||!b0.succeeded())return 5;
 auto ar=t.wait(before),br=u.wait(refBefore);
 auto f=ctx.submitResident(world,rejected,cfg,a,t);if(!f.succeeded())return 6;
 auto fr=t.wait(failed);
 auto f2=ctx.submitResident(world,rejected,cfg,a,t);if(!f2.succeeded())return 7;
 auto fr2=t.wait(repeat);
 auto c=ctx.submitResident(world,neutral,cfg,a,t);
 auto d=control.submitResident(world,neutral,cfg,b,u);
 if(!c.succeeded()||!d.succeeded())return 8;
 auto cr=t.wait(after),dr=u.wait(refAfter);
 unsigned cache=0;for(auto n:before.contactEvidence.manifoldCounts)cache+=n;
 bool mixed=false;for(auto&i:failed.contactEvidence.islands)if(i.rodNodeCount&&i.articulationNodeCount)mixed=true;
 std::cout<<"{\"initial_status\":"<<ar.firstGPUStatusCode<<",\"reference_initial_status\":"<<br.firstGPUStatusCode
  <<",\"initial_cache_count\":"<<cache<<",\"initial_equal\":"<<(stateeq(before,refBefore)?"true":"false")
  <<",\"failure_status\":"<<fr.firstGPUStatusCode<<",\"repeat_status\":"<<fr2.firstGPUStatusCode
  <<",\"failure_succeeded\":"<<(fr.succeeded()?"true":"false")<<",\"mixed_island\":"<<(mixed?"true":"false")
  <<",\"failed_q\":"<<(eq(before.finalQ,failed.finalQ)?"true":"false")
  <<",\"failed_v\":"<<(eq(before.finalV,failed.finalV)?"true":"false")
  <<",\"failed_scene\":"<<(eq(before.finalSceneBodies,failed.finalSceneBodies)?"true":"false")
  <<",\"failed_rod_nodes\":"<<(eq(before.finalRodNodes,failed.finalRodNodes)?"true":"false")
  <<",\"failed_rod_edges\":"<<(eq(before.finalRodEdges,failed.finalRodEdges)?"true":"false")
  <<",\"failed_cache_counts\":"<<(eq(before.contactEvidence.manifoldCounts,failed.contactEvidence.manifoldCounts)?"true":"false")
  <<",\"failed_cache_headers\":"<<(eq(before.contactEvidence.manifoldHeaders,failed.contactEvidence.manifoldHeaders)?"true":"false")
  <<",\"failed_cache_points\":"<<(eq(before.contactEvidence.manifoldPoints,failed.contactEvidence.manifoldPoints)?"true":"false")
  <<",\"repeat_identical\":"<<(stateeq(failed,repeat)?"true":"false")
  <<",\"continuation_status\":"<<cr.firstGPUStatusCode<<",\"reference_continuation_status\":"<<dr.firstGPUStatusCode
  <<",\"continuation_identical\":"<<(stateeq(after,refAfter)?"true":"false")
  <<",\"before_vy\":"<<before.finalV[1]<<",\"failed_vy\":"<<failed.finalV[1]
  <<",\"failed_status_residual\":"<<(failed.contactStatuses.empty()?0:failed.contactStatuses[0].residuals.y)
  <<",\"failed_contacts\":"<<(failed.contactStatuses.empty()?0:failed.contactStatuses[0].activeContacts)
  <<",\"rows\":[";
 for(size_t i=0;i<failed.contactStatuses[0].activeContacts && i<failed.contactEvidence.contacts.size() && 3*i<failed.contactEvidence.evaluatedRows.size();++i){
  if(i)std::cout<<",";
  auto&x=failed.contactEvidence.contacts[i];auto&r=failed.contactEvidence.evaluatedRows[3*i];
  std::cout<<"{\"pre\":"<<r.preSolveVelocity<<",\"target\":"<<r.targetVelocity<<",\"normal_impulse\":"<<x.impulses.x<<"}";
 }
 std::cout<<"]}\n";
 return 0;
}

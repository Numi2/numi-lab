#!/bin/bash
cd /Users/numi/numi-lab-ccd-thin-evidence-20261107/cold-four-sliding-v1 || exit 1
date -u +%FT%TZ > timestamps.txt
for thermal in warm cold; do
  ./metalrobo_ccd_box_multistep_probe candidate.metallib "$thermal" > "multi-$thermal.json" 2> "multi-$thermal.stderr"
  printf "multi-%s exit=%s\n" "$thermal" "$?" >> statuses.txt
done
for probe in geometry friction_dissipation moving_contact kinematic_rollback; do
  if [ "$probe" = friction_dissipation ]; then
    ./metalrobo_ccd_${probe}_probe candidate.metallib 2 > "${probe}.json" 2> "${probe}.stderr"
  else
    ./metalrobo_ccd_${probe}_probe candidate.metallib > "${probe}.json" 2> "${probe}.stderr"
  fi
  printf "%s exit=%s\n" "$probe" "$?" >> statuses.txt
done
date -u +%FT%TZ >> timestamps.txt
cat timestamps.txt statuses.txt

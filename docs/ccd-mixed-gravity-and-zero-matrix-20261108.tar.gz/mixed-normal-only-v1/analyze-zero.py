import json, math
from pathlib import Path
p=Path('/Users/numi/numi-lab-ccd-thin-evidence-20261107/mixed-normal-only-v1')
def dot(a,b): return sum(x*y for x,y in zip(a,b))
def add(a,b): return [x+y for x,y in zip(a,b)]
def sub(a,b): return [x-y for x,y in zip(a,b)]
def scale(a,b): return [x*b for x in a]
def cross(a,b): return [a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0]]
def norm(a): return math.sqrt(dot(a,a))
details=[]
for q in sorted((p/'zero-witness').glob('*.json')):
 d=json.loads(q.read_text()); c=json.loads((p/'zero-candidate'/q.name).read_text())
 errors=[]
 for r in c['rows']:
  for k in ('witness_edge','witness_weight','shader_normal','tool_point','radial'): r.pop(k,None)
 for r in d['rows']:
  for k in ('witness_edge','witness_weight','shader_normal','tool_point','radial'): pass
 stripped=json.loads(json.dumps(d))
 for r in stripped['rows']:
  for k in ('witness_edge','witness_weight','shader_normal','tool_point','radial'): r.pop(k,None)
 if c!=stripped: errors.append('candidate/witness common output mismatch')
 if d['world_gravity']!=[0,0,0] or d['rod_gravity']!=[0,0,0]: errors.append('gravity')
 for k in ('initial_status','reference_initial_status','first_status','reference_first_status','second_status','reference_second_status','continuation_status','reference_continuation_status'):
  if d[k]!=0: errors.append(k+'='+str(d[k]))
 for k in ('initial_equal','first_equal','second_equal','continuation_identical','mixed_island'):
  if not d[k]: errors.append(k)
 v=d['body_after_v6']; pos=d['body_before_xyz']; before=d['node_before_xyzv']; after=d['node_after_xyzv']; twists=d['rod_twist_rate']
 max_comp=0.; max_normal_diff=0.
 for idx,row in enumerate(d['rows']):
  n=row['normal']; point=row['point']
  if idx==0:
   velocity=add(v[:3],cross(v[3:],sub(point,pos)))
   vn=dot(n,sub(velocity,[0,float(q.stem.split('-')[-1]),0]))
  else:
   edge=round(row['witness_edge']); w=row['witness_weight']; radial=row['radial']; point=row['tool_point']
   if edge<0 or edge+1>=len(before) or not 0<=w<=1 or abs(norm(radial)-1)>1e-5: errors.append('invalid witness '+str(idx)); continue
   tangent=sub(before[edge+1][:3],before[edge][:3]); length=norm(tangent)
   if length<1e-10: errors.append('degenerate edge'); continue
   tangent=scale(tangent,1/length)
   va=after[edge][3:]; vb=after[edge+1][3:]; dv=sub(vb,va)
   tangent_rate=scale(sub(dv,scale(tangent,dot(tangent,dv))),1/length)
   omega=add(cross(tangent,tangent_rate),scale(tangent,twists[edge]))
   rv=add(add(scale(va,1-w),scale(vb,w)),cross(omega,scale(radial,.003)))
   bv=add(v[:3],cross(v[3:],sub(point,pos)))
   vn=dot(n,sub(bv,rv))
   max_normal_diff=max(max_normal_diff,abs(vn-row['shader_normal']))
  residual=vn-row['target']; impulse=row['normal_impulse']
  err=abs(residual) if impulse>1e-8 else max(-residual,0)
  max_comp=max(max_comp,err)
  if impulse<0 or any(abs(t)>1e-10 for t in row['tangent_impulse']): errors.append('invalid impulse '+str(idx))
 if max_comp>1e-4: errors.append('complementarity '+str(max_comp))
 if max_normal_diff>1e-4: errors.append('witness normal discrepancy '+str(max_normal_diff))
 masses=d['rod_masses']; dp=sub(v[:3],d['body_before_v6'][:3])
 for m,b,a in zip(masses,before,after): dp=add(dp,scale(sub(a[3:],b[3:]),m))
 g=d['rows'][0]; ext=scale(g['normal'],g['normal_impulse']); perr=norm(sub(dp,ext))
 if perr>1e-6: errors.append('linear impulse '+str(perr))
 # World z moment from center and node translational changes and sphere spin.
 dlz=cross(pos,sub(v[:3],d['body_before_v6'][:3]))[2]+d['body_inertia_z']*(v[5]-d['body_before_v6'][5])
 for m,b,a in zip(masses,before,after): dlz+=m*cross(b[:3],sub(a[3:],b[3:]))[2]
 extlz=cross(g['point'],ext)[2]; lerr=abs(dlz-extlz)
 if lerr>1e-6: errors.append('angular impulse z '+str(lerr))
 details.append(dict(case=q.stem,errors=errors,max_complementarity=max_comp,max_witness_difference=max_normal_diff,linear_impulse_error=perr,angular_impulse_z_error=lerr))
print(json.dumps(dict(total=len(details),passed=sum(not d['errors'] for d in details),cases=details),indent=2))

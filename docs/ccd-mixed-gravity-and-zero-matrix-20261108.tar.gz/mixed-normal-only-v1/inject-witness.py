from pathlib import Path
p=Path("/Users/numi/numi-lab-ccd-mixed-island-containment-20261108/src/metal/MetalWorldContact.metal")
s=p.read_text(); st=s.index("inline void mrWorldWave32SolvePacket("); en=s.index("// One SIMD32 group owns one full mixed-contact island",st)
a=s[st:en]
old="device const MREvaluatedConstraintIRRowGPU* evaluatedRows,"
assert a.count(old)==1
a=a.replace(old,"device MREvaluatedConstraintIRRowGPU* evaluatedRows,",1)
marker="    float laneNormalResidual = 0.0f;"
i=a.index(marker)
needle="""        const float normalEquation =
            dot(localRows[0].direction.xyz, relative) -"""
insert="""        // TEST-ONLY: expose selected rod witness geometry and actual row
        // velocity for an independent host-side kinematic reconstruction.
        if (typedRodConstraint(contact)) {
            const uint wi = constraintWitnessIndices[constraintBase+localConstraint];
            if (wi != MR_INVALID_INDEX) {
                const MRRodToolWitnessGPU w = rodWitnesses[wi];
                const MRRodColliderGPU c = rodColliders[w.identity.z];
                evaluatedRows[rowBase+3u*localConstraint].reserved0 = float(c.edgeIndex);
                evaluatedRows[rowBase+3u*localConstraint].reserved1 = w.rodPointAndWeight.w;
                evaluatedRows[rowBase+3u*localConstraint].reserved2 = dot(localRows[0].direction.xyz,relative);
                evaluatedRows[rowBase+3u*localConstraint+1u].reserved0 = w.toolPointAndSeparation.x;
                evaluatedRows[rowBase+3u*localConstraint+1u].reserved1 = w.toolPointAndSeparation.y;
                evaluatedRows[rowBase+3u*localConstraint+1u].reserved2 = w.toolPointAndSeparation.z;
                evaluatedRows[rowBase+3u*localConstraint+2u].reserved0 = w.radialAndTwistJacobianV.x;
                evaluatedRows[rowBase+3u*localConstraint+2u].reserved1 = w.radialAndTwistJacobianV.y;
                evaluatedRows[rowBase+3u*localConstraint+2u].reserved2 = w.radialAndTwistJacobianV.z;
            }
        }
        const float normalEquation =
            dot(localRows[0].direction.xyz, relative) -"""
assert a[i:].count(needle)==1
a=a[:i]+a[i:].replace(needle,insert,1)
s=s[:st]+a+s[en:]
for kernel in ("kernel void mr_world_wave32_solve(", "kernel void mr_world_wave32_solve_persistent("):
 st=s.index(kernel); en=s.index(") {",st); a=s[st:en]
 old="device const MREvaluatedConstraintIRRowGPU* evaluatedRows [[buffer(7)]],"
 assert a.count(old)==1
 a=a.replace(old,"device MREvaluatedConstraintIRRowGPU* evaluatedRows [[buffer(7)]],",1)
 s=s[:st]+a+s[en:]
p.write_text(s)

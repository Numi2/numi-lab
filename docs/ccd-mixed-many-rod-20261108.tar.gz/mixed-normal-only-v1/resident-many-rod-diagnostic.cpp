#include "metalrobo/HeterogeneousWorld.hpp"
#include "metalrobo/MetalWorld.hpp"
#include <algorithm>
#include <cstring>
#include <filesystem>
#include <iostream>
#include <iomanip>
#include <vector>
template<class T> bool eq(const std::vector<T>&a,const std::vector<T>&b) {
 return a.size()==b.size()&&(a.empty()||std::memcmp(a.data(),b.data(),a.size()*sizeof(T))==0);
}
bool stateeq(const metalrobo::MetalWorldResult&a,const metalrobo::MetalWorldResult&b) {
 return eq(a.finalQ,b.finalQ)&&eq(a.finalV,b.finalV)&&eq(a.finalSceneBodies,b.finalSceneBodies)&&
  eq(a.finalRodNodes,b.finalRodNodes)&&eq(a.finalRodEdges,b.finalRodEdges)&&
  eq(a.contactEvidence.manifoldCounts,b.contactEvidence.manifoldCounts)&&
  eq(a.contactEvidence.manifoldHeaders,b.contactEvidence.manifoldHeaders)&&
  eq(a.contactEvidence.manifoldPoints,b.contactEvidence.manifoldPoints);
}
int main(int argc,char**argv) {
 if(argc!=4||!std::filesystem::is_regular_file(argv[1]))return 2; const float offset=std::stof(argv[2]), speed=std::stof(argv[3]);
 auto m=metalrobo::makeFreeSphereEngineModel();
 m.world.gravityAndTimestep={0,0,0,.001f};m.defaultQ[1]=.01f;m.defaultQ[0]=offset;
 m.bodies[0].motionType=MR_MOTION_KINEMATIC;
 m.shapes[1].dimensions={.01f,0,0,0};m.shapes[1].contactRestAndBoundingRadius={.001f,0,.01f,0};
 for(auto& x:m.materials){x.friction={0,0,0,0};x.response={0,0,0,0};}
 MRBodyStateGPU ground{};ground.position.w=1;ground.orientation.w=1;
 ground.flagsAndIndices[0]=MR_MOTION_KINEMATIC;ground.flagsAndIndices[1]=MR_INVALID_INDEX;
 std::vector<MRBodyStateGPU> scene{ground};
 metalrobo::DiscreteRodMaterial mat;mat.radius=.003;mat.density=1000;mat.youngModulus=1.e5;
 metalrobo::HeterogeneousRodProgram rod;rod.instanceId="mixed_resident";
 rod.model=metalrobo::makeStraightSutureRod(3,.04,mat);
 rod.defaultState=metalrobo::makeDiscreteElasticRodDefaultState(rod.model);
 for(auto& p:rod.defaultState.positions){p[0]-=.02;p[1]=.023;}
 rod.collision.enableCCD=false;rod.collision.contactOffset=.001;
 rod.stepConfig.gravity={0,0,0};rod.stepConfig.timestep=.001;
 const std::vector<metalrobo::HeterogeneousWorldComponent> components{{&m,"body",scene}};
 std::vector<metalrobo::HeterogeneousRodProgram> rods; for (int i=0;i<33;++i) { auto copy=rod; copy.instanceId=std::string("stress_rod_")+std::to_string(i); for(auto& pos:copy.defaultState.positions) pos[2]+=(i-16)*.0005f; rods.push_back(copy); }
 metalrobo::EngineModelComposeConfig composeConfig;composeConfig.gravityAndTimestep={0,0,0,.001f};
 metalrobo::HeterogeneousWorld hw;auto hd=metalrobo::composeHeterogeneousWorld(components,rods,hw,composeConfig);
 if(!hd.succeeded()){std::cerr<<"compose: "<<hd.message<<"\n";return 3;}
 if(hw.model.world.gravityAndTimestep.x!=0.f||hw.model.world.gravityAndTimestep.y!=0.f||hw.model.world.gravityAndTimestep.z!=0.f||rod.stepConfig.gravity[0]!=0.f||rod.stepConfig.gravity[1]!=0.f||rod.stepConfig.gravity[2]!=0.f){std::cerr<<"gravity mismatch\n";return 9;}
 metalrobo::CompiledWorld world;auto cd=metalrobo::compileMetalWorld(hw,world);
 if(!cd.succeeded()){std::cerr<<"compile: "<<cd.message<<"\n";return 4;}
 std::vector<float> zero(world.nv(),0.f);
 MRBodyStateGPU driven=ground;driven.linearVelocityAndInverseMass.y=speed;
 const std::vector<MRBodyStateGPU> targets{driven};
 metalrobo::MetalWorldBatch initial{.environmentCount=1,.controlStepCount=1,.initialQ=hw.model.defaultQ,
  .initialV=hw.model.defaultV,.efforts=zero,.initialSceneBodies=hw.defaultSceneBodies};
 metalrobo::MetalWorldBatch rejected{.environmentCount=1,.controlStepCount=1,.efforts=zero,.kinematicTargets=targets};
 metalrobo::MetalWorldBatch neutral{.environmentCount=1,.controlStepCount=1,.efforts=zero};
 metalrobo::MetalWorldStepConfig cfg;cfg.timestepSeconds=.001f;cfg.physicsSubsteps=1;
 cfg.velocityIterations=2;cfg.finalVelocityIterations=0;cfg.ccdMode=metalrobo::MetalWorldCCDMode::disabled;
 cfg.applyBodyDamping=false;cfg.captureContactEvidence=true;
 metalrobo::MetalWorldConfig owner;owner.metallibPath=argv[1];
 metalrobo::MetalWorldContext ctx(owner),control(owner),neutralControl(owner);metalrobo::MetalWorldResidentState a,b,n;
 metalrobo::MetalWorldSubmission t,u,v;metalrobo::MetalWorldResult before,refBefore,failed,refFailed,repeat,refRepeat,after,refAfter,neutralBefore,neutralAfter;
 auto a0=ctx.initializeResidentState(world,initial,cfg,a,t);
 auto b0=control.initializeResidentState(world,initial,cfg,b,u);
 auto n0=neutralControl.initializeResidentState(world,initial,cfg,n,v); if(!a0.succeeded()||!b0.succeeded()||!n0.succeeded())return 5; auto nr=v.wait(neutralBefore); if(!nr.succeeded())return 10;
 auto ar=t.wait(before),br=u.wait(refBefore);

 auto f=ctx.submitResident(world,rejected,cfg,a,t);auto rf=control.submitResident(world,rejected,cfg,b,u);
 if(!f.succeeded()||!rf.succeeded())return 6;
 auto fr=t.wait(failed), rfr=u.wait(refFailed);
 auto f2=ctx.submitResident(world,rejected,cfg,a,t);auto rf2=control.submitResident(world,rejected,cfg,b,u);
 if(!f2.succeeded()||!rf2.succeeded())return 7;
 auto fr2=t.wait(repeat),rfr2=u.wait(refRepeat);
 auto c=ctx.submitResident(world,neutral,cfg,a,t);auto d=control.submitResident(world,neutral,cfg,b,u);
 if(!c.succeeded()||!d.succeeded())return 8;
 auto cr=t.wait(after),dr=u.wait(refAfter); auto ns=neutralControl.submitResident(world,neutral,cfg,n,v); if(!ns.succeeded())return 11; auto ncr=v.wait(neutralAfter);
 unsigned cache=0;for(auto n:before.contactEvidence.manifoldCounts)cache+=n;
 bool mixed=false;unsigned maxMixedRows=0;for(auto&i:failed.contactEvidence.islands)if(i.rodNodeCount&&i.articulationNodeCount){mixed=true; maxMixedRows=std::max(maxMixedRows,i.constraintCount);}
 std::cout<<std::setprecision(10)<<"{\"initial_status\":"<<ar.firstGPUStatusCode<<",\"reference_initial_status\":"<<br.firstGPUStatusCode
  <<",\"world_gravity\":["<<hw.model.world.gravityAndTimestep.x<<","<<hw.model.world.gravityAndTimestep.y<<","<<hw.model.world.gravityAndTimestep.z<<"]"
  <<",\"rod_gravity\":["<<rod.stepConfig.gravity[0]<<","<<rod.stepConfig.gravity[1]<<","<<rod.stepConfig.gravity[2]<<"]"
  <<",\"initial_cache_count\":"<<cache<<",\"initial_equal\":"<<(stateeq(before,refBefore)?"true":"false")
  <<",\"first_status\":"<<fr.firstGPUStatusCode<<",\"reference_first_status\":"<<rfr.firstGPUStatusCode
  <<",\"first_equal\":"<<(stateeq(failed,refFailed)?"true":"false")<<",\"first_restored\":"<<(stateeq(before,failed)?"true":"false")
  <<",\"second_status\":"<<fr2.firstGPUStatusCode<<",\"reference_second_status\":"<<rfr2.firstGPUStatusCode
  <<",\"second_equal\":"<<(stateeq(repeat,refRepeat)?"true":"false")<<",\"second_restored\":"<<(stateeq(before,repeat)?"true":"false")
  <<",\"continuation_status\":"<<cr.firstGPUStatusCode<<",\"reference_continuation_status\":"<<dr.firstGPUStatusCode
  <<",\"continuation_identical\":"<<(stateeq(after,refAfter)?"true":"false")<<",\"neutral_control_status\":"<<ncr.firstGPUStatusCode<<",\"neutral_matches_after_rejection\":"<<(stateeq(after,neutralAfter)?"true":"false")
  <<",\"mixed_island\":"<<(mixed?"true":"false")<<",\"max_mixed_rows\":"<<maxMixedRows<<",\"active_contacts\":"<<failed.contactStatuses[0].activeContacts<<",\"queue_flags\":"<<failed.contactStatuses[0].queueFlags
  <<",\"initial_vy\":"<<before.finalV[1]<<",\"first_vy\":"<<failed.finalV[1]
  <<",\"first_scene_vy\":"<<failed.finalSceneBodies[0].linearVelocityAndInverseMass.y
  <<",\"first_violation\":"<<failed.contactStatuses[0].residuals.x<<",\"first_tolerance\":"<<failed.contactStatuses[0].residuals.y<<",\"rows\":[";
 for(size_t i=0;i<failed.contactStatuses[0].activeContacts && i<failed.contactEvidence.contacts.size();++i){
  if(i)std::cout<<",";
  auto&x=failed.contactEvidence.contacts[i];auto&r=failed.contactEvidence.evaluatedRows[3*i];auto&r1=failed.contactEvidence.evaluatedRows[3*i+1];auto&r2=failed.contactEvidence.evaluatedRows[3*i+2];
  std::cout<<"{\"pre\":"<<r.preSolveVelocity<<",\"target\":"<<r.targetVelocity<<",\"regularization\":"<<r.regularization<<",\"normal_impulse\":"<<x.impulses.x<<",\"tangent_impulse\":["<<x.impulses.y<<","<<x.impulses.z<<"]"<<",\"flags\":"<<x.flags<<",\"point\":["<<x.pointAndSeparation.x<<","<<x.pointAndSeparation.y<<","<<x.pointAndSeparation.z<<"],\"normal\":["<<x.normal.x<<","<<x.normal.y<<","<<x.normal.z<<"],\"witness_edge\":"<<r.reserved0<<",\"witness_weight\":"<<r.reserved1<<",\"shader_normal\":"<<r.reserved2<<",\"tool_point\":["<<r1.reserved0<<","<<r1.reserved1<<","<<r1.reserved2<<"],\"radial\":["<<r2.reserved0<<","<<r2.reserved1<<","<<r2.reserved2<<"]}";
 }
 std::cout<<"],\"body_xy\":["<<before.finalQ[0]<<","<<before.finalQ[1]<<"]"
  <<",\"body_before_vxyw\":["<<before.finalV[0]<<","<<before.finalV[1]<<","<<before.finalV[5]<<"]"
  <<",\"body_after_vxyw\":["<<failed.finalV[0]<<","<<failed.finalV[1]<<","<<failed.finalV[5]<<"]"
  <<",\"body_inertia_z\":"<<m.bodies[1].inertiaRow2.z
  <<",\"ground_point_x\":"<<failed.contactEvidence.contacts[0].pointAndSeparation.x
  <<",\"node_before_xyv\":[";
 for(size_t i=0;i<before.finalRodNodes.size();++i){if(i)std::cout<<",";auto&n=before.finalRodNodes[i];std::cout<<"["<<n.position.x<<","<<n.position.y<<","<<n.velocity.x<<","<<n.velocity.y<<"]";}
 std::cout<<"],\"node_after_xyv\":[";
 for(size_t i=0;i<failed.finalRodNodes.size();++i){if(i)std::cout<<",";auto&n=failed.finalRodNodes[i];std::cout<<"["<<n.position.x<<","<<n.position.y<<","<<n.velocity.x<<","<<n.velocity.y<<"]";}
 std::cout<<"],\"body_before_xyz\":["<<before.finalQ[0]<<","<<before.finalQ[1]<<","<<before.finalQ[2]<<"]"
  <<",\"body_before_v6\":[";
 for(int i=0;i<6;++i){if(i)std::cout<<",";std::cout<<before.finalV[i];}
 std::cout<<"],\"body_after_v6\":[";
 for(int i=0;i<6;++i){if(i)std::cout<<",";std::cout<<failed.finalV[i];}
 std::cout<<"],\"node_before_xyzv\":[";
 for(size_t i=0;i<before.finalRodNodes.size();++i){if(i)std::cout<<",";auto&n=before.finalRodNodes[i];std::cout<<"["<<n.position.x<<","<<n.position.y<<","<<n.position.z<<","<<n.velocity.x<<","<<n.velocity.y<<","<<n.velocity.z<<"]";}
 std::cout<<"],\"node_after_xyzv\":[";
 for(size_t i=0;i<failed.finalRodNodes.size();++i){if(i)std::cout<<",";auto&n=failed.finalRodNodes[i];std::cout<<"["<<n.position.x<<","<<n.position.y<<","<<n.position.z<<","<<n.velocity.x<<","<<n.velocity.y<<","<<n.velocity.z<<"]";}
 std::cout<<"],\"rod_masses\":[";
 for(size_t i=0;i<rod.model.nodeMasses.size();++i){if(i)std::cout<<",";std::cout<<rod.model.nodeMasses[i];}
 std::cout<<"],\"rod_before_vy\":[";
 for(size_t i=0;i<before.finalRodNodes.size();++i){if(i)std::cout<<",";std::cout<<before.finalRodNodes[i].velocity.y;}
 std::cout<<"],\"rod_after_vy\":[";
 for(size_t i=0;i<failed.finalRodNodes.size();++i){if(i)std::cout<<",";std::cout<<failed.finalRodNodes[i].velocity.y;}
 std::cout<<"],\"rod_twist_rate\":[";
 for(size_t i=0;i<failed.finalRodEdges.size();++i){if(i)std::cout<<",";std::cout<<failed.finalRodEdges[i].twistAndRate.y;}
 std::cout<<"]}\n";
 return 0;
}

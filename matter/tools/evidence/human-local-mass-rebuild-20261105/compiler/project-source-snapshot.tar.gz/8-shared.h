#pragma once

// Pointer-free ABI shared by C++, Objective-C++, and Metal.
// Every offset and stride is measured in elements, never bytes.

#ifdef __METAL_VERSION__
#include <metal_stdlib>
using namespace metal;
#define NM_ALIGN16 alignas(16)
typedef uint nm_u32;
typedef int nm_i32;
typedef ulong nm_u64;
typedef float4 nm_float4;
typedef uint4 nm_uint4;
typedef int4 nm_int4;
#else
#include <cstdint>
#define NM_ALIGN16 alignas(16)
typedef std::uint32_t nm_u32;
typedef std::int32_t nm_i32;
typedef std::uint64_t nm_u64;
typedef struct NM_ALIGN16 nm_float4 {
    float x;
    float y;
    float z;
    float w;
} nm_float4;
typedef struct NM_ALIGN16 nm_uint4 {
    nm_u32 x;
    nm_u32 y;
    nm_u32 z;
    nm_u32 w;
} nm_uint4;
typedef struct NM_ALIGN16 nm_int4 {
    nm_i32 x;
    nm_i32 y;
    nm_i32 z;
    nm_i32 w;
} nm_int4;
#endif

#define NM_MATTER_ABI_VERSION 47u
#define NM_INVALID_INDEX 0xffffffffu
#define NM_VASCULAR_TISSUE_MOMENTUM_TRANSFER 0x80000000u
#define NM_EXPRESSION_STACK_CAPACITY 96u
#define NM_EXPRESSION_CACHE_CAPACITY 512u
#define NM_TANGENT_BUNDLE_CACHE_CAPACITY 64u
#define NM_TANGENT_BUNDLE_OUTPUT_COUNT 9u
#define NM_MPM_STENCIL_WIDTH 27u
#define NM_EVENT_CLASS_COUNT 8u
#define NM_MAX_RATE_EXPONENT 8u
#define NM_MPM_BLOCK_EDGE 8u
#define NM_MPM_BLOCK_NODE_COUNT 512u
#define NM_MPM_MAX_PARTICLES_PER_BLOCK 256u
// Full multiplicative paperboard plasticity needs nine Fp components,
// twelve hardening variables, a plastic multiplier and damage history.
// Packages cooked with the old sixteen-state layout must be recooked.
#define NM_MAX_MATERIAL_STATE 32u
#define NM_STATUS5_CAPTURE_MAX_PARAMETER_WORDS 512u
#define NM_STATUS5_INDEX_NONE 0u
#define NM_STATUS5_INDEX_NODE 1u
#define NM_STATUS5_INDEX_TETRAHEDRON 2u
#define NM_STATUS5_INDEX_SOLVER_ITERATION 3u
#define NM_STATUS5_CAPTURE_DOMAIN_GLOBAL 0u
#define NM_STATUS5_CAPTURE_DOMAIN_PRIVATE 1u
#define NM_MIXED_NEWTON_ITERATIONS 7u
// Maximum supported compiled basis depth.
#define NM_MIXED_FGMRES_RESTART 16u
// Measured production default. Worlds may author a larger supported
// restart/total budget explicitly.
#define NM_MIXED_FGMRES_DEFAULT_RESTART 10u
#define NM_MIXED_FGMRES_ITERATIONS 10u
// Operational command-encoding ceiling. This bounds restart-cycle host work;
// it is intentionally separate from the smaller compiled basis depth above.
#define NM_MIXED_FGMRES_MAX_ITERATIONS 1024u
#define NM_MIXED_LINE_SEARCH_STEPS 8u
#define NM_MIXED_LINE_SEARCH_MAX_STEPS 32u
#define NM_MIXED_FIELD_SMOOTHER_MAX_PASSES 3u
#define NM_MIXED_MUTATION_RESTARTS 4u
#define NM_LEARNED_MAX_LAYERS 8u
#define NM_LEARNED_MAX_WIDTH 16u
#define NM_LEARNED_MAX_INVARIANTS 8u
// Coupled-candidate storage is part of Matter's compiled ABI. These are hard
// admission ceilings, not blanket allocation sizes: each cooked world records
// an exact authored capacity. The larger class admits the Numi Human runtime;
// the legacy MetalWorld bridge remains valid at its smaller ABA capacity.
#define NM_MATTER_MAX_ARTICULATED_DOFS 160u
#define NM_MATTER_MAX_ARTICULATED_Q 161u
// Matter's authored Human-attachment suffix remains independently bounded at
// 4,096 points. The borrowed generic operator also carries private body probes,
// so its enclosing point-stream ceiling may be larger than this suffix cap.
// Reject larger attachment batches while compiling, before a package can
// encode a shape that the owning candidate service must reject at runtime.
#define NM_MATTER_MAX_HUMAN_ATTACHMENT_POINTS 4096u

enum NMRepresentationKind : nm_u32 {
    NM_REPRESENTATION_RIGID = 0u,
    NM_REPRESENTATION_MPM = 1u,
    NM_REPRESENTATION_FEM = 2u,
};

enum NMConstitutiveKind : nm_u32 {
    NM_CONSTITUTIVE_BYTECODE = 0u,
    NM_CONSTITUTIVE_NEO_HOOKEAN = 1u,
    NM_CONSTITUTIVE_COROTATED = 2u,
    NM_CONSTITUTIVE_DRUCKER_PRAGER = 3u,
    NM_CONSTITUTIVE_VON_MISES = 4u,
    NM_CONSTITUTIVE_VISCO_HYPERELASTIC = 5u,
    NM_CONSTITUTIVE_POLYCONVEX_ICNN = 6u,
};

enum NMExpressionOpcode : nm_u32 {
    NM_EXPR_CONSTANT = 0u,
    NM_EXPR_PARAMETER = 1u,
    NM_EXPR_F = 2u,
    NM_EXPR_DF = 3u,
    NM_EXPR_STATE = 4u,
    NM_EXPR_ADD = 5u,
    NM_EXPR_SUBTRACT = 6u,
    NM_EXPR_MULTIPLY = 7u,
    NM_EXPR_DIVIDE = 8u,
    NM_EXPR_NEGATE = 9u,
    NM_EXPR_LOG = 10u,
    NM_EXPR_EXP = 11u,
    NM_EXPR_SQRT = 12u,
    NM_EXPR_ABS = 13u,
    NM_EXPR_MIN = 14u,
    NM_EXPR_MAX = 15u,
    NM_EXPR_POW_INTEGER = 16u,
    NM_EXPR_CLAMP = 17u,
    NM_EXPR_DT = 18u,
    NM_EXPR_TEMPERATURE = 19u,
    NM_EXPR_RATE = 20u,
    NM_EXPR_NEXT_STATE = 21u,
    NM_EXPR_EXPM1_MINUS_X = 22u,
    NM_EXPR_FIBER_EXP_LINEAR = 23u,
    NM_EXPR_SELECT_NONNEGATIVE = 24u,
    NM_EXPR_CACHE_STORE = 25u,
    NM_EXPR_CACHE_LOAD = 26u,
};

enum NMStatusCode : nm_u32 {
    NM_STATUS_SUCCESS = 0u,
    NM_STATUS_INVALID_DISPATCH = 1u,
    NM_STATUS_CAPACITY_OVERFLOW = 2u,
    NM_STATUS_NONFINITE_INPUT = 3u,
    NM_STATUS_NONFINITE_RESULT = 4u,
    NM_STATUS_INVALID_DEFORMATION = 5u,
    NM_STATUS_CONTACT_FAILURE = 6u,
    NM_STATUS_LINEAR_SOLVER_FAILURE = 7u,
    NM_STATUS_UNSUPPORTED = 8u,
    NM_STATUS_RIGID_WORLD_FAILURE = 9u,
    NM_STATUS_NONLINEAR_SOLVER_FAILURE = 10u,
    NM_STATUS_MULTIPHYSICS_FAILURE = 11u,
    NM_STATUS_TOPOLOGY_FAILURE = 12u,
    NM_STATUS_LEARNED_MATERIAL_FAILURE = 13u,
    NM_STATUS_LOCAL_MATERIAL_FAILURE = 14u,
    NM_STATUS_TOPOLOGY_GROWTH_REQUIRED = 15u,
};

enum NMMaterialFlags : nm_u32 {
    NM_MATERIAL_HAS_STATE = 1u << 0u,
    NM_MATERIAL_HAS_DISSIPATION = 1u << 1u,
    NM_MATERIAL_HAS_IMPLICIT_STATE = 1u << 2u,
    NM_MATERIAL_PAPER_HILL_SCALAR_INITIALIZER = 1u << 3u,
    NM_MATERIAL_PAPER_COMPENSATED_ARITHMETIC = 1u << 4u,
    NM_MATERIAL_PAPER_HILL_ACCURATE_PROJECTION = 1u << 5u,
    NM_MATERIAL_GENERIC_COMPENSATED_IMPLICIT_PROJECTION = 1u << 6u,
    NM_MATERIAL_GENERIC_BILINEAR15_ACCURATE_PROJECTION = 1u << 7u,
    NM_MATERIAL_GENERIC_BILINEAR15_STRICT_STATE_CERTIFICATION = 1u << 8u,
    NM_MATERIAL_CANONICAL_COMPRESSIBLE_NEOHOOKEAN_TANGENT = 1u << 9u,
    NM_MATERIAL_SHARED_15_STATE_TANGENT_FACTORIZATION = 1u << 10u,
    NM_MATERIAL_HAS_TANGENT_BUNDLE = 1u << 11u,
};

enum NMScalarProgramFlags : nm_u32 {
    NM_SCALAR_PROGRAM_FLAG_LOCAL_CACHE = 1u << 0u,
    NM_SCALAR_PROGRAM_FLAG_COMPENSATED = 1u << 1u,
    NM_SCALAR_PROGRAM_FLAG_TANGENT_BUNDLE_CACHE = 1u << 2u,
    NM_SCALAR_PROGRAM_FLAG_TANGENT_BUNDLE_PRELUDE = 1u << 3u,
};

enum NMMaterialProjectionKind : nm_u32 {
    NM_MATERIAL_PROJECTION_GENERIC = 0u,
    NM_MATERIAL_PROJECTION_VON_MISES = 1u,
    NM_MATERIAL_PROJECTION_DRUCKER_PRAGER = 2u,
};

enum NMMaterialStateTransfer : nm_u32 {
    NM_MATERIAL_TRANSFER_AVERAGE = 0u,
    NM_MATERIAL_TRANSFER_MAXIMUM = 1u,
    NM_MATERIAL_TRANSFER_SUM = 2u,
};

enum NMMatterFlags : nm_u32 {
    NM_MATTER_DETERMINISTIC = 1u << 0u,
    NM_MATTER_CONTACT = 1u << 1u,
    NM_MATTER_ADAPTIVE = 1u << 2u,
    NM_MATTER_IDENTIFICATION = 1u << 3u,
    NM_MATTER_MIXED_FEM = 1u << 4u,
    NM_MATTER_MULTIPHYSICS = 1u << 5u,
    NM_MATTER_MUTATION = 1u << 6u,
    NM_MATTER_LEARNED_MATERIAL = 1u << 7u,
    NM_MATTER_IPC = 1u << 8u,
    // surfaceFaceCount indexes an exterior-only immutable FEM map. Source
    // face identities remain 4*tet+opposite, distinct from compact slots.
    NM_MATTER_STATIC_FEM_SURFACE_MAP = 1u << 9u,
    // Cooked capacities are authorized by an external articulated owner even
    // when no articulated proxy or FEM attachment is authored in this world.
    NM_MATTER_EXTERNAL_COUPLED_CANDIDATE_AUTHORITY = 1u << 10u,
};

enum NMObjectFlags : nm_u32 {
    NM_OBJECT_ACTIVE = 1u << 0u,
    NM_OBJECT_TWO_WAY_COUPLED = 1u << 1u,
    NM_OBJECT_ADAPTIVE = 1u << 2u,
    NM_OBJECT_IDENTIFIABLE = 1u << 3u,
    NM_OBJECT_MIXED_FEM = 1u << 4u,
    NM_OBJECT_MULTIPHYSICS = 1u << 5u,
    NM_OBJECT_MUTABLE_TOPOLOGY = 1u << 6u,
    NM_OBJECT_DISABLE_SELF_CONTACT = 1u << 7u,
    NM_OBJECT_DISABLE_DEFORMABLE_CONTACT = 1u << 8u,
    NM_OBJECT_FEM_MATERIAL_FRAME = 1u << 9u,
    NM_OBJECT_FEM_REGIONAL_MATERIAL = 1u << 10u,
    NM_OBJECT_FEM_REFERENCE_CONFIGURATION = 1u << 11u,
    // Use F = I + grad(x - X) for explicit FEM elements with authored X.
    NM_OBJECT_FEM_REFERENCE_DISPLACEMENT_GRADIENT = 1u << 12u,
};

enum NMTetrahedronFlags : nm_u32 {
    NM_TETRAHEDRON_REFERENCE_DISPLACEMENT_GRADIENT = 1u << 1u,
    // Immutable authored preconditioner region ID occupies bits 8..10 only
    // when the source-selected regional Galerkin mode is active. This is
    // solver metadata, not a physical material or topology flag.
    NM_TETRAHEDRON_PRECONDITIONER_REGION_SHIFT = 8u,
    NM_TETRAHEDRON_PRECONDITIONER_REGION_MASK = 7u << 8u,
};

enum NMFieldBoundaryFlags : nm_u32 {
    NM_FIELD_DIRICHLET_TEMPERATURE = 1u << 0u,
    NM_FIELD_DIRICHLET_PORE_PRESSURE = 1u << 1u,
    NM_FIELD_DIRICHLET_ELECTRIC_POTENTIAL = 1u << 2u,
    NM_FIELD_DIRICHLET_ACTIVATION = 1u << 3u,
    NM_FIELD_NEUMANN_TEMPERATURE = 1u << 4u,
    NM_FIELD_NEUMANN_PORE_PRESSURE = 1u << 5u,
    NM_FIELD_NEUMANN_ELECTRIC_CURRENT = 1u << 6u,
};

enum NMMutationKind : nm_u32 {
    NM_MUTATION_COHESIVE_SEPARATION = 0u,
    NM_MUTATION_PLANE_EROSION = 1u,
    NM_MUTATION_CYLINDER_PUNCTURE = 2u,
    NM_MUTATION_DEACTIVATE_TETRAHEDRON = 3u,
    NM_MUTATION_EDGE_SPLIT = 4u,
    NM_MUTATION_EDGE_COLLAPSE = 5u,
    NM_MUTATION_FACE_FLIP_23 = 6u,
    NM_MUTATION_FACE_FLIP_32 = 7u,
    NM_MUTATION_VERTEX_SMOOTH = 8u,
};

typedef struct NM_ALIGN16 NMTopologyGrowthRequestGPU {
    // Required marker, allocation generation, first requesting object, reason.
    nm_uint4 identity;
    // Requested global node, tetrahedron, cohesive-face, channel capacities.
    nm_uint4 topology;
    // Requested incidence, mutation, rigid-contact, deformable-contact arenas.
    nm_uint4 work;
} NMTopologyGrowthRequestGPU;

enum NMMutationFlags : nm_u32 {
    NM_MUTATION_ACTIVE = 1u << 0u,
    NM_MUTATION_PHYSICS_TRIGGERED = 1u << 1u,
};

enum NMTopologyFlags : nm_u32 {
    NM_TOPOLOGY_ACTIVE = 1u << 0u,
    NM_TOPOLOGY_SURFACE = 1u << 1u,
    NM_TOPOLOGY_COHESIVE = 1u << 2u,
    NM_TOPOLOGY_ERODED = 1u << 3u,
    NM_TOPOLOGY_SEPARATED = 1u << 4u,
    // An authored, already duplicated face pair driven by an explicit
    // constitutive interface material. Unlike event-created cohesive faces,
    // side B is present in separatedNodes from the initial state.
    NM_TOPOLOGY_PAIRED_COHESIVE = 1u << 5u,
    // Authored mixed-mode bilinear interface with per-quadrature irreversible
    // history. The paired nodes are already duplicated in the source mesh.
    NM_TOPOLOGY_COHESIVE_MIXED_MODE = 1u << 6u,
    // A mixed-mode paired interface that has not yet been activated by its
    // explicit control-step request and accepted-geometry contact gate.
    NM_TOPOLOGY_COHESIVE_DORMANT = 1u << 7u,
    // Mixed-mode mortar patch: the three patch vertices are independently
    // mapped into the two parent faces by the source barycentric maps below.
    NM_TOPOLOGY_COHESIVE_MORTAR = 1u << 8u,
};

// Per-exterior-face deformable-contact participation. The static surface map
// remains complete; this bit suppresses only the selected face as a contact
// primitive, without changing its FEM/topology identity.
enum NMFEMSurfaceFaceFlags : nm_u32 {
    NM_FEM_SURFACE_DISABLE_DEFORMABLE_CONTACT = 1u << 31u,
};

enum NMCohesiveLawKind : nm_u32 {
    NM_COHESIVE_LAW_TRYDING_MODE_I = 0u,
    NM_COHESIVE_LAW_MIXED_MODE_BILINEAR = 1u,
};

enum NMCohesiveActivationMode : nm_u32 {
    NM_COHESIVE_ACTIVATION_SCHEDULED = 0u,
    NM_COHESIVE_ACTIVATION_EXPLICIT_COMMAND = 1u,
};

enum NMLearnedActivationKind : nm_u32 {
    NM_LEARNED_SOFTPLUS = 0u,
};

enum NMRigidShapeKind : nm_u32 {
    NM_RIGID_PLANE = 0u,
    NM_RIGID_SPHERE = 1u,
    NM_RIGID_CAPSULE = 2u,
    NM_RIGID_BOX = 3u,
    // Circular tube arc in the proxy-local XY plane. localExtent carries
    // centreline radius, start angle and positive sweep angle.
    NM_RIGID_ARC = 4u,
};

enum NMRigidBindingFlags : nm_u32 {
    NM_RIGID_ARTICULATED = 1u << 0u,
    NM_RIGID_DYNAMIC = 1u << 1u,
    // A capsule whose localCenterAndRadius.xyz endpoint is the physical
    // sharp tip and whose localExtent.xyz endpoint is the base of the
    // tapered tip segment. Only this explicitly authored geometry may admit
    // a closing contact-driven tissue tract.
    NM_RIGID_PUNCTURE_TIP = 1u << 2u,
    // Capsule endpoints are live MetalWorld DER nodes. bodyIndex and
    // sceneBodyIndex carry node A and node B respectively; this proxy owns no
    // rigid generalized coordinate. Matter resolves continuum contact against
    // the live segment and scatters the accepted rigid-side impulse back to
    // both nodes before the DER substep.
    NM_RIGID_SUTURE_STRAND = 1u << 3u,
    // Needle geometry that establishes the final embedded tract gauge after
    // the sharp tip admits fracture. Only an explicitly flagged capsule or
    // circular arc on the same body may dilate that tract.
    NM_RIGID_PUNCTURE_DILATOR = 1u << 4u,
    // Endpoint-authoritative translating kinematic capsule; native feasible predictor and swept nodal certificate.
    NM_RIGID_PRESCRIBED_TRANSLATION = 1u << 5u,
};

enum NMResetFlags : nm_u32 {
    NM_RESET_ENABLED = 1u << 0u,
    NM_RESET_PARAMETERS = 1u << 1u,
};

enum NMContactFlags : nm_u32 {
    NM_CONTACT_VALID = 1u << 0u,
    NM_CONTACT_STICKING = 1u << 1u,
    NM_CONTACT_NEW = 1u << 2u,
    // Contact feature geometry is a clipped subtriangle whose shape
    // derivatives map into six parent-triangle FEM nodes.
    NM_CONTACT_MAPPED_FEATURE = 1u << 3u,
    // Single immutable-plane MPM velocity complementarity row; KKT reaction is in impulseAndNormal.
    NM_CONTACT_MPM_FIXED_PLANE_KKT = 1u << 8u,
};

enum NMEventClass : nm_u32 {
    NM_EVENT_CONTACT_ONSET = 0u,
    NM_EVENT_CONTACT_RELEASE = 1u,
    NM_EVENT_SLIP_ONSET = 2u,
    NM_EVENT_YIELD_ONSET = 3u,
    NM_EVENT_DAMAGE_ONSET = 4u,
    NM_EVENT_INVERSION_RISK = 5u,
    NM_EVENT_SOLVER_RESIDUAL = 6u,
    NM_EVENT_RATE_CHANGE = 7u,
};

typedef struct NM_ALIGN16 NMMatterDispatchGPU {
    nm_u32 abiVersion;
    nm_u32 flags;
    nm_u32 environmentCount;
    nm_u32 objectCount;

    nm_u32 materialCount;
    nm_u32 parameterCount;
    nm_u32 particleCount;
    nm_u32 gridNodeCount;

    nm_u32 femNodeCount;
    nm_u32 tetrahedronCount;
    nm_u32 rigidProxyCount;
    nm_u32 contactPairCount;

    nm_u32 maximumRateExponent;
    // Exact per-environment moving Human/FEM attachment record count. ABI v24
    // assigned the slot that ABI v20 had left reserved. ABI v25 additionally
    // cooks the complete component-major point-Jacobian scalar stride so no
    // runtime or shader site can silently wrap count * 3 * generalized DOFs.
    nm_u32 femHumanAttachmentCount;
    nm_u32 femHumanAttachmentPointJacobianStride;
    nm_u32 identificationCandidateCount;
    nm_u32 eventStride;

    nm_u32 mpmGridCount;
    nm_u32 mpmBlockCount;
    nm_u32 mpmBlockLookupCount;
    nm_u32 maximumParticlesPerBlock;

    // Fixed scalar stride used by every particle/tetrahedron material-state
    // record and total authored state-initializer count.
    nm_u32 materialStateStride;
    nm_u32 stateInitialCount;
    nm_u32 mixedMaterialCount;

    nm_u32 fieldBoundaryCount;
    nm_u32 cohesiveFaceCount;
    nm_u32 mutationCommandCount;
    nm_u32 learnedMaterialCount;

    nm_u32 learnedLayerCount;
    nm_u32 learnedWeightCount;
    nm_u32 topologyNodeCapacity;
    nm_u32 topologyTetrahedronCapacity;

    nm_u32 punctureChannelCount;
    nm_u32 femCapacityCount;
    // Per-environment capacity of the compact active-MPM Krylov arena. The
    // physical grid and node-to-active map retain gridNodeCount stride.
    nm_u32 mpmActiveNodeCapacity;
    nm_u32 reservedMixed1;

    // Cooked source-face count (package/source audit), dynamic
    // deformable-contact capacity, conservative articulated/free-body v
    // capacity, and conservative articulated q capacity. Runtime surface
    // primitives are derived from all four faces of each active tetrahedron.
    nm_u32 surfaceFaceCount;
    nm_u32 deformableContactCapacity;
    nm_u32 rigidGeneralizedCapacity;
    nm_u32 rigidQCapacity;

    // xyz gravity, w frame timestep.
    nm_float4 gravityAndTimestep;
    // contact slop, maximum depenetration speed, determinant floor, finite limit.
    nm_float4 numericalLimits;
} NMMatterDispatchGPU;

typedef struct NM_ALIGN16 NMMixedSolverGPU {
    // Newton, FGMRES restart, total FGMRES, determinant backtracking.
    nm_uint4 nonlinearIterations;
    // Field-smoother passes, mutation restarts, FEM preconditioner selector,
    // FEM algorithmic tangent-cache policy (0 disabled, 1 enabled). Selector
    // 2 is regional RAP with scalar fine correction; selector 3 uses the same
    // RAP with a 3x3 nodal block fine correction.
    nm_uint4 executionBudgets;
    // Equilibrium, volume, pressure, and transport relative residuals.
    nm_float4 residualTolerances;
    // Minimum separation/contact-slop ratio, reserved, reserved, reserved.
    nm_float4 contactAcceptance;
    // diagonal floor, initial LM shift, maximum LM shift, curvature tolerance.
    nm_float4 regularization;
    // Armijo coefficient, minimum absolute temperature, activation epsilon,
    // pressure-projection stabilization.
    nm_float4 globalization;
} NMMixedSolverGPU;

typedef struct NM_ALIGN16 NMFEMCapacityGPU {
    // node capacity, tetrahedron capacity, cohesive-face capacity, channel capacity.
    nm_uint4 topology;
    // mutation-command capacity, incidence capacity, contact capacity,
    // puncture impulse threshold encoded as IEEE-754 float bits.
    nm_uint4 work;
} NMFEMCapacityGPU;

typedef struct NM_ALIGN16 NMMixedMaterialGPU {
    // bulk modulus, thermal expansion, Biot coefficient, reference temperature.
    nm_float4 mechanics;
    // heat capacity, conductivity, heat source, electrical Joule fraction.
    nm_float4 thermal;
    // pore storage, permeability/viscosity, pore source, reserved.
    nm_float4 porous;
    // electrical conductivity, activation diffusivity, activation on/off rate.
    nm_float4 electrical;
    // reference fibre xyz, maximum active Cauchy tension.
    nm_float4 fibre;
    // activation threshold, activation slope, cohesive strength, fracture energy.
    nm_float4 coupling;
} NMMixedMaterialGPU;

// Passive vascular V1. Every unknown uses one float4.x in the existing
// monolithic Krylov arena; y/z/w are zero. Accepted x = physical / variableScale.
enum {
    NM_VASCULAR_LAYOUT_PERSISTENT_LOW_WORDS = 1u << 0u,
    NM_VASCULAR_LAYOUT_COMPENSATED_CAVITY_WORDS = 1u << 1u,
    NM_VASCULAR_LAYOUT_SEMISMOOTH_TRANSPORT = 1u << 2u,
    NM_VASCULAR_WORKING_SET_VALVE_STATE_MASK = 0x3u,
    NM_VASCULAR_WORKING_SET_TRANSPORT_BRANCH_VALID = 1u << 2u,
    NM_VASCULAR_WORKING_SET_TRANSPORT_REVERSE = 1u << 3u
};

typedef struct NM_ALIGN16 NMVascularLayoutGPU {
    nm_uint4 counts; // compartments, connections, species, fixed tissue reservoirs
    nm_uint4 ranges; // exchanges, tissue bindings, unknown count, flags (zero)
    nm_uint4 offsets; // volume/storage, flow, blood amount, tissue amount base indices
    nm_uint4 clock; // x: signed binary time quantum exponent, y/z/w reserved zero
    nm_uint4 cavities; // cavity count, face count, pressure unknown base, reserved zero
} NMVascularLayoutGPU;
// A material-wall cavity is an explicit pressure-volume constraint. Its
// boundary is cavity-outward (opposite the adjacent material's outward face).
typedef struct NM_ALIGN16 NMVascularCavityGPU {
    nm_uint4 identity; // stable id, compartment index, FEM object, pressure row
    nm_uint4 faces; // first face, count, reserved zero, reserved zero
    nm_u64 sourceIdentity[4]; // authored cavity geometry SHA256 provenance
    nm_u64 mechanicalIdentity[4]; // authored wall-mechanics SHA256 provenance
} NMVascularCavityGPU;
typedef struct NM_ALIGN16 NMVascularCavityFaceGPU {
    nm_uint4 nodes; // global FEM nodes xyz, reserved zero
    nm_uint4 identity; // cavity index, stable face id, materialWall (1), zero
} NMVascularCavityFaceGPU;

typedef struct NM_ALIGN16 NMVascularClockGPU {
    nm_u64 low; // elapsed accepted ticks, unsigned 128-bit low/high words
    nm_u64 high;
} NMVascularClockGPU;
typedef struct NM_ALIGN16 NMVascularIdentityGPU {
    nm_u64 content[4];
    nm_u64 source[4];
    nm_u64 authored[4];
} NMVascularIdentityGPU;
typedef struct NM_ALIGN16 NMVascularUnknownGPU {
    // physical initial value, variable scale, physical residual scale,
    // dimensionless absolute residual tolerance.
    nm_float4 initialAndScaling;
} NMVascularUnknownGPU;
typedef struct NM_ALIGN16 NMVascularSpeciesGPU {
    nm_uint4 identity; // stable id, name byte offset, reserved zero, reserved zero
    nm_float4 scaling; // mol scale, normalized amount residual tolerance, 0, 0
} NMVascularSpeciesGPU;
typedef struct NM_ALIGN16 NMVascularCompartmentGPU {
    nm_uint4 identity; // stable id, anatomical name byte offset, storage kind, pressure law
    nm_float4 compliance; // reference volume/storage, reference pressure, compliance, external pressure
    nm_float4 elastance; // Emin, Emax (Pa/m3), activation start, activation end/duration
    nm_u64 periodTicks; // rational period numerator in binary clock quanta
    nm_u64 periodMultiplier; // rational period denominator; zero for untimed laws
    nm_float4 waveform; // source pi, cosine pulse phase delay, reserved zero
    nm_float4 pressureParameters; // atan-law Vmax (m3), reserved zero
} NMVascularCompartmentGPU;
typedef struct NM_ALIGN16 NMVascularConnectionGPU {
    nm_uint4 identity; // stable id, from compartment index, to compartment index, flow law
    nm_float4 physical; // resistance (forward for law 4), inertance, orifice CV, Starling floor
    nm_float4 directional; // law 4 reverse resistance, 0, 0, 0; all zero for other laws
} NMVascularConnectionGPU;
typedef struct NM_ALIGN16 NMVascularTissueGPU {
    // stable id, anatomical name byte offset, FEM object or invalid,
    // blood-owner compartment index + 1 (zero means no mechanical owner)
    nm_uint4 identity;
    // fixed reservoir volume, registered blood density (kg/m3), initial
    // mechanically partitioned blood mass (kg), pressure-reaction area (m2).
    nm_float4 physical; // fixed reservoir volume, density, initial mass, pressure area
    // first tissue binding, count, pressure-from compartment + 1,
    // pressure-to compartment + 1. Both pressure entries are zero when the
    // explicit pressure-gradient wall reaction is disabled.
    nm_uint4 region;
    // authored FEM-region spatial moments in the initial object frame:
    // weighted first moment (x,y,z), then raw second moments (xx,xy,xz)
    // and (yy,yz,zz). Runtime mass multiplies these geometry moments. The
    // reserved w lanes carry the authored pressure-reaction unit direction
    // xyz when region.z and region.w are nonzero.
    nm_float4 spatialFirst;
    nm_float4 spatialSecond0;
    nm_float4 spatialSecond1;
} NMVascularTissueGPU;
typedef struct NM_ALIGN16 NMVascularExchangeGPU {
    nm_uint4 identity; // stable id, compartment index, tissue index, species index
    nm_float4 physical; // permeability-surface, partition coefficient, 0, 0
} NMVascularExchangeGPU;
typedef struct NM_ALIGN16 NMVascularTissueBindingGPU {
    nm_uint4 identity; // tissue index, global FEM node, 0, 0
    nm_float4 physical; // normalized regional weight, 0, 0, 0
} NMVascularTissueBindingGPU;
typedef struct NM_ALIGN16 NMVascularTissueMomentGPU {
    // Current mass-weighted first moment (kg m); w is current mass (kg).
    nm_float4 firstMassMoment;
    // Current raw second moments (kg m2): xx, xy, xz.
    nm_float4 secondMassMoment0;
    // Current raw second moments (kg m2): yy, yz, zz.
    nm_float4 secondMassMoment1;
    // Current co-moving linear momentum (kg m/s); w is reserved zero.
    nm_float4 linearMomentum;
} NMVascularTissueMomentGPU;
typedef struct NM_ALIGN16 NMVascularRangeGPU {
    nm_u32 first;
    nm_u32 count;
    nm_u32 reserved0;
    nm_u32 reserved1;
} NMVascularRangeGPU;

typedef struct NM_ALIGN16 NMFEMFieldStateGPU {
    // mechanical pressure, temperature, pore pressure, electric potential.
    nm_float4 primary;
    // activation, previous log(J), accumulated Joule heat, flags-as-float.
    nm_float4 secondary;
} NMFEMFieldStateGPU;

typedef struct NM_ALIGN16 NMFieldBoundaryGPU {
    // global FEM node, object, flags, stable identifier.
    nm_uint4 identity;
    // Dirichlet temperature, pore pressure, electric potential, activation.
    nm_float4 value;
    // thermal flux, pore flux, electric current, reserved.
    nm_float4 flux;
} NMFieldBoundaryGPU;

typedef struct NM_ALIGN16 NMFEMTopologyNodeGPU {
    // source node, object, topology generation, flags.
    nm_uint4 identity;
} NMFEMTopologyNodeGPU;

typedef struct NM_ALIGN16 NMFEMSurfaceFaceGPU {
    // First tetrahedron, second tetrahedron or invalid, object, flags.
    nm_uint4 adjacency;
    // Opposite corner in first/second tetrahedron, stable face id, reserved.
    nm_uint4 sides;
} NMFEMSurfaceFaceGPU;

enum NMContinuumSurfaceKind : nm_u32 {
    NM_CONTINUUM_SURFACE_TRIANGLE = 0u,
    NM_CONTINUUM_SURFACE_POINT = 1u,
};

typedef struct NM_ALIGN16 NMContinuumSurfacePrimitiveGPU {
    // Up to three unified continuum nodes and owning object. MPM nodes use
    // [0, gridNodeCount); FEM nodes use gridNodeCount + local FEM node.
    nm_uint4 nodesAndObject;
    // Stable source, NMContinuumSurfaceKind, topology generation, flags.
    nm_uint4 identity;
    // Swept AABB minimum xyz and current measure (one for a point).
    nm_float4 boundsMinimum;
    // Swept AABB maximum xyz and maximum vertex travel.
    nm_float4 boundsMaximum;
} NMContinuumSurfacePrimitiveGPU;

// First failed deformable narrowphase attempt; diagnostic-only, outside rollback.
typedef struct NM_ALIGN16 NMDeformableContactFailureGPU {
    // Present, control step, microtick, candidate slot.
    nm_uint4 attempt;
    nm_uint4 primitivePair;
    NMContinuumSurfacePrimitiveGPU primitives[2];
    nm_float4 start[6];
    nm_float4 finish[6];
    nm_float4 diagnostics;
    // Thickness, first/second object dt, solver iteration.
    nm_float4 parameters;
} NMDeformableContactFailureGPU;

typedef struct NM_ALIGN16 NMDeformableContactCandidateGPU {
    // First/second environment-local surface primitive, stable candidate id,
    // flags.
    nm_uint4 identity;
} NMDeformableContactCandidateGPU;

// Optional exact-call diagnostic written only by a selected private Armijo
// narrowphase invocation. It is not a solver/contact state and is never read
// by production mechanics. Endpoint arrays are the exact float32 arguments
// passed to vertexTriangleCCD, before any offline replay.
typedef struct NM_ALIGN16 NMDeformableVTCCDAuditGPU {
    // written, environment, candidate slot, direction*3 + vertex index.
    nm_uint4 attempt;
    nm_uint4 candidateIdentity;
    nm_uint4 leftNodesAndObject;
    nm_uint4 rightNodesAndObject;
    nm_float4 start[6];
    nm_float4 finish[6];
    // hit, certified, TOI, separation at the production helper return.
    nm_float4 result;
    nm_float4 normal;
    nm_float4 barycentric;
    nm_float4 point;
    // thickness, left object dt, right object dt, solver iteration.
    nm_float4 parameters;
} NMDeformableVTCCDAuditGPU;

// Optional first-uncertified mortar-complement CCD query, written inline by
// the selected production candidate thread. attempt.w: 1=partition invalid,
// 2=paired-boundary rejection, 3=left VT, 4=right VT, 5=EE. start/finish hold
// exact subtriangle endpoints (parent endpoints for invalid partitions);
// leftBary/rightBary preserve each cell map. This is diagnostic-only storage.
typedef struct NM_ALIGN16 NMMortarComplementAuditGPU {
    nm_uint4 attempt; // written, environment, candidate slot, query kind
    nm_uint4 candidateIdentity; // source primitive pair and production flags
    nm_uint4 cells; // left cell, right cell, left patch, right patch
    nm_uint4 feature; // VT vertex/direction or EE endpoint indices
    nm_float4 start[6]; // left subtriangle xyz[0..2], right xyz[3..5]
    nm_float4 finish[6];
    nm_float4 leftBary[3];
    nm_float4 rightBary[3];
    nm_float4 result; // hit, certified, TOI, separation
    nm_float4 parameters; // thickness, left dt, right dt, solver iteration
} NMMortarComplementAuditGPU;

enum NMDeformableContactKind : nm_u32 {
    NM_DEFORMABLE_CONTACT_VERTEX_TRIANGLE = 0u,
    NM_DEFORMABLE_CONTACT_EDGE_EDGE = 1u,
    NM_DEFORMABLE_CONTACT_POINT_POINT = 2u,
};

typedef struct NM_ALIGN16 NMDeformableContactGPU {
    // Up to six unified continuum nodes carrying the contact Jacobian. The
    // first four retain the legacy layout; mapped mortar-complement features
    // use extraNodes/extraWeights/extraTimeScales for the final two.
    nm_uint4 nodes;
    // Positive-side object, negative-side object, feature kind, flags.
    nm_uint4 identity;
    // Signed nodal weights; sum is zero for translational invariance.
    nm_float4 weights;
    // Per-node timestep divided by the positive-side reference timestep.
    // These scales make cross-rate IPC the gradient/Hessian of one action.
    nm_float4 timeScales;
    // Contact normal xyz and normalized time of impact in [0, 1].
    nm_float4 normalAndTOI;
    // Contact point xyz and unsigned feature separation at impact.
    nm_float4 pointAndSeparation;
    // Relative velocity xyz and lumped normal inverse response.
    nm_float4 velocityAndResponse;
    // Source primitive pair, stable candidate id, topology generation.
    nm_uint4 source;
    // Primal barrier impulse, two lagged-friction coordinates, friction.
    nm_float4 impulseAndFriction;
    // IPC normal impulse, velocity-space PSD curvature, thickness, barrier k.
    nm_float4 barrier;
    // Rows of the PSD-projected spatial barrier/friction Hessian. Signed
    // feature weights map this 3x3 metric into the complete nodal block.
    nm_float4 barrierHessianRow0;
    nm_float4 barrierHessianRow1;
    nm_float4 barrierHessianRow2;
    // Analytic gradient of the IPC feature mollifier with respect to each
    // nodal position. Point-point rows are zero.
    nm_float4 mollifierGradientRow0;
    nm_float4 mollifierGradientRow1;
    nm_float4 mollifierGradientRow2;
    nm_float4 mollifierGradientRow3;
    // mollifier value, dt * unmollified barrier energy,
    // dt^2 * PSD Gauss-Newton curvature, unmollified barrier stiffness.
    nm_float4 mollifier;
    nm_uint4 extraNodes;
    nm_float4 extraWeights;
    nm_float4 extraTimeScales;
    nm_float4 mollifierGradientRow4;
    nm_float4 mollifierGradientRow5;
    // Clipped contact feature vertices are barycentric points on one of the
    // two source parent triangles. These maps reconstruct exact moving feature
    // geometry for CCD and trial-energy evaluation without adding FEM nodes.
    nm_uint4 featureSideByVertex;
    nm_float4 featureBarycentricX;
    nm_float4 featureBarycentricY;
    nm_float4 featureBarycentricZ;
} NMDeformableContactGPU;

// Opt-in, transaction-local diagnostic output for the deformable CCD line
// search. This is scratch only: it is neither serialized in a Matter package
// nor part of accepted/checkpoint state. One record corresponds to one active
// contact candidate and carries the exact feature mapping used by CCD.
typedef struct NM_ALIGN16 NMDeformableContactLimitTraceGPU {
    nm_uint4 identity;
    nm_uint4 source;
    nm_uint4 nodes;
    nm_uint4 extraNodes;
    nm_float4 weights;
    nm_float4 extraWeights;
    nm_uint4 featureSideByVertex;
    nm_float4 featureBarycentricX;
    nm_float4 featureBarycentricY;
    nm_float4 featureBarycentricZ;
    nm_float4 featureStart[4];
    nm_float4 featureEnd[4];
    nm_float4 normalAndTOI;
    nm_float4 pointAndSeparation;
    nm_float4 barrierParameters;
    // collision thickness, exact CCD TOI, separation at TOI, lane alpha after
    // this candidate (before the final SIMD minimum).
    nm_float4 metrics;
    // start gap, directional gap, start barrier energy, start separation.
    nm_float4 barrier;
    // lane alpha before this contact, lane alpha after this contact,
    // initially requested object alpha, record-written marker.
    nm_float4 lineSearch;
    // active slot, contact slot, CCD hit, CCD certified.
    nm_uint4 result;
    // record valid, zero-bound/failure reason code, reserved, reserved.
    nm_uint4 diagnostic;
    // Exact source contact record for bounded selected-iteration replay.
    // This is diagnostic scratch only; it is not part of a runtime checkpoint
    // or the production contact arena. The writer fills it only for a captured
    // active slot, and readers must honor the active count/truncation fields.
    NMDeformableContactGPU contact;
    // Optional read-only result from the production exact VT matrix-action
    // helper, evaluated on each of the four source support nodes using the
    // selected Newton correction. Each float4 stores action xyz and a reserved
    // zero w lane. The matching uint4 stores one supported-branch marker per
    // support; these fields are diagnostic scratch and never solver state.
    nm_float4 productionExactAction[4];
    nm_uint4 productionExactActionSupported;
    // Actual per-object timestep passed to the production helper. This can
    // differ from the owner microstep for multirate objects.
    nm_float4 productionExactActionMetadata;
    // Diagnostic coordinate frame only: xyz is the immutable world reference
    // origin; w=1 means feature/CCD positions are relative to it, w=0 world.
    // This scratch metadata never participates in physical or replay state.
    nm_float4 referenceOriginAndMode;
    // Potential geometry before FP32 endpoint projection. Each actual point
    // is high+low in referenceOriginAndMode's frame. featureStart/End above
    // are the separate float3 endpoints passed to CCD.
    nm_float4 potentialFeatureStartHigh[4];
    nm_float4 potentialFeatureStartLow[4];
    nm_float4 potentialFeatureEndHigh[4];
    nm_float4 potentialFeatureEndLow[4];
} NMDeformableContactLimitTraceGPU;

// Optional bounded trace of every alpha tested for one selected deformable
// contact. These records are diagnostic scratch only and never feed solver
// state. One environment owns 32 entries, matching the production line-search
// upper bound.
typedef struct NM_ALIGN16 NMDeformableContactLimitTrialTraceGPU {
    // environment, solver iteration, active-list slot, contact arena slot
    nm_uint4 identity;
    // attempted, reject/accept reason, CCD hit, CCD certified
    nm_uint4 outcome;
    // full tested fraction, initial-touch nonclosing, finite barrier, accepted
    nm_uint4 guards;
    // current energy, base directional derivative, start alpha, current separation
    nm_float4 base;
    // alpha, trial TOI, trial separation, tested fraction
    nm_float4 ccd;
    // Exact certified CCD normal and point at the requested endpoint.
    nm_float4 ccdNormal;
    nm_float4 ccdPoint;
    // trial energy, trial separation, Armijo RHS, reserved
    nm_float4 energy;
    // trial weighted direction xyz and its dot with the oriented normal
    nm_float4 weightedDirection;
    // Four projected feature endpoints tested by production CCD
    nm_float4 featureEndpoint[4];
    // Diagnostic coordinate frame only: xyz is the immutable world reference
    // origin; w=1 means feature/CCD positions are relative to it, w=0 world.
    // This scratch metadata never participates in physical or replay state.
    nm_float4 referenceOriginAndMode;
    // Potential geometry before FP32 endpoint projection; separate from
    // featureEndpoint, which records the endpoints passed to CCD.
    nm_float4 potentialFeatureEndpointHigh[4];
    nm_float4 potentialFeatureEndpointLow[4];
} NMDeformableContactLimitTrialTraceGPU;

// Compact transaction-owned deformable-contact history. The
// geometric contact record is rebuilt from current surface primitives on each
// Newton candidate; only the stable source, transported frame, and lagged
// primal-potential history cross iteration/microstep boundaries.
typedef struct NM_ALIGN16 NMDeformableContactHistoryGPU {
    // Source primitive pair, stable candidate id, topology generation.
    nm_uint4 source;
    // Previous contact normal xyz and primal barrier impulse.
    nm_float4 normalAndBarrier;
    // Lagged tangent-potential coordinates, effective friction, valid marker.
    nm_float4 laggedTangentAndFriction;
} NMDeformableContactHistoryGPU;

typedef struct NM_ALIGN16 NMFEMTopologyStateGPU {
    // active nodes, active tetrahedra, active cohesive faces, active channels.
    nm_uint4 counts;
    // accepted arena, candidate arena, checkpoint arena, generation.
    nm_uint4 roles;
    // conserved mass, removed mass, removed energy, separated cohesive-face area (m^2).
    nm_float4 accounting;
} NMFEMTopologyStateGPU;

typedef struct NM_ALIGN16 NMCohesiveFaceGPU {
    // three nodes and first tetrahedron.
    nm_uint4 nodesAndFirst;
    // second tetrahedron, object, stable identifier, flags.
    nm_uint4 adjacency;
    // damage, maximum opening, traction, fracture work.
    nm_float4 state;
    // Interface reference normal xyz and latched reference area. Mortar
    // patches replace the preflight area with the actual accepted setting
    // endpoint area when activated.
    nm_float4 geometry;
    // For event-created faces, separated-side node copies. For
    // NM_TOPOLOGY_PAIRED_COHESIVE, xyz are authored side-B nodes and w is the
    // cohesive material index. Event-created faces keep w zero.
    nm_uint4 separatedNodes;
    // kind, cohesive-material-table index, activation control step, reserved.
    // Legacy Tryding faces keep kind zero and continue to use separatedNodes.w
    // as their generic material index.
    nm_uint4 lawIdentity;
    // Maximum accepted nodal opening at activation in metres; remaining lanes
    // are reserved and must be zero.
    nm_float4 activationControl;
    // Per paired node, activation gap in the co-rotating local basis
    // (normal, tangent-1, tangent-2), metres.
    nm_float4 activationLocalGap[3];
    // Actual side-A patch vertices and tangent-1 at the accepted activation
    // endpoint. Dormant faces keep these zero.
    nm_float4 activationSideAPosition[3];
    nm_float4 activationTangent1;
    // For mortar patches, each row is one patch vertex's barycentric map
    // into the corresponding parent face. Conforming legacy pairs use the
    // identity rows. w is reserved and must remain zero.
    nm_float4 mortarSideAVertexWeights[3];
    nm_float4 mortarSideBVertexWeights[3];
    // Three triangle quadrature points: maximum energy-norm separation,
    // onset energy-norm separation, frozen mixed fracture energy, damage.
    nm_float4 mixedPointHistory[3];
    // Cumulative dissipation per quadrature point in x/y/z, J/m^2.
    nm_float4 mixedPointWork;
} NMCohesiveFaceGPU;

typedef struct NM_ALIGN16 NMCohesiveActivationCommandGPU {
    // environment, object, stable face identifier, reserved zero.
    nm_uint4 identity;
} NMCohesiveActivationCommandGPU;

typedef struct NM_ALIGN16 NMCohesiveMaterialGPU {
    // Normal, shear, compression penalties (Pa/m) and normal initiation
    // strength (Pa).
    nm_float4 stiffnessAndNormalStrength;
    // Shear initiation strength (Pa), GIc (J/m^2), GIIc (J/m^2), BK exponent.
    nm_float4 shearStrengthAndFracture;
} NMCohesiveMaterialGPU;

typedef struct NM_ALIGN16 NMMutationCommandGPU {
    // kind, object, stable identifier, flags.
    nm_uint4 identity;
    // Control step, deterministic target, priority, reserved. Remeshing
    // targets are object-local tetrahedra except vertex smoothing, whose
    // target is an object-local node.
    nm_uint4 schedule;
    // plane normal or cylinder axis, w plane offset/radius.
    nm_float4 geometry0;
    // cylinder origin, w finite half length.
    nm_float4 geometry1;
} NMMutationCommandGPU;

typedef struct NM_ALIGN16 NMPunctureChannelGPU {
    // object, stable identifier, topology generation, flags.
    nm_uint4 identity;
    // origin xyz and radius.
    nm_float4 originAndRadius;
    // axis xyz and finite half length.
    nm_float4 axisAndHalfLength;
} NMPunctureChannelGPU;

typedef struct NM_ALIGN16 NMLearnedMaterialGPU {
    // first layer, layer count, first weight, weight count.
    nm_uint4 layout;
    // invariant count, material index, activation kind, flags.
    nm_uint4 identity;
    // softplus beta, determinant floor, growth coefficient, reserved.
    nm_float4 policy;
    // canonical content fingerprint low/high, accepted revision low/high.
    nm_uint4 fingerprint;
} NMLearnedMaterialGPU;

typedef struct NM_ALIGN16 NMLearnedLayerGPU {
    // input width, output width, first weight, first bias.
    nm_uint4 layout;
    // input skip offset, hidden recurrence offset, flags, reserved.
    nm_uint4 routing;
} NMLearnedLayerGPU;

typedef struct NM_ALIGN16 NMLearnedDifferentialGPU {
    nm_float4 deformationRow0;
    nm_float4 deformationRow1;
    nm_float4 deformationRow2;
    nm_float4 directionRow0;
    nm_float4 directionRow1;
    nm_float4 directionRow2;
    nm_float4 firstPiolaRow0;
    nm_float4 firstPiolaRow1;
    nm_float4 firstPiolaRow2;
    nm_float4 tangentRow0;
    nm_float4 tangentRow1;
    nm_float4 tangentRow2;
    nm_float4 diagnostics;
} NMLearnedDifferentialGPU;

typedef struct NM_ALIGN16 NMSolverCertificateGPU {
    // nonlinear residual, relative correction, volume residual, pressure residual.
    nm_float4 nonlinear;
    // maximum barrier impulse, minimum separation, tangential impulse,
    // barrier energy.
    nm_float4 contact;
    // thermal, pore, electric, activation residual.
    nm_float4 transport;
    // minimum determinant, minimum curvature, energy error, accepted flag.
    nm_float4 validity;
} NMSolverCertificateGPU;

enum NMMicrostepFlags : nm_u32 {
    NM_MICROSTEP_CAPTURE_EVENTS = 1u << 0u,
    NM_MICROSTEP_FGMRES_OPERATOR = 1u << 1u,
    NM_MICROSTEP_FIELD_PRECONDITIONER = 1u << 2u,
    // Diagnostic matrix-free reapplication after a completed Krylov cycle.
    // It bypasses only the cycle-accepted early-out in the FEM tangent action.
    NM_MICROSTEP_FGMRES_TRUE_RESIDUAL = 1u << 3u,
    // Replace only cache-valid nonmixed FEM xyz element actions with the
    // Newton-scoped assembled block-CSR operator.
    NM_MICROSTEP_FGMRES_ASSEMBLED_FEM = 1u << 4u,
    // Initialization-only scale for pressure traction transferred from the
    // vascular owner into deformable mechanics. The flow and blood-mass
    // equations remain unscaled.
    NM_MICROSTEP_VASCULAR_PRESSURE_LOAD_SCALE = 1u << 5u,
    // Experimental exact tangent for the current-volume blood-mass correction.
    NM_MICROSTEP_VASCULAR_BLOOD_MASS_TANGENT = 1u << 6u,
};

typedef struct NM_ALIGN16 NMMicrostepGPU {
    nm_u32 controlStep;
    nm_u32 microtick;
    nm_u32 microtickCount;
    nm_u32 solverIteration;

    nm_u32 seedLo;
    nm_u32 seedHi;
    nm_u32 flags;
    nm_u32 reserved;

    // microtick dt, inverse dt, execution time, duration.
    nm_float4 time;
    // Typed opt-in metadata. x is the vascular-to-FEM mechanical pressure
    // load scale when NM_MICROSTEP_VASCULAR_PRESSURE_LOAD_SCALE is set.
    nm_float4 initializationLoadScales;
} NMMicrostepGPU;

typedef struct NM_ALIGN16 NMBridgeDispatchGPU {
    nm_u32 environmentCount;
    nm_u32 rigidProxyCount;
    nm_u32 currentBodyCount;
    nm_u32 currentBodyStride;

    nm_u32 bodyWrenchCount;
    nm_u32 sceneBodyCount;
    nm_u32 bodyWrenchStride;
    nm_u32 sceneStride;

    nm_u32 reactionStride;
    // Number of body-owned reaction ranges compiled by the runtime.
    nm_u32 reactionBodyCount;
    nm_u32 rodNodeCount;
    nm_u32 rodNodeStride;

    // inverse dt, dt, reserved, reserved.
    nm_float4 time;
} NMBridgeDispatchGPU;

typedef struct NM_ALIGN16 NMResetPassGPU {
    nm_u32 controlStep;
    nm_u32 resetMaskStepStride;
    nm_u32 stateWidth;
    nm_u32 flags;
} NMResetPassGPU;

typedef struct NM_ALIGN16 NMIdentificationPassGPU {
    nm_u32 candidateCount;
    nm_u32 distributionCount;
    nm_u32 generation;
    nm_u32 flags;

    nm_u32 seedLo;
    nm_u32 seedHi;
    nm_u32 reserved0;
    nm_u32 reserved1;
} NMIdentificationPassGPU;

typedef struct NM_ALIGN16 NMExpressionInstructionGPU {
    nm_u32 opcode;
    nm_u32 index;
    nm_i32 integer;
    nm_u32 reserved;
    nm_float4 immediate;
} NMExpressionInstructionGPU;

typedef struct NM_ALIGN16 NMScalarProgramGPU {
    nm_u32 firstInstruction;
    nm_u32 instructionCount;
    nm_u32 maximumStack;
    nm_u32 flags;
} NMScalarProgramGPU;

typedef struct NM_ALIGN16 NMMaterialGPU {
    nm_u32 constitutiveKind;
    nm_u32 parameterOffset;
    nm_u32 parameterCount;
    nm_u32 stateCount;

    nm_u32 stressProgramOffset;
    nm_u32 tangentProgramOffset;
    nm_u32 validityProgram;
    nm_u32 flags;

    // Material-local initial state, next-state update programs, dissipation
    // scalar program, and projection policy.
    nm_u32 stateInitialOffset;
    nm_u32 stateUpdateProgramOffset;
    nm_u32 dissipationProgram;
    nm_u32 projectionKind;

    // Viscous stress and rate-tangent program ranges. Invalid offsets mean
    // that the material has no rate-dependent constitutive contribution.
    nm_u32 viscousStressProgramOffset;
    nm_u32 viscousTangentProgramOffset;
    nm_u32 implicitResidualProgramOffset;
    nm_u32 implicitJacobianProgramOffset;

    // R_F dF programs, P_z programs, packed 2-bit transfer policies, and the
    // fixed local Newton budget. These programs produce the consistent
    // algorithmic tangent P_F - P_z R_z^-1 R_F.
    nm_u32 implicitDeformationProgramOffset;
    nm_u32 stressStateDerivativeProgramOffset;
    nm_u64 stateTransferMask;
    nm_u32 localNewtonIterations;

    // density, reference temperature, specialized shear modulus, lambda.
    nm_float4 bulk;
    // static friction, dynamic friction, restitution, adhesion.
    nm_float4 interfaceResponse;
    // yield/cohesion strength, isotropic hardening, DP alpha, DP cohesion.
    nm_float4 inelastic;
    // minimum J, maximum J, maximum stress, maximum energy density.
    nm_float4 validity;
} NMMaterialGPU;

typedef struct NM_ALIGN16 NMParameterRangeGPU {
    // value, lower, upper, logarithmic flag.
    nm_float4 valueAndBounds;
} NMParameterRangeGPU;

typedef struct NM_ALIGN16 NMContinuumObjectGPU {
    nm_u32 representation;
    nm_u32 materialIndex;
    nm_u32 flags;
    nm_u32 schedulerIndex;

    nm_u32 stateOffset;
    nm_u32 stateCount;
    nm_u32 elementOffset;
    nm_u32 elementCount;

    nm_u32 auxiliaryOffset;
    nm_u32 auxiliaryCount;
    nm_u32 rigidBinding;
    nm_u32 topologyGeneration;

    // Base rate exponent, maximum exponent, reserved, reserved.
    nm_uint4 solver;
    // characteristic length, rigid tolerance, promotion strain, demotion strain.
    nm_float4 fidelity;
    // SHA256 of the immutable authored material-frame field and conversion.
    // Canonical zero when NM_OBJECT_FEM_MATERIAL_FRAME is absent.
    nm_u64 materialFrameSourceIdentity[4];
    // SHA256 of immutable source regional labels and the material/density map.
    // Canonical zero when NM_OBJECT_FEM_REGIONAL_MATERIAL is absent.
    nm_u64 materialSourceIdentity[4];
    // Supplied stress-free reference provenance; zero without reference opt-in.
    nm_u64 referenceSourceIdentity[4];
} NMContinuumObjectGPU;


typedef struct NM_ALIGN16 NMMPMGridGPU {
    // xyz inclusive minimum global node coordinate; w object index.
    nm_int4 nodeMinimumAndObject;
    // xyz node dimensions; w first node in the global node arena.
    nm_uint4 nodeDimensionsAndOffset;
    // xyz inclusive minimum block coordinate; w first block.
    nm_int4 blockMinimumAndOffset;
    // xyz block dimensions; w first dense block-lookup entry.
    nm_uint4 blockDimensionsAndLookup;
    // cell width, inverse cell width, support radius in cells, reserved.
    nm_float4 metrics;
} NMMPMGridGPU;

typedef struct NM_ALIGN16 NMMPMBlockGPU {
    // low/high Morton key, grid index, object index.
    nm_uint4 identity;
    // xyz block coordinate, w local dense lookup index.
    nm_int4 coordinateAndLookup;
} NMMPMBlockGPU;

typedef struct NM_ALIGN16 NMMPMParticleKeyGPU {
    // block index, low/high cell Morton key, flags.
    nm_uint4 identity;
} NMMPMParticleKeyGPU;

typedef struct NM_ALIGN16 NMActiveMPMBlockGPU {
    nm_u32 environment;
    nm_u32 blockIndex;
    nm_u32 firstParticle;
    nm_u32 particleCount;
} NMActiveMPMBlockGPU;

typedef struct NM_ALIGN16 NMIndirectDispatchGPU {
    nm_u32 threadgroupsX;
    nm_u32 threadgroupsY;
    nm_u32 threadgroupsZ;
    nm_u32 reserved;
} NMIndirectDispatchGPU;

typedef struct NM_ALIGN16 NMParticleStateGPU {
    nm_float4 positionAndMass;
    nm_float4 velocityAndReferenceVolume;
    nm_float4 deformationRow0;
    nm_float4 deformationRow1;
    nm_float4 deformationRow2;
    nm_float4 affineRow0;
    nm_float4 affineRow1;
    nm_float4 affineRow2;
    nm_float4 referenceAndTemperature;
    // object, material, topology generation, flags.
    nm_uint4 identity;
} NMParticleStateGPU;

typedef struct NM_ALIGN16 NMGridNodeStateGPU {
    nm_float4 positionAndMass;
    nm_float4 velocityAndInverseMass;
    nm_float4 forceAndEnergy;
    nm_float4 candidateVelocity;
} NMGridNodeStateGPU;

typedef struct NM_ALIGN16 NMMPMStencilGPU {
    nm_u32 particleIndex;
    nm_u32 nodeIndex;
    nm_u32 localSlot;
    nm_u32 reserved;
    // xyz reference gradient, w weight.
    nm_float4 gradientAndWeight;
} NMMPMStencilGPU;

typedef struct NM_ALIGN16 NMIncidenceRangeGPU {
    nm_u32 first;
    nm_u32 count;
    nm_u32 objectIndex;
    nm_u32 reserved;
} NMIncidenceRangeGPU;

typedef struct NM_ALIGN16 NMFEMHumanAttachmentGPU {
    // Global FEM node, global Numi Human body, owning continuum object, and
    // stable authored attachment identifier.
    nm_uint4 identity;
    // Body-local attachment point xyz; w is reserved and must be zero.
    nm_float4 localPoint;
} NMFEMHumanAttachmentGPU;

typedef struct NM_ALIGN16 NMFEMNodeStateGPU {
    nm_float4 positionAndMass;
    nm_float4 velocityAndInverseMass;
    nm_float4 restAndFixed;
    nm_float4 deltaVelocity;
    // Opt-in reference-displacement FEM stores the high limb of authoritative
    // displacement u in xyz and mode tag 1 in w. Legacy nodes require zero.
    nm_float4 referenceDisplacementAndMode;
    // Low limb of reference displacement; w is reserved and must be zero.
    nm_float4 referenceDisplacementLow;
} NMFEMNodeStateGPU;

typedef struct NM_ALIGN16 NMTetrahedronGPU {
    nm_uint4 nodes;
    // inverse rest matrix rows; row0.w is rest volume.
    nm_float4 inverseRestRow0;
    nm_float4 inverseRestRow1;
    nm_float4 inverseRestRow2;
    // material, object, topology generation, flags.
    nm_uint4 identity;
    // Unit Hamilton material-local -> reference-world quaternion (x,y,z,w).
    // Canonical zero for legacy material coordinates and dormant slots.
    nm_float4 materialFrameRotation;
} NMTetrahedronGPU;

typedef struct NM_ALIGN16 NMFEMElementVectorGPU {
    nm_float4 node0;
    nm_float4 node1;
    nm_float4 node2;
    nm_float4 node3;
} NMFEMElementVectorGPU;

// Runtime-only six-node force or directional-force contribution for an
// explicitly paired cohesive face (side A slots 0..2, side B slots 3..5).
typedef struct NM_ALIGN16 NMCohesiveFaceVectorGPU {
    nm_float4 node[6];
} NMCohesiveFaceVectorGPU;

// Runtime-only Krylov extension; never serialized into a Matter pack. Physical
// FEM/MPM/rigid strides retain their authored meanings. Each support row adds
// one float4 containing a world-space impulse correction (xyz; w is zero).
typedef struct NM_ALIGN16 NMFGMRESLayoutGPU {
    nm_u32 supportContactCount;
    nm_u32 supportBase;
    nm_u32 unknownCount;
    nm_u32 reserved;
    // First-class normalized scalar vascular block follows Human support.
    nm_u32 vascularUnknownCount;
    nm_u32 vascularBase;
    float vascularResidualTolerance;
    nm_u32 vascularReserved;
} NMFGMRESLayoutGPU;

typedef struct NM_ALIGN16 NMHumanSupportKKTGPU {
    nm_float4 residual;
    // Derivative of the non-associated Coulomb projection. This matrix can
    // be nonsymmetric during sliding; do not project it onto a PSD matrix.
    nm_float4 projectionRow0;
    nm_float4 projectionRow1;
    nm_float4 projectionRow2;
} NMHumanSupportKKTGPU;

// Observational root-local totals. These counters never affect acceptance,
// convergence, time or physical rollback. Unlike status.fgmresIterations,
// linear.x is the SUM of columns used by all cycles in the encoded root.
typedef struct NM_ALIGN16 NMFGMRESTelemetryGPU {
    // Used columns, cycles with work, encoded cycles, exhausted FGMRES solves.
    nm_uint4 linear;
    // Active Newton starts, active restart starts, final nonpressure/nontransport
    // residual norm bits, final aggregate transport residual norm bits.
    nm_uint4 nonlinear;
    // Last outer residual norm bits, its convergence threshold bits, minimum
    // observed outer norm bits, packed last iteration/latch/initialized flags.
    nm_uint4 outer;
    // Diagnostic-only partitioned RHS norms: nonvascular, vascular, mechanical
    // nonlinear threshold, vascular threshold. Zero means no distributed sample.
    nm_float4 domains;
    // Aggregate cycle ICB range selection, not actual child-kernel invocation:
    // x = nonempty selected ranges, y = selected command spans, z/w reserved.
    nm_uint4 aggregateCycle;
} NMFGMRESTelemetryGPU;

typedef struct NM_ALIGN16 NMFGMRESStateGPU {
    // Current residual, initial residual, convergence flag, Arnoldi columns.
    nm_float4 diagnostics;
    // First Newton residual, current Newton residual, last correction ratio,
    // nonlinear convergence flag. Private runtime state; never serialized.
    nm_float4 nonlinear;
    // Initial norm in the row-scaled Arnoldi metric. Raw diagnostics.y remains
    // the reference for physical true-residual certification.
    nm_float4 rowEquilibration;
} NMFGMRESStateGPU;

typedef struct NM_ALIGN16 NMRigidProxyGPU {
    nm_u32 shapeKind;
    // Global EngineModel body index. This is the canonical index used by the
    // current-body arena and the unified external-wrench arena. For
    // NM_RIGID_SUTURE_STRAND this carries the first live DER node index.
    nm_u32 bodyIndex;
    // Environment-local scene-body index used only when adaptive transfer
    // publishes a rigid state back into MetalWorld's scene-state stream. For
    // NM_RIGID_SUTURE_STRAND this carries the second live DER node index.
    nm_u32 sceneBodyIndex;
    nm_u32 materialIndex;

    nm_u32 flags;
    // Adaptive continuum object that owns this rigid fallback, or invalid.
    nm_u32 adaptiveObjectIndex;
    // Stable compact free-body generalized coordinate owner. Every proxy on
    // the same dynamic non-articulated body shares one index; all other
    // proxies carry NM_INVALID_INDEX.
    nm_u32 generalizedFreeBodyIndex;
    // IEEE FP32 prescribed-tool barrier scale bits. Zero is the exact legacy
    // scale 1.0; nonzero is legal only with NM_RIGID_PRESCRIBED_TRANSLATION.
    nm_u32 reserved2;

    // body-local center or plane normal; w radius or plane offset.
    nm_float4 localCenterAndRadius;
    // capsule endpoint B or box half extent.
    nm_float4 localExtent;
    nm_float4 localOrientation;
} NMRigidProxyGPU;

typedef struct NM_ALIGN16 NMRigidStateGPU {
    nm_float4 centerAndRadius;
    nm_float4 extent;
    nm_float4 orientation;
    nm_float4 linearVelocityAndInverseMass;
    nm_float4 angularVelocity;
    nm_float4 bodyCenter;
    nm_float4 inverseInertiaRow0;
    nm_float4 inverseInertiaRow1;
    nm_float4 inverseInertiaRow2;
} NMRigidStateGPU;

typedef struct NM_ALIGN16 NMContactPairGPU {
    // Unified node index: MPM nodes first, then FEM nodes.
    nm_u32 continuumNode;
    nm_u32 rigidProxy;
    nm_u32 objectIndex;
    nm_u32 materialInterface;
} NMContactPairGPU;

typedef struct NM_ALIGN16 NMContactSampleGPU {
    // continuum node, rigid proxy, object, flags.
    nm_uint4 identity;
    nm_float4 pointAndSeparation;
    nm_float4 normalAndVelocity;
    // Pre-correction continuum-minus-rigid relative velocity, with its
    // normal component in w. Topology events consume this admission motion;
    // the post-solve normal velocity above remains the contact certificate.
    nm_float4 admissionVelocityAndNormal;
    // xyz impulse on rigid, w normal impulse.
    nm_float4 impulseAndNormal;
    // xyz angular impulse on rigid, w tangential impulse.
    nm_float4 angularImpulseAndTangent;
    // IPC normal impulse, velocity-space PSD curvature, thickness, barrier k.
    nm_float4 barrier;
    // Rows of the physical velocity-space barrier/friction Hessian. Exact
    // capsule-side geometry may make this block indefinite; preconditioners
    // apply their own PSD policy without changing the physical operator.
    nm_float4 barrierHessianRow0;
    nm_float4 barrierHessianRow1;
    nm_float4 barrierHessianRow2;
} NMContactSampleGPU;

// Immutable, source-authored Human support row. These rows are deliberately
// separate from the continuum/rigid contact-pair table: both endpoints are
// the articulated Human and a fixed world plane. Matter condenses the local
// Coulomb multiplier into its monolithic Newton/FGMRES operator through the
// exact point Jacobian supplied by the coupled Human service.
typedef struct NM_ALIGN16 NMHumanSupportContactGPU {
    // Global articulated body, source geometry, source point-query, shape (0 point, 1 sphere, 2 ellipsoid).
    nm_uint4 identity;
    // COM-relative point/centre xyz; w is zero for point, positive radius for sphere.
    nm_float4 localPoint;
    // Coulomb friction, activation slop metres, normal stabilization, reserved.
    nm_float4 frictionSlopAndStabilization;
    nm_float4 supportRadii;
    nm_float4 supportOrientation;
} NMHumanSupportContactGPU;

// Byte-exact query consumed by the external articulated candidate service.
// It mirrors that service's point-query ABI without making Matter's public
// C++ header depend on MetalRobo engine types.
typedef struct NM_ALIGN16 NMHumanSupportPointQueryGPU {
    nm_u32 bodyIndex;
    nm_u32 flags;
    nm_u32 reserved0;
    nm_u32 reserved1;
    nm_float4 localPoint;
    nm_float4 worldImpulse;
    nm_float4 supportPlaneNormalAndRadius;
    // Ellipsoid semi-axes xyz (w=0) and shape-to-COM-frame quaternion xyzw.
    // Both all zero unless ELLIPSOID_SUPPORT is selected (sphere radius=0).
    nm_float4 supportRadii;
    nm_float4 supportOrientation;
} NMHumanSupportPointQueryGPU;

// Transactional physical consequence of one Human support row. Matter owns an
// accepted and a candidate stream beside the friction history; HumanIO reads
// only the candidate stream while its enclosing root remains unpublished.
typedef struct NM_ALIGN16 NMHumanSupportConsequenceGPU {
    // Source row, source geometry, contact flags, reserved.
    nm_uint4 identity;
    // World point xyz and signed plane separation.
    nm_float4 pointAndSeparation;
    // World impulse on Human xyz and nonnegative normal impulse.
    nm_float4 impulseAndNormal;
    // Tangential velocity xyz and tangential impulse magnitude.
    nm_float4 tangentVelocityAndImpulse;
} NMHumanSupportConsequenceGPU;

typedef struct NM_ALIGN16 NMHumanSupportDispatchGPU {
    nm_u32 contactCount;
    nm_u32 articulatedNv;
    nm_u32 articulationRootBody;
    nm_u32 bodyCount;
    nm_u32 bodyStride;
    nm_u32 reserved0;
    nm_u32 reserved1;
    nm_u32 reserved2;
    // xyz fixed-plane point, w timestep seconds.
    nm_float4 groundPointAndTimestep;
    // xyz unit fixed-plane normal, w reserved.
    nm_float4 groundNormal;
} NMHumanSupportDispatchGPU;

#define NM_HUMAN_SUPPORT_CONTACT_CAPACITY 32u
#define NM_HUMAN_SUPPORT_CONSEQUENCE_VERSION 1u

typedef struct NM_ALIGN16 NMRigidReactionGPU {
    nm_float4 impulseAndCount;
    nm_float4 angularImpulse;
} NMRigidReactionGPU;

typedef struct NM_ALIGN16 NMAdaptiveStateGPU {
    nm_u32 activeRepresentation;
    nm_u32 requestedRepresentation;
    nm_u32 stableFrames;
    nm_u32 flags;

    // mass, maximum strain, RMS strain, reconstruction residual.
    nm_float4 massAndError;
    // Current world-space centre of mass; w is the measured bounding radius.
    nm_float4 centerAndRadius;
    // Immutable authored rest-frame centre used for rigid-to-continuum
    // reconstruction. Keeping it separate from the current COM prevents
    // translation from leaking into the promoted deformation.
    nm_float4 referenceCenter;
    nm_float4 linearVelocityAndAngularSpeed;
    // xyz angular velocity, w minimum determinant.
    nm_float4 angularVelocityAndMinimumJ;
    nm_float4 orientation;
    nm_float4 inverseInertiaRow0;
    nm_float4 inverseInertiaRow1;
    nm_float4 inverseInertiaRow2;
} NMAdaptiveStateGPU;

typedef struct NM_ALIGN16 NMIdentificationDistributionGPU {
    // material, local parameter, global parameter, flags.
    nm_uint4 identity;
    // mean, standard deviation, lower, upper.
    nm_float4 momentsAndBounds;
    // learning rate, temperature, minimum std, logarithmic flag.
    nm_float4 update;
} NMIdentificationDistributionGPU;

typedef struct NM_ALIGN16 NMIdentificationCandidateGPU {
    nm_u32 environment;
    nm_u32 candidate;
    nm_u32 distribution;
    nm_u32 antitheticPartner;
    // value, normalized perturbation, loss, weight.
    nm_float4 sample;
} NMIdentificationCandidateGPU;

typedef struct NM_ALIGN16 NMSchedulerStateGPU {
    nm_u32 baseExponent;
    nm_u32 activeExponent;
    nm_u32 requestedExponent;
    nm_u32 quietFrames;

    // contact speed, slip impulse, maximum strain, maximum stress.
    nm_float4 physical;
    // minimum J, solver residual, damage, continuum-enabled flag.
    nm_float4 numerical;
    // contact, slip, strain, residual thresholds.
    nm_float4 thresholds;
    // elapsed episode time, last event time, last event delta, event count.
    nm_float4 timing;
} NMSchedulerStateGPU;

typedef struct NM_ALIGN16 NMEventTokenGPU {
    nm_u32 environment;
    nm_u32 objectIndex;
    nm_u32 eventClass;
    nm_u32 flags;
    // episode time, delta since the previous object event, severity, current.
    nm_float4 payload;
    // previous value, current value, reserved, reserved.
    nm_float4 transition;
} NMEventTokenGPU;

typedef struct NM_ALIGN16 NMMatterStatusGPU {
    nm_u32 code;
    nm_u32 environment;
    nm_u32 objectIndex;
    nm_u32 failingIndex;

    nm_u32 completedMicrosteps;
    nm_u32 fgmresIterations;
    nm_u32 contactCount;
    nm_u32 eventCount;

    // minimum J, maximum stress, residual, correction.
    nm_float4 diagnostics;
} NMMatterStatusGPU;

// Read-only first global nonzero status observed after a named production
// dispatch. This record never feeds solver, status, history, or rollback state.
typedef struct NM_ALIGN16 NMMatterFirstFailureCaptureGPU {
    // present, production dispatch ordinal, phase, control step.
    nm_uint4 capture;
    NMMatterStatusGPU status;
    NMSolverCertificateGPU certificate;
} NMMatterFirstFailureCaptureGPU;

// Diagnostic-only, bounded snapshot written by nm_fem_status5_capture.
// The runtime allocates two records per environment: the first global
// status-5 event and the first private Armijo status-5 event. This is not a
// solver input and must never be used to alter status, history, or rollback.
typedef struct NM_ALIGN16 NMFEMStatus5CaptureGPU {
    // present, stage ID, domain (0 global / 1 private), index kind.
    nm_uint4 capture;
    // control step, microtick, microtick count, Newton solver iteration.
    nm_uint4 context;
    // object index, status failing index, typed subject index, trial index.
    nm_uint4 identity;
    // payload flags, material index, state count, parameter count.
    nm_uint4 payload;
    // exact material dt, line-search alpha when supplied, det(F), reserved.
    nm_float4 scalars;
    NMMatterStatusGPU status;
    NMMicrostepGPU microstep;
    NMMaterialGPU material;
    NMTetrahedronGPU tetrahedron;
    NMFEMNodeStateGPU acceptedNodes[4];
    NMFEMNodeStateGPU candidateNodes[4];
    // Three row-major float4 rows; lane w is zero.
    nm_float4 deformationHigh[3];
    nm_float4 deformationLow[3];
    nm_float4 deformationRate[3];
    float acceptedInternalState[NM_MAX_MATERIAL_STATE];
    float parameterWords[NM_STATUS5_CAPTURE_MAX_PARAMETER_WORDS];
} NMFEMStatus5CaptureGPU;

#ifndef __METAL_VERSION__
static_assert(sizeof(nm_float4) == 16);
static_assert(sizeof(nm_uint4) == 16);
static_assert(sizeof(nm_int4) == 16);
static_assert(sizeof(NMMatterDispatchGPU) % 16 == 0);
static_assert(sizeof(NMMicrostepGPU) == 64);
static_assert(sizeof(NMResetPassGPU) == 16);
static_assert(sizeof(NMBridgeDispatchGPU) % 16 == 0);
static_assert(sizeof(NMRigidProxyGPU) == 80);
static_assert(sizeof(NMMaterialGPU) % 16 == 0);
static_assert(sizeof(NMContinuumObjectGPU) % 16 == 0);
static_assert(sizeof(NMMPMGridGPU) == 80);
static_assert(sizeof(NMMPMBlockGPU) == 32);
static_assert(sizeof(NMParticleStateGPU) % 16 == 0);
static_assert(sizeof(NMVascularLayoutGPU) == 80);
static_assert(sizeof(NMVascularCavityGPU) == 96);
static_assert(sizeof(NMVascularCavityFaceGPU) == 32);
static_assert(sizeof(NMFEMHumanAttachmentGPU) == 32);
static_assert(alignof(NMFEMHumanAttachmentGPU) == 16);
static_assert(sizeof(NMFEMNodeStateGPU) == 96);
static_assert(sizeof(NMFEMStatus5CaptureGPU) % 16 == 0);
static_assert(sizeof(NMDeformableVTCCDAuditGPU) == 336);
static_assert(sizeof(NMMortarComplementAuditGPU) == 384);
static_assert(sizeof(NMAdaptiveStateGPU) == 160);
static_assert(sizeof(NMSchedulerStateGPU) == 80);
static_assert(sizeof(NMEventTokenGPU) == 48);
static_assert(sizeof(NMHumanSupportContactGPU) == 80);
static_assert(sizeof(NMHumanSupportPointQueryGPU) == 96);
static_assert(sizeof(NMHumanSupportConsequenceGPU) == 64);
static_assert(sizeof(NMHumanSupportDispatchGPU) == 64);
#endif

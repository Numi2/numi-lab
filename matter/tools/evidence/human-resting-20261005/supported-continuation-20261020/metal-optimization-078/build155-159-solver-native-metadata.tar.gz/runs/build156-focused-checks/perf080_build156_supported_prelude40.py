#!/usr/bin/env python3
"""Prepare or execute one frozen full-gravity supported-rest continuation.

Default behavior is dry-run only. --execute is required to launch the GPU job.
The measurement horizon is --measurement-steps; the app adds the prelude.
"""
import argparse
import copy
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path("/Users/numi/numi-human-aortic-contact-opt-20261019")
EVIDENCE = ROOT / "matter/tools/evidence/human-resting-20261005/supported-continuation-20261020/metal-optimization-078"
TEMPLATE = EVIDENCE / "global-icb-native-stateless-allnative-hier-tailicb-domain-tight3-work-compact-parallelbt-plainpso-build151-block-coarse-femtangent-principal-cavity3-graph-coupled-strictinit-strictrows-prefixbase-stages-due-identity-3/invocation.json"
DEFAULT_BINARY = ROOT / "build-integrated-validation-20261019/perf078-build156-frozen/numi-human-native"
DEFAULT_OUTPUT = EVIDENCE / "build156-supported-prelude40-125us-1"
DEFAULT_MANIFEST = EVIDENCE / "native-build156-source-manifest.json"

def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--binary", type=Path, default=DEFAULT_BINARY)
    ap.add_argument("--manifest", type=Path, default=DEFAULT_MANIFEST)
    ap.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    ap.add_argument("--prelude-steps", type=int, default=40)
    ap.add_argument("--measurement-steps", type=int, default=1)
    ap.add_argument("--execute", action="store_true", help="launch; omitted means dry-run")
    a = ap.parse_args()
    if not (8 <= a.prelude_steps <= 4096 and a.measurement_steps >= 1):
        raise SystemExit("prelude must be 8..4096 and measurement horizon must be positive")
    base = json.loads(TEMPLATE.read_text())
    argv = list(base["argv"])
    env = dict(base["simulation_environment"])
    argv[0] = str(a.binary)
    argv[argv.index("--muscle-step-count") + 1] = str(a.measurement_steps)
    argv[argv.index("--muscle-step-seconds") + 1] = "0.00012500"
    argv[argv.index("--muscle-activation") + 1] = "1.0"
    run_dir = a.output
    argv[4] = str(run_dir / "output")
    env["DYLD_LIBRARY_PATH"] = str(a.binary.parent)
    env["NUMI_MATTER_METALLIB_OVERRIDE"] = str(a.binary.parent / "NumiMatter.metallib")
    env["NUMI_HUMAN_RESTING_COMMON_FAILURE_RECEIPT"] = str(run_dir / "common-field-failure.json")
    env["NUMI_HUMAN_SUPPORTED_INITIALIZATION"] = "1"
    env["NUMI_HUMAN_STATIC_WEIGHTED_SKIN_SUPPORT"] = "1"
    env["NUMI_HUMAN_SUPPORTED_PRELUDE_STEPS"] = str(a.prelude_steps)
    expected = {
        "NUMI_EXPERIMENT_RECRUITMENT_CAP": "1",
        "NUMI_EXPERIMENT_SUPPORT_ROWS": "1,4,5",
        "NM_FEM_TRUE_RESIDUAL_CERTIFY": "1",
    }
    for key, value in expected.items():
        if env.get(key) != value:
            raise SystemExit(f"template lacks required {key}={value}")
    if "--resting-gravity-ramp-steps" in argv or "--resting-release-initialization" in argv:
        raise SystemExit("strict supported mode must not use release or gravity-ramp initialization")
    if a.execute:
        if not a.binary.is_file():
            raise SystemExit(f"frozen build binary is missing: {a.binary}")
        if not a.manifest.is_file():
            raise SystemExit(f"build156 source manifest is missing: {a.manifest}")
        if run_dir.exists():
            raise SystemExit(f"refusing to overwrite existing evidence directory: {run_dir}")
        run_dir.mkdir(parents=True)
        record = {
            "argv": argv,
            "cwd": str(run_dir),
            "binary_sha256": digest(a.binary),
            "template_invocation_sha256": digest(TEMPLATE),
            "source_manifest_path": str(a.manifest),
            "source_manifest_sha256": digest(a.manifest),
            "simulation_environment": env,
            "prelude_accepted_steps": a.prelude_steps,
            "measurement_steps": a.measurement_steps,
            "expected_total_accepted_steps": a.prelude_steps + a.measurement_steps,
            "started_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        }
        (run_dir / "invocation.json").write_text(json.dumps(record, indent=2) + "\n")
        process_env = os.environ.copy()
        process_env.update(env)
        start = time.monotonic()
        with (run_dir / "stdout.log").open("w") as stdout, (run_dir / "stderr.log").open("w") as stderr:
            code = subprocess.run(argv, cwd=run_dir, env=process_env, stdout=stdout, stderr=stderr).returncode
        (run_dir / "process.json").write_text(json.dumps({"exit_code": code, "wall_seconds": time.monotonic() - start}, indent=2) + "\n")
        return code
    print(json.dumps({
        "dry_run": True,
        "binary": str(a.binary),
        "output": str(run_dir),
        "prelude_steps": a.prelude_steps,
        "measurement_steps": a.measurement_steps,
        "expected_total_accepted_steps": a.prelude_steps + a.measurement_steps,
        "argv": argv,
        "environment_delta": {
            "NUMI_HUMAN_SUPPORTED_INITIALIZATION": env["NUMI_HUMAN_SUPPORTED_INITIALIZATION"],
            "NUMI_HUMAN_STATIC_WEIGHTED_SKIN_SUPPORT": env["NUMI_HUMAN_STATIC_WEIGHTED_SKIN_SUPPORT"],
            "NUMI_HUMAN_SUPPORTED_PRELUDE_STEPS": env["NUMI_HUMAN_SUPPORTED_PRELUDE_STEPS"],
            "DYLD_LIBRARY_PATH": env["DYLD_LIBRARY_PATH"],
            "NUMI_MATTER_METALLIB_OVERRIDE": env["NUMI_MATTER_METALLIB_OVERRIDE"],
            "NUMI_HUMAN_RESTING_COMMON_FAILURE_RECEIPT": env["NUMI_HUMAN_RESTING_COMMON_FAILURE_RECEIPT"],
        },
    }, indent=2))
    return 0

if __name__ == "__main__":
    sys.exit(main())

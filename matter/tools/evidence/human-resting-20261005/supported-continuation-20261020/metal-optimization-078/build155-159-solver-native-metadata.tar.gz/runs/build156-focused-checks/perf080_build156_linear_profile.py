from pathlib import Path
import os,json,subprocess,time,hashlib,sys
r=Path('/Users/numi/numi-human-aortic-contact-opt-20261019')
e=r/'matter/tools/evidence/human-resting-20261005/supported-continuation-20261020/metal-optimization-078'
template=next(e.glob('*build156*z0-control*pair1/invocation.json'))
d=json.loads(template.read_text())
baseenv=d['simulation_environment'].copy()
baseenv.pop('NM_FEM_REGIONAL_SELECTOR6_ACCEPTED_Z0_RECYCLE',None)
baseenv.pop('NUMI_HUMAN_CAPTURE_FEM_ENDPOINT_STATE',None)
baseenv['NUMI_MATTER_WORK_COUNTERS']='1'
arms={
 'uninstrumented':dict(NUMI_MATTER_GPU_TIMING='0',NUMI_MATTER_GPU_TIMING_STAGES='0',NUMI_MATTER_GPU_TIMING_KERNELS='none'),
 'stage':dict(NUMI_MATTER_GPU_TIMING='1',NUMI_MATTER_GPU_TIMING_STAGES='1',NUMI_MATTER_GPU_TIMING_KERNELS='none',NUMI_MATTER_GPU_TIMING_ROOT='0'),
 'graph-phase0':dict(NUMI_MATTER_GPU_TIMING='1',NUMI_MATTER_GPU_TIMING_STAGES='1',NUMI_MATTER_GPU_TIMING_KERNELS='nm_fgmres_graph_validate_mask,nm_fgmres_graph_build_patch_matrices,nm_fgmres_graph_build_patch_matrices_cached_rows,nm_fgmres_graph_factor_patches',NUMI_MATTER_GPU_TIMING_SAMPLE_EVERY='17',NUMI_MATTER_GPU_TIMING_PHASE='0',NUMI_MATTER_GPU_TIMING_ROOT='0'),
 'graph-phase5':dict(NUMI_MATTER_GPU_TIMING='1',NUMI_MATTER_GPU_TIMING_STAGES='1',NUMI_MATTER_GPU_TIMING_KERNELS='nm_fgmres_graph_validate_mask,nm_fgmres_graph_build_patch_matrices,nm_fgmres_graph_build_patch_matrices_cached_rows,nm_fgmres_graph_factor_patches',NUMI_MATTER_GPU_TIMING_SAMPLE_EVERY='17',NUMI_MATTER_GPU_TIMING_PHASE='5',NUMI_MATTER_GPU_TIMING_ROOT='0')}
for name in sys.argv[1:]:
 env=baseenv.copy();env.update(arms[name])
 out=e/('build156-linear-profile-'+name+'-1')
 if out.exists():raise SystemExit('Refuse overwrite '+str(out))
 out.mkdir()
 argv=d['argv'].copy();argv[4]=str(out/'output')
 argv[argv.index('--muscle-step-count')+1]='1'
 env['NUMI_HUMAN_RESTING_COMMON_FAILURE_RECEIPT']=str(out/'common-field-failure.json')
 (out/'invocation.json').write_text(json.dumps(dict(argv=argv,simulation_environment=env,template=str(template),binary_sha256=hashlib.file_digest(open(argv[0],'rb'),'sha256').hexdigest()),indent=2))
 start=time.monotonic()
 with (out/'stdout.log').open('w') as so,(out/'stderr.log').open('w') as se:
  code=subprocess.run(argv,cwd=r,env={**os.environ,**env},stdout=so,stderr=se).returncode
 receipt=dict(exit_code=code,wall_seconds=time.monotonic()-start)
 (out/'process.json').write_text(json.dumps(receipt,indent=2))
 print(name,receipt,flush=True)
 if code:raise SystemExit(code)

#import <Foundation/Foundation.h>
#import <Metal/Metal.h>
#include <cstdio>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <algorithm>
int main(){@autoreleasepool{
id<MTLDevice>d=MTLCreateSystemDefaultDevice();id<MTLCommandQueue>q=[d newCommandQueue];
NSString*s=@"#include <metal_stdlib>\nusing namespace metal;\nkernel void k(device const float4* x[[buffer(0)]],device float4* y[[buffer(1)]],uint i[[thread_position_in_grid]]){float a=x[i].x,dt=x[i].y,f=x[i].z;float g=a;g+=-dt*dt*f;float c=-dt*dt*f;float n=a+c;if(!isfinite(c)||!isfinite(n))n=NAN;float z=fma(-dt*dt,f,a);y[i]=float4(g,n,z,c);}";
MTLCompileOptions*o=[MTLCompileOptions new];o.mathMode=MTLMathModeSafe;NSError*e=nil;
id<MTLLibrary>l=[d newLibraryWithSource:s options:o error:&e];if(!l){fprintf(stderr,"%s\n",e.description.UTF8String);return 1;}
id<MTLComputePipelineState>p=[d newComputePipelineStateWithFunction:[l newFunctionWithName:@"k"] error:&e];if(!p)return 2;
const unsigned N=1048576; id<MTLBuffer>in=[d newBufferWithLength:N*16 options:MTLResourceStorageModeShared],out=[d newBufferWithLength:N*16 options:MTLResourceStorageModeShared];
float*x=(float*)in.contents;uint32_t rng=7;auto r=[&](){rng^=rng<<13;rng^=rng>>17;rng^=rng<<5;return (float(rng)/4294967296.0f)*2-1;};
for(unsigned i=0;i<N;i++){x[4*i]=std::ldexp(r(),int(i%24)-16);x[4*i+1]=3.12500015e-5f;x[4*i+2]=std::ldexp(r(),int(i%32)-8);x[4*i+3]=0;}
id<MTLCommandBuffer>b=[q commandBuffer];id<MTLComputeCommandEncoder>c=[b computeCommandEncoder];[c setComputePipelineState:p];[c setBuffer:in offset:0 atIndex:0];[c setBuffer:out offset:0 atIndex:1];[c dispatchThreads:MTLSizeMake(N,1,1) threadsPerThreadgroup:MTLSizeMake(256,1,1)];[c endEncoding];[b commit];[b waitUntilCompleted];if(b.status!=MTLCommandBufferStatusCompleted)return 3;
float*y=(float*)out.contents;unsigned gn=0,gf=0,nf=0;for(unsigned i=0;i<N;i++){uint32_t a,v,w;memcpy(&a,y+4*i,4);memcpy(&v,y+4*i+1,4);memcpy(&w,y+4*i+2,4);gn+=a!=v;gf+=a!=w;nf+=v!=w;if(a!=v&&gn==1)printf("witness a=%.9g dt=%.9g f=%.9g generic=%.9g checked=%.9g fma=%.9g\n",x[4*i],x[4*i+1],x[4*i+2],y[4*i],y[4*i+1],y[4*i+2]);}
printf("safe_math_arithmetic samples=%u generic_checked_differences=%u generic_fma_differences=%u checked_fma_differences=%u gpu_seconds=%.9g\n",N,gn,gf,nf,b.GPUEndTime-b.GPUStartTime);
}}

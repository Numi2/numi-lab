from pathlib import Path
import tarfile,json,hashlib
r=Path('/Users/numi/numi-human-aortic-contact-opt-20261019')
e=r/'matter/tools/evidence/human-resting-20261005/supported-continuation-20261020/metal-optimization-078'
members={}
def add(p,n):
 if p.is_file():members[n]=p
for v in range(214,220):
 for p in e.glob('build'+str(v)+'*'):
  if p.is_dir():
   for name in ('stdout.log','stderr.log','invocation.json','process.json','common-field-failure.json','summary.json'):add(p/name,p.name+'/'+name)
   for x in (p/'output').glob('*.csv'):
    if x.stat().st_size<1048576:add(x,p.name+'/output/'+x.name)
  elif p.suffix in ('.json','.md'):add(p,p.name)
 for p in Path('/tmp').glob('perf080*'+str(v)+'*'):
  if p.suffix in ('.py','.log','.json','.patch'):add(p,'retained-tmp/'+p.name)
 f=r/('build-integrated-validation-20261019/perf078-build'+str(v)+'-frozen')
 for name in ('source.patch','source-changes.tar.gz','manifest.json','source-manifest.json'):add(f/name,'frozen'+str(v)+'/'+name)
 for p in e.glob('native-build'+str(v)+'-source-*.json'):add(p,p.name)
for n in ('fgmres-true-residual-native','vascular-cavity'):
 p=r/('build-integrated-validation-20261019/profile-build-039/matter/numi-matter-'+n+'-check')
 add(p,'native219/'+p.name)
for p in e.glob('verified-output-clones-incremental-20261021-104814.json'):add(p,p.name)
for name in ('perf080-build218-regional815-fidelity.json','perf080-build218-comparison.json','perf080-reuseoff-comparison.json','perf080-build167-regional-refinement.json'):add(Path('/tmp')/name,'retained-tmp/'+name)
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
manifest={n:dict(bytes=p.stat().st_size,sha256=sha(p)) for n,p in members.items()}
out=e/'build214-219-coupled-initialization-solver-metadata.tar.gz'
assert not out.exists()
with tarfile.open(out,'w:gz',compresslevel=6) as t:
 for n,p in sorted(members.items()):t.add(p,arcname=n,recursive=False)
with tarfile.open(out) as t:
 assert set(t.getnames())==set(members)
 for m in t.getmembers():
  assert hashlib.sha256(t.extractfile(m).read()).hexdigest()==manifest[m.name]['sha256']
receipt=dict(archive=out.name,sha256=sha(out),bytes=out.stat().st_size,members=manifest,all_members_independently_reopened_and_verified=True)
(e/'build214-219-coupled-initialization-solver-metadata-receipt.json').write_text(json.dumps(receipt,indent=2))
print(json.dumps({k:v for k,v in receipt.items() if k!='members'}))


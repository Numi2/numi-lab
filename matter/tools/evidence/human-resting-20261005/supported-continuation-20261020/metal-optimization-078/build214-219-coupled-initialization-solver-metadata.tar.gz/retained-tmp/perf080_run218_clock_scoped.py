from pathlib import Path
import subprocess,json
r=Path('/Users/numi/numi-human-aortic-contact-opt-20261019');e=r/'matter/tools/evidence/human-resting-20261005/supported-continuation-20261020/metal-optimization-078'
def run(name,env,steps=3,dt=None,template='build186-uninstrumented-control/invocation.json'):
 cmd=['python3',str(r/'matter/tools/run_human_frozen_invocation.py'),'--template',str(e/template),'--provenance',str(e/'native-build218-source-provenance.json'),'--output',str(e/name),'--cwd',str(r),'--steps',str(steps),'--metal-validation','0']
 if dt:cmd+=['--step-seconds',str(dt)]
 for key,value in env.items():cmd+=['--env',key+'='+str(value)]
 p=subprocess.run(cmd);print(json.dumps({'case':name,'returncode':p.returncode}),flush=True)
 return p.returncode

common={'NM_FEM_DEFORMABLE_COLLISION_GAP':1,'NM_VASCULAR_COMPENSATED_CAVITY_WORDS':0,'NM_FEM_FRESH_DIRECTION_ALPHA_RESET':0,'NM_FGMRES_FLAT_COLUMN_ICB':1,'NM_FGMRES_AGGREGATE_CYCLE_ICB':0,'NUMI_MATTER_HUMAN_PARTITIONED_FEM_TANGENT_PAIRED_PROJECT':1}


common.update({'NM_VASCULAR_SEMISMOOTH_TRANSPORT':0,'NM_FEM_FRESH_RHS_CLEAR_SKIPPED_CACHES':0,'NM_FGMRES_AGGREGATE_CYCLE_ICB':1,'NM_FGMRES_AGGREGATE_FIRST_CYCLE_ICB':1,'NM_FEM_FRESH_RHS_PREFLIGHT_SKIP_DOMAIN_DIAGNOSTIC':0})

for dt in [0.000125,0.00025,0.0005,0.001,0.002]:
 env=dict(common,NM_FEM_FRESH_RHS_PRECONDITIONER_PREFLIGHT=0,NM_VASCULAR_PERSISTENT_LOW_WORDS=1,NM_VASCULAR_COMPENSATED_CAVITY_WORDS=1,NM_VASCULAR_SEMISMOOTH_TRANSPORT=1)
 result=run('build218-coupled-clock-owner-scoped-'+str(round(dt*1e6))+'us',env,steps=3,dt=dt)
 if result: break

from pathlib import Path
import subprocess,json
r=Path('/Users/numi/numi-human-aortic-contact-opt-20261019');e=r/'matter/tools/evidence/human-resting-20261005/supported-continuation-20261020/metal-optimization-078'
selector=json.loads(Path('/tmp/perf080-build167-regional-refinement.json').read_text())
for mode,template in [('full','full'),('hybrid','embedded')]:
 t=e/('build167-'+template+'-contact-boundary-3/invocation.json')
 cmd=['python3',str(r/'matter/tools/run_human_frozen_invocation.py'),'--template',str(t),'--provenance',str(e/'native-build218-source-provenance.json'),'--output',str(e/('build218-regional815-'+mode)),'--cwd',json.loads(t.read_text())['cwd'],'--metal-validation','0']
 if mode=='hybrid':
  for k,v in selector['compiler_environment'].items():cmd+=['--env',k+'='+str(v)]
 p=subprocess.run(cmd)
 print(json.dumps({'case':mode,'returncode':p.returncode}),flush=True)
 if p.returncode:break

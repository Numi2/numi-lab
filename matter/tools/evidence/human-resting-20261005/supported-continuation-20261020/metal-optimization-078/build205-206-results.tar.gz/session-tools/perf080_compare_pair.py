from pathlib import Path
import json,re,sys
ns={};exec(Path("/tmp/perf080_compare157_z0.py").read_text().split("def main(")[0],ns)
e=ns["EVIDENCE"]; a=e/sys.argv[1];b=e/sys.argv[2]
def records(p,tag):
 return [json.loads(x) for x in re.findall(tag+r"=(\{[^\n]+\})",(p/"stderr.log").read_text())]
audit={}
for p in (a,b):
 m=ns["latest_metrics"](p); s=(p/"stderr.log").read_text();o=(p/"stdout.log").read_text()
 audit[p.name]={"metrics":m,"process":json.loads((p/"process.json").read_text()),"active_work":records(p,"matter_fgmres_active_work"),"coarse_lines":[l for l in s.splitlines() if "global_coarse" in l or "coarse_" in l],"timing_lines":[l for l in o.splitlines() if "authoritative_segment" in l],"body_seconds":[(end-start)/1000 for start,end in zip(map(float,re.findall(r"authoritative_segment_begin wall_elapsed_ms=([0-9.]+)",o)),map(float,re.findall(r"authoritative_segment_end wall_elapsed_ms=([0-9.]+)",o)))]}
x=ns["latest_metrics"](a);y=ns["latest_metrics"](b)
relative={k:max(abs(u-v)/max(abs(u),abs(v),1e-5) for u,v in zip(x[k],y[k])) for k in x}
r={"relative":relative,"passed_1pct":all(v<=.01 for v in relative.values()),"runs":audit}
(e/sys.argv[3]).write_text(json.dumps(r,indent=2));print(json.dumps({"passed":r["passed_1pct"],"relative":relative,"body_seconds":{k:v["body_seconds"] for k,v in audit.items()},"active_work":{k:v["active_work"] for k,v in audit.items()}},indent=2))

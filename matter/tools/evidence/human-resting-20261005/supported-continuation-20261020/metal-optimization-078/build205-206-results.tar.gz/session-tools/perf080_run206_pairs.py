from pathlib import Path
import subprocess
r=Path('/Users/numi/numi-human-aortic-contact-opt-20261019');e=r/'matter/tools/evidence/human-resting-20261005/supported-continuation-20261020/metal-optimization-078'
for pair in range(1,4):
 for on in ([False,True] if pair%2 else [True,False]):
  name=f'build206-combined-pair{pair}-'+('on' if on else 'control')
  cmd=['python3',str(r/'matter/tools/run_human_frozen_invocation.py'),'--template',str(e/'build186-uninstrumented-control/invocation.json'),'--provenance',str(e/'native-build206-source-provenance.json'),'--output',str(e/name),'--cwd',str(r),'--steps','3','--metal-validation','0','--env','NM_FEM_FRESH_RHS_PRECONDITIONER_PREFLIGHT=0','--env','NM_FEM_FRESH_DIRECTION_ALPHA_RESET=0']
  for key in ('NM_FEM_PARALLEL_CONSTITUTIVE_BACKTRACKING','NM_FGMRES_FLAT_COLUMN_ICB','NM_FGMRES_AGGREGATE_CYCLE_ICB','NM_MATTER_CONTACT_ZERO_STEP_GEOMETRY_REUSE'):cmd+=['--env',key+'='+str(int(on))]
  p=subprocess.run(cmd);print(name,p.returncode,flush=True)
  if p.returncode:raise SystemExit(p.returncode)
 subprocess.run(['python3','/tmp/perf080_compare_pair.py',f'build206-combined-pair{pair}-control',f'build206-combined-pair{pair}-on',f'build206-combined-pair{pair}-comparison.json'],check=True,stdout=subprocess.DEVNULL)


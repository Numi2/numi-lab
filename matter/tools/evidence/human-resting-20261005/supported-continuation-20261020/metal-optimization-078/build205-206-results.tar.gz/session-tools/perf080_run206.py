from pathlib import Path
import subprocess,json
r=Path('/Users/numi/numi-human-aortic-contact-opt-20261019');e=r/'matter/tools/evidence/human-resting-20261005/supported-continuation-20261020/metal-optimization-078'
def run(name,env,steps=3,dt=None,template='build186-uninstrumented-control/invocation.json'):
 cmd=['python3',str(r/'matter/tools/run_human_frozen_invocation.py'),'--template',str(e/template),'--provenance',str(e/'native-build206-source-provenance.json'),'--output',str(e/name),'--cwd',str(r),'--steps',str(steps),'--metal-validation','1']
 if dt:cmd+=['--step-seconds',str(dt)]
 for key,value in env.items():cmd+=['--env',key+'='+str(value)]
 p=subprocess.run(cmd);print(json.dumps({'case':name,'returncode':p.returncode}),flush=True)
 if p.returncode==0 and steps==3:
  subprocess.run(['python3','/tmp/perf080_compare_pair.py','build202-control',name,name+'-comparison.json'],stdout=subprocess.DEVNULL,check=True)
 return p.returncode
run('build206-aggregate-cycle',{'NM_FGMRES_FLAT_COLUMN_ICB':1,'NM_FGMRES_AGGREGATE_CYCLE_ICB':1,'NM_FEM_FRESH_RHS_PRECONDITIONER_PREFLIGHT':0})
for mode in (1,2):
 run('build206-preflight-domain'+str(mode),{'NM_FEM_FRESH_RHS_PRECONDITIONER_PREFLIGHT':1,'NM_FEM_FRESH_RHS_PREFLIGHT_DIAGNOSTIC':0,'NM_FEM_FRESH_RHS_PREFLIGHT_SKIP_DOMAIN_DIAGNOSTIC':mode})
run('build206-fresh-alpha-lowwords-fine12',{'NM_FEM_FRESH_DIRECTION_ALPHA_RESET':1,'NM_VASCULAR_PERSISTENT_LOW_WORDS':1,'NM_FEM_FRESH_RHS_PRECONDITIONER_PREFLIGHT':0,'NUMI_HUMAN_CONTACT_CONNECTED_CLOCK_LOCK':0},steps=12,dt=3.125e-5,template='build201-lowwords-31p25us-lock0-12/invocation.json')


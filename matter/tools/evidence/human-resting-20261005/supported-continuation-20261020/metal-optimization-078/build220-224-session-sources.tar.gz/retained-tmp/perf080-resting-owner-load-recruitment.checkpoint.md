# Accepted FEM load to resting MyoSim excitation handoff

Status: private and unbuilt; no native, Metal, or Human run has validated this patch. It is intentionally not applied to the canonical checkout.

Patch: `/tmp/perf080-resting-owner-load-recruitment.patch`
SHA-256: `3381abbcff6c39e2ec4cd6ab3a585bf4e4f452cd318eabe0726dc07e194889f5`
Base checked: SSH Numi `28ed85f7ac9b26afdefc7ab1d78dd8b5e31087ea`; `git apply --check` passed.

The feature is default-off. To exercise it after integration, set both `NUMI_HUMAN_ACCEPTED_LOAD_RECRUITMENT_HANDOFF=1` and `NUMI_HUMAN_ACCEPTED_FEM_BODY_LOAD_CAPTURE=1`, then run the existing strict supported weighted-skin initialization with a full-horizon supported prelude. The source step defaults to 2 and can be selected with `NUMI_HUMAN_ACCEPTED_LOAD_RECRUITMENT_SOURCE_STEP`; the prelude must leave at least eight accepted steps after the one-step-lagged target starts.

At the selected accepted boundary, the code pairs the existing captured pre-dynamics FEM generalized load with its exact source q, recaptures weighted support witnesses at that q, and performs a frozen-pose static muscle recruitment fit. The existing RestingCoupling callback applies only the fitted MyoSim excitation `.x` from the next beginStep through the requested horizon. Activation/fibre state and the resting RespiratoryBrain owner remain with their existing owners. Accepted application counts are updated only after successful segments return. Logs explicitly call the result a source-pose static muscle fit and include a diagnostic full-mass support deficit; they do not certify whole-body equilibrium or settled tissue.

Next validation must compile the native targets, run the existing source-capture and rollback checks, add/execute a focused beginStep test proving only `.x` changes and rejected candidates restore it, then compare strict supported-prelude evidence with the feature off/on. Preserve the static-fit residual, full-mass support deficit, accepted source fingerprint, and application count; do not treat the fit as a balanced or rested body.

from pathlib import Path
root=Path('/tmp/perf080-sparse-basis-private-20261021/base')

def edit(rel, pairs):
    p=root/rel
    s=p.read_text()
    for old,new,count in pairs:
        n=s.count(old)
        if n != count:
            raise RuntimeError(f'{rel}: expected {count} occurrences, found {n}: {old[:100]!r}')
        s=s.replace(old,new)
    p.write_text(s)

# Fingerprint exact payload encoding and arrays; representation changes invalidate the layout token.
edit('matter/include/numi/matter/compiled_world_partitioned_reduction.hpp', [
('    mix(source.minimumCoordinateReductionFactor);\n    mix(source.opticOnly ? 1u : 0u);\n',
 '    mix(source.minimumCoordinateReductionFactor);\n    mix(source.opticOnly ? 1u : 0u);\n    mix(source.sparseCoefficientEncoding ? 1u : 0u);\n',1),
('    for(auto x:source.blockModeIndices) mix(x);\n    for(const auto& v:source.basisValues){mix(std::bit_cast<std::uint32_t>(v.x));mix(std::bit_cast<std::uint32_t>(v.y));mix(std::bit_cast<std::uint32_t>(v.z));mix(std::bit_cast<std::uint32_t>(v.w));}\n',
 '    for(auto x:source.blockModeIndices) mix(x);\n    for(const auto& v:source.basisValues){mix(std::bit_cast<std::uint32_t>(v.x));mix(std::bit_cast<std::uint32_t>(v.y));mix(std::bit_cast<std::uint32_t>(v.z));mix(std::bit_cast<std::uint32_t>(v.w));}\n    for(auto x:source.sparseRegionSupportOffsets) mix(x);\n    for(auto x:source.sparseRegionSupportRows) mix(x);\n    for(auto x:source.sparseModeValueOffsets) mix(x);\n    for(const auto& v:source.sparseBasisValues){mix(std::bit_cast<std::uint32_t>(v.x));mix(std::bit_cast<std::uint32_t>(v.y));mix(std::bit_cast<std::uint32_t>(v.z));mix(std::bit_cast<std::uint32_t>(v.w));}\n    for(auto x:source.sparseNodeModeValueIndices) mix(x);\n    for(auto x:source.sparseRegionModeSupportOffsets) mix(x);\n    for(auto x:source.sparseRegionModeSupportValueIndices) mix(x);\n',1)
])

# Validate exact sparse payload against the dense reference source at the compilation boundary.
edit('matter/src/runtime.mm', [
('    id<MTLBuffer> femHumanPartitionedBasis = nil;\n',
 '    bool femHumanPartitionedSparseCoefficientEncodingEnabled = false;\n    id<MTLBuffer> femHumanPartitionedBasis = nil;\n',1),
('    id<MTLBuffer> femHumanPartitionedNodeModeSlots = nil;\n',
 '    id<MTLBuffer> femHumanPartitionedNodeModeSlots = nil;\n    id<MTLBuffer> femHumanPartitionedNodeModeValueIndices = nil;\n    id<MTLBuffer> femHumanPartitionedRegionModeSupportOffsets = nil;\n    id<MTLBuffer> femHumanPartitionedRegionModeSupportValueIndices = nil;\n',1),
('    id<MTLBuffer> femHumanPartitionedFEMTangentTetBasisRows = nil;\n',
 '    id<MTLBuffer> femHumanPartitionedFEMTangentTetBasisRows = nil;\n    id<MTLBuffer> femHumanPartitionedFEMTangentTetModeValueIndices = nil;\n',1),
('    for (const nm_float4 value : source.basisValues) {\n        if (!std::isfinite(value.x) || !std::isfinite(value.y) ||\n            !std::isfinite(value.z) || value.w != 0.0f)\n            return fail("Human partitioned coarse preconditioner basis contains a non-finite or packed-coordinate value");\n    }\n',
 '''    for (const nm_float4 value : source.basisValues) {
        if (!std::isfinite(value.x) || !std::isfinite(value.y) ||
            !std::isfinite(value.z) || value.w != 0.0f)
            return fail("Human partitioned coarse preconditioner basis contains a non-finite or packed-coordinate value");
    }
    const bool anySparsePayload = !source.sparseRegionSupportOffsets.empty() ||
        !source.sparseRegionSupportRows.empty() ||
        !source.sparseModeValueOffsets.empty() ||
        !source.sparseBasisValues.empty() ||
        !source.sparseNodeModeValueIndices.empty() ||
        !source.sparseRegionModeSupportOffsets.empty() ||
        !source.sparseRegionModeSupportValueIndices.empty();
    if (source.sparseCoefficientEncoding) {
        const auto support = numi::matter::buildPartitionedReductionSparseSupport(
            std::span<const nm_float4>(source.basisValues), source.basisNodeCount,
            source.modeCount, std::span<const std::uint32_t>(source.blockModeIndices),
            source.regionCount, source.blockModeCount);
        const auto sparse = numi::matter::buildPartitionedReductionSparseCoefficients(
            std::span<const nm_float4>(source.basisValues), source.basisNodeCount,
            source.modeCount, std::span<const std::uint32_t>(source.blockModeIndices),
            source.regionCount, source.blockModeCount, support);
        if (!support.valid() || !sparse.valid() ||
            source.sparseRegionSupportOffsets.size() != source.regionCount + 1u ||
            source.sparseRegionSupportRows != support.regionSupportRows ||
            source.sparseModeValueOffsets != sparse.modeValueOffsets ||
            source.sparseNodeModeValueIndices != sparse.nodeModeValueIndices ||
            source.sparseRegionModeSupportOffsets != sparse.regionModeSupportOffsets ||
            source.sparseRegionModeSupportValueIndices != sparse.regionModeSupportValueIndices ||
            source.sparseBasisValues.size() != sparse.values.size() ||
            source.sparseBasisValues.size() >= source.basisValues.size())
            return fail("Human sparse basis payload does not match its exact dense reference and support map");
        for (std::uint32_t region = 0u; region < source.regionCount; ++region) {
            const auto range = support.regionSupportRanges[region];
            if (source.sparseRegionSupportOffsets[region] != range.first ||
                source.sparseRegionSupportOffsets[region + 1u] != range.first + range.count)
                return fail("Human sparse region offsets do not match exact regional support");
        }
        for (std::size_t i = 0u; i < sparse.values.size(); ++i) {
            const auto a = source.sparseBasisValues[i];
            const auto b = sparse.values[i];
            if (a.x != b.x || a.y != b.y || a.z != b.z || a.w != b.w)
                return fail("Human sparse basis coefficients differ from exact dense source values");
        }
    } else if (anySparsePayload) {
        return fail("Human sparse basis arrays require explicit sparse-coefficient encoding");
    }
''',1)
])

# Compile state: prepare the coefficient-index indirection matching the actual uploaded dense or sparse value arena.
edit('matter/src/runtime.mm', [
('            const auto& source = world.humanPartitionedPreconditioner;\n            const auto sparseSupport =\n',
 '''            const auto& source = world.humanPartitionedPreconditioner;
            const auto sparseSupport =
''',1),
('                !sparseSupport.nodeModeSlots.empty();\n            if (candidate->femHumanHybridCoordinatesEnabled) {\n',
 '''                !sparseSupport.nodeModeSlots.empty();
            numi::matter::PartitionedReductionCoefficientIndexMap coefficientIndexMap;
            if (sparseSupportShapeValid) {
                if (source.sparseCoefficientEncoding) {
                    coefficientIndexMap.nodeModeValueIndices =
                        source.sparseNodeModeValueIndices;
                    coefficientIndexMap.regionModeSupportOffsets =
                        source.sparseRegionModeSupportOffsets;
                    coefficientIndexMap.regionModeSupportValueIndices =
                        source.sparseRegionModeSupportValueIndices;
                } else {
                    coefficientIndexMap =
                        numi::matter::buildPartitionedReductionDenseCoefficientIndexMap(
                            std::span<const nm_float4>(source.basisValues),
                            source.basisNodeCount, source.modeCount,
                            std::span<const std::uint32_t>(source.blockModeIndices),
                            source.regionCount, source.blockModeCount, sparseSupport);
                }
                if (!coefficientIndexMap.valid() ||
                    coefficientIndexMap.nodeModeValueIndices.size() !=
                        sparseSupport.nodeModeSlots.size() ||
                    coefficientIndexMap.regionModeSupportOffsets.size() !=
                        std::size_t(source.regionCount) * source.blockModeCount + 1u ||
                    coefficientIndexMap.regionModeSupportValueIndices.size() !=
                        std::size_t(source.modeCount) *
                            (sparseSupport.regionSupportRows.size() / source.regionCount)) {
                    diagnostics.message =
                        "Human sparse coefficient index map failed its checked extents: " +
                        coefficientIndexMap.error;
                    return diagnostics;
                }
            } else if (source.sparseCoefficientEncoding) {
                diagnostics.message =
                    "sparse coefficient encoding requires exact sparse support worklists";
                return diagnostics;
            }
            if (candidate->femHumanHybridCoordinatesEnabled) {
''',1),
('            PartitionedReductionFEMTangentSupport femTangentSupport;\n            PartitionedReductionHybridGSSupport hybridGSSupport;\n',
 '''            PartitionedReductionFEMTangentSupport femTangentSupport;
            PartitionedReductionHybridGSSupport hybridGSSupport;
            std::vector<std::uint32_t> tangentTetModeValueIndices;
''',1),
('                auto& tangentDispatch =\n                    candidate->femHumanPartitionedFEMTangentDispatch;\n',
 '''                const std::uint64_t tangentMapCount =
                    static_cast<std::uint64_t>(femTangentSupport.regionTetrahedronIndices.size()) *
                    source.blockModeCount * 4u;
                if (tangentMapCount > std::numeric_limits<std::size_t>::max() ||
                    tangentMapCount > std::numeric_limits<std::uint32_t>::max()) {
                    diagnostics.message =
                        "Human sparse tangent coefficient map exceeds checked indexing";
                    return diagnostics;
                }
                tangentTetModeValueIndices.assign(
                    static_cast<std::size_t>(tangentMapCount), NM_INVALID_INDEX);
                for (std::uint32_t region = 0u; region < source.regionCount; ++region) {
                    const auto tetRange =
                        femTangentSupport.regionTetrahedronRanges[region];
                    const auto rowRange = sparseSupport.regionSupportRanges[region];
                    const auto rowBegin = sparseSupport.regionSupportRows.begin() +
                        rowRange.first;
                    const auto rowEnd = rowBegin + rowRange.count;
                    for (std::uint32_t i = 0u; i < tetRange.count; ++i) {
                        const std::uint32_t flatTet = tetRange.first + i;
                        if (flatTet >= femTangentSupport.regionTetrahedronIndices.size()) {
                            diagnostics.message =
                                "Human sparse tangent tet range escapes its support map";
                            return diagnostics;
                        }
                        const std::uint32_t tetIndex =
                            femTangentSupport.regionTetrahedronIndices[flatTet];
                        if (std::uint64_t(tetIndex) * 4u + 3u >=
                            femTangentSupport.tetrahedronBasisNodeRows.size()) {
                            diagnostics.message =
                                "Human sparse tangent tet row map escapes its source rows";
                            return diagnostics;
                        }
                        for (std::uint32_t localMode = 0u;
                             localMode < source.blockModeCount; ++localMode) {
                            const std::uint32_t packed =
                                region * source.blockModeCount + localMode;
                            for (std::uint32_t corner = 0u; corner < 4u; ++corner) {
                                const std::uint32_t row =
                                    femTangentSupport.tetrahedronBasisNodeRows[
                                        std::size_t(tetIndex) * 4u + corner];
                                if (row >= source.basisNodeCount) {
                                    diagnostics.message =
                                        "Human sparse tangent corner is outside basis rows";
                                    return diagnostics;
                                }
                                const auto found = std::lower_bound(
                                    rowBegin, rowEnd, row);
                                if (found == rowEnd || *found != row) continue;
                                const std::size_t supportIndex =
                                    coefficientIndexMap.regionModeSupportOffsets[packed] +
                                    static_cast<std::size_t>(found - rowBegin);
                                if (supportIndex >= coefficientIndexMap.regionModeSupportValueIndices.size()) {
                                    diagnostics.message =
                                        "Human sparse tangent coefficient lookup escapes its regional map";
                                    return diagnostics;
                                }
                                tangentTetModeValueIndices[
                                    (std::size_t(flatTet) * source.blockModeCount +
                                     localMode) * 4u + corner] =
                                    coefficientIndexMap.regionModeSupportValueIndices[
                                        supportIndex];
                            }
                        }
                    }
                }
                auto& tangentDispatch =
                    candidate->femHumanPartitionedFEMTangentDispatch;
''',1),
('            if (!fitsOneBuffer(source.basisValues.size(), sizeof(nm_float4)) ||\n',
 '''            const std::size_t coefficientValueCount = source.sparseCoefficientEncoding
                ? source.sparseBasisValues.size() : source.basisValues.size();
            if (!fitsOneBuffer(coefficientValueCount, sizeof(nm_float4)) ||
''',1),
('                    fitsOneBuffer(sparseSupport.nodeModeSlots.size(),\n                                  sizeof(std::uint32_t)) &&\n                    fitsOneBuffer(sparseBlockPartials, sizeof(float)) &&\n',
 '''                    fitsOneBuffer(sparseSupport.nodeModeSlots.size(),
                                  sizeof(std::uint32_t)) &&
                    fitsOneBuffer(coefficientIndexMap.nodeModeValueIndices.size(),
                                  sizeof(std::uint32_t)) &&
                    fitsOneBuffer(coefficientIndexMap.regionModeSupportOffsets.size(),
                                  sizeof(std::uint32_t)) &&
                    fitsOneBuffer(coefficientIndexMap.regionModeSupportValueIndices.size(),
                                  sizeof(std::uint32_t)) &&
                    fitsOneBuffer(sparseBlockPartials, sizeof(float)) &&
''',1),
('''                 !fitsOneBuffer(
                    femTangentSupport.tetrahedronBasisNodeRows.size(),
                    sizeof(std::uint32_t)) ||
''',
 '''                 !fitsOneBuffer(
                    femTangentSupport.tetrahedronBasisNodeRows.size(),
                    sizeof(std::uint32_t)) ||
                 !fitsOneBuffer(tangentTetModeValueIndices.size(),
                    sizeof(std::uint32_t)) ||
''',1),
('            candidate->femHumanPartitionedBasis = humanPartitionedUploads.one(\n                std::span<const nm_float4>(source.basisValues), valid,\n                candidate->residentBytes);\n',
 '''            candidate->femHumanPartitionedSparseCoefficientEncodingEnabled =
                source.sparseCoefficientEncoding;
            candidate->femHumanPartitionedBasis = source.sparseCoefficientEncoding
                ? humanPartitionedUploads.one(
                    std::span<const nm_float4>(source.sparseBasisValues), valid,
                    candidate->residentBytes)
                : humanPartitionedUploads.one(
                    std::span<const nm_float4>(source.basisValues), valid,
                    candidate->residentBytes);
''',1),
('                candidate->femHumanPartitionedNodeModeSlots = humanPartitionedUploads.one(\n                    std::span<const std::uint32_t>(\n                        sparseSupport.nodeModeSlots), valid,\n                    candidate->residentBytes);\n',
 '''                candidate->femHumanPartitionedNodeModeSlots = humanPartitionedUploads.one(
                    std::span<const std::uint32_t>(
                        sparseSupport.nodeModeSlots), valid,
                    candidate->residentBytes);
                candidate->femHumanPartitionedNodeModeValueIndices =
                    humanPartitionedUploads.one(std::span<const std::uint32_t>(
                        coefficientIndexMap.nodeModeValueIndices), valid,
                        candidate->residentBytes);
                candidate->femHumanPartitionedRegionModeSupportOffsets =
                    humanPartitionedUploads.one(std::span<const std::uint32_t>(
                        coefficientIndexMap.regionModeSupportOffsets), valid,
                        candidate->residentBytes);
                candidate->femHumanPartitionedRegionModeSupportValueIndices =
                    humanPartitionedUploads.one(std::span<const std::uint32_t>(
                        coefficientIndexMap.regionModeSupportValueIndices), valid,
                        candidate->residentBytes);
''',1),
('                candidate->femHumanPartitionedFEMTangentTetBasisRows =\n                    humanPartitionedUploads.one(std::span<const std::uint32_t>(\n                        femTangentSupport.tetrahedronBasisNodeRows),\n                        valid, candidate->residentBytes);\n',
 '''                candidate->femHumanPartitionedFEMTangentTetBasisRows =
                    humanPartitionedUploads.one(std::span<const std::uint32_t>(
                        femTangentSupport.tetrahedronBasisNodeRows),
                        valid, candidate->residentBytes);
                candidate->femHumanPartitionedFEMTangentTetModeValueIndices =
                    humanPartitionedUploads.one(std::span<const std::uint32_t>(
                        tangentTetModeValueIndices), valid,
                        candidate->residentBytes);
''',1),
])

print('runtime/fingerprint integration edits applied')

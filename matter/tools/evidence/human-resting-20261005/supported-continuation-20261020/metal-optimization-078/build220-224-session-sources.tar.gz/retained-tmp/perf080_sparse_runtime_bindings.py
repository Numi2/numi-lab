from pathlib import Path
root=Path('/tmp/perf080-sparse-basis-private-20261021/base')
def edit(rel,pairs):
 p=root/rel;s=p.read_text()
 for old,new,n in pairs:
  k=s.count(old)
  if k!=n: raise RuntimeError(f'{rel} expected {n}, saw {k}: {old[:100]!r}')
  s=s.replace(old,new)
 p.write_text(s)

edit('matter/src/runtime.mm',[
('''                        std::size_t(source.modeCount) *
                            (sparseSupport.regionSupportRows.size() / source.regionCount)) {''',
 '''                        std::size_t(source.blockModeCount) *
                            sparseSupport.regionSupportRows.size()) {''',1),
# Compile fingerprint shape includes representation bit and new buffer identities.
('''                    mixShape(shapeSignature, state.femHumanPartitionedBlockModeCount);
                    mixShape(shapeSignature, state.femHumanPartitionedRegionCount);
                    mixShape(shapeSignature, state.femHumanPartitionedSparseTileCount);
''',
 '''                    mixShape(shapeSignature, state.femHumanPartitionedBlockModeCount);
                    mixShape(shapeSignature, state.femHumanPartitionedRegionCount);
                    mixShape(shapeSignature, state.femHumanPartitionedSparseTileCount);
                    mixShape(shapeSignature,
                        state.femHumanPartitionedSparseCoefficientEncodingEnabled ? 1u : 0u);
''',1),
('''                    mixShape(shapeSignature, reinterpret_cast<std::uintptr_t>(
                        (__bridge void*)state.femHumanPartitionedNodeModeSlots));
''',
 '''                    mixShape(shapeSignature, reinterpret_cast<std::uintptr_t>(
                        (__bridge void*)state.femHumanPartitionedNodeModeSlots));
                    mixShape(shapeSignature, reinterpret_cast<std::uintptr_t>(
                        (__bridge void*)state.femHumanPartitionedNodeModeValueIndices));
                    mixShape(shapeSignature, reinterpret_cast<std::uintptr_t>(
                        (__bridge void*)state.femHumanPartitionedRegionModeSupportOffsets));
                    mixShape(shapeSignature, reinterpret_cast<std::uintptr_t>(
                        (__bridge void*)state.femHumanPartitionedRegionModeSupportValueIndices));
''',1),
('''                    mixShape(shapeSignature, reinterpret_cast<std::uintptr_t>(
                        (__bridge void*)state.femHumanPartitionedFEMTangentTetBasisRows));
''',
 '''                    mixShape(shapeSignature, reinterpret_cast<std::uintptr_t>(
                        (__bridge void*)state.femHumanPartitionedFEMTangentTetBasisRows));
                    mixShape(shapeSignature, reinterpret_cast<std::uintptr_t>(
                        (__bridge void*)state.femHumanPartitionedFEMTangentTetModeValueIndices));
''',1),
# direct sparse B^T projection
('''                [encoder setBuffer:state.femHumanPartitionedRegionSupportRows offset:0u atIndex:8u];
            });
''',
 '''                [encoder setBuffer:state.femHumanPartitionedRegionSupportRows offset:0u atIndex:8u];
                [encoder setBuffer:state.femHumanPartitionedRegionModeSupportOffsets offset:0u atIndex:9u];
                [encoder setBuffer:state.femHumanPartitionedRegionModeSupportValueIndices offset:0u atIndex:10u];
            });
''',1),
# hybrid lift node->compact coefficient lookup
('''                [encoder setBuffer:destinationVector offset:destinationOffset atIndex:7u];
            });
''',
 '''                [encoder setBuffer:destinationVector offset:destinationOffset atIndex:7u];
                [encoder setBuffer:state.femHumanPartitionedNodeModeValueIndices offset:0u atIndex:8u];
            });
''',1),
# sparse block matrix tiles
('''                        [encoder setBuffer:
                            state.femHumanPartitionedRegionSupportRows
                                     offset:0u atIndex:6u];
                    }
''',
 '''                        [encoder setBuffer:
                            state.femHumanPartitionedRegionSupportRows
                                     offset:0u atIndex:6u];
                        [encoder setBuffer:
                            state.femHumanPartitionedRegionModeSupportOffsets
                                     offset:0u atIndex:9u];
                        [encoder setBuffer:
                            state.femHumanPartitionedRegionModeSupportValueIndices
                                     offset:0u atIndex:10u];
                    }
''',1),
# Tangent construction coefficient map buffer 14
('''                        [encoder setBuffer:
                            state.femHumanPartitionedFEMTangentActions
                                     offset:0u atIndex:13u];
                    });
''',
 '''                        [encoder setBuffer:
                            state.femHumanPartitionedFEMTangentActions
                                     offset:0u atIndex:13u];
                        [encoder setBuffer:
                            state.femHumanPartitionedFEMTangentTetModeValueIndices
                                     offset:0u atIndex:14u];
                    });
''',1),
# Tangent projection map buffer 8
('''                        [encoder setBuffer:
                            state.femHumanPartitionedFEMTangentPartials
                                     offset:0u atIndex:7u];
                    });
''',
 '''                        [encoder setBuffer:
                            state.femHumanPartitionedFEMTangentPartials
                                     offset:0u atIndex:7u];
                        [encoder setBuffer:
                            state.femHumanPartitionedFEMTangentTetModeValueIndices
                                     offset:0u atIndex:8u];
                    });
''',1),
# in-solve sparse B^T mode projection (second sparse mode tile bind site)
('''                            [encoder setBuffer:
                                state.femHumanPartitionedRegionSupportRows
                                         offset:0u atIndex:8u];
                        }
                    });
''',
 '''                            [encoder setBuffer:
                                state.femHumanPartitionedRegionSupportRows
                                         offset:0u atIndex:8u];
                            [encoder setBuffer:
                                state.femHumanPartitionedRegionModeSupportOffsets
                                         offset:0u atIndex:9u];
                            [encoder setBuffer:
                                state.femHumanPartitionedRegionModeSupportValueIndices
                                         offset:0u atIndex:10u];
                        }
                    });
''',1),
# sparse residual correction node-value lookup
('''                            [encoder setBuffer:
                                state.femHumanPartitionedNodeModeSlots
                                         offset:0u atIndex:8u];
                        }
                    });
''',
 '''                            [encoder setBuffer:
                                state.femHumanPartitionedNodeModeSlots
                                         offset:0u atIndex:8u];
                            [encoder setBuffer:
                                state.femHumanPartitionedNodeModeValueIndices
                                         offset:0u atIndex:9u];
                        }
                    });
''',1),
# ICB sparse projection map
('''                        bind(preCmd, 7u, state.femHumanPartitionedRegionSupportRanges);
                        bind(preCmd, 8u, state.femHumanPartitionedRegionSupportRows);
                        if (!finishGrid256(preCmd,
''',
 '''                        bind(preCmd, 7u, state.femHumanPartitionedRegionSupportRanges);
                        bind(preCmd, 8u, state.femHumanPartitionedRegionSupportRows);
                        bind(preCmd, 9u, state.femHumanPartitionedRegionModeSupportOffsets);
                        bind(preCmd, 10u, state.femHumanPartitionedRegionModeSupportValueIndices);
                        if (!finishGrid256(preCmd,
''',1),
# ICB sparse correction map
('''                        bind(preCmd, 7u, state.femHumanPartitionedNodeModeRanges);
                        bind(preCmd, 8u, state.femHumanPartitionedNodeModeSlots);
                        finish(preCmd, "nm_partitioned_reduction_add_sparse_region_correction",
''',
 '''                        bind(preCmd, 7u, state.femHumanPartitionedNodeModeRanges);
                        bind(preCmd, 8u, state.femHumanPartitionedNodeModeSlots);
                        bind(preCmd, 9u, state.femHumanPartitionedNodeModeValueIndices);
                        finish(preCmd, "nm_partitioned_reduction_add_sparse_region_correction",
''',1),
])
# Fix the same mode variable used in the scalar tangent projection's new coefficient-index lookup.
edit('matter/src/metal/partitioned_reduction_fem_tangent.metalinc',[
('''            const uint leftMode = blockModeIndices[
                region * tangent.blockModeCount +
                localPair / tangent.blockModeCount];
            const uint rightLocalMode = localPair % tangent.blockModeCount;
''',
 '''            const uint leftLocalMode = localPair / tangent.blockModeCount;
            const uint leftMode = blockModeIndices[
                region * tangent.blockModeCount + leftLocalMode];
            const uint rightLocalMode = localPair % tangent.blockModeCount;
''',1),
])
print('sparse map bindings and tangent mode fix applied')

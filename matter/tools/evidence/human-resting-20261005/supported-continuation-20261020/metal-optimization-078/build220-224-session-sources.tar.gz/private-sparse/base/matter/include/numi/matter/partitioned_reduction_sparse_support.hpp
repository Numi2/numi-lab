#pragma once

#include "numi/matter/partitioned_reduction_basis.hpp"
#include "numi/matter/partitioned_reduction_projection.h"

#include <algorithm>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <span>
#include <string>
#include <vector>

namespace numi::matter {

// Immutable upload metadata for the exact sparse support of the exported FP32
// basis. Ranges are {first,count} pairs into the accompanying flat arrays.
struct PartitionedReductionSparseSupport {
    std::vector<NMPartitionedReductionSparseRangeGPU> regionSupportRanges;
    std::vector<std::uint32_t> regionSupportRows;
    std::vector<NMPartitionedReductionSparseRangeGPU> nodeModeRanges;
    // Packed as region * blockModeCount + localMode.
    std::vector<std::uint32_t> nodeModeSlots;
    std::uint32_t sparseTileCount = 0u;
    std::uint32_t maximumNodeModeCount = 0u;
    std::string error;

    [[nodiscard]] bool valid() const noexcept { return error.empty(); }
};

// Hybrid Bq requires bijective coordinates and a race-free source row map.
// The compiled Human owner promises strictly ascending global node IDs; retain
// that contract here so GPU lift/scatter never aliases two basis rows.
[[nodiscard]] inline std::string validatePartitionedHybridIndexMaps(
    const std::span<const std::uint32_t> globalFEMNodeIndices,
    const std::uint32_t basisNodeCount,
    const std::uint32_t globalNodeCount,
    const std::span<const std::uint32_t> blockModeIndices,
    const std::uint32_t modeCount,
    const std::uint32_t regionCount,
    const std::uint32_t blockModeCount
) {
    if (basisNodeCount == 0u || globalNodeCount == 0u || modeCount == 0u ||
        regionCount == 0u || blockModeCount == 0u || blockModeCount > 32u ||
        globalFEMNodeIndices.size() != basisNodeCount ||
        blockModeIndices.size() != modeCount ||
        static_cast<std::uint64_t>(regionCount) * blockModeCount != modeCount)
        return "hybrid index map dimensions do not match the full basis";

    for (std::uint32_t row = 0u; row < basisNodeCount; ++row) {
        const std::uint32_t node = globalFEMNodeIndices[row];
        if (node >= globalNodeCount)
            return "hybrid source node is outside the compiled FEM range";
        if (row != 0u && globalFEMNodeIndices[row - 1u] >= node)
            return "hybrid source nodes must be unique and strictly ascending";
    }

    std::vector<std::uint8_t> modeSeen(modeCount, 0u);
    for (const std::uint32_t mode : blockModeIndices) {
        if (mode >= modeCount)
            return "hybrid regional mode is outside the full coordinate range";
        if (modeSeen[mode] != 0u)
            return "hybrid regional mode map contains a duplicate coordinate";
        modeSeen[mode] = 1u;
    }
    return {};
}

// Validates that one complete compiled FEM object remains on the identity-fine
// path of a hybrid Bq vector. A row with no B support is copied through by
// hybrid_lift and is never selected/zeroed by hybrid_restrict; bind that rule
// to the exact object-local range and reject any nonzero coefficient there.
[[nodiscard]] inline std::string validatePartitionedHybridFineOwnerRows(
    const std::span<const std::uint32_t> globalFEMNodeIndices,
    const std::span<const std::uint32_t> rowObjectIndices,
    const std::span<const nm_float4> basisValues,
    const std::uint32_t basisNodeCount,
    const std::uint32_t modeCount,
    const std::uint32_t fineObjectIndex,
    const std::uint32_t fineStateOffset,
    const std::uint32_t fineStateCount
) {
    if (basisNodeCount == 0u || modeCount == 0u ||
        globalFEMNodeIndices.size() != basisNodeCount ||
        rowObjectIndices.size() != basisNodeCount || fineStateCount == 0u ||
        static_cast<std::uint64_t>(basisNodeCount) * modeCount !=
            basisValues.size() ||
        static_cast<std::uint64_t>(fineStateOffset) + fineStateCount >
            std::numeric_limits<std::uint32_t>::max())
        return "hybrid identity-fine owner dimensions are invalid";

    std::vector<std::uint8_t> seen(fineStateCount, 0u);
    std::uint32_t ownerRows = 0u;
    const std::uint64_t fineEnd =
        static_cast<std::uint64_t>(fineStateOffset) + fineStateCount;
    for (std::uint32_t row = 0u; row < basisNodeCount; ++row) {
        const std::uint32_t global = globalFEMNodeIndices[row];
        const bool inFineRange = global >= fineStateOffset && global < fineEnd;
        const bool ownedByFineObject = rowObjectIndices[row] == fineObjectIndex;
        if (inFineRange != ownedByFineObject)
            return "hybrid identity-fine source range and compiled row ownership disagree";
        if (!ownedByFineObject) continue;
        const std::uint32_t local = global - fineStateOffset;
        if (seen[local] != 0u)
            return "hybrid identity-fine source range contains a duplicate row";
        seen[local] = 1u;
        ++ownerRows;
        for (std::uint32_t mode = 0u; mode < modeCount; ++mode) {
            const nm_float4 value = basisValues[
                static_cast<std::size_t>(mode) * basisNodeCount + row];
            if (!std::isfinite(value.x) || !std::isfinite(value.y) ||
                !std::isfinite(value.z) || !std::isfinite(value.w))
                return "hybrid identity-fine source coefficient is non-finite";
            if (value.x != 0.0f || value.y != 0.0f || value.z != 0.0f ||
                value.w != 0.0f)
                return "hybrid identity-fine source row has a nonzero B coefficient";
        }
    }
    if (ownerRows != fineStateCount ||
        std::find(seen.begin(), seen.end(), std::uint8_t{0u}) != seen.end())
        return "hybrid identity-fine source object is not represented by its complete row range";
    return {};
}

// Builds deterministic compact support from the exact uploaded float B. The
// caller supplies the existing region-major [region][localMode] global-mode
// map; no thresholds are used, so a coefficient is present iff any xyz
// component is exactly nonzero in the GPU basis representation.
[[nodiscard]] inline PartitionedReductionSparseSupport
buildPartitionedReductionSparseSupport(
    const std::span<const nm_float4> basisValues,
    const std::uint32_t basisNodeCount,
    const std::uint32_t modeCount,
    const std::span<const std::uint32_t> blockModeIndices,
    const std::uint32_t regionCount,
    const std::uint32_t blockModeCount
) {
    PartitionedReductionSparseSupport result;
    const auto fail = [&](const char* message) {
        result.error = message;
        result.regionSupportRanges.clear();
        result.regionSupportRows.clear();
        result.nodeModeRanges.clear();
        result.nodeModeSlots.clear();
        result.sparseTileCount = 0u;
        result.maximumNodeModeCount = 0u;
        return result;
    };
    if (basisNodeCount == 0u || modeCount == 0u ||
        basisValues.size() != static_cast<std::size_t>(basisNodeCount) *
            modeCount || regionCount == 0u || blockModeCount == 0u ||
        blockModeCount > 32u ||
        blockModeIndices.size() != static_cast<std::size_t>(regionCount) *
            blockModeCount) {
        return fail("sparse support inputs do not match the dense basis and regional block map");
    }
    std::vector<std::uint8_t> modeSeen(modeCount, 0u);
    for (const std::uint32_t mode : blockModeIndices) {
        if (mode >= modeCount || modeSeen[mode] != 0u)
            return fail("sparse support regional mode map is out of range or duplicated");
        modeSeen[mode] = 1u;
    }

    result.regionSupportRanges.resize(regionCount);
    result.nodeModeRanges.resize(basisNodeCount);
    std::uint32_t maximumRegionRows = 0u;
    for (std::uint32_t region = 0u; region < regionCount; ++region) {
        if (result.regionSupportRows.size() >
            std::numeric_limits<std::uint32_t>::max())
            return fail("sparse support row offsets exceed uint32 range");
        auto& range = result.regionSupportRanges[region];
        range.first = static_cast<std::uint32_t>(result.regionSupportRows.size());
        for (std::uint32_t row = 0u; row < basisNodeCount; ++row) {
            bool supported = false;
            for (std::uint32_t localMode = 0u;
                 localMode < blockModeCount; ++localMode) {
                const std::uint32_t mode = blockModeIndices[
                    static_cast<std::size_t>(region) * blockModeCount + localMode];
                const auto& value = basisValues[
                    static_cast<std::size_t>(mode) * basisNodeCount + row];
                if (!std::isfinite(value.x) || !std::isfinite(value.y) ||
                    !std::isfinite(value.z))
                    return fail("sparse support basis contains a non-finite xyz coefficient");
                supported = supported || value.x != 0.0f || value.y != 0.0f ||
                    value.z != 0.0f;
            }
            if (supported) result.regionSupportRows.push_back(row);
        }
        const std::size_t count = result.regionSupportRows.size() - range.first;
        if (count > std::numeric_limits<std::uint32_t>::max())
            return fail("sparse support region row count exceeds uint32 range");
        range.count = static_cast<std::uint32_t>(count);
        maximumRegionRows = std::max(maximumRegionRows, range.count);
    }
    const std::uint64_t tileCount =
        (static_cast<std::uint64_t>(maximumRegionRows) +
         NM_PARTITIONED_REDUCTION_TILE_WIDTH - 1u) /
        NM_PARTITIONED_REDUCTION_TILE_WIDTH;
    if (tileCount == 0u)
        return fail("sparse support has no nonzero regional basis rows");
    if (tileCount > std::numeric_limits<std::uint32_t>::max())
        return fail("sparse support tile count exceeds uint32 range");
    result.sparseTileCount = static_cast<std::uint32_t>(tileCount);

    for (std::uint32_t row = 0u; row < basisNodeCount; ++row) {
        if (result.nodeModeSlots.size() >
            std::numeric_limits<std::uint32_t>::max())
            return fail("sparse support node mode offsets exceed uint32 range");
        auto& range = result.nodeModeRanges[row];
        range.first = static_cast<std::uint32_t>(result.nodeModeSlots.size());
        for (std::uint32_t region = 0u; region < regionCount; ++region) {
            for (std::uint32_t localMode = 0u;
                 localMode < blockModeCount; ++localMode) {
                const std::uint32_t mode = blockModeIndices[
                    static_cast<std::size_t>(region) * blockModeCount + localMode];
                const auto& value = basisValues[
                    static_cast<std::size_t>(mode) * basisNodeCount + row];
                if (!std::isfinite(value.x) || !std::isfinite(value.y) ||
                    !std::isfinite(value.z))
                    return fail("sparse support basis contains a non-finite xyz coefficient");
                if (value.x == 0.0f && value.y == 0.0f && value.z == 0.0f)
                    continue;
                const std::uint64_t packed =
                    static_cast<std::uint64_t>(region) * blockModeCount + localMode;
                if (packed > std::numeric_limits<std::uint32_t>::max())
                    return fail("sparse support packed node mode exceeds uint32 range");
                result.nodeModeSlots.push_back(static_cast<std::uint32_t>(packed));
            }
        }
        const std::size_t count = result.nodeModeSlots.size() - range.first;
        if (count > std::numeric_limits<std::uint32_t>::max())
            return fail("sparse support node mode count exceeds uint32 range");
        range.count = static_cast<std::uint32_t>(count);
        result.maximumNodeModeCount =
            std::max(result.maximumNodeModeCount, range.count);
    }
    if (result.regionSupportRows.size() >
            std::numeric_limits<std::uint32_t>::max() ||
        result.nodeModeSlots.size() >
            std::numeric_limits<std::uint32_t>::max())
        return fail("sparse support flattened arrays exceed uint32 address range");
    return result;
}


[[nodiscard]] inline PartitionedReductionSparseSupport
buildPartitionedReductionSparseSupport(
    const PartitionedReductionBasis& basis,
    const std::span<const std::uint32_t> blockModeIndices,
    const std::uint32_t regionCount,
    const std::uint32_t blockModeCount
) {
    if (!basis.valid()) {
        PartitionedReductionSparseSupport result;
        result.error = "sparse support basis is invalid: " + basis.error;
        return result;
    }
    return buildPartitionedReductionSparseSupport(
        std::span<const nm_float4>(basis.values), basis.nodeCount,
        basis.modeCount, blockModeIndices, regionCount, blockModeCount);
}


// Compact coefficient storage for the exact regional support map. Each mode
// stores one value for each row in its owning region's support list; rows not
// in that list are exact zero. The mode offsets form a CSR start array.
struct PartitionedReductionSparseCoefficients {
    std::vector<std::uint32_t> modeValueOffsets;
    std::vector<nm_float4> values;
    std::vector<std::uint32_t> nodeModeValueIndices;
    // Coefficient indices in packed [region][localMode][support row] order.
    std::vector<std::uint32_t> regionModeSupportOffsets;
    std::vector<std::uint32_t> regionModeSupportValueIndices;
    std::uint64_t denseCoefficientCount = 0u;
    std::string error;
    [[nodiscard]] bool valid() const noexcept { return error.empty(); }
};

[[nodiscard]] inline PartitionedReductionSparseCoefficients
buildPartitionedReductionSparseCoefficients(
    const std::span<const nm_float4> denseBasis,
    const std::uint32_t basisNodeCount,
    const std::uint32_t modeCount,
    const std::span<const std::uint32_t> blockModeIndices,
    const std::uint32_t regionCount,
    const std::uint32_t blockModeCount,
    const PartitionedReductionSparseSupport& support
) {
    PartitionedReductionSparseCoefficients out;
    const auto fail = [&](const char* message) {
        out.error = message;
        out.modeValueOffsets.clear();
        out.values.clear();
        out.nodeModeValueIndices.clear();
        return out;
    };
    if (!support.valid() || basisNodeCount == 0u || modeCount == 0u ||
        regionCount == 0u || blockModeCount == 0u ||
        denseBasis.size() != static_cast<std::size_t>(basisNodeCount) * modeCount ||
        blockModeIndices.size() != static_cast<std::size_t>(regionCount) * blockModeCount ||
        support.regionSupportRanges.size() != regionCount ||
        support.nodeModeRanges.size() != basisNodeCount ||
        support.nodeModeSlots.size() > std::numeric_limits<std::uint32_t>::max())
        return fail("sparse coefficient inputs do not match exact dense basis support");

    out.denseCoefficientCount = static_cast<std::uint64_t>(basisNodeCount) * modeCount;
    out.modeValueOffsets.assign(static_cast<std::size_t>(modeCount) + 1u,
                                std::numeric_limits<std::uint32_t>::max());
    std::vector<std::uint32_t> modeRegion(modeCount, NM_INVALID_INDEX);
    std::vector<std::uint8_t> modeSeen(modeCount, 0u);
    std::uint64_t sparseCount = 0u;
    for (std::uint32_t region = 0u; region < regionCount; ++region) {
        const auto range = support.regionSupportRanges[region];
        if (static_cast<std::uint64_t>(range.first) + range.count >
            support.regionSupportRows.size())
            return fail("sparse region support range escapes its row list");
        for (std::uint32_t local = 0u; local < blockModeCount; ++local) {
            const std::uint32_t mode = blockModeIndices[
                static_cast<std::size_t>(region) * blockModeCount + local];
            if (mode >= modeCount || modeSeen[mode] != 0u)
                return fail("sparse coefficient mode map is out of range or duplicated");
            modeSeen[mode] = 1u;
            modeRegion[mode] = region;
            sparseCount += range.count;
            if (sparseCount > std::numeric_limits<std::uint32_t>::max())
                return fail("sparse coefficient storage exceeds uint32 addressing");
        }
    }
    if (std::find(modeSeen.begin(), modeSeen.end(), std::uint8_t{0u}) != modeSeen.end())
        return fail("sparse coefficient mode map does not cover every mode");
    out.values.reserve(static_cast<std::size_t>(sparseCount));
    for (std::uint32_t mode = 0u; mode < modeCount; ++mode) {
        const auto region = modeRegion[mode];
        const auto range = support.regionSupportRanges[region];
        out.modeValueOffsets[mode] = static_cast<std::uint32_t>(out.values.size());
        for (std::uint32_t index = 0u; index < range.count; ++index) {
            const auto row = support.regionSupportRows[range.first + index];
            if (row >= basisNodeCount)
                return fail("sparse coefficient support row is outside the basis row domain");
            const auto value = denseBasis[
                static_cast<std::size_t>(mode) * basisNodeCount + row];
            if (!std::isfinite(value.x) || !std::isfinite(value.y) ||
                !std::isfinite(value.z) || !std::isfinite(value.w))
                return fail("sparse coefficient source contains a non-finite value");
            out.values.push_back(value);
        }
    }
    out.modeValueOffsets[modeCount] = static_cast<std::uint32_t>(out.values.size());

    out.regionModeSupportOffsets.assign(
        static_cast<std::size_t>(regionCount) * blockModeCount + 1u, 0u);
    for (std::uint32_t region = 0u; region < regionCount; ++region) {
        const auto range = support.regionSupportRanges[region];
        for (std::uint32_t local = 0u; local < blockModeCount; ++local) {
            const std::uint32_t packed = region * blockModeCount + local;
            const std::uint32_t mode = blockModeIndices[packed];
            if (out.regionModeSupportValueIndices.size() >
                std::numeric_limits<std::uint32_t>::max())
                return fail("sparse region-mode coefficient index exceeds uint32 addressing");
            out.regionModeSupportOffsets[packed] =
                static_cast<std::uint32_t>(out.regionModeSupportValueIndices.size());
            for (std::uint32_t index = 0u; index < range.count; ++index) {
                const std::uint64_t valueIndex =
                    static_cast<std::uint64_t>(out.modeValueOffsets[mode]) + index;
                if (valueIndex >= out.values.size())
                    return fail("sparse region-mode coefficient index escapes value storage");
                out.regionModeSupportValueIndices.push_back(
                    static_cast<std::uint32_t>(valueIndex));
            }
        }
    }
    out.regionModeSupportOffsets.back() = static_cast<std::uint32_t>(
        out.regionModeSupportValueIndices.size());

    out.nodeModeValueIndices.reserve(support.nodeModeSlots.size());
    for (std::uint32_t row = 0u; row < basisNodeCount; ++row) {
        const auto nodeRange = support.nodeModeRanges[row];
        if (static_cast<std::uint64_t>(nodeRange.first) + nodeRange.count >
            support.nodeModeSlots.size())
            return fail("sparse node-mode range escapes its support list");
        for (std::uint32_t slot = 0u; slot < nodeRange.count; ++slot) {
            const auto packed = support.nodeModeSlots[nodeRange.first + slot];
            const auto region = packed / blockModeCount;
            const auto local = packed - region * blockModeCount;
            if (region >= regionCount || local >= blockModeCount)
                return fail("sparse node-mode slot is outside the regional map");
            const auto mode = blockModeIndices[
                static_cast<std::size_t>(region) * blockModeCount + local];
            const auto range = support.regionSupportRanges[region];
            const auto begin = support.regionSupportRows.begin() + range.first;
            const auto end = begin + range.count;
            const auto found = std::lower_bound(begin, end, row);
            if (found == end || *found != row)
                return fail("sparse node-mode row is missing from its region support");
            const std::uint32_t packed = region * blockModeCount + local;
            const std::uint64_t supportIndex =
                static_cast<std::uint64_t>(out.regionModeSupportOffsets[packed]) +
                static_cast<std::uint64_t>(found - begin);
            if (supportIndex >= out.regionModeSupportValueIndices.size())
                return fail("sparse node-mode support index escapes coefficient map");
            const std::uint32_t valueIndex =
                out.regionModeSupportValueIndices[supportIndex];
            if (valueIndex >= out.values.size())
                return fail("sparse node-mode value index escapes coefficient storage");
            const auto value = out.values[valueIndex];
            if (value.x == 0.0f && value.y == 0.0f && value.z == 0.0f)
                return fail("sparse node-mode map references a zero coefficient");
            out.nodeModeValueIndices.push_back(valueIndex);
        }
    }
    if (out.nodeModeValueIndices.size() != support.nodeModeSlots.size())
        return fail("sparse node-mode coefficient map has the wrong extent");
    return out;
}


struct PartitionedReductionCoefficientIndexMap {
    std::vector<std::uint32_t> nodeModeValueIndices;
    std::vector<std::uint32_t> regionModeSupportOffsets;
    std::vector<std::uint32_t> regionModeSupportValueIndices;
    std::string error;
    [[nodiscard]] bool valid() const noexcept { return error.empty(); }
};

[[nodiscard]] inline PartitionedReductionCoefficientIndexMap
buildPartitionedReductionDenseCoefficientIndexMap(
    const std::span<const nm_float4> denseBasis,
    const std::uint32_t basisNodeCount,
    const std::uint32_t modeCount,
    const std::span<const std::uint32_t> blockModeIndices,
    const std::uint32_t regionCount,
    const std::uint32_t blockModeCount,
    const PartitionedReductionSparseSupport& support
) {
    PartitionedReductionCoefficientIndexMap out;
    const auto fail = [&](const char* message) {
        out.error = message;
        out.nodeModeValueIndices.clear();
        out.regionModeSupportOffsets.clear();
        out.regionModeSupportValueIndices.clear();
        return out;
    };
    if (!support.valid() || basisNodeCount == 0u || modeCount == 0u ||
        regionCount == 0u || blockModeCount == 0u ||
        denseBasis.size() != static_cast<std::size_t>(basisNodeCount) * modeCount ||
        blockModeIndices.size() != static_cast<std::size_t>(regionCount) * blockModeCount ||
        support.regionSupportRanges.size() != regionCount ||
        support.nodeModeRanges.size() != basisNodeCount)
        return fail("dense support coefficient-map inputs have inconsistent dimensions");
    out.regionModeSupportOffsets.assign(
        static_cast<std::size_t>(regionCount) * blockModeCount + 1u, 0u);
    for (std::uint32_t region = 0u; region < regionCount; ++region) {
        const auto range = support.regionSupportRanges[region];
        if (static_cast<std::uint64_t>(range.first) + range.count >
            support.regionSupportRows.size())
            return fail("dense support coefficient-map region range escapes its rows");
        for (std::uint32_t local = 0u; local < blockModeCount; ++local) {
            const std::uint32_t packed = region * blockModeCount + local;
            const std::uint32_t mode = blockModeIndices[packed];
            if (mode >= modeCount)
                return fail("dense support coefficient-map mode is out of range");
            if (out.regionModeSupportValueIndices.size() >
                std::numeric_limits<std::uint32_t>::max())
                return fail("dense support coefficient-map exceeds uint32 addressing");
            out.regionModeSupportOffsets[packed] =
                static_cast<std::uint32_t>(out.regionModeSupportValueIndices.size());
            for (std::uint32_t i = 0u; i < range.count; ++i) {
                const std::uint32_t row = support.regionSupportRows[range.first + i];
                if (row >= basisNodeCount)
                    return fail("dense support coefficient-map row is out of range");
                const std::uint64_t index =
                    static_cast<std::uint64_t>(mode) * basisNodeCount + row;
                if (index >= denseBasis.size())
                    return fail("dense support coefficient-map index escapes basis");
                out.regionModeSupportValueIndices.push_back(
                    static_cast<std::uint32_t>(index));
            }
        }
    }
    out.regionModeSupportOffsets.back() = static_cast<std::uint32_t>(
        out.regionModeSupportValueIndices.size());
    out.nodeModeValueIndices.reserve(support.nodeModeSlots.size());
    for (std::uint32_t row = 0u; row < basisNodeCount; ++row) {
        const auto rowRange = support.nodeModeRanges[row];
        if (static_cast<std::uint64_t>(rowRange.first) + rowRange.count >
            support.nodeModeSlots.size())
            return fail("dense node-mode range escapes support slot list");
        for (std::uint32_t j = 0u; j < rowRange.count; ++j) {
            const std::uint32_t packed = support.nodeModeSlots[rowRange.first + j];
            const std::uint32_t region = packed / blockModeCount;
            const std::uint32_t local = packed - region * blockModeCount;
            if (region >= regionCount || local >= blockModeCount)
                return fail("dense node-mode slot is outside its block map");
            const auto regionRange = support.regionSupportRanges[region];
            const auto begin = support.regionSupportRows.begin() + regionRange.first;
            const auto end = begin + regionRange.count;
            const auto found = std::lower_bound(begin, end, row);
            if (found == end || *found != row)
                return fail("dense node-mode row is missing from regional support");
            const std::uint64_t mapIndex =
                static_cast<std::uint64_t>(out.regionModeSupportOffsets[packed]) +
                static_cast<std::uint64_t>(found - begin);
            if (mapIndex >= out.regionModeSupportValueIndices.size())
                return fail("dense node-mode map index escapes support index list");
            out.nodeModeValueIndices.push_back(
                out.regionModeSupportValueIndices[mapIndex]);
        }
    }
    return out;
}

} // namespace numi::matter

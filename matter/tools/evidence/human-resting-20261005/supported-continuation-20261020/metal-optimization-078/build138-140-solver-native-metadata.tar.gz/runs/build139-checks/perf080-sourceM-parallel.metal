#include <metal_stdlib>
using namespace metal;
#include "metalrobo/engine_types.h"
kernel void mr_articulated_source_mass_operation(
    device const MRArticulatedSourceMassOperationDispatchGPU& dispatch [[buffer(0)]],
    device const float* sourceMass [[buffer(1)]],
    device const float* input [[buffer(2)]],
    device float* output [[buffer(3)]],
    device atomic_uint* statuses [[buffer(4)]],
    device float* factorScratch [[buffer(5)]],
    device const MRArticulatedOperatorStatusGPU* assemblyStatuses [[buffer(6)]],
    device float* diagonalScaleScratch [[buffer(7)]],
    device atomic_uint* factorValidity [[buffer(8)]],
    uint3 group [[threadgroup_position_in_grid]],
    uint lane [[thread_index_in_threadgroup]],
    uint3 groupSize [[threads_per_threadgroup]]) {
    const uint width = groupSize.x;
    if (dispatch.abiVersion != 1u || dispatch.environmentCount == 0u ||
        dispatch.dofCount == 0u ||
        dispatch.matrixStride < dispatch.dofCount * dispatch.dofCount ||
        dispatch.vectorStride < dispatch.dofCount ||
        dispatch.statusStride == 0u ||
        (dispatch.flags & ~MR_ARTICULATED_SOURCE_MASS_REUSE_FACTOR) != 0u ||
        (dispatch.operation != MR_ARTICULATED_SOURCE_MASS_ACTION &&
         dispatch.operation != MR_ARTICULATED_SOURCE_MASS_SOLVE) ||
        (dispatch.operation == MR_ARTICULATED_SOURCE_MASS_ACTION &&
         dispatch.flags != 0u)) {
        if (group.x == 0u && group.y == 0u && lane == 0u &&
            dispatch.environmentCount != 0u && dispatch.statusStride != 0u) {
            atomic_store_explicit(statuses, uint(MR_ARTICULATED_SOURCE_MASS_INVALID),
                                  memory_order_relaxed);
        }
        return;
    }

    if (dispatch.operation == MR_ARTICULATED_SOURCE_MASS_ACTION) {
        const uint environment = group.y;
        const uint row = group.x * width + lane;
        if (environment >= dispatch.environmentCount ||
            row >= dispatch.dofCount) return;
        if (assemblyStatuses[environment].code !=
            MR_ARTICULATED_OPERATOR_SUCCESS) {
            atomic_store_explicit(
                statuses + environment * dispatch.statusStride,
                uint(MR_ARTICULATED_SOURCE_MASS_INVALID),
                memory_order_relaxed);
            return;
        }
        const uint matrixBase = environment * dispatch.matrixStride;
        const uint vectorBase = environment * dispatch.vectorStride;
        float value = 0.0f;
        for (uint column = 0u; column < dispatch.dofCount; ++column) {
            const float coefficient =
                sourceMass[matrixBase + row * dispatch.dofCount + column];
            const float component = input[vectorBase + column];
            if (!isfinite(coefficient) || !isfinite(component)) {
                output[vectorBase + row] = 0.0f;
                atomic_fetch_or_explicit(
                    statuses + environment * dispatch.statusStride,
                    uint(MR_ARTICULATED_SOURCE_MASS_NONFINITE),
                    memory_order_relaxed);
                return;
            }
            value += coefficient * component;
        }
        if (!isfinite(value)) {
            output[vectorBase + row] = 0.0f;
            atomic_fetch_or_explicit(
                statuses + environment * dispatch.statusStride,
                uint(MR_ARTICULATED_SOURCE_MASS_NONFINITE),
                memory_order_relaxed);
            return;
        }
        output[vectorBase + row] = value;
        return;
    }

    const uint environment = group.x;
    if (environment >= dispatch.environmentCount) return;
    device atomic_uint* status =
        statuses + environment * dispatch.statusStride;
    const bool reuseFactor =
        (dispatch.flags & MR_ARTICULATED_SOURCE_MASS_REUSE_FACTOR) != 0u;
    const uint n = dispatch.dofCount;
    const uint matrixBase = environment * dispatch.matrixStride;
    const uint vectorBase = environment * dispatch.vectorStride;
    const uint factorBase = environment * dispatch.matrixStride;
    const uint scaleBase = environment * n;
    if (lane == 0u) {
        const auto prepare = [&]() {
    if (assemblyStatuses[environment].code !=
        MR_ARTICULATED_OPERATOR_SUCCESS) {
        if (!reuseFactor) {
            atomic_store_explicit(factorValidity + environment, 0u,
                                  memory_order_relaxed);
        }
        atomic_store_explicit(status, uint(MR_ARTICULATED_SOURCE_MASS_INVALID),
                              memory_order_relaxed);
        return;
    }
    atomic_store_explicit(status, uint(MR_ARTICULATED_SOURCE_MASS_SUCCESS),
                          memory_order_relaxed);
    if (reuseFactor &&
        atomic_load_explicit(factorValidity + environment,
                             memory_order_relaxed) != 1u) {
        atomic_store_explicit(status,
            uint(MR_ARTICULATED_SOURCE_MASS_NOT_POSITIVE_DEFINITE),
            memory_order_relaxed);
        return;
    }
    if (!reuseFactor) {
        atomic_store_explicit(factorValidity + environment, 0u,
                              memory_order_relaxed);
    }
    for (uint row = 0u; row < n; ++row) {
        if (!isfinite(input[vectorBase + row])) {
            atomic_store_explicit(status, uint(MR_ARTICULATED_SOURCE_MASS_NONFINITE),
                                  memory_order_relaxed);
            return;
        }
    }
    if (!reuseFactor) {
        // Cholesky the diagonally equilibrated matrix S^-1 M S^-1,
        // where S_ii=sqrt(M_ii). This makes pivot screening dimensionless
        // across translational and rotational generalized coordinates; no
        // diagonal regularization is added to the physical mass matrix.
        for (uint row = 0u; row < n; ++row) {
            const float diagonal = sourceMass[matrixBase + row * n + row];
            if (!isfinite(diagonal)) {
                atomic_store_explicit(status,
                    uint(MR_ARTICULATED_SOURCE_MASS_NONFINITE),
                    memory_order_relaxed);
                return;
            }
            if (!(diagonal > 0.0f)) {
                atomic_store_explicit(status,
                    uint(MR_ARTICULATED_SOURCE_MASS_NOT_POSITIVE_DEFINITE),
                    memory_order_relaxed);
                return;
            }
            const float scale = sqrt(diagonal);
            if (!(scale > 0.0f) || !isfinite(scale)) {
                atomic_store_explicit(status,
                    uint(MR_ARTICULATED_SOURCE_MASS_NONFINITE),
                    memory_order_relaxed);
                return;
            }
            diagonalScaleScratch[scaleBase + row] = scale;
        }
        for (uint row = 0u; row < n; ++row) {
            const float rowScale = diagonalScaleScratch[scaleBase + row];
            for (uint column = 0u; column < n; ++column) {
                const float raw = sourceMass[matrixBase + row * n + column];
                const float columnScale = diagonalScaleScratch[scaleBase + column];
                const float reverseRaw = sourceMass[matrixBase + column * n + row];
                if (!isfinite(raw) || !isfinite(reverseRaw)) {
                    atomic_store_explicit(status,
                        uint(MR_ARTICULATED_SOURCE_MASS_NONFINITE),
                        memory_order_relaxed);
                    return;
                }
                const float value = (raw / rowScale) / columnScale;
                const float reverseValue =
                    (reverseRaw / columnScale) / rowScale;
                if (!isfinite(value) || !isfinite(reverseValue)) {
                    atomic_store_explicit(status,
                        uint(MR_ARTICULATED_SOURCE_MASS_NONFINITE),
                        memory_order_relaxed);
                    return;
                }
                const float symmetryScale = max(1.0f,
                    max(abs(value), abs(reverseValue)));
                if (abs(value - reverseValue) >
                    32.0f * 1.1920928955078125e-7f * symmetryScale) {
                    atomic_store_explicit(status,
                        uint(MR_ARTICULATED_SOURCE_MASS_INVALID),
                        memory_order_relaxed);
                    return;
                }
                factorScratch[factorBase + row * n + column] = value;
            }
        }
    }
        };
        prepare();
    }
    threadgroup_barrier(mem_flags::mem_device);
    if (atomic_load_explicit(status, memory_order_relaxed) !=
        uint(MR_ARTICULATED_SOURCE_MASS_SUCCESS)) return;
    if (!reuseFactor) {
        const float pivotFloor =
            4.0f * sqrt(float(n)) * 1.1920928955078125e-7f;
        // Left-looking columns: each lower entry retains the serial kernel's
        // ascending inner-product order, while independent rows share a group.
        for (uint column = 0u; column < n; ++column) {
            if (lane == 0u) {
                float diagonal = factorScratch[factorBase + column * n + column];
                for (uint inner = 0u; inner < column; ++inner) {
                    const float value = factorScratch[factorBase + column * n + inner];
                    diagonal -= value * value;
                }
                if (!(diagonal > pivotFloor) || !isfinite(diagonal)) {
                    atomic_store_explicit(status,
                        uint(MR_ARTICULATED_SOURCE_MASS_NOT_POSITIVE_DEFINITE),
                        memory_order_relaxed);
                } else {
                    factorScratch[factorBase + column * n + column] = sqrt(diagonal);
                }
            }
            threadgroup_barrier(mem_flags::mem_device);
            if (atomic_load_explicit(status, memory_order_relaxed) !=
                uint(MR_ARTICULATED_SOURCE_MASS_SUCCESS)) return;
            const float pivot = factorScratch[factorBase + column * n + column];
            for (uint row = column + 1u + lane; row < n; row += width) {
                float value = factorScratch[factorBase + row * n + column];
                for (uint inner = 0u; inner < column; ++inner) {
                    value -= factorScratch[factorBase + row * n + inner] *
                             factorScratch[factorBase + column * n + inner];
                }
                factorScratch[factorBase + row * n + column] = value / pivot;
            }
            threadgroup_barrier(mem_flags::mem_device);
        }
        if (lane == 0u)
            atomic_store_explicit(factorValidity + environment, 1u,
                                  memory_order_relaxed);
    }
    if (lane != 0u) return;
    // Forward solve L y=b; output can alias input because rows are visited
    // monotonically and no future input row is overwritten.
    for (uint row = 0u; row < n; ++row) {
        float value = input[vectorBase + row] /
            diagonalScaleScratch[scaleBase + row];
        for (uint column = 0u; column < row; ++column) {
            value -= factorScratch[factorBase + row * n + column] *
                     output[vectorBase + column];
        }
        output[vectorBase + row] =
            value / factorScratch[factorBase + row * n + row];
    }
    // Back solve L^T x=y.
    for (uint reverse = 0u; reverse < n; ++reverse) {
        const uint row = n - 1u - reverse;
        float value = output[vectorBase + row];
        for (uint column = row + 1u; column < n; ++column) {
            value -= factorScratch[factorBase + column * n + row] *
                     output[vectorBase + column];
        }
        output[vectorBase + row] =
            value / factorScratch[factorBase + row * n + row];
        if (!isfinite(output[vectorBase + row])) {
            atomic_store_explicit(status, uint(MR_ARTICULATED_SOURCE_MASS_NONFINITE),
                                  memory_order_relaxed);
            return;
        }
    }
    // x=S^-1 y. Delay scaling until the triangular solve completes because
    // back substitution still needs the unscaled normalized-coordinate y.
    for (uint row = 0u; row < n; ++row) {
        output[vectorBase + row] /= diagonalScaleScratch[scaleBase + row];
        if (!isfinite(output[vectorBase + row])) {
            atomic_store_explicit(status, uint(MR_ARTICULATED_SOURCE_MASS_NONFINITE),
                                  memory_order_relaxed);
            return;
        }
    }
}

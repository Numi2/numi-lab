#import <Foundation/Foundation.h>
#import <Metal/Metal.h>
#include "metalrobo/engine_types.h"
#include <vector>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <algorithm>
int main(int argc,char**argv){ @autoreleasepool {
 if(argc!=2)return 2;
 id<MTLDevice>d=MTLCreateSystemDefaultDevice(); NSError*e=nil;
 id<MTLLibrary>l=[d newLibraryWithURL:[NSURL fileURLWithPath:@(argv[1])] error:&e];
 id<MTLFunction>f=[l newFunctionWithName:@"mr_articulated_source_mass_operation"];
 id<MTLComputePipelineState>p=[d newComputePipelineStateWithFunction:f error:&e];
 if(!p){fprintf(stderr,"%s\n",e.localizedDescription.UTF8String);return 2;}
 id<MTLCommandQueue>q=[d newCommandQueue];
 for(unsigned n:{32u,128u,256u}){
  std::vector<double>L(n*n,0),scale(n),x(n); std::vector<float>A(n*n),b(n);
  for(unsigned i=0;i<n;i++){scale[i]=std::pow(10.,-4.+8.*i/(n-1));x[i]=std::sin(i+1.)/scale[i];for(unsigned j=0;j<=i;j++)L[i*n+j]=i==j?1.:.02*std::sin(double(i*13+j*7));}
  for(unsigned i=0;i<n;i++)for(unsigned j=0;j<n;j++){double v=0;for(unsigned k=0;k<=std::min(i,j);k++)v+=L[i*n+k]*L[j*n+k];A[i*n+j]=float(v*scale[i]*scale[j]);}
  for(unsigned i=0;i<n;i++){double v=0;for(unsigned j=0;j<n;j++)v+=double(A[i*n+j])*x[j];b[i]=float(v);}
  MRArticulatedSourceMassOperationDispatchGPU dispatch{1,n,n*n,n,1,MR_ARTICULATED_SOURCE_MASS_SOLVE,1,0};
  MRArticulatedOperatorStatusGPU assembly{};
  id<MTLBuffer>buf[9];
  buf[0]=[d newBufferWithBytes:&dispatch length:sizeof(dispatch) options:MTLResourceStorageModeShared];
  buf[1]=[d newBufferWithBytes:A.data() length:n*n*4 options:MTLResourceStorageModeShared];
  buf[2]=[d newBufferWithBytes:b.data() length:n*4 options:MTLResourceStorageModeShared];
  buf[3]=[d newBufferWithLength:n*4 options:MTLResourceStorageModeShared];
  buf[4]=[d newBufferWithLength:4 options:MTLResourceStorageModeShared];
  buf[5]=[d newBufferWithLength:n*n*4 options:MTLResourceStorageModeShared];
  buf[6]=[d newBufferWithBytes:&assembly length:sizeof(assembly) options:MTLResourceStorageModeShared];
  buf[7]=[d newBufferWithLength:n*4 options:MTLResourceStorageModeShared];
  buf[8]=[d newBufferWithLength:4 options:MTLResourceStorageModeShared];
  for(unsigned repeat=0;repeat<2;repeat++){
   dispatch.flags=repeat?MR_ARTICULATED_SOURCE_MASS_REUSE_FACTOR:0;std::memcpy(buf[0].contents,&dispatch,sizeof(dispatch));
   id<MTLCommandBuffer>cb=[q commandBuffer];id<MTLComputeCommandEncoder>enc=[cb computeCommandEncoder];
   [enc setComputePipelineState:p];for(unsigned j=0;j<9;j++)[enc setBuffer:buf[j] offset:0 atIndex:j];
   [enc dispatchThreadgroups:MTLSizeMake(1,1,1) threadsPerThreadgroup:MTLSizeMake(std::min<NSUInteger>(128,p.maxTotalThreadsPerThreadgroup),1,1)];
   [enc endEncoding];[cb commit];[cb waitUntilCompleted];
   if(cb.status!=MTLCommandBufferStatusCompleted||*(unsigned*)buf[4].contents!=0){fprintf(stderr,"reject n=%u status=%u\n",n,*(unsigned*)buf[4].contents);return 1;}
   auto*y=(float*)buf[3].contents;double residual=0,denom=0,error=0;
   for(unsigned i=0;i<n;i++){double ay=0;for(unsigned j=0;j<n;j++)ay+=double(A[i*n+j])*y[j];residual=std::max(residual,std::abs((ay-b[i])/scale[i]));denom=std::max(denom,std::abs(double(b[i])/scale[i]));error=std::max(error,std::abs((double(y[i])-x[i])*scale[i]));}
   printf("sourceM n=%u reused=%u relative_scaled_residual=%.9g scaled_forward_error=%.9g gpu_seconds=%.9g\n",n,repeat,residual/denom,error,cb.GPUEndTime-cb.GPUStartTime);
   if(residual/denom>2e-5||error>2e-4)return 1;
  }
 }
 return 0;
}}


import json,hashlib,os,subprocess,time
from pathlib import Path
r=Path('/Users/numi/numi-human-aortic-contact-opt-20261019/matter/tools/evidence/human-resting-20261005/supported-continuation-20261020/metal-optimization-078')
old=r/'verified-output-clones-20261020-182015.json';d=json.loads(old.read_text());known={};seen=set()
for e in d['entries']:
 for k in ['path','clone_source']:
  p=r/e[k];seen.add(p)
  if p.exists():known[(p.name,e['bytes'],e['sha256'])]=p
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
before=subprocess.check_output(['df','-k',str(r)],text=True);entries=[];verified={}
for run in sorted(r.iterdir()):
 if not run.is_dir() or not (run/'process.json').exists():continue
 for p in sorted((run/'output').rglob('*')):
  if p in seen or not p.is_file() or p.is_symlink() or p.stat().st_size<1024*1024:continue
  size=p.stat().st_size;h=digest(p);key=(p.name,size,h)
  if key not in known:known[key]=p;continue
  src=known[key]
  if src==p:continue
  if src not in verified:verified[src]=digest(src)
  assert verified[src]==h
  temp=p.with_name(p.name+'.verified-clone-tmp');assert not temp.exists()
  try:
   subprocess.run(['/bin/cp','-c',str(src),str(temp)],check=True)
   assert temp.stat().st_size==size and digest(temp)==h
   os.replace(temp,p);entries.append(dict(path=str(p.relative_to(r)),clone_source=str(src.relative_to(r)),sha256=h,bytes=size))
  finally:temp.unlink(missing_ok=True)
after=subprocess.check_output(['df','-k',str(r)],text=True)
out=r/('verified-output-clones-incremental-'+time.strftime('%Y%m%d-%H%M%S')+'.json')
receipt=dict(method=d['method'],parent_manifest=old.name,parent_sha256=digest(old),before_df=before,after_df=after,entries=entries)
out.write_text(json.dumps(receipt,indent=2));print(json.dumps(dict(manifest=out.name,files=len(entries),logical_bytes=sum(e['bytes'] for e in entries),before=before,after=after),indent=2))

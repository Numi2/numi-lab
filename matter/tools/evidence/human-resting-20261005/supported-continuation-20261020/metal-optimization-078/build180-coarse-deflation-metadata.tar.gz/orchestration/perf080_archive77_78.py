import pathlib,json,hashlib,tarfile
r=pathlib.Path('/Users/numi/numi-human-aortic-contact-opt-20261019')
e=r/'matter/tools/evidence/human-resting-20261005/supported-continuation-20261020/metal-optimization-078'
members={}
def add(p,n):
 if p.is_file():members[n]=p
for run in e.iterdir():
 if run.is_dir() and ('build78' in run.name or ('build76' in run.name and 'hybrid' in run.name and 'cap1' in run.name)):
  for name in ('stdout.log','stderr.log','invocation.json','process.json','summary.json','common-field-failure.json'):add(run/name,run.name+'/'+name)
  for p in (run/'output').glob('*.csv'):
   if p.stat().st_size<1048576:add(p,run.name+'/output/'+p.name)
for p in pathlib.Path('/tmp').glob('perf080-build7[78]*.log'):add(p,'retained-tmp/'+p.name)
add(pathlib.Path('/tmp/perf080-build76-hybrid-cap1.log'),'retained-tmp/perf080-build76-hybrid-cap1.log')
for p in pathlib.Path('/tmp').glob('perf080_build78*.py'):add(p,'retained-tmp/'+p.name)
for p in (r/'build-integrated-validation-20261019/perf078-build78-frozen').iterdir():
 if p.name in ('source.patch','source-changes.tar.gz','manifest.json'):add(p,'frozen78/'+p.name)
for pat in ('native-build78-source-*.json','build78-total-load-parity.json'):
 for p in e.glob(pat):add(p,p.name)
add(pathlib.Path('/tmp/perf080-anchor-load-private-20261021/anchor-full-fem-load.patch'),'private-patches/anchor-full-fem-load.patch')
add(r/'matter/tools/fgmres_true_residual_native_check.mm','checker77/fgmres_true_residual_native_check.mm')
def digest(p):return hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
artifacts={str(p.relative_to(r)):digest(p) for p in (
 r/'build-integrated-validation-20261019/profile-build-039/matter/numi-matter-fgmres-true-residual-native-check',
 r/'build-integrated-validation-20261019/profile-build-039/numi-human-accepted-fem-load-capture-check')}
manifest={n:dict(bytes=p.stat().st_size,sha256=digest(p)) for n,p in members.items()}
out=e/'build77-78-and-hybrid76-native-metadata.tar.gz'
with tarfile.open(out,'w:gz') as t:
 for n,p in members.items():t.add(p,arcname=n,recursive=False)
with tarfile.open(out) as t:
 assert set(t.getnames())==set(members)
 for m in t.getmembers():assert hashlib.sha256(t.extractfile(m).read()).hexdigest()==manifest[m.name]['sha256']
receipt=dict(archive=out.name,sha256=digest(out),bytes=out.stat().st_size,members=manifest,native_artifact_sha256=artifacts,all_members_independently_reopened_and_verified=True)
(e/'build77-78-and-hybrid76-native-metadata-receipt.json').write_text(json.dumps(receipt,indent=2))
print(json.dumps({k:v for k,v in receipt.items() if k not in ('members','native_artifact_sha256')}))


import os,json,pathlib,subprocess
r=pathlib.Path('/Users/numi/numi-human-aortic-contact-opt-20261019')
e=r/'matter/tools/evidence/human-resting-20261005/supported-continuation-20261020/metal-optimization-078'
d=json.load(open(next(e.glob('*build124*fullcert-patch0-stages-1/invocation.json'))))
common=os.environ.copy()
common.update({k:v for k,v in d['simulation_environment'].items() if k.startswith('NUMI_EXPERIMENT') or k in ('NUMI_HUMAN_SUPPORTED_INITIALIZATION','NUMI_HUMAN_STATIC_WEIGHTED_SKIN_SUPPORT')})
common.update(NM_FEM_TRUE_RESIDUAL_CERTIFY='1',NM_FEM_PRIVATE_CONTACT_FAILURE_CAPTURE='1',NM_VASCULAR_PERSISTENT_LOW_WORDS='0')
base='global-icb-native-stateless-allnative-hier-tailicb-domain-tight3-work-compact-parallelbt-plainpso-build143-block-coarse-femtangent-principal-cavity3-graph-coupled-strictinit-strictrows-prefixbase-stages'
base+='-ewtight2'
for suffix,extra in [('strict-control-1',{'NM_FEM_GRAPH_SOLVE_COMPACT_SCRATCH':'1','NM_FEM_STRICT_INNER_FORCING':'1','NM_FEM_NEWTON_TRACE_ROOT':'0'}),('strict-cache-1',{'NM_FEM_GRAPH_SOLVE_COMPACT_SCRATCH':'1','NM_FEM_STRICT_INNER_FORCING':'1','NM_FEM_SELECTOR6_GRAPH_TET_BLOCK_REUSE':'1','NM_FEM_NEWTON_TRACE_ROOT':'0'})]:
 env=common.copy();env.update(extra)
 result=subprocess.run(['python3','/tmp/perf080_build143_graphmeasure_run.py',base+'-'+suffix,'1'],env=env)
 print(suffix,result.returncode,flush=True)

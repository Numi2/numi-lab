from pathlib import Path
import subprocess,tarfile,json,hashlib,tempfile,os,time,shutil
r=Path('/Users/numi/numi-human-aortic-contact-opt-20261019')
e=r/'matter/tools/evidence/human-resting-20261005/supported-continuation-20261020/metal-optimization-078'
tag='human-metal-replay-history-20261021'
def gh(*a):return subprocess.run(['gh',*a],cwd=r,check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
def digest(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
try:gh('release','view',tag)
except subprocess.CalledProcessError:
 gh('release','create',tag,'--target','main','--title','Retained Human Metal replay history','--notes','Exact historical native replay outputs, source-linked by per-file manifests. Archived for storage recovery; failed and provisional trials remain evidence, not qualification.')
paths=[Path(p) for p in Path('/tmp/perf080-old-recordings-candidates.txt').read_text().splitlines() if p]
paths=[p for p in paths if 'baseline' not in str(p) and p.exists()]
for shard in range(1,17):
 if shutil.disk_usage(r).free>=14*1024**3:break
 selected=paths[(shard-1)*5:shard*5]
 if not selected:break
 name=f'old-native-replays-{shard:02d}-20261021.tar.gz'
 archive=e/name
 if archive.exists():raise RuntimeError('do not overwrite archive '+name)
 entries=[dict(path=str(p.relative_to(r)),bytes=p.stat().st_size,sha256=digest(p)) for p in selected]
 for p in selected:
  check=subprocess.run(['/usr/sbin/lsof','-t',str(p)],stdout=subprocess.PIPE,stderr=subprocess.DEVNULL)
  if check.stdout.strip():raise RuntimeError('active replay reader '+str(p))
 manifest=dict(schema=1,release=tag,entries=entries,policy='Preserve all source/config/trace metadata and current/baseline replays; retire only independently restored historical .mrvpack outputs.')
 manifestpath=e/name.replace('.tar.gz','-manifest.json')
 manifestpath.write_text(json.dumps(manifest,indent=2)+'\n')
 before=subprocess.check_output(['df','-k',str(r)],text=True)
 with archive.open('wb') as raw:
  import gzip
  with gzip.GzipFile(fileobj=raw,mode='wb',compresslevel=1) as compressed:
   with tarfile.open(fileobj=compressed,mode='w|') as t:
    t.add(manifestpath,arcname='manifest.json',recursive=False)
    for entry,p in zip(entries,selected):t.add(p,arcname=entry['path'],recursive=False)
 h=digest(archive)
 gh('release','upload',tag,str(archive),str(manifestpath))
 with tempfile.TemporaryDirectory(prefix='perf080-replay-restore-') as tmpdir:
  tmp=Path(tmpdir)
  gh('release','download',tag,'--pattern',name,'--dir',str(tmp))
  downloaded=tmp/name
  assert digest(downloaded)==h
  with tarfile.open(downloaded) as t:
   restored_manifest=json.load(t.extractfile('manifest.json'))
   assert restored_manifest==manifest
   for entry in entries:
    member=t.getmember(entry['path'])
    assert member.isfile() and member.size==entry['bytes']
    f=t.extractfile(member);assert hashlib.file_digest(f,'sha256').hexdigest()==entry['sha256']
   first=entries[0];restored=tmp/'restored-recording.mrvpack'
   with t.extractfile(first['path']) as src,restored.open('wb') as dst:shutil.copyfileobj(src,dst,1024*1024)
   assert restored.stat().st_size==first['bytes'] and digest(restored)==first['sha256']
  # Recheck exact local identity immediately before retiring only these files.
  for entry,p in zip(entries,selected):
   assert p.is_file() and not p.is_symlink() and digest(p)==entry['sha256']
   check=subprocess.run(['/usr/sbin/lsof','-t',str(p)],stdout=subprocess.PIPE,stderr=subprocess.DEVNULL)
   assert not check.stdout.strip()
  for p in selected:p.unlink()
 after=subprocess.check_output(['df','-k',str(r)],text=True)
 receipt=dict(schema=1,archive=name,archive_sha256=h,release=tag,entries=entries,download_verified=True,all_members_hash_verified=True,first_member_extracted_and_hash_verified=True,before_df=before,after_df=after)
 (e/name.replace('.tar.gz','-retirement-receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n')
 # Exact archive remains remotely verified; remove only our local archive copy.
 assert digest(archive)==h
 archive.unlink()
 print(json.dumps(dict(shard=shard,retired_files=len(entries),logical_bytes=sum(v['bytes'] for v in entries),free_bytes=shutil.disk_usage(r).free,archive_sha256=h)),flush=True)

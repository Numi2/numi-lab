import pathlib,json,hashlib,tarfile
r=pathlib.Path('/Users/numi/numi-human-aortic-contact-opt-20261019')
e=r/'matter/tools/evidence/human-resting-20261005/supported-continuation-20261020/metal-optimization-078'
out=e/'build68-72-native-metadata.tar.gz'; members={}
def add(p,n):
 if p.is_file():members[n]=p
for run in sorted(e.iterdir()):
 if run.is_dir() and any(('build'+str(n)) in run.name for n in (68,69,70,71,72)):
  for name in ('stdout.log','stderr.log','invocation.json','process.json','summary.json','common-field-failure.json'):
   add(run/name,run.name+'/'+name)
for n in (68,69,70,71,72):
 for suffix in ('source-manifest.json','source-provenance.json'):add(e/f'native-build{n}-{suffix}',f'native-build{n}-{suffix}')
 f=r/f'build-integrated-validation-20261019/perf078-build{n}-frozen'
 for name in ('source.patch','source-changes.tar.gz','manifest.json'):add(f/name,f'build{n}-frozen/'+name)
for pat in ('build69-*residual*','build67-schur-strict-comparison.json','verified-*clones*.json'):
 for p in e.glob(pat):add(p,p.name)
for pat in ('perf080-build6[89]*.log','perf080-build7[012]*.log','perf080_build6[89]*.py','perf080_build7[012]*.py'):
 for p in pathlib.Path('/tmp').glob(pat):add(p,'retained-tmp/'+p.name)
def digest(p):return hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
manifest={n:dict(bytes=p.stat().st_size,sha256=digest(p)) for n,p in members.items()}
with tarfile.open(out,'w:gz') as t:
 for n,p in members.items():t.add(p,arcname=n,recursive=False)
with tarfile.open(out) as t:
 assert set(t.getnames())==set(members)
 for m in t.getmembers():assert hashlib.sha256(t.extractfile(m).read()).hexdigest()==manifest[m.name]['sha256']
receipt=dict(archive=out.name,sha256=digest(out),bytes=out.stat().st_size,members=manifest,all_members_independently_reopened_and_verified=True)
(e/'build68-72-native-metadata-receipt.json').write_text(json.dumps(receipt,indent=2))
print(json.dumps({k:v for k,v in receipt.items() if k!='members'}))


from pathlib import Path
import json,os,subprocess,time,sys
r=Path('/Users/numi/numi-human-aortic-contact-opt-20261019');e=r/'matter/tools/evidence/human-resting-20261005/supported-continuation-20261020/metal-optimization-078';f=r/'build-integrated-validation-20261019/perf078-build173-frozen'
base=json.loads((e/'build165-indirect-mass-candidate-pair1/invocation.json').read_text())
cases=[]
if sys.argv[1]=='typed-owner':
 for mode in (0,1):
  cases.append((f'implicit20-typed-owner-{mode}',dict(NUMI_HUMAN_IMPLICIT_BODY_SPRINGS='20',NUMI_HUMAN_EXACT_CANDIDATE_KINEMATICS='1',NM_FGMRES_COUPLED_BORROWED_ENCODER=str(mode))))
elif sys.argv[1]=='targeted':
 base=json.loads((e/'build167-embedded-contact-boundary-3/invocation.json').read_text())
 cases=[('hybrid-targeted-shell',dict(NM_FGMRES_OPERATOR_ICB='1',NM_FGMRES_PREFIX_PRECONDITIONER_ICB='0',NM_FEM_HUMAN_PARTITIONED_OPTIC_BINS='10',NM_FEM_HUMAN_PARTITIONED_SPLIT_SKIN_TETS='24530,22879,19970',NM_FGMRES_COUPLED_BORROWED_ENCODER='0'))]
elif sys.argv[1]=='coarse':
 cases=[('coarse-control',{}),('coarse-vascular',dict(NM_FEM_SELECTOR6_GLOBAL_COARSE='1',NM_FEM_SELECTOR6_GLOBAL_COARSE_COUPLED_TAILS='1',NM_FGMRES_PREFIX_PRECONDITIONER_ICB='0'))]
elif sys.argv[1]=='stages':
 cases=[('stages-root0',dict(NUMI_MATTER_GPU_TIMING='1',NUMI_MATTER_GPU_TIMING_STAGES='1',NUMI_MATTER_GPU_TIMING_ROOT='0')),('stages-control',{})]
elif sys.argv[1]=='backsub':
 cases=[('backsub-control',dict(NM_FEM_GRAPH_PARALLEL_BACKSUBSTITUTION='0')),('backsub-parallel',dict(NM_FEM_GRAPH_PARALLEL_BACKSUBSTITUTION='1'))]
elif sys.argv[1]=='owner':
 for mode in (0,1):
  cases.append((f'implicit20-borrowed-{mode}',dict(NUMI_HUMAN_IMPLICIT_BODY_SPRINGS='20',NUMI_HUMAN_EXACT_CANDIDATE_KINEMATICS='1',NM_FGMRES_COUPLED_BORROWED_ENCODER=str(mode))))
elif sys.argv[1]=='refined':
 base=json.loads((e/'build167-embedded-contact-boundary-3/invocation.json').read_text())
 cases=[('hybrid-refined-anatomy',dict(NM_FGMRES_OPERATOR_ICB='1',NM_FGMRES_PREFIX_PRECONDITIONER_ICB='0',NM_FEM_HUMAN_PARTITIONED_OPTIC_BINS='10',NM_FEM_HUMAN_PARTITIONED_SPLIT_SKIN_TET='24451',NM_FGMRES_COUPLED_BORROWED_ENCODER='0'))]
elif sys.argv[1]=='patch':
 cases=[('patch32-control',dict(NM_FEM_HUMAN6_GRAPH_PATCH_NODES='32',NM_FGMRES_COUPLED_BORROWED_ENCODER='0')),('patch16-simd32',dict(NM_FEM_HUMAN6_GRAPH_PATCH_NODES='16',NM_FGMRES_COUPLED_BORROWED_ENCODER='0'))]
elif sys.argv[1]=='borrow':
 for pair in range(1,4):
  for mode in (0,1):
   cases.append((f'borrowed-{mode}-pair{pair}',dict(NM_FGMRES_COUPLED_BORROWED_ENCODER=str(mode))))
elif sys.argv[1]=='telemetry':
 cases=[('cpu-timing',dict(NUMI_MATTER_CPU_TIMING='1',NM_FGMRES_COUPLED_BORROWED_ENCODER='1')),('jacobi-8-counters',dict(NM_FEM_GRAPH_SOLVE_JACOBI_SWEEPS='8',NM_FGMRES_COUPLED_BORROWED_ENCODER='1'))]
elif sys.argv[1]=='operator':
 cases=[('assembled-simd',dict(NM_FEM_ASSEMBLED_XYZ_OPERATOR='1',NM_FEM_ASSEMBLED_XYZ_SIMD_ROW='1',NM_FGMRES_COUPLED_BORROWED_ENCODER='0')),('morton-cache',dict(NM_CONTACT_SURFACE_MORTON_ORDER_CACHE='1',NM_FGMRES_COUPLED_BORROWED_ENCODER='0'))]
elif sys.argv[1]=='warm':
 base['argv'][base['argv'].index('--muscle-step-count')+1]='3'
 cases=[('three-root-initial-throughput',dict(NM_FGMRES_COUPLED_BORROWED_ENCODER='0'))]
elif sys.argv[1]=='refine':
 base=json.loads((e/'build167-embedded-contact-boundary-3/invocation.json').read_text())
 cases=[('hybrid-refined-optic20',dict(NM_FGMRES_OPERATOR_ICB='1',NM_FGMRES_PREFIX_PRECONDITIONER_ICB='0',NM_FEM_HYBRID_RESIDUAL_REFINEMENT_TRACE=str(e/'coordinate-fidelity-build167-witness/build167-latest-active-final-cycle.jsonl'),NM_FGMRES_COUPLED_BORROWED_ENCODER='0'))]
elif sys.argv[1]=='hybrid':
 base=json.loads((e/'build167-embedded-contact-boundary-3/invocation.json').read_text())
 cases=[('hybrid-operator-icb',dict(NM_FGMRES_OPERATOR_ICB='1',NM_FGMRES_PREFIX_PRECONDITIONER_ICB='0',NM_FGMRES_COUPLED_BORROWED_ENCODER='0'))]
else:raise SystemExit('unknown trial cohort')
for name,overrides in cases:
 out=e/('build173-'+name);out.mkdir();cfg=json.loads(json.dumps(base));argv=cfg['argv'];argv[0]=str(f/'numi-human-native');argv[4]=str(out/'output')
 env=cfg['simulation_environment'];env.update(DYLD_LIBRARY_PATH=str(f),NUMI_MATTER_METALLIB_OVERRIDE=str(f/'NumiMatter.metallib'),NM_FEM_GRAPH_SOLVE_JACOBI_SWEEPS='0',NM_FGMRES_COUPLED_BORROWED_ENCODER='0');env.update(overrides)
 env['NUMI_HUMAN_RESTING_COMMON_FAILURE_RECEIPT']=str(out/'common-field-failure.json')
 cfg['binary']=argv[0];cfg['source_manifest']=str(e/'native-build173-source-manifest.json');(out/'invocation.json').write_text(json.dumps(cfg,indent=2));start=time.monotonic()
 with (out/'stdout.log').open('w') as so,(out/'stderr.log').open('w') as se:code=subprocess.run(argv,cwd=r,env={**os.environ,**env},stdout=so,stderr=se).returncode
 rec=dict(name=name,exit_code=code,wall_seconds=time.monotonic()-start);(out/'process.json').write_text(json.dumps(rec,indent=2));print(rec,flush=True)
 if code:break

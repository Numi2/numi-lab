import os,json,pathlib,subprocess
r=pathlib.Path('/Users/numi/numi-human-aortic-contact-opt-20261019')
e=r/'matter/tools/evidence/human-resting-20261005/supported-continuation-20261020/metal-optimization-078'
d=json.load(open(next(e.glob('*build124*fullcert-patch0-stages-1/invocation.json'))))
common=os.environ.copy()
common.update({k:v for k,v in d['simulation_environment'].items() if k.startswith('NUMI_EXPERIMENT') or k in ('NUMI_HUMAN_SUPPORTED_INITIALIZATION','NUMI_HUMAN_STATIC_WEIGHTED_SKIN_SUPPORT')})
common.update(NM_FEM_TRUE_RESIDUAL_CERTIFY='1',NM_FEM_PRIVATE_CONTACT_FAILURE_CAPTURE='1',NM_VASCULAR_PERSISTENT_LOW_WORDS='0')

base="global-native-stateless-allnative-hier-tailicb-domain-tight3-work-compact-parallelbt-plainpso-build152-block-coarse-femtangent-principal-cavity3-graph-coupled-strictinit-strictrows-stages-capture"
for label in ("hybrid",):
 env=common.copy()
 env.update(NM_FEM_GRAPH_SOLVE_COMPACT_SCRATCH="1",NM_FEM_SELECTOR6_GRAPH_TET_BLOCK_REUSE="1",NM_FEM_SELECTOR6_GRAPH_DUE_ROW_IDENTITY="1")
 env.pop("NM_FEM_TRUE_RESIDUAL_CERTIFY",None)
 env.update(NM_FEM_HYBRID_RESIDUAL_WITNESS="1",NM_FEM_TRUE_RESIDUAL_ROOT="0")
 result=subprocess.run(["python3","/tmp/perf080_build152_endpoint_staged_run.py",base+"-"+label+"-pair3-mandatorycert","1"],env=env)
 print(label,result.returncode,flush=True)
 if result.returncode:raise SystemExit(result.returncode)

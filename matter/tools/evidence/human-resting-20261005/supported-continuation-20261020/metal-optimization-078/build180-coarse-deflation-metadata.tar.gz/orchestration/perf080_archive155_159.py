from pathlib import Path
import tarfile,hashlib,json,re
r=Path("/Users/numi/numi-human-aortic-contact-opt-20261019")
e=r/"matter/tools/evidence/human-resting-20261005/supported-continuation-20261020/metal-optimization-078"
entries={}
for i in range(155,160):
 for p in Path("/tmp").glob("perf080-build"+str(i)+"*.log"):
  entries["logs/"+p.name]=p
 for p in e.glob("native-build"+str(i)+"-*.json"):entries["metadata/"+p.name]=p
 frozen=r/"build-integrated-validation-20261019"/("perf078-build"+str(i)+"-frozen")
 if frozen.exists():
  for name in ("source.patch","source-changes.tar.gz","source-manifest.json","manifest.json"):
   p=frozen/name
   if p.exists():entries["build"+str(i)+"/"+name]=p
for d in e.iterdir():
 if d.is_dir() and re.search(r"build(?:155|156|157|158|159)(?:-|$)",d.name):
  for p in d.rglob("*"):
   if p.is_file() and p.suffix in (".json",".log",".csv",".mm",".metal",".py"):entries["runs/"+d.name+"/"+str(p.relative_to(d))]=p
for i in range(155,160):
 for p in e.glob("build"+str(i)+"*.json"):
  entries["metadata/"+p.name]=p

for p in Path("/tmp").glob("perf080_armath*"):
 if p.suffix in (".mm",".log"):entries["arithmetic/"+p.name]=p
for p in e.glob("build144-ewtight4*.json"):entries["prior-failed-trials/"+p.name]=p
for name in ("fem_static_surface_map_check.cpp","directional_valve_check.mm"):
 entries["checker-followup/"+name]=r/"matter/tools"/name
path=e/"build155-159-solver-native-metadata.tar.gz"
manifest={k:dict(bytes=p.stat().st_size,sha256=hashlib.file_digest(p.open("rb"),"sha256").hexdigest()) for k,p in entries.items()}
with tarfile.open(path,"w:gz") as t:
 for k,p in sorted(entries.items()):t.add(p,arcname=k,recursive=False)
with tarfile.open(path,"r:gz") as t:
 for m in t.getmembers():
  data=t.extractfile(m).read()
  assert len(data)==manifest[m.name]["bytes"] and hashlib.sha256(data).hexdigest()==manifest[m.name]["sha256"]
receipt=dict(archive=path.name,sha256=hashlib.file_digest(path.open("rb"),"sha256").hexdigest(),bytes=path.stat().st_size,independently_reopened=True,members=manifest)
path.with_suffix(".receipt.json").write_text(json.dumps(receipt,indent=2)+"\n")
print(json.dumps({k:v for k,v in receipt.items() if k!="members"}))

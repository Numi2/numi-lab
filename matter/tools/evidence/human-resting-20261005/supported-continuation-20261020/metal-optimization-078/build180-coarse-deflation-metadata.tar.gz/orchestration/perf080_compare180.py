from pathlib import Path
import json,re
ns={};exec(Path("/tmp/perf080_compare157_z0.py").read_text().split("def main(")[0],ns)
e=ns["EVIDENCE"]; a=e/"build180-coarse-control";b=e/"build180-coarse-vascular"
def records(p,tag):
 return [json.loads(x) for x in re.findall(tag+r"=(\{[^\n]+\})",(p/"stderr.log").read_text())]
audit={}
for p in (a,b):
 m=ns["latest_metrics"](p); s=(p/"stderr.log").read_text();o=(p/"stdout.log").read_text()
 audit[p.name]={"metrics":m,"process":json.loads((p/"process.json").read_text()),"active_work":records(p,"matter_fgmres_active_work"),"coarse_lines":[l for l in s.splitlines() if "global_coarse" in l or "coarse_" in l],"timing_lines":[l for l in o.splitlines() if "authoritative_segment" in l]}
x=ns["latest_metrics"](a);y=ns["latest_metrics"](b)
relative={k:max(abs(u-v)/max(abs(u),abs(v),1e-5) for u,v in zip(x[k],y[k])) for k in x}
r={"relative":relative,"passed_1pct":all(v<=.01 for v in relative.values()),"runs":audit}
(e/"build180-deflated-coarse-comparison.json").write_text(json.dumps(r,indent=2));print(json.dumps({"passed":r["passed_1pct"],"relative":relative,"coarse":audit[b.name]["coarse_lines"]},indent=2))

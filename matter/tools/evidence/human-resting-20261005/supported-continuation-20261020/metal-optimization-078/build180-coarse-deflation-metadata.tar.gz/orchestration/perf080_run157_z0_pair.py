from __future__ import annotations
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path("/Users/numi/numi-human-aortic-contact-opt-20261019")
EVIDENCE = ROOT / "matter/tools/evidence/human-resting-20261005/supported-continuation-20261020/metal-optimization-078"
BASE_MODE = (
    "global-icb-native-stateless-allnative-hier-tailicb-domain-tight3-work-"
    "compact-parallelbt-plainpso-build157-block-coarse-femtangent-principal-"
    "cavity3-graph-coupled-strictinit-strictrows-prefixbase"
)
RUNNER = Path("/tmp/perf080_build157_z0_run.py")
ROOTS = "2"
_reference = json.loads(next(EVIDENCE.glob("*build124*fullcert-patch0-stages-1/invocation.json")).read_text())
_REFERENCE_ENV = {k:v for k,v in _reference["simulation_environment"].items() if k.startswith("NUMI_EXPERIMENT") or k in ("NUMI_HUMAN_SUPPORTED_INITIALIZATION", "NUMI_HUMAN_STATIC_WEIGHTED_SKIN_SUPPORT")}
os.environ.update(_REFERENCE_ENV)
COMMON = {
    "NM_FEM_TRUE_RESIDUAL_CERTIFY": "1",
    "NM_FEM_SELECTOR6_GRAPH_DUE_ROW_IDENTITY": "1",
    "NM_FEM_GRAPH_SOLVE_COMPACT_SCRATCH": "1",
    "NM_FEM_SELECTOR6_GRAPH_TET_BLOCK_REUSE": "1",
    # Same endpoint capture and work-counter setting on both variants. The
    # candidate's counter is the device-side cumulative basis-injection count.
    "NUMI_HUMAN_CAPTURE_FEM_ENDPOINT_STATE": "1",
    "NUMI_MATTER_WORK_COUNTERS": "1",
}

def run(label: str, accepted_z0: bool) -> Path:
    suffix = "recycle" if accepted_z0 else "control"
    mode = f"{BASE_MODE}-z0-{suffix}-capture-{label}"
    env = os.environ.copy()
    env.update(COMMON)
    if accepted_z0:
        env["NM_FEM_REGIONAL_SELECTOR6_ACCEPTED_Z0_RECYCLE"] = "1"
    else:
        env.pop("NM_FEM_REGIONAL_SELECTOR6_ACCEPTED_Z0_RECYCLE", None)
    result = subprocess.run(
        ["python3", str(RUNNER), mode, ROOTS], cwd=str(ROOT), env=env,
        check=False)
    if result.returncode:
        raise SystemExit(f"{label} run failed with exit {result.returncode}")
    path = EVIDENCE / mode
    for required in ("invocation.json", "process.json", "stdout.log", "stderr.log"):
        if not (path / required).is_file():
            raise SystemExit(f"{label} run missing {required}: {path}")
    return path

if len(sys.argv) != 2:
    raise SystemExit("usage: perf080_run157_z0_pair.py <unique-label>")
label = sys.argv[1]
control = run(label, False)
candidate = run(label, True)
print(json.dumps({"control": str(control), "accepted_z0": str(candidate),
                  "roots_per_run": int(ROOTS)}, indent=2))

from pathlib import Path
import re,json
e=Path('/Users/numi/numi-human-aortic-contact-opt-20261019/matter/tools/evidence/human-resting-20261005/supported-continuation-20261020/metal-optimization-078')
keys='root_xyz_m center_of_mass_xyz_m root_linear_velocity_xyz_m_s root_linear_speed_m_s max_generalized_acceleration penetration_m contact_count min_J max_J max_displacement_m max_anchor_reaction_N passive_ligament_max_tension_N passive_ligament_force_residual_N passive_ligament_moment_residual_Nm body_contact_normal_force_N body_contact_force_residual_N body_contact_moment_residual_Nm'.split()
def load(n):
 p=next(e.glob(n))
 text=(p/'stdout.log').read_text()
 selected='\n'.join(x for x in text.splitlines() if any(t in x for t in ['human_standing_progress=accepted','resting_FEM_terminal_audit=','resting_fascia_fem_terminal_audit=']))
 m={}
 for k in keys:
  v=re.search(r'\b'+k+r'=(\[[^]]+\]|\S+)',selected).group(1)
  m[k]=list(map(float,v[1:-1].split(','))) if v.startswith('[') else [float(v)]
 return p,m,float(re.search(r'wall_s=(\S+)',text).group(1))

p,a,t0=load('*build134*stages-control-1')
import sys
q,b,t1=load('*build134*'+sys.argv[1]+'-1')
diff={k:max(abs(x-y)/max(abs(x),abs(y),1e-5) for x,y in zip(a[k],b[k])) for k in keys}
out=dict(control=str(p),candidate=str(q),control_body_seconds=t0,candidate_body_seconds=t1,relative_differences=diff,gate=.01,passed=all(v<=.01 for v in diff.values()),note='Full linear certification both; preconditioner neighborhood only. One short pair, startup excluded; not sustained performance.')
(e/('build134-'+sys.argv[1]+'-comparison.json')).write_text(json.dumps(out,indent=2))
print(json.dumps(out))

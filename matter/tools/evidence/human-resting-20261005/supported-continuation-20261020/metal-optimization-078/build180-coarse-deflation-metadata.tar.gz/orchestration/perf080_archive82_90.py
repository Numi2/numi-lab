import pathlib,json,hashlib,tarfile
r=pathlib.Path('/Users/numi/numi-human-aortic-contact-opt-20261019')
e=r/'matter/tools/evidence/human-resting-20261005/supported-continuation-20261020/metal-optimization-078'
members={}
def add(p,n):
 if p.is_file(): members[n]=p
for run in e.iterdir():
 if run.is_dir() and any('build'+str(v) in run.name for v in (82,83,84,85,86,87,88,89,90)):
  for name in ('stdout.log','stderr.log','invocation.json','process.json','summary.json','common-field-failure.json'): add(run/name,run.name+'/'+name)
  for p in (run/'output').glob('*.csv'):
   if p.stat().st_size<1048576:add(p,run.name+'/output/'+p.name)
for v in (82,83,84,85,86,87,88,89,90):
 for p in pathlib.Path('/tmp').glob('perf080-build'+str(v)+'*.log'):add(p,'retained-tmp/'+p.name)
 for p in pathlib.Path('/tmp').glob('perf080_build'+str(v)+'*.py'):add(p,'retained-tmp/'+p.name)
 f=r/('build-integrated-validation-20261019/perf078-build'+str(v)+'-frozen')
 for name in ('source.patch','source-changes.tar.gz','manifest.json','source-manifest.json'):add(f/name,'frozen'+str(v)+'/'+name)
 for p in e.glob('native-build'+str(v)+'-source-*.json'):add(p,p.name)
for pattern in ('perf080*hybrid*.patch','perf081*equil*.patch'):
 for p in pathlib.Path('/tmp').glob(pattern):add(p,'private-patches/'+p.name)
for extra in ('/tmp/perf080-schur-interface-current.patch','/tmp/perf080-schur-raw-interface-audit-rebased/raw-interface-audit.patch','/tmp/perf080-schur-raw-audit-order-private/raw-audit-order.patch'):
 p=pathlib.Path(extra);add(p,'private-patches/'+p.name)

add(r/'matter/tools/fgmres_true_residual_native_check.mm','source/fgmres_true_residual_native_check.mm')
def digest(p):return hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
manifest={n:dict(bytes=p.stat().st_size,sha256=digest(p)) for n,p in members.items()}
out=e/'build82-90-schur-coarse-native-metadata.tar.gz'
with tarfile.open(out,'w:gz') as t:
 for n,p in members.items():t.add(p,arcname=n,recursive=False)
with tarfile.open(out) as t:
 assert set(t.getnames())==set(members)
 for m in t.getmembers():assert hashlib.sha256(t.extractfile(m).read()).hexdigest()==manifest[m.name]['sha256']
receipt=dict(archive=out.name,sha256=digest(out),bytes=out.stat().st_size,members=manifest,all_members_independently_reopened_and_verified=True)
(e/'build82-90-schur-coarse-native-metadata-receipt.json').write_text(json.dumps(receipt,indent=2))
print(json.dumps({k:v for k,v in receipt.items() if k!='members'}))

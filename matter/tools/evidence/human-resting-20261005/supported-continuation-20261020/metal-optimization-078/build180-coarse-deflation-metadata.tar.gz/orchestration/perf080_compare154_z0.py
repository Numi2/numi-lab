from __future__ import annotations
import json
from pathlib import Path
import re
import sys

ROOT = Path("/Users/numi/numi-human-aortic-contact-opt-20261019")
EVIDENCE = ROOT / "matter/tools/evidence/human-resting-20261005/supported-continuation-20261020/metal-optimization-078"
KEYS = (
    "root_xyz_m center_of_mass_xyz_m root_linear_velocity_xyz_m_s "
    "root_linear_speed_m_s max_generalized_acceleration penetration_m "
    "contact_count min_J max_J max_displacement_m max_anchor_reaction_N "
    "passive_ligament_max_tension_N passive_ligament_force_residual_N "
    "passive_ligament_moment_residual_Nm body_contact_normal_force_N "
    "body_contact_force_residual_N body_contact_moment_residual_Nm"
).split()

def latest_metrics(path: Path):
    text = (path / "stdout.log").read_text()
    selected = "\n".join(
        line for line in text.splitlines()
        if any(tag in line for tag in (
            "human_standing_progress=accepted", "resting_FEM_terminal_audit=",
            "resting_fascia_fem_terminal_audit=")))
    result = {}
    for key in KEYS:
        matches = re.findall(r"\b" + re.escape(key) + r"=(\[[^]]+\]|\S+)", selected)
        if not matches:
            raise RuntimeError(f"{path.name}: missing final audit field {key}")
        value = matches[-1]
        result[key] = ([float(item) for item in value[1:-1].split(",")]
                       if value.startswith("[") else [float(value)])
    return result

def endpoint(path: Path):
    text = (path / "stdout.log").read_text()
    if text.count("resting_FEM_endpoint_capture=begin") != 1 or \
       text.count("resting_FEM_endpoint_capture=end") != 1:
        raise RuntimeError(f"{path.name}: endpoint capture block missing or repeated")
    nodes = {}
    tets = {}
    for line in text.splitlines():
        if line.startswith("resting_FEM_node,"):
            fields = dict(re.findall(r"(?:^|,)([A-Za-z0-9_]+)=([^,\s]+)", line))
            key = (fields["object"], int(fields["local"]))
            nodes[key] = tuple(float(fields[name]) for name in
                ("accepted_x", "accepted_y", "accepted_z", "vx", "vy", "vz"))
        elif line.startswith("resting_FEM_tet,"):
            fields = dict(re.findall(r"(?:^|,)([A-Za-z0-9_]+)=([^,\s]+)", line))
            tets[(fields["object"], int(fields["local"]))] = float(fields["J"])
    if not nodes or not tets:
        raise RuntimeError(f"{path.name}: endpoint capture had no node/tet records")
    return nodes, tets

def accepted_use_records(path: Path):
    text = (path / "stderr.log").read_text()
    records = []
    for payload in re.findall(r"matter_accepted_z0_use=(\{[^\n]+\})", text):
        records.append(json.loads(payload))
    return records

def main(label: str):
    candidates = sorted(EVIDENCE.glob(f"*build154*z0-control-capture-{label}"))
    controls = [p for p in candidates if "z0-control-capture" in p.name]
    z0runs = [p for p in candidates if "z0-recycle-capture" in p.name]
    if len(controls) != 1 or len(z0runs) != 1:
        raise RuntimeError(f"expected one control and one candidate for {label}: {candidates}")
    control, candidate = controls[0], z0runs[0]
    for path, enabled in ((control, False), (candidate, True)):
        invocation = json.loads((path / "invocation.json").read_text())
        env = invocation["simulation_environment"]
        for name, value in (
            ("NM_FEM_TRUE_RESIDUAL_CERTIFY", "1"),
            ("NM_FEM_SELECTOR6_GRAPH_DUE_ROW_IDENTITY", "1"),
            ("NM_FEM_GRAPH_SOLVE_COMPACT_SCRATCH", "1"),
            ("NM_FEM_SELECTOR6_GRAPH_TET_BLOCK_REUSE", "1"),
            ("NUMI_HUMAN_CAPTURE_FEM_ENDPOINT_STATE", "1"),
            ("NUMI_MATTER_WORK_COUNTERS", "1")):
            if env.get(name) != value:
                raise RuntimeError(f"{path.name}: missing matched {name}={value}")
        if (env.get("NM_FEM_REGIONAL_SELECTOR6_ACCEPTED_Z0_RECYCLE") == "1") != enabled:
            raise RuntimeError(f"{path.name}: Z0 setting mismatch")
        argv = invocation["argv"]
        if "--muscle-step-count" not in argv or argv[argv.index("--muscle-step-count") + 1] != "2":
            raise RuntimeError(f"{path.name}: run did not contain exactly two roots")
        process = json.loads((path / "process.json").read_text())
        if process.get("exit_code") != 0:
            raise RuntimeError(f"{path.name}: process did not complete successfully")
    control_metrics = latest_metrics(control)
    candidate_metrics = latest_metrics(candidate)
    if any(len(control_metrics[k]) != len(candidate_metrics[k]) for k in KEYS):
        raise RuntimeError("control and candidate audit vector lengths differ")
    relative = {
        key: max(abs(a-b) / max(abs(a), abs(b), 1e-5)
                 for a, b in zip(control_metrics[key], candidate_metrics[key]))
        for key in KEYS
    }
    control_nodes, control_tets = endpoint(control)
    candidate_nodes, candidate_tets = endpoint(candidate)
    if control_nodes.keys() != candidate_nodes.keys() or control_tets.keys() != candidate_tets.keys():
        raise RuntimeError("control and candidate endpoint identities differ")
    node_delta = [
        abs(a-b) for key in control_nodes for a,b in
        zip(control_nodes[key], candidate_nodes[key])
    ]
    tet_delta = [
        abs(control_tets[key] - candidate_tets[key]) for key in control_tets
    ]
    z0_records = accepted_use_records(candidate)
    if len(z0_records) < 2:
        raise RuntimeError("candidate did not emit accepted-Z0 use telemetry for both roots")
    if len({record["root"] for record in z0_records}) < 2:
        raise RuntimeError("candidate telemetry does not span two accepted roots")
    z0_records.sort(key=lambda record: (record["root"], record["environment"]))
    roots = sorted({record["root"] for record in z0_records})
    if len(roots) != 2 or roots[1] != roots[0] + 1:
        raise RuntimeError("candidate telemetry must cover exactly two consecutive accepted roots")
    if any(record["environment"] != 0 for record in z0_records):
        raise RuntimeError("unexpected environment in single-environment Z0 run")
    first_root, second_root = roots
    first_records = [record for record in z0_records if record["root"] == first_root]
    second_records = [record for record in z0_records if record["root"] == second_root]
    if any(record["accepted_valid"] != 1 for record in first_records + second_records):
        raise RuntimeError("accepted-Z0 telemetry reports an invalid accepted basis")
    first_count = max(record["cumulative_injections"] for record in first_records)
    second_count = max(record["cumulative_injections"] for record in second_records)
    if second_count <= first_count:
        raise RuntimeError("accepted Z0 was enabled but no cross-root basis injection was observed")
    output = {
        "schema": 1,
        "control": str(control),
        "accepted_z0": str(candidate),
        "roots_per_run": 2,
        "control_process_wall_seconds": json.loads((control / "process.json").read_text())["process_wall_seconds"],
        "candidate_process_wall_seconds": json.loads((candidate / "process.json").read_text())["process_wall_seconds"],
        "matched_true_certificate_due_identity_compact_scratch_and_tet_reuse": True,
        "candidate_actual_z0_use_records": z0_records,
        "candidate_cross_root_injection_observed": True,
        "candidate_z0_injections_first_two_roots": [first_count, second_count],
        "terminal_audit_max_relative_difference": relative,
        "terminal_audit_one_percent_gate": all(value <= 0.01 for value in relative.values()),
        "endpoint_node_count": len(control_nodes),
        "endpoint_tetrahedron_count": len(control_tets),
        "endpoint_max_abs_position_or_velocity_difference": max(node_delta),
        "endpoint_max_abs_J_difference": max(tet_delta),
        "note": "Two accepted roots per variant. Full-coupled certification remains enabled; use telemetry must rise across roots before this is called an actual Z0 reuse run."
    }
    out = EVIDENCE / f"build154-z0-{label}-comparison.json"
    out.write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps(output, indent=2))

if len(sys.argv) != 2:
    raise SystemExit("usage: perf080_compare154_z0.py <unique-label>")
main(sys.argv[1])

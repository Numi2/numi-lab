from pathlib import Path
import subprocess,json
r=Path('/Users/numi/numi-human-aortic-contact-opt-20261019');e=r/'matter/tools/evidence/human-resting-20261005/supported-continuation-20261020/metal-optimization-078'

for label,mode,pipelines in [('tangent-mode2-generic',2,0),('tangent-mode2-material-pipelines',2,1)]:
 name='build199-'+label
 cmd=['python3',str(r/'matter/tools/run_human_frozen_invocation.py'),'--template',str(e/'build186-uninstrumented-control/invocation.json'),'--provenance',str(e/'native-build199-source-provenance.json'),'--output',str(e/name),'--cwd',str(r),'--steps','3','--metal-validation','1','--env',f'NM_FEM_STATELESS_TANGENT_BUNDLE={mode}','--env',f'NM_FEM_MATERIAL_PIPELINES={pipelines}']
 p=subprocess.run(cmd);print(name,p.returncode,flush=True)
 if p.returncode:continue
 subprocess.run(['python3','/tmp/perf080_compare_pair.py','build199-control',name,name+'-comparison.json'],check=True,stdout=subprocess.DEVNULL)
 d=json.loads((e/(name+'-comparison.json')).read_text());print(name,'passed_1pct',d['passed_1pct'],'relative',d['relative'],flush=True)

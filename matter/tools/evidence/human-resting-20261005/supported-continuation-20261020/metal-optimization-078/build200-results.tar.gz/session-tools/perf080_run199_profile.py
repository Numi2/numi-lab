from pathlib import Path
import subprocess,json
r=Path('/Users/numi/numi-human-aortic-contact-opt-20261019');e=r/'matter/tools/evidence/human-resting-20261005/supported-continuation-20261020/metal-optimization-078'


for label,phase in [('profile-stage-kernels-p0','0'),('profile-control',None),('profile-stage-kernels-p11','11')]:
 name='build199-'+label
 cmd=['python3',str(r/'matter/tools/run_human_frozen_invocation.py'),'--template',str(e/'build186-uninstrumented-control/invocation.json'),'--provenance',str(e/'native-build199-source-provenance.json'),'--output',str(e/name),'--cwd',str(r),'--steps','3','--metal-validation','0']
 if phase is not None:
  for k,v in [('NUMI_MATTER_GPU_TIMING','1'),('NUMI_MATTER_GPU_TIMING_STAGES','1'),('NUMI_MATTER_GPU_TIMING_ROOT','2'),('NUMI_MATTER_GPU_TIMING_SAMPLE_EVERY','31'),('NUMI_MATTER_GPU_TIMING_PHASE',phase),('NUMI_MATTER_GPU_TIMING_KERNELS','all')]:cmd+=['--env',k+'='+v]
 else:
  for k in ['NUMI_MATTER_GPU_TIMING','NUMI_MATTER_GPU_TIMING_STAGES','NUMI_MATTER_GPU_TIMING_KERNELS']:cmd+=['--unset-env',k]
 p=subprocess.run(cmd);print(name,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)

#!/usr/bin/env python3
"""Sequential, frozen-source 375 us contact-clock refinement plan.

Dry-run by default. Pass --execute only when the GPU owner schedules the run.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path("/Users/numi/numi-human-aortic-contact-opt-20261019")
EVIDENCE = ROOT / "matter/tools/evidence/human-resting-20261005/supported-continuation-20261020/metal-optimization-078"
TEMPLATE = EVIDENCE / "build198-control/invocation.json"
PROVENANCE = EVIDENCE / "native-build198-source-provenance.json"
RUNNER = ROOT / "matter/tools/run_human_frozen_invocation.py"
COMPARATOR = ROOT / "matter/tools/human_performance_compare.py"
DURATION_S = 0.000375
REFERENCE_MRVPACK = EVIDENCE / "build192-startup-control/output/resting-human.mrvpack"
PINNED_FLAGS = {
    "NM_FGMRES_FLAT_COLUMN_ICB": "0",
    "NM_FGMRES_GRAPH_FULL_PSD_CONTACT_BLOCKS": "0",
    "NM_FEM_GRAPH_PARALLEL_BACKSUB_PRODUCTS": "0",
}
CASES = (
    ("125us-lock0", "0.00012500", 3, "0"),
    ("125us-lock1", "0.00012500", 3, "1"),
    ("62p5us-lock1", "0.00006250", 6, "1"),
    ("62p5us-lock0", "0.00006250", 6, "0"),
    ("31p25us-lock0", "0.00003125", 12, "0"),
    ("31p25us-lock1", "0.00003125", 12, "1"),
)
CLOCK_RE = re.compile(
    r"passive_fem_clock_selection maximum_rate_exponent=(\d+) "
    r"physical_frame_s=([^ ]+).*contact_connected_clock_lock=(enabled|disabled)"
)
PARTICIPANT_RE = re.compile(
    r"contact_connected_clock_lock=enabled conservative_component_objects=(\d+) "
    r"common_base_exponent=(\d+) maximum_rate_exponent=(\d+)"
)
PAIR_COMPARE_RE = re.compile(r"(?:^|\s)([A-Za-z0-9_]+)=((?:\[[^\]]*\])|[^\s]+)")
METRICS = {
    "root_xyz_m", "center_of_mass_xyz_m", "root_linear_velocity_xyz_m_s",
    "root_linear_speed_m_s", "max_generalized_acceleration", "penetration_m",
    "contact_count", "min_J", "max_J", "max_displacement_m",
    "max_anchor_reaction_N", "passive_ligament_max_tension_N",
    "passive_ligament_force_residual_N", "passive_ligament_moment_residual_Nm",
    "body_contact_normal_force_N", "body_contact_force_residual_N",
    "body_contact_moment_residual_Nm",
}
PHASE_COLUMNS = (
    "time_s", "step", "lv_mmhg", "rv_mmhg", "aorta_mmhg",
    "pulmonary_artery_mmhg", "lv_ml", "rv_ml", "blood_ml",
    "PaO2_mmhg", "PaCO2_mmhg", "SaO2", "last_inspiration_step",
    "last_inspiration_time_s", "min_contact_gap_m", "peak_penetration_m",
    "normal_impulse_ns", "root_assistance_n", "root_assistance_nm",
)

def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()

def parse_value(value: str):
    if value.startswith("[") and value.endswith("]"):
        body = value[1:-1]
        return [float(x) for x in body.split(",") if x]
    try:
        return float(value)
    except ValueError:
        return value

def parse_fields(line: str) -> dict:
    return {key: parse_value(value) for key, value in PAIR_COMPARE_RE.findall(line)}

def frozen_inputs() -> tuple[dict, dict]:
    template = json.loads(TEMPLATE.read_text())
    provenance = json.loads(PROVENANCE.read_text())
    if Path(template["source_provenance"]).resolve() != PROVENANCE.resolve():
        raise RuntimeError("build198 template points at different source provenance")
    if Path(template["binary"]).resolve() != (
        Path(provenance["frozen_artifact_directory"]) / "numi-human-native"
    ).resolve():
        raise RuntimeError("build198 template binary differs from frozen provenance")
    if template["binary_sha256"] != provenance["artifacts"]["numi-human-native"]:
        raise RuntimeError("build198 binary hash differs from frozen provenance")
    if template["simulation_environment"].get("NM_FEM_TRUE_RESIDUAL_CERTIFY") != "1":
        raise RuntimeError("template does not preserve the full true-residual certificate")
    if template["simulation_environment"].get("NUMI_HUMAN_SUPPORTED_INITIALIZATION") != "1":
        raise RuntimeError("template does not preserve supported initialization")
    for key, value in PINNED_FLAGS.items():
        if template["simulation_environment"].get(key) != value:
            raise RuntimeError(f"control template must pin {key}={value}")
    return template, provenance

def case_record(output: Path, case_name: str, seconds: str,
                steps: int, lock: str) -> dict:
    stdout_path, stderr_path = output / "stdout.log", output / "stderr.log"
    stdout = stdout_path.read_text(errors="replace") if stdout_path.exists() else ""
    stderr = stderr_path.read_text(errors="replace") if stderr_path.exists() else ""
    process_path = output / "process.json"
    process = json.loads(process_path.read_text()) if process_path.exists() else {
        "exit_code": None, "wall_seconds": None
    }

    progress = []
    metrics = {}
    for line in stdout.splitlines():
        if "human_standing_progress=accepted" in line:
            fields = parse_fields(line)
            progress.append(fields)
            for name in METRICS:
                if name in fields:
                    metrics[name] = fields[name]
        if ("resting_FEM_terminal_audit=" in line or
                "resting_fascia_fem_terminal_audit=" in line):
            for name, value in parse_fields(line).items():
                if name in METRICS:
                    metrics[name] = value

    body_match = re.search(r"resting_integrated_body=completed([^\n]*)", stdout)
    body = parse_fields(body_match.group(1)) if body_match else {}
    accepted_summary = None
    fem_audit = re.search(r"resting_FEM_terminal_audit=passed([^\n]*)", stdout)
    if fem_audit:
        accepted_summary = parse_fields(fem_audit.group(1))

    clock_selection = None
    clock_line = next((line for line in stderr.splitlines()
                       if "passive_fem_clock_selection " in line), "")
    clock_match = CLOCK_RE.search(clock_line)
    if clock_match:
        clock_selection = {
            "maximum_rate_exponent": int(clock_match.group(1)),
            "physical_frame_s": float(clock_match.group(2)),
            "lock_reported": clock_match.group(3),
        }
    participant_line = next((line for line in stderr.splitlines()
                             if "contact_connected_clock_lock=enabled conservative_component_objects=" in line), "")
    participant_match = PARTICIPANT_RE.search(participant_line)
    if participant_match:
        if clock_selection is None:
            clock_selection = {}
        clock_selection.update({
            "participant_objects": int(participant_match.group(1)),
            "common_base_exponent": int(participant_match.group(2)),
            "maximum_rate_exponent_reported": int(participant_match.group(3)),
        })

    phase_history = []
    csv_path = output / "output/resting-coupled.csv"
    if csv_path.exists():
        with csv_path.open(newline="") as stream:
            for row in csv.DictReader(stream):
                phase_history.append({
                    key: (float(row[key]) if row.get(key, "") not in ("", "nan", "NaN") else None)
                    for key in PHASE_COLUMNS if key in row
                })

    receipt_path = output / "invocation.json"
    receipt = json.loads(receipt_path.read_text()) if receipt_path.exists() else {}
    return {
        "case": case_name,
        "requested_dt_s": float(seconds),
        "requested_steps": steps,
        "requested_total_s": DURATION_S,
        "requested_lock": lock,
        "process": process,
        "accepted_progress": progress,
        "accepted_step_count": len(progress),
        "final_accepted_time_s": progress[-1].get("simulated_seconds") if progress else None,
        "body": body,
        "fem_terminal_passed": "resting_FEM_terminal_audit=passed" in stdout,
        "fascia_terminal_passed": "resting_fascia_fem_terminal_audit=passed" in stdout,
        "terminal_fem_audit": accepted_summary,
        "terminal_metrics": metrics,
        "contact_clock": clock_selection,
        "physiology_contact_phase_history": phase_history,
        "receipt": {
            "binary": receipt.get("binary"),
            "binary_sha256": receipt.get("binary_sha256"),
            "source_head": receipt.get("source_head"),
            "source_provenance_sha256": receipt.get("source_provenance_sha256"),
            "source_archive_sha256": receipt.get("source_archive_sha256"),
            "source_patch_sha256": receipt.get("source_patch_sha256"),
            "artifact_sha256": receipt.get("artifact_sha256"),
            "input_sha256": receipt.get("input_sha256"),
            "simulation_environment": receipt.get("simulation_environment"),
            "argv": receipt.get("argv"),
        },
        "raw_logs": {
            "stdout": str(stdout_path),
            "stderr": str(stderr_path),
            "coupled_csv": str(csv_path),
        },
    }

def deduplicate_mrvpack(output: Path, process_exit_code: int,
                        reference_hash: str, reference_stat: dict) -> dict:
    live_reference = REFERENCE_MRVPACK.stat()
    reference_stat = {
        "device": live_reference.st_dev,
        "inode": live_reference.st_ino,
        "links": live_reference.st_nlink,
        "size_bytes": live_reference.st_size,
    }
    candidate = output / "output/resting-human.mrvpack"
    if not candidate.is_file():
        return {"path": str(candidate), "present": False, "hardlinked": False}
    before = candidate.stat()
    candidate_hash = sha256(candidate)
    exact_match = (
        process_exit_code == 0
        and before.st_size == reference_stat["size_bytes"]
        and candidate_hash == reference_hash
    )
    hardlinked = False
    if exact_match and (before.st_dev, before.st_ino) != (
            reference_stat["device"], reference_stat["inode"]):
        temporary = candidate.with_name(candidate.name + ".verified-link")
        if temporary.exists():
            raise RuntimeError("dedup temporary path already exists: " + str(temporary))
        os.link(REFERENCE_MRVPACK, temporary)
        os.replace(temporary, candidate)
        hardlinked = True
    after = candidate.stat()
    return {
        "path": str(candidate),
        "present": True,
        "candidate_sha256": candidate_hash,
        "reference_path": str(REFERENCE_MRVPACK),
        "reference_sha256": reference_hash,
        "bytes": after.st_size,
        "exact_match": exact_match,
        "hardlinked": hardlinked,
        "candidate_before": {
            "device": before.st_dev, "inode": before.st_ino,
            "links": before.st_nlink, "bytes": before.st_size,
        },
        "reference": {
            "device": reference_stat["device"], "inode": reference_stat["inode"],
            "links": reference_stat["links"], "bytes": reference_stat["size_bytes"],
        },
        "candidate_after": {
            "device": after.st_dev, "inode": after.st_ino,
            "links": after.st_nlink, "bytes": after.st_size,
        },
    }

def make_summary(record: dict) -> dict:
    body = dict(record["body"])
    return {
        "exit_code": record["process"]["exit_code"],
        "final_accepted_time_s": record["final_accepted_time_s"],
        "time_check": record.get("time_check"),
        "terminal_metrics_complete": record.get("terminal_metrics_complete"),
        "body": body,
        "terminal_metrics": record["terminal_metrics"],
        "fem_terminal_passed": record["fem_terminal_passed"],
        "fascia_terminal_passed": record["fascia_terminal_passed"],
    }

def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--execute", action="store_true",
                        help="launch all six frozen cases sequentially; default only prints the plan")
    args = parser.parse_args()
    template, provenance = frozen_inputs()
    experiment_root = EVIDENCE / "build198-clock-refinement"
    outputs = {name: experiment_root.parent / f"build198-clock-refinement-{name}"
               for name, _, _, _ in CASES}
    existing = [str(path) for path in outputs.values() if path.exists()]
    if existing:
        raise RuntimeError("preserve existing output directories: " + ", ".join(existing))

    plan = {
        "source": "frozen build198 control; three experimental solver flags pinned off",
        "template": str(TEMPLATE),
        "template_sha256": sha256(TEMPLATE),
        "provenance": str(PROVENANCE),
        "provenance_sha256": sha256(PROVENANCE),
        "binary_sha256": provenance["artifacts"]["numi-human-native"],
        "metallib_sha256": provenance["artifacts"].get("NumiMatter.metallib"),
        "profile_policy": {
            "NUMI_HUMAN_TRAINING_PROFILE": "0",
            "NUMI_MATTER_PIPELINE_TRACE": "unset",
            "NM_FEM_RESIDUAL_ARMIJO_TRACE_ROOT": "unset",
            "MTL_DEBUG_LAYER": "1",
        },
        "pinned_experiment_flags": PINNED_FLAGS,
        "mrvpack_dedup_reference": str(REFERENCE_MRVPACK),
        "duration_s": DURATION_S,
        "execution_order": [
            {"name": name, "dt_s": float(dt), "steps": steps,
             "lock": lock, "output": str(outputs[name])}
            for name, dt, steps, lock in CASES
        ],
        "only_run_variations": [
            "--muscle-step-seconds", "--muscle-step-count",
            "NUMI_HUMAN_CONTACT_CONNECTED_CLOCK_LOCK",
            "profile-off settings listed above", "unique output directory",
            "explicitly pinned three solver flags listed above",
        ],
        "interpretation": {
            "same_dt_lock_pairs": "clock-lock effect at fixed dt",
            "locked_dt_ladder": "same-horizon timestep refinement, not a 1% physical qualification",
            "common_substep": "must be inferred from each run's logged common_base_exponent and frame time",
        },
    }
    print(json.dumps(plan, indent=2))
    if not args.execute:
        return 0
    if not REFERENCE_MRVPACK.is_file():
        raise RuntimeError("retained MRVPack dedup reference is missing")
    reference_stat_value = REFERENCE_MRVPACK.stat()
    reference_stat = {
        "device": reference_stat_value.st_dev,
        "inode": reference_stat_value.st_ino,
        "links": reference_stat_value.st_nlink,
        "size_bytes": reference_stat_value.st_size,
    }
    reference_hash = sha256(REFERENCE_MRVPACK)

    helper_args = [
        sys.executable, str(RUNNER),
        "--template", str(TEMPLATE),
        "--provenance", str(PROVENANCE),
        "--cwd", str(ROOT),
        "--metal-validation", "1",
    ]
    records = {}
    for name, dt, steps, lock in CASES:
        command = helper_args + [
            "--output", str(outputs[name]),
            "--steps", str(steps),
            "--step-seconds", str(float(dt)),
            "--env", f"NUMI_HUMAN_CONTACT_CONNECTED_CLOCK_LOCK={lock}",
            "--env", "NUMI_HUMAN_TRAINING_PROFILE=0",
            "--unset-env", "NUMI_MATTER_PIPELINE_TRACE",
            "--unset-env", "NM_FEM_RESIDUAL_ARMIJO_TRACE_ROOT",
        ]
        for key, value in PINNED_FLAGS.items():
            command.extend(["--env", f"{key}={value}"])
        proc = subprocess.run(command, cwd=ROOT, check=False)
        record = case_record(outputs[name], name, dt, steps, lock)
        if proc.returncode != 0 and record["process"]["exit_code"] is None:
            record["runner_exit_code"] = proc.returncode
        expected_time = float(dt) * steps
        actual_time = record["final_accepted_time_s"]
        time_passed = actual_time is not None and math.isclose(
            float(actual_time), expected_time, rel_tol=2e-6, abs_tol=1e-9
        )
        record["time_check"] = {
            "passed": time_passed, "expected_s": expected_time,
            "observed_s": actual_time,
        }
        record["terminal_metrics_complete"] = set(METRICS).issubset(
            record["terminal_metrics"]
        )
        record["mrvpack_dedup"] = deduplicate_mrvpack(
            outputs[name], record["process"]["exit_code"],
            reference_hash, reference_stat
        )
        (outputs[name] / "mrvpack-dedup.json").write_text(
            json.dumps(record["mrvpack_dedup"], indent=2, allow_nan=False) + "\n"
        )
        records[name] = record
        (outputs[name] / "case-record.json").write_text(
            json.dumps(record, indent=2, allow_nan=False) + "\n"
        )

    for name, record in records.items():
        (outputs[name] / "summary.json").write_text(
            json.dumps(make_summary(record), indent=2, allow_nan=False) + "\n"
        )

    comparisons = []
    pairs = []
    for dt_label in ("125us", "62p5us", "31p25us"):
        pairs.append((f"same-dt-{dt_label}",
                      f"{dt_label}-lock0", f"{dt_label}-lock1",
                      "same timestep; clock-lock A/B"))
    pairs.extend([
        ("locked-refine-125us-vs-62p5us", "125us-lock1", "62p5us-lock1",
         "same 375 us horizon; temporal refinement diagnostic"),
        ("locked-refine-62p5us-vs-31p25us", "62p5us-lock1", "31p25us-lock1",
         "same 375 us horizon; temporal refinement diagnostic"),
        ("locked-refine-125us-vs-31p25us", "125us-lock1", "31p25us-lock1",
         "same 375 us horizon; temporal refinement diagnostic"),
    ])
    for label, a, b, meaning in pairs:
        out = experiment_root.parent / f"build198-clock-refinement-{label}-comparison.json"
        command = [sys.executable, str(COMPARATOR),
                   str(outputs[a] / "summary.json"),
                   str(outputs[b] / "summary.json"), str(out)]
        result = subprocess.run(command, cwd=ROOT, check=False,
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        comparisons.append({
            "name": label, "left": a, "right": b, "meaning": meaning,
            "comparator_exit_code": result.returncode,
            "comparator_stdout": result.stdout.strip(),
            "comparison_json": str(out),
        })

    final = {
        "plan": plan,
        "runs": records,
        "comparisons": comparisons,
        "qualification": "bounded common-clock/timestep diagnostic only; no resting or long-horizon qualification",
    }
    result_path = experiment_root.parent / "build198-clock-refinement-results.json"
    result_path.write_text(json.dumps(final, indent=2, allow_nan=False) + "\n")
    print(f"RESULTS {result_path}")
    return 0 if all(
        r["process"]["exit_code"] == 0
        and r["time_check"]["passed"]
        and r["terminal_metrics_complete"]
        for r in records.values()
    ) else 1

if __name__ == "__main__":
    raise SystemExit(main())

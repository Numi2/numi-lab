from pathlib import Path
import subprocess
r=Path('/Users/numi/numi-human-aortic-contact-opt-20261019');e=r/'matter/tools/evidence/human-resting-20261005/supported-continuation-20261020/metal-optimization-078'
for pair in range(1,4):
 for on in ([False,True] if pair%2 else [True,False]):
  name=f'build200-stress-pair{pair}-'+('on' if on else 'control')
  cmd=['python3',str(r/'matter/tools/run_human_frozen_invocation.py'),'--template',str(e/'build186-uninstrumented-control/invocation.json'),'--provenance',str(e/'native-build200-source-provenance.json'),'--output',str(e/name),'--cwd',str(r),'--steps','3','--metal-validation','0','--env','NM_FEM_PARALLEL_CONSTITUTIVE_BACKTRACKING='+str(int(on))]
  p=subprocess.run(cmd);print(name,p.returncode,flush=True)
  if p.returncode:raise SystemExit(p.returncode)
 subprocess.run(['python3','/tmp/perf080_compare_pair.py',f'build200-stress-pair{pair}-control',f'build200-stress-pair{pair}-on',f'build200-stress-pair{pair}-comparison.json'],check=True,stdout=subprocess.DEVNULL)


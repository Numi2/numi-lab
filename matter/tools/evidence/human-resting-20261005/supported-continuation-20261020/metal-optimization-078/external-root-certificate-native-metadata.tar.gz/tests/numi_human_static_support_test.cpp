#include "metalrobo/ArticulatedDynamics.hpp"
#include "metalrobo/NumiHumanSupport.hpp"
#include <cstring>
#include "metalrobo/NumiHumanMuscleEquilibrium.hpp"
#include "metalrobo/MetalArticulatedOperator.hpp"
#include "metalrobo/NumiHumanCompliantEquilibrium.hpp"

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdlib>
#include <iostream>
#include <limits>
#include <string_view>
#include <vector>

namespace {
void require(const bool value, const std::string_view message) {
    if (value) return;
    std::cerr << "numi_human_static_support_test=failed error=\""
              << message << "\"\n";
    std::exit(1);
}
bool near(const double a, const double b, const double tolerance = 1.0e-7) {
    return std::abs(a - b) <= tolerance;
}
mr_float4 f4(
    const double x,
    const double y,
    const double z,
    const double w = 0.0
) {
    return {
        static_cast<float>(x),
        static_cast<float>(y),
        static_cast<float>(z),
        static_cast<float>(w),
    };
}

MRDofPropertiesGPU rootDof(const std::uint32_t localDof) {
    MRDofPropertiesGPU result{};
    result.articulationIndex = 0u;
    result.jointIndex = MR_INVALID_INDEX;
    result.qIndex = localDof < 3u
        ? localDof
        : MR_INVALID_INDEX;
    result.vIndex = localDof;
    result.localDof = localDof;
    result.flags = MR_DOF_FLAG_ROOT;
    return result;
}

MRBodyPropertiesGPU body(
    const std::uint32_t parent,
    const std::uint32_t inboundJoint,
    const double mass,
    const std::array<double, 3> inertia
) {
    MRBodyPropertiesGPU result{};
    result.articulationIndex = 0u;
    result.parentBody = parent;
    result.inboundJoint = inboundJoint;
    result.motionType = MR_MOTION_DYNAMIC;
    result.massAndInverseMass = f4(mass, 1.0 / mass, 0.0, 0.0);
    result.inertiaRow0 = f4(inertia[0], 0.0, 0.0);
    result.inertiaRow1 = f4(0.0, inertia[1], 0.0);
    result.inertiaRow2 = f4(0.0, 0.0, inertia[2]);
    result.inverseInertiaRow0 =
        f4(1.0 / inertia[0], 0.0, 0.0);
    result.inverseInertiaRow1 =
        f4(0.0, 1.0 / inertia[1], 0.0);
    result.inverseInertiaRow2 =
        f4(0.0, 0.0, 1.0 / inertia[2]);
    result.dampingAndSpeedLimits =
        f4(0.0, 0.0, 1.0e6, 1.0e6);
    return result;
}

metalrobo::EngineModel makeFreeBodyModel() {
    metalrobo::EngineModel model;
    model.name = "analytic_contact_free_body";
    MRArticulationGPU articulation{};
    articulation.rootBody = 0u;
    articulation.rootType = MR_ROOT_FLOATING;
    articulation.firstBody = 0u;
    articulation.bodyCount = 1u;
    articulation.firstJoint = 0u;
    articulation.jointCount = 0u;
    articulation.qOffset = 0u;
    articulation.nq = 7u;
    articulation.vOffset = 0u;
    articulation.nv = 6u;
    model.articulations.push_back(articulation);
    for (std::uint32_t localDof = 0u;
         localDof < 6u;
         ++localDof) {
        model.dofs.push_back(rootDof(localDof));
    }
    model.bodies.push_back(body(
        MR_INVALID_INDEX,
        MR_INVALID_INDEX,
        2.5,
        {0.7, 1.1, 1.6}
    ));
    model.defaultQ = {
        0.0f, 0.0f, 0.0f,
        0.0f, 0.0f, 0.0f, 1.0f,
    };
    model.defaultV.assign(6u, 0.0f);
    return model;
}


struct Fixture {
    metalrobo::EngineModel model = makeFreeBodyModel();
    std::vector<double> q;
    const std::vector<metalrobo::MujocoMuscleSite> sites{
        {0u, {-0.5, 0.0, 0.0}}, {0u, {0.5, 0.0, 0.0}}};
    std::vector<metalrobo::MujocoMuscleDefinition> muscles;
    const std::vector<metalrobo::MujocoCompliantMuscleArchitecture> architectures{1u};
    metalrobo::NumiHumanMuscleEquilibriumConfig config;

    Fixture() {
        model.world.gravityAndTimestep = {0.0f, 0.0f, -9.81f, 0.0001f};
        q.assign(model.defaultQ.begin(), model.defaultQ.end());
        metalrobo::MujocoMuscleDefinition muscle;
        muscle.route = {
            {metalrobo::MujocoRouteNodeType::site, 0u},
            {metalrobo::MujocoRouteNodeType::site, 1u}};
        muscle.lengthRange = {0.8, 1.2};
        muscle.accelerationScale = 1.0;
        muscle.controlRange = {0.0, 1.0};
        muscle.gainParameters = {0.75, 1.05, 1.0, 200.0, 0.5, 1.6,
                                 1.5, 1.3, 1.2, 0.0};
        muscle.biasParameters = muscle.gainParameters;
        muscle.dynamicParameters = {0.01, 0.04, 0.0};
        muscles.push_back(muscle);
        config.activationSamples = 3u;
        config.activationSweeps = 8u;
        config.poseSweeps = 0u;
        config.globalActivationPolishIterations = 2u;
    }

    auto compile(const std::vector<metalrobo::NumiHumanStaticSupportContact>& supports,
                 metalrobo::NumiHumanMuscleEquilibriumResult& result) const {
        return metalrobo::compileNumiHumanMuscleEquilibrium(
            model, 0u, q, sites, {}, muscles, architectures, {}, {}, supports,
            result, config);
    }
    double weight() const {
        return -2.5 * static_cast<double>(model.world.gravityAndTimestep.z);
    }
};
} // namespace

void testGravityScaleRamp() {
    using namespace metalrobo;
    MetalNumiHumanGravityScaleRamp disabled;
    require(!disabled.configured() &&
                disabled.scaleAtAcceptedStep(1u) == 1.0f &&
                disabled.scaleAtAcceptedStep(100u) == 1.0f,
            "default gravity ramp did not preserve full source gravity");
    const MetalNumiHumanGravityScaleRamp ramp{
        .firstAcceptedStep = 1u,
        .fullGravityAcceptedStep = 5u,
        .initialScale = 0.0f,
        .fullGravityScale = 1.0f,
    };
    require(ramp.configured() &&
                ramp.scaleAtAcceptedStep(1u) == 0.0f &&
                near(ramp.scaleAtAcceptedStep(2u), 0.25) &&
                near(ramp.scaleAtAcceptedStep(3u), 0.5) &&
                near(ramp.scaleAtAcceptedStep(4u), 0.75) &&
                ramp.scaleAtAcceptedStep(5u) == 1.0f &&
                ramp.scaleAtAcceptedStep(8u) == 1.0f,
            "accepted-step gravity ramp did not reach full gravity exactly on its declared step");
}

void testCurvedSupport() {
    using namespace metalrobo;
    auto model = makeFreeBodyModel();
    std::vector<double> q{0,0,0, std::sqrt(0.5),0,0,std::sqrt(0.5)};
    std::vector<double> v{0,0,0,2,0,0};
    std::vector<ArticulatedPointQuery> queries{{0u, {0,0,0}, 0.2, {0,0,1}}};
    std::vector<ArticulatedPointKinematics> points(1);
    std::vector<double> jac(18);
    require(computeArticulatedPointJacobians(model,0,q,v,queries,points,jac).succeeded(),
        "sphere query rejected");
    require(near(points[0].position[2],-0.2) && near(points[0].position[1],0) &&
            near(points[0].linearVelocity[1],0.4) && near(jac[6+3],0.2),
        "sphere surface or material friction velocity is wrong");
    // Rotating about an offset centre changes normal gap; its derivative is n*J.
    const double angle=0.31, eps=1.0e-6;
    queries[0].localPoint={0.5,0,0};
    q={0,0,0,0,std::sin(angle/2),0,std::cos(angle/2)};
    require(computeArticulatedPointJacobians(model,0,q,v,queries,points,jac).succeeded(),"tilted sphere failed");
    const double derivative=jac[12+4];
    double gap[2];
    for (unsigned i=0;i<2;++i) {
        const double a=angle+(i ? eps : -eps);
        q[4]=std::sin(a/2);q[6]=std::cos(a/2);
        require(computeArticulatedPointJacobians(model,0,q,v,queries,points,jac).succeeded(),"gap derivative failed");
        gap[i]=points[0].position[2];
    }
    require(near((gap[1]-gap[0])/(2*eps),derivative,1.0e-9),"sphere normal-gap Jacobian disagrees with geometry");
    const auto kept=points[0].position;
    for (double bad : {-0.1, std::numeric_limits<double>::quiet_NaN()}) {
        queries[0].supportRadius=bad;
        require(!computeArticulatedPointJacobians(model,0,q,v,queries,points,jac).succeeded() && points[0].position==kept,
            "bad radius published point output");
    }
    queries[0].supportRadius=0.2;queries[0].supportPlaneNormal={0,0,2};
    require(!computeArticulatedPointJacobians(model,0,q,v,queries,points,jac).succeeded(),"nonunit sphere plane admitted");
    queries[0].supportPlaneNormal={0,0.6,0.8};queries[0].localPoint={0,0,0};
    require(computeArticulatedPointJacobians(model,0,q,v,queries,points,jac).succeeded() &&
            near(points[0].position[1],-0.12) && near(points[0].position[2],-0.16),"oblique sphere plane failed");
    const std::vector<NumiHumanStaticSupportContact> supports{
        {.bodyIndex=0,.normal={0,0.6,0.8},.planePoint={0,0.3,0.4},.supportRadius=0.2}};
    const std::vector<NumiHumanSupportPoseCoordinate> coordinates{{1u,2.0},{2u,2.0}};
    const std::vector<std::uint32_t> active{0};
    NumiHumanSupportPoseResult fitted;
    require(compileNumiHumanSupportPose(model,0,q,{},supports,active,coordinates,fitted).succeeded() &&
            near(0.6*fitted.q[1]+0.8*fitted.q[2],0.7),"stance fitted centre instead of surface");

    queries[0].supportRadius=0;
    queries[0].supportRadii={0.2,0.3,0.4}; queries[0].supportOrientation={0,0,0,1};
    queries[0].supportPlaneNormal={0,0,1};
    q={0,0,0,0,std::sqrt(0.5),0,std::sqrt(0.5)};
    require(computeArticulatedPointJacobians(model,0,q,v,queries,points,jac).succeeded() &&
            near(points[0].position[2],-0.2),"ellipsoid did not refresh its rotated semi-axis");
    queries[0].supportRadii[1]=0;
    require(!computeArticulatedPointJacobians(model,0,q,v,queries,points,jac).succeeded(),"degenerate ellipsoid admitted");

    NumiHumanSupportHeader h;
    h.magic={'N','H','C','N','T','2',0,0};h.payloadAbi=2;h.engineBodyCount=1;h.contactCount=1;
    std::vector<std::byte> bytes(84+96);
    std::memcpy(bytes.data(),&h,84);
    const std::array<std::uint32_t,4> identity{0,42,2,0};
    const std::array<float,12> primitive{-0.5,0,0,0.2, 0.5,0,0,0.7, -0.2,-0.2,0,0};
    std::memcpy(bytes.data()+84,identity.data(),16);std::memcpy(bytes.data()+100,primitive.data(),48);
    NumiHumanSupportPayload payload;std::string error;
    require(decodeNumiHumanSupportPayload(bytes,1,h.sourceSha256,payload,error) && payload.contacts.size()==2 &&
            payload.contacts[0].localPointX==-0.5f && payload.contacts[1].localPointX==0.5f &&
            payload.contacts[0].supportRadius==0.2f && payload.header.contactCount==2,
        "capsule did not compile both endpoint-sphere constraints");
    for (const std::size_t offset : {std::size_t(80),std::size_t(128)}) {
        auto subnormal=bytes;
        const float value=std::numeric_limits<float>::denorm_min();
        std::memcpy(subnormal.data()+offset,&value,sizeof(value));
        require(!decodeNumiHumanSupportPayload(subnormal,1,h.sourceSha256,payload,error) &&
                payload.contacts.size()==2 && payload.contacts[0].friction==0.7f,
            "subnormal NHCNT2 friction admitted or mutated prior output");
    }
    for (const float value : {0.0f,std::numeric_limits<float>::min()}) {
        auto representable=bytes;
        std::memcpy(representable.data()+128,&value,sizeof(value));
        NumiHumanSupportPayload admitted;
        require(decodeNumiHumanSupportPayload(representable,1,h.sourceSha256,admitted,error) &&
                admitted.contacts.size()==2 && admitted.contacts[0].friction==value,
            "representable NHCNT2 friction rejected");
    }
    auto bad=bytes;bad.pop_back();
    require(!decodeNumiHumanSupportPayload(bad,1,h.sourceSha256,payload,error) && payload.contacts.size()==2,
        "truncated primitive published output");
    for (std::size_t offset : {std::size_t(92),std::size_t(96),std::size_t(112),std::size_t(140)}) {
        bad=bytes;const std::uint32_t invalid=0xffffffffu;std::memcpy(bad.data()+offset,&invalid,4);
        require(!decodeNumiHumanSupportPayload(bad,1,h.sourceSha256,payload,error),"malformed primitive admitted");
    }
    auto foreign=h.sourceSha256;foreign[0]=1;
    require(!decodeNumiHumanSupportPayload(bytes,1,foreign,payload,error),"foreign source primitive admitted");
    h.magic[5]='1';h.payloadAbi=1;
    bytes.resize(84+48);std::memcpy(bytes.data(),&h,84);
    NumiHumanSupportContact legacy;legacy.bodyIndex=0;legacy.sourceGeometryIndex=42;
    std::memcpy(bytes.data()+84,&legacy,48);
    require(decodeNumiHumanSupportPayload(bytes,1,h.sourceSha256,payload,error) && payload.contacts.size()==1 &&
        payload.contacts[0].supportRadius==0,"legacy witness changed semantics");
    auto subnormalLegacy=bytes;
    const float subnormal=std::numeric_limits<float>::denorm_min();
    std::memcpy(subnormalLegacy.data()+116,&subnormal,sizeof(subnormal));
    require(!decodeNumiHumanSupportPayload(subnormalLegacy,1,h.sourceSha256,payload,error) &&
            payload.contacts.size()==1 && payload.contacts[0].friction==0.0f,
        "subnormal NHCNT1 friction admitted or mutated prior output");
}

void testPointQuerySourceWidening() {
    using namespace metalrobo;
    EngineModel model;
    MRArticulationGPU articulation{};
    articulation.rootBody = 0u;
    articulation.rootType = MR_ROOT_FIXED;
    articulation.firstBody = 0u;
    articulation.bodyCount = 3u;
    articulation.firstJoint = 0u;
    articulation.jointCount = 2u;
    articulation.nq = 2u;
    articulation.nv = 2u;
    model.articulations.push_back(articulation);
    model.bodies.push_back(body(
        MR_INVALID_INDEX, MR_INVALID_INDEX, 1.0, {1.0, 1.0, 1.0}
    ));
    for (std::uint32_t jointIndex = 0u; jointIndex < 2u; ++jointIndex) {
        model.bodies.push_back(body(
            jointIndex, jointIndex, 1.0, {1.0, 1.0, 1.0}
        ));
        MRJointDescriptorGPU joint{};
        joint.parentBody = jointIndex;
        joint.childBody = jointIndex + 1u;
        joint.jointType = MR_JOINT_PRISMATIC;
        joint.qOffset = jointIndex;
        joint.nq = 1u;
        joint.vOffset = jointIndex;
        joint.nv = 1u;
        joint.axis0 = f4(0.0, 1.0, 0.0);
        joint.parentRotation = f4(0.0, 0.0, 0.0, 1.0);
        joint.childRotation = f4(0.0, 0.0, 0.0, 1.0);
        model.joints.push_back(joint);
        MRDofPropertiesGPU dof{};
        dof.articulationIndex = 0u;
        dof.jointIndex = jointIndex;
        dof.qIndex = jointIndex;
        dof.vIndex = jointIndex;
        dof.localDof = 0u;
        dof.flags = MR_DOF_FLAG_POSITION_LIMIT;
        dof.limits = f4(-0.1, 0.1, 0.0, 0.0);
        model.dofs.push_back(dof);
    }
    const std::array<float, 2u> sourceQ{{0.01f, 0.02f}};
    const std::vector<double> q{
        static_cast<double>(sourceQ[0]),
        static_cast<double>(sourceQ[1]),
    };
    const std::vector<double> v(2u, 0.0);
    const auto gap = [&](const ArticulatedPointQuery& query) {
        std::array<ArticulatedPointKinematics, 1u> point{};
        std::array<double, 6u> jacobian{};
        require(
            computeArticulatedPointJacobians(
                model, 0u, q, v, std::span(&query, 1u), point, jacobian
            ).succeeded(),
            "widened point query was not accepted by FP64 kinematics"
        );
        return point.front().position[1u];
    };
    const auto sameQuery = [](const ArticulatedPointQuery& first,
                              const ArticulatedPointQuery& second) {
        return first.bodyIndex == second.bodyIndex &&
            first.localPoint == second.localPoint &&
            first.supportRadius == second.supportRadius &&
            first.supportPlaneNormal == second.supportPlaneNormal &&
            first.supportRadii == second.supportRadii &&
            first.supportOrientation == second.supportOrientation;
    };

    MRArticulatedPointImpulseGPU sphere{};
    sphere.bodyIndex = 2u;
    sphere.flags = MR_ARTICULATED_POINT_SPHERE_SUPPORT;
    sphere.supportPlaneNormalAndRadius = f4(0.0, 1.0, 0.0, 0.03);
    ArticulatedPointQuery sphereQuery{};
    require(
        widenArticulatedPointQueryFromGPU(sphere, sphereQuery) ==
                ArticulatedDynamicsStatus::success &&
            sphereQuery.bodyIndex == sphere.bodyIndex &&
            sphereQuery.localPoint == std::array<double, 3u>{0.0, 0.0, 0.0} &&
            sphereQuery.supportRadius ==
                static_cast<double>(sphere.supportPlaneNormalAndRadius.w) &&
            sphereQuery.supportPlaneNormal ==
                std::array<double, 3u>{0.0, 1.0, 0.0} &&
            gap(sphereQuery) == 0.0,
        "source-authored coincident sphere did not widen exactly"
    );

    ArticulatedPointQuery reauthored = sphereQuery;
    reauthored.supportRadius = 0.03;
    const double historicalGap =
        static_cast<double>(sourceQ[0]) + static_cast<double>(sourceQ[1]) - 0.03;
    require(
        historicalGap == -6.7055225261292151e-10 &&
            gap(reauthored) == historicalGap,
        "re-authored FP64 radius no longer reproduces the historical oracle gap"
    );

    for (const float direction : {
             -std::numeric_limits<float>::infinity(),
             std::numeric_limits<float>::infinity(),
         }) {
        MRArticulatedPointImpulseGPU adjacent = sphere;
        adjacent.supportPlaneNormalAndRadius.w = std::nextafter(
            sphere.supportPlaneNormalAndRadius.w, direction
        );
        ArticulatedPointQuery adjacentQuery{};
        require(
            widenArticulatedPointQueryFromGPU(adjacent, adjacentQuery) ==
                ArticulatedDynamicsStatus::success,
            "adjacent source-float radius was rejected"
        );
        const double expected =
            static_cast<double>(sourceQ[0]) + static_cast<double>(sourceQ[1]) -
            static_cast<double>(adjacent.supportPlaneNormalAndRadius.w);
        require(
            gap(adjacentQuery) == expected &&
                ((direction < 0.0f && expected > 0.0) ||
                 (direction > 0.0f && expected < 0.0)),
            "one-ULP source radius lost its exact gap sign or magnitude"
        );
    }

    MRArticulatedPointImpulseGPU ellipsoid{};
    ellipsoid.bodyIndex = 2u;
    ellipsoid.flags = MR_ARTICULATED_POINT_ELLIPSOID_SUPPORT;
    ellipsoid.localPoint = f4(0.125, -0.25, 0.375, 0.0);
    ellipsoid.worldImpulse = f4(0.5, -0.25, 0.125, 0.0);
    ellipsoid.supportPlaneNormalAndRadius = f4(0.6, 0.8, 0.0, 0.0);
    ellipsoid.supportRadii = f4(0.02, 0.03, 0.04, 0.0);
    const float halfRoot = std::sqrt(0.5f);
    ellipsoid.supportOrientation = {0.0f, 0.0f, halfRoot, halfRoot};
    ArticulatedPointQuery ellipsoidQuery{};
    require(
        widenArticulatedPointQueryFromGPU(ellipsoid, ellipsoidQuery) ==
                ArticulatedDynamicsStatus::success &&
            ellipsoidQuery.localPoint == std::array<double, 3u>{
                static_cast<double>(ellipsoid.localPoint.x),
                static_cast<double>(ellipsoid.localPoint.y),
                static_cast<double>(ellipsoid.localPoint.z),
            } &&
            ellipsoidQuery.supportPlaneNormal == std::array<double, 3u>{
                static_cast<double>(ellipsoid.supportPlaneNormalAndRadius.x),
                static_cast<double>(ellipsoid.supportPlaneNormalAndRadius.y),
                static_cast<double>(ellipsoid.supportPlaneNormalAndRadius.z),
            } &&
            ellipsoidQuery.supportRadii == std::array<double, 3u>{
                static_cast<double>(ellipsoid.supportRadii.x),
                static_cast<double>(ellipsoid.supportRadii.y),
                static_cast<double>(ellipsoid.supportRadii.z),
            } &&
            ellipsoidQuery.supportOrientation == std::array<double, 4u>{
                static_cast<double>(ellipsoid.supportOrientation.x),
                static_cast<double>(ellipsoid.supportOrientation.y),
                static_cast<double>(ellipsoid.supportOrientation.z),
                static_cast<double>(ellipsoid.supportOrientation.w),
            } &&
            std::isfinite(gap(ellipsoidQuery)),
        "ellipsoid source geometry was not widened field-for-field"
    );

    ArticulatedPointQuery sentinel{};
    sentinel.bodyIndex = 91u;
    sentinel.localPoint = {1.0, 2.0, 3.0};
    sentinel.supportRadius = 4.0;
    sentinel.supportPlaneNormal = {5.0, 6.0, 7.0};
    sentinel.supportRadii = {8.0, 9.0, 10.0};
    sentinel.supportOrientation = {11.0, 12.0, 13.0, 14.0};
    struct InvalidCase {
        MRArticulatedPointImpulseGPU source{};
        ArticulatedDynamicsStatus expected = ArticulatedDynamicsStatus::invalidModel;
    };
    std::vector<InvalidCase> invalid;
    const auto reject = [&](const MRArticulatedPointImpulseGPU& source,
                            const ArticulatedDynamicsStatus expected =
                                ArticulatedDynamicsStatus::invalidModel) {
        invalid.push_back({source, expected});
    };
    auto bad = sphere;
    bad.bodyIndex = MR_INVALID_INDEX;
    reject(bad);
    bad = sphere;
    bad.flags |= MR_ARTICULATED_POINT_INACTIVE;
    reject(bad);
    bad = sphere;
    bad.flags |= MR_ARTICULATED_POINT_ELLIPSOID_SUPPORT;
    reject(bad);
    bad = sphere;
    bad.reserved0 = 1u;
    reject(bad);
    bad = sphere;
    bad.reserved1 = 1u;
    reject(bad);
    bad = sphere;
    bad.localPoint.w = 1.0f;
    reject(bad);
    bad = sphere;
    bad.worldImpulse.w = 1.0f;
    reject(bad);
    bad = sphere;
    bad.localPoint.x = std::numeric_limits<float>::quiet_NaN();
    reject(bad, ArticulatedDynamicsStatus::nonfiniteInput);
    bad = sphere;
    bad.supportPlaneNormalAndRadius.y = 0.0f;
    reject(bad);
    bad = sphere;
    bad.supportPlaneNormalAndRadius.w = 0.0f;
    reject(bad);
    bad = sphere;
    bad.supportRadii.x = 0.01f;
    reject(bad);
    bad = ellipsoid;
    bad.supportPlaneNormalAndRadius.w = 0.01f;
    reject(bad);
    bad = ellipsoid;
    bad.supportOrientation = {};
    reject(bad);
    bad = {};
    bad.bodyIndex = 2u;
    bad.supportPlaneNormalAndRadius.x = 1.0f;
    reject(bad);
    for (const InvalidCase& item : invalid) {
        ArticulatedPointQuery output = sentinel;
        require(
            widenArticulatedPointQueryFromGPU(item.source, output) ==
                    item.expected &&
                sameQuery(output, sentinel),
            "invalid GPU point metadata did not fail closed"
        );
    }
}

void testSourceCompliantPreparation() {
    using namespace metalrobo;
    NumiHumanSourceScalarLaw law{{-100,-2,0,0},{0.5f,0.5f,0.1f,0.5f},{2,0,0,0},0.4,true};
    double force=123;
    require(evaluateNumiHumanSourceStaticForce(law,0,1e-4,force) && force==0,
        "zero deformation supplied an ideal static reaction");
    require(evaluateNumiHumanSourceStaticForce(law,-0.02,1e-4,force) && near(force,10,1e-10),
        "source inverse weight or impedance was omitted from static force");
    auto invalid=law;invalid.inverseWeight=0;force=123;
    require(!evaluateNumiHumanSourceStaticForce(invalid,-0.02,1e-4,force) && force==123,
        "invalid source law changed the accepted output");
    auto positive=law;positive.solref={0.001f,1,0,0};
    double safe=0,unsafe=0;
    require(evaluateNumiHumanSourceStaticForce(positive,-0.02,0.01,safe),"REFSAFE scalar failed");
    positive.referenceSafe=false;
    require(evaluateNumiHumanSourceStaticForce(positive,-0.02,0.01,unsafe) &&
        near(unsafe/safe,std::pow(0.02/double(positive.solref.x),2),1e-8),"REFSAFE timestep law changed");
    auto model=makeFreeBodyModel();model.world.gravityAndTimestep={0,0,-9.81f,1e-4f};
    std::vector<double> q(model.defaultQ.begin(),model.defaultQ.end());
    NumiHumanCompliantEquality equality;
    equality.source.indices={2,2,MR_INVALID_INDEX,MR_INVALID_INDEX};
    equality.source.solref=law.solref;equality.source.solimp0=law.solimp0;equality.source.solimp1=law.solimp1;
    equality.inverseWeight=law.inverseWeight;
    const std::vector<NumiHumanCompliantEquality> equalities{equality};
    NumiHumanCompliantEquilibriumConfig config;config.accelerationTolerance=1e-6;
    NumiHumanCompliantEquilibriumResult result;
    const auto run=[&](auto& output) {
        return compileNumiHumanCompliantEquilibrium(model,0,q,{},{},{},{},{},equalities,{},{},output,config);
    };
    auto status=run(result);
    const double expected=2.5*double(model.world.gravityAndTimestep.z)/500.0;
    require(status.succeeded() && status.balanced && near(result.state.q[2],expected,1e-8),
        "compliant preparation did not find the analytic loaded deformation");
    require(result.objectiveHistory.size()>1 && result.objectiveHistory.back()<result.objectiveHistory.front(),
        "preparation trace omitted its converged search");
    NumiHumanCompliantEquilibriumResult replay;
    require(run(replay).succeeded() && replay.state.q==result.state.q && replay.objectiveHistory==result.objectiveHistory,
        "source-compliant preparation replay changed");
    config.maximumCoordinateDisplacement=0.001;
    require(run(replay).succeeded() && !replay.state.diagnostics.balanced && near(replay.state.q[2],-0.001,1e-9),
        "infeasible compliant preparation waived its displacement bound");
    const auto accepted=replay.state.q;q[2]=NAN;
    require(!run(replay).succeeded() && replay.state.q==accepted,"failed preparation overwrote accepted output");
    q[2]=0;config.maximumCoordinateDisplacement=0.15;
    NumiHumanCompliantLimit limit{2,2,0,1,0,law};
    const std::vector<NumiHumanCompliantLimit> limits{limit};
    status=compileNumiHumanCompliantEquilibrium(model,0,q,{},{},{},{},{},{},limits,{},result,config);
    require(status.succeeded() && status.balanced && near(result.state.q[2],expected,1e-8) &&
        result.state.generalizedPositionLimitForce[2]>0,"source lower stop did not acquire its loaded deformation");
    q[2]=5e-7;config.optimizePose=false;
    const std::vector<NumiHumanStaticSupportContact> grounded{{.bodyIndex=0}};
    status=compileNumiHumanCompliantEquilibrium(model,0,q,{},{},{},{},{},{},{},grounded,result,config);
    require(status.succeeded() && status.balanced && result.state.q==q &&
        near(result.state.supportNormalForce[0],-2.5*double(model.world.gravityAndTimestep.z),1e-7),
        "support-only admission moved the fixed prepared state or lost weight");
    q[2]=0;config.optimizePose=true;
    model.world.gravityAndTimestep.z=9.81f;limit.lower=-1;limit.upper=0;
    const std::vector<NumiHumanCompliantLimit> upper{limit};
    status=compileNumiHumanCompliantEquilibrium(model,0,q,{},{},{},{},{},{},upper,{},result,config);
    require(status.succeeded() && status.balanced && near(result.state.q[2],-expected,1e-8) &&
        result.state.generalizedPositionLimitForce[2]<0,"source upper stop did not acquire its loaded deformation");
}


void testAnalyticBodySpatialReference() {
    using namespace metalrobo;
    EngineModel model;
    MRArticulationGPU articulation{};
    articulation.rootBody = 0u;
    articulation.rootType = MR_ROOT_FLOATING;
    articulation.firstBody = 0u;
    articulation.bodyCount = 4u;
    articulation.firstJoint = 0u;
    articulation.jointCount = 3u;
    articulation.qOffset = 0u;
    articulation.nq = 9u;
    articulation.vOffset = 0u;
    articulation.nv = 8u;
    model.articulations.push_back(articulation);

    model.bodies.push_back(body(MR_INVALID_INDEX, MR_INVALID_INDEX, 2.0, {0.8, 1.1, 1.4}));
    model.bodies.push_back(body(0u, 2u, 1.5, {0.7, 0.9, 1.2}));
    model.bodies.push_back(body(1u, 0u, 1.1, {0.6, 0.8, 1.0}));
    model.bodies.push_back(body(2u, 1u, 0.9, {0.5, 0.7, 0.9}));
    model.bodies[1].centerOfMass = f4(0.03, -0.02, 0.01);
    model.bodies[2].centerOfMass = f4(-0.04, 0.01, 0.02);
    model.bodies[3].centerOfMass = f4(0.02, 0.03, -0.01);

    const auto unitAxis = [](const std::array<double, 3> axis,
                             const std::uint32_t coordinate,
                             const OpenSimFunctionDefinition function) {
        return OpenSimSpatialAxisDefinition{
            .axis = axis,
            .coordinateIndex = coordinate,
            .function = function,
        };
    };
    OpenSimSpatialTransformDefinition definition{};
    definition.coordinateCount = 2u;
    for (std::size_t axis = 0u; axis < definition.axes.size(); ++axis) {
        const std::array<double, 3> direction =
            axis % 3u == 0u ? std::array<double, 3>{1.0, 0.0, 0.0} :
            axis % 3u == 1u ? std::array<double, 3>{0.0, 1.0, 0.0} :
                              std::array<double, 3>{0.0, 0.0, 1.0};
        definition.axes[axis] = unitAxis(
            direction, kOpenSimNoCoordinate,
            {.kind = OpenSimFunctionKind::constant, .coefficients = {0.0}});
    }
    definition.axes[0] = unitAxis(
        {0.0, 0.0, 1.0}, 0u,
        {.kind = OpenSimFunctionKind::linear, .coefficients = {1.0, 0.0}});
    // SpatialTransform requires each angular and translation triplet to have
    // pairwise independent axes. Keep the unused angular axis orthogonal to
    // the active Z rotation and default Y axis.
    definition.axes[2] = unitAxis(
        {1.0, 0.0, 0.0}, kOpenSimNoCoordinate,
        {.kind = OpenSimFunctionKind::constant, .coefficients = {0.0}});
    // One source coordinate drives both rotation and translation, while the
    // second controls an independent translation axis.
    definition.axes[3] = unitAxis(
        {1.0, 0.0, 0.0}, 0u,
        {.kind = OpenSimFunctionKind::linear, .coefficients = {0.4, 0.1}});
    definition.axes[5] = unitAxis(
        {0.0, 0.0, 1.0}, 1u,
        {.kind = OpenSimFunctionKind::linear, .coefficients = {0.2, -0.03}});
    const auto compiled = compileOpenSimSpatialTransform(definition);
    require(compiled.succeeded(), "analytic body reference transform did not compile");

    const auto identity = f4(0.0, 0.0, 0.0, 1.0);
    const auto fixed = [&](const std::uint32_t parent,
                           const std::uint32_t child,
                           const std::uint32_t qOffset,
                           const std::uint32_t vOffset,
                           const mr_float4 parentAnchor,
                           const mr_float4 childAnchor) {
        MRJointDescriptorGPU joint{};
        joint.parentBody = parent;
        joint.childBody = child;
        joint.jointType = MR_JOINT_FIXED;
        joint.qOffset = qOffset;
        joint.vOffset = vOffset;
        joint.parentAnchor = parentAnchor;
        joint.childAnchor = childAnchor;
        joint.parentRotation = identity;
        joint.childRotation = identity;
        return joint;
    };
    MRJointDescriptorGPU functionJoint{};
    functionJoint.parentBody = 1u;
    functionJoint.childBody = 2u;
    functionJoint.jointType = MR_JOINT_FUNCTION_BASED;
    functionJoint.qOffset = 7u;
    functionJoint.nq = 2u;
    functionJoint.vOffset = 6u;
    functionJoint.nv = 2u;
    functionJoint.axis0 = f4(0.0, 0.0, 1.0);
    functionJoint.axis1 = f4(1.0, 0.0, 0.0);
    functionJoint.parentAnchor = f4(0.08, -0.03, 0.05);
    functionJoint.childAnchor = f4(-0.02, 0.04, -0.01);
    functionJoint.parentRotation = identity;
    functionJoint.childRotation = identity;
    // Deliberately non-root-order: the function-based child is recorded before
    // its fixed parent link, and a fixed descendant follows that transform.
    model.joints.push_back(functionJoint); // parent 1 -> child 2
    model.joints.push_back(fixed(2u, 3u, 9u, 8u,
                                 f4(0.03, 0.02, -0.01),
                                 f4(-0.05, 0.01, 0.02)));
    model.joints.push_back(fixed(0u, 1u, 9u, 8u,
                                 f4(0.11, -0.07, 0.06),
                                 f4(-0.04, 0.02, 0.03)));
    model.functionBasedJointPrograms.push_back({0u, compiled.transform});

    for (std::uint32_t dof = 0u; dof < 6u; ++dof) {
        model.dofs.push_back(rootDof(dof));
    }
    for (std::uint32_t local = 0u; local < 2u; ++local) {
        MRDofPropertiesGPU dof{};
        dof.articulationIndex = 0u;
        dof.jointIndex = 0u;
        dof.qIndex = 7u + local;
        dof.vIndex = 6u + local;
        dof.localDof = local;
        model.dofs.push_back(dof);
    }

    constexpr double rootAngle = 0.71;
    const double half = rootAngle * 0.5;
    std::vector<double> q{
        0.31, -0.24, 0.18,
        0.0, std::sin(half), 0.0, std::cos(half),
        0.27, -0.19,
    };
    model.defaultQ.reserve(q.size());
    for (const double value : q) model.defaultQ.push_back(static_cast<float>(value));
    model.defaultV.assign(8u, 0.0f);
    model.world.abiVersion = MR_ENGINE_ABI_VERSION;
    model.world.gravityAndTimestep = {0.0f, 0.0f, -9.81f, 0.001f};
    model.world.bodyCount = static_cast<mr_u32>(model.bodies.size());
    model.world.jointCount = static_cast<mr_u32>(model.joints.size());
    model.world.articulationCount = 1u;
    model.world.nq = 9u;
    model.world.nv = 8u;
    model.world.contactCapacity = 1u;
    model.world.constraintCapacity = 1u;
    model.world.islandCapacity = 1u;
    model.world.pairCapacity = 1u;
    std::string modelReason;
    require(model.valid(&modelReason),
            "analytic spatial reference model invalid: " + modelReason);

    constexpr std::size_t bodyCount = 4u;
    constexpr std::size_t nv = 8u;
    std::vector<ArticulatedBodyKinematics> poses(bodyCount);
    const std::vector<double> zeroVelocity(nv, 0.0);
    require(computeArticulatedBodyKinematics(
                model, 0u, q, zeroVelocity, poses).succeeded(),
            "analytic spatial reference base pose failed");

    // This is the CPU source for the candidate's first six sidecar rows:
    // direct angular and COM-linear columns for every generalized velocity.
    // It invokes the FP64 tree-motion recursion with unit velocities rather
    // than inferring angular velocity from four rounded point-J rows.
    std::vector<double> sourceColumns(bodyCount * 6u * nv);
    for (std::size_t column = 0u; column < nv; ++column) {
        std::vector<double> unitVelocity(nv, 0.0);
        unitVelocity[column] = 1.0;
        std::vector<ArticulatedBodyKinematics> motion(bodyCount);
        require(computeArticulatedBodyKinematics(
                    model, 0u, q, unitVelocity, motion).succeeded(),
                "analytic source column failed");
        for (std::size_t bodyIndex = 0u; bodyIndex < bodyCount; ++bodyIndex) {
            for (std::size_t row = 0u; row < 3u; ++row) {
                sourceColumns[(bodyIndex * 6u + row) * nv + column] =
                    motion[bodyIndex].angularVelocity[row];
                sourceColumns[(bodyIndex * 6u + 3u + row) * nv + column] =
                    motion[bodyIndex].linearVelocity[row];
            }
        }
    }

    const auto crossProduct = [](const std::array<double, 3>& a,
                                 const std::array<double, 3>& b) {
        return std::array<double, 3>{
            a[1] * b[2] - a[2] * b[1],
            a[2] * b[0] - a[0] * b[2],
            a[0] * b[1] - a[1] * b[0],
        };
    };
    const auto rotate = [](const std::array<double, 4>& quaternion,
                           const std::array<double, 3>& value) {
        const std::array<double, 3> u{
            quaternion[0], quaternion[1], quaternion[2]};
        const std::array<double, 3> uxv{
            u[1] * value[2] - u[2] * value[1],
            u[2] * value[0] - u[0] * value[2],
            u[0] * value[1] - u[1] * value[0],
        };
        const std::array<double, 3> uxu{
            u[1] * uxv[2] - u[2] * uxv[1],
            u[2] * uxv[0] - u[0] * uxv[2],
            u[0] * uxv[1] - u[1] * uxv[0],
        };
        return std::array<double, 3>{
            value[0] + 2.0 * (quaternion[3] * uxv[0] + uxu[0]),
            value[1] + 2.0 * (quaternion[3] * uxv[1] + uxu[1]),
            value[2] + 2.0 * (quaternion[3] * uxv[2] + uxu[2]),
        };
    };
    for (std::size_t column = 0u; column < 3u; ++column) {
        for (std::size_t bodyIndex = 0u; bodyIndex < bodyCount; ++bodyIndex) {
            for (std::size_t row = 0u; row < 3u; ++row) {
                require(near(sourceColumns[(bodyIndex * 6u + row) * nv + column],
                             0.0, 1.0e-12),
                        "floating-root translation gained angular motion");
                require(near(sourceColumns[(bodyIndex * 6u + 3u + row) * nv + column],
                             row == column ? 1.0 : 0.0, 1.0e-12),
                        "floating-root translation did not reach descendant COM");
            }
        }
    }
    for (std::size_t rotation = 0u; rotation < 3u; ++rotation) {
        std::array<double, 3> axis{};
        axis[rotation] = 1.0;
        for (std::size_t bodyIndex = 0u; bodyIndex < bodyCount; ++bodyIndex) {
            const auto expectedLinear = crossProduct(
                axis,
                std::array<double, 3>{
                    poses[bodyIndex].centerOfMassPosition[0] -
                        poses[0].centerOfMassPosition[0],
                    poses[bodyIndex].centerOfMassPosition[1] -
                        poses[0].centerOfMassPosition[1],
                    poses[bodyIndex].centerOfMassPosition[2] -
                        poses[0].centerOfMassPosition[2],
                });
            for (std::size_t row = 0u; row < 3u; ++row) {
                require(near(sourceColumns[
                                 (bodyIndex * 6u + row) * nv + 3u + rotation],
                             axis[row], 1.0e-10),
                        "rotated floating root lost its world angular basis");
                require(near(sourceColumns[
                                 (bodyIndex * 6u + 3u + row) * nv + 3u + rotation],
                             expectedLinear[row], 1.0e-10),
                        "offset-COM root column disagrees with analytic screw motion");
            }
        }
    }

    const auto transformState = evaluateOpenSimSpatialTransform(
        compiled.transform, {q[7], q[8]}, {0.0, 0.0});
    require(transformState.succeeded(),
            "coupled source transform evaluation failed");
    const auto& functionParentOrientation = poses[1].orientation;
    const auto expectedTipPositionDelta = std::array<double, 3>{
        poses[3].centerOfMassPosition[0] - poses[2].centerOfMassPosition[0],
        poses[3].centerOfMassPosition[1] - poses[2].centerOfMassPosition[1],
        poses[3].centerOfMassPosition[2] - poses[2].centerOfMassPosition[2],
    };
    for (std::size_t local = 0u; local < 2u; ++local) {
        const std::size_t column = 6u + local;
        const auto localAngular = transformState.motionSubspace[local].angular;
        const auto localLinear = transformState.motionSubspace[local].linear;
        const auto worldAngular = rotate(functionParentOrientation, localAngular);
        const auto worldJointLinear = rotate(functionParentOrientation, localLinear);
        const auto parentAnchor = rotate(
            functionParentOrientation,
            std::array<double, 3>{
                static_cast<double>(functionJoint.parentAnchor.x),
                static_cast<double>(functionJoint.parentAnchor.y),
                static_cast<double>(functionJoint.parentAnchor.z)});
        const auto functionTranslation = rotate(
            functionParentOrientation, transformState.translation);
        const std::array<double, 3> jointPoint{
            poses[1].centerOfMassPosition[0] + parentAnchor[0] + functionTranslation[0],
            poses[1].centerOfMassPosition[1] + parentAnchor[1] + functionTranslation[1],
            poses[1].centerOfMassPosition[2] + parentAnchor[2] + functionTranslation[2],
        };
        const std::array<double, 3> body2FromJoint{
            poses[2].centerOfMassPosition[0] - jointPoint[0],
            poses[2].centerOfMassPosition[1] - jointPoint[1],
            poses[2].centerOfMassPosition[2] - jointPoint[2],
        };
        const auto expectedBody2Offset = crossProduct(worldAngular, body2FromJoint);
        const auto expectedBody3Offset = crossProduct(worldAngular, expectedTipPositionDelta);
        for (std::size_t row = 0u; row < 3u; ++row) {
            require(near(sourceColumns[(2u * 6u + row) * nv + column],
                         worldAngular[row], 1.0e-9),
                    "function-based joint angular column disagrees with its source H");
            require(near(sourceColumns[(2u * 6u + 3u + row) * nv + column],
                         worldJointLinear[row] + expectedBody2Offset[row],
                         1.0e-9),
                    "function-based joint linear column lost its COM anchor offset");
            require(near(sourceColumns[(3u * 6u + row) * nv + column],
                         worldAngular[row], 1.0e-9),
                    "fixed descendant lost coupled joint angular ancestry");
            require(near(sourceColumns[(3u * 6u + 3u + row) * nv + column],
                         sourceColumns[(2u * 6u + 3u + row) * nv + column] +
                             expectedBody3Offset[row],
                         1.0e-9),
                    "fixed descendant COM column disagrees with the source screw");

            // The sidecar linear row is the COM point Jacobian. A separate
            // arbitrary point obeys v_point = v_COM + omega x r, without
            // differencing point probes or using a runtime GPU result as oracle.
            const std::array<double, 3> localPoint{0.13, -0.07, 0.09};
            const auto worldOffset = rotate(poses[3].orientation, localPoint);
            const auto pointOffset = crossProduct(worldAngular, worldOffset);
            const ArticulatedPointQuery query{3u, localPoint};
            std::array<ArticulatedPointKinematics, 1u> point{};
            std::array<double, 3u * nv> pointJacobian{};
            const std::vector<double> unitVelocity = [&] {
                std::vector<double> value(nv, 0.0);
                value[column] = 1.0;
                return value;
            }();
            require(computeArticulatedPointJacobians(
                        model, 0u, q, unitVelocity,
                        std::span(&query, 1u), point, pointJacobian).succeeded(),
                    "offset point query failed for spatial reference");
            for (std::size_t row = 0u; row < 3u; ++row) {
                require(near(pointJacobian[row * nv + column],
                             sourceColumns[(3u * 6u + 3u + row) * nv + column] +
                                 pointOffset[row],
                             1.0e-9),
                        "analytic body sidecar does not reconstruct the arbitrary-point Jacobian");
            }
        }
    }
}

int main() {
    testSourceCompliantPreparation();
    testGravityScaleRamp();
    testCurvedSupport();
    testPointQuerySourceWidening();
    testAnalyticBodySpatialReference();
    using namespace metalrobo;
    Fixture fixture;
    const NumiHumanStaticSupportContact touching{.bodyIndex = 0u};
    auto separated = touching;
    separated.localPoint[2] = 0.02;
    NumiHumanMuscleEquilibriumResult accepted;
    const auto grounded = fixture.compile({touching, separated}, accepted);
    require(grounded.succeeded() && grounded.balanced,
            "analytic grounded mass did not balance");
    require(accepted.supportNormalForce.size() == 2u &&
                accepted.supportPlaneGapMeters.size() == 2u &&
                near(accepted.supportNormalForce[0], fixture.weight()) &&
                accepted.supportNormalForce[1] == 0.0 &&
                near(accepted.supportPlaneGapMeters[0], 0.0) &&
                near(accepted.supportPlaneGapMeters[1], 0.02),
            "separated witness carried weight or lost its source index");
    require(near(accepted.generalizedSupportForce[2], fixture.weight()),
            "support generalized force disagrees with analytic weight");
    require(near(accepted.gravityTarget[2], fixture.weight()),
            "default static gravity scale changed the source gravity load");

    Fixture quarterGravity = fixture;
    quarterGravity.config.gravityScale = 0.25;
    NumiHumanMuscleEquilibriumResult quarterGravityResult;
    require(quarterGravity.compile({touching}, quarterGravityResult).succeeded() &&
                near(quarterGravityResult.gravityTarget[2],
                     0.25 * fixture.weight()) &&
                near(quarterGravityResult.supportNormalForce[0],
                     0.25 * fixture.weight()),
            "static gravity scale did not scale the gravity and support loads together");
    Fixture zeroGravity = fixture;
    zeroGravity.config.gravityScale = 0.0;
    NumiHumanMuscleEquilibriumResult zeroGravityResult;
    require(zeroGravity.compile({touching}, zeroGravityResult).succeeded() &&
                zeroGravityResult.gravityTarget[2] == 0.0 &&
                zeroGravityResult.supportNormalForce[0] == 0.0,
            "zero-gravity static initialization retained a weight or support load");
    zeroGravity.config.gravityScale = 1.01;
    require(zeroGravity.compile({touching}, zeroGravityResult).status ==
                NumiHumanMuscleEquilibriumStatus::invalidConfiguration,
            "out-of-range static gravity scale was accepted");

    auto weightedContact = touching;
    NumiHumanStaticSupportContact::WeightedWitness weightedWitness;
    weightedWitness.sourceContactIndex = 17u;
    weightedWitness.pointQueryIndex = 23u;
    weightedWitness.sourceGeometryIndex = 42u;
    weightedWitness.modelFingerprint =
        numiHumanStaticSupportModelFingerprint(fixture.model, 0u);
    weightedWitness.pointJacobian.assign(18u, 0.0);
    weightedWitness.pointJacobian[2u * 6u + 2u] = 1.0;
    weightedWitness.referenceQ = fixture.q;
    weightedContact.weightedWitness = weightedWitness;
    NumiHumanMuscleEquilibriumResult weightedAccepted;
    require(fixture.compile({weightedContact}, weightedAccepted).succeeded() &&
                weightedAccepted.supportNormalForce.size() == 1u &&
                near(weightedAccepted.supportNormalForce[0], fixture.weight()) &&
                near(weightedAccepted.supportPlaneGapMeters[0], 0.0) &&
                near(weightedAccepted.generalizedSupportForce[2],
                     fixture.weight()) &&
                weightedAccepted.supportWitnessIdentity.size() == 1u &&
                weightedAccepted.supportWitnessIdentity[0] ==
                    NumiHumanStaticSupportWitnessIdentity{17u, 23u, 42u},
            "captured weighted witness lost its force, Jacobian, or identity");

    auto separatedWeightedContact = weightedContact;
    separatedWeightedContact.weightedWitness->worldPoint[2] = 15.0e-6;
    NumiHumanMuscleEquilibriumResult separatedWeighted;
    require(fixture.compile({separatedWeightedContact}, separatedWeighted)
                    .succeeded() &&
                !separatedWeighted.diagnostics.balanced &&
                separatedWeighted.supportNormalForce.size() == 1u &&
                separatedWeighted.supportNormalForce[0] == 0.0 &&
                near(separatedWeighted.supportPlaneGapMeters[0], 15.0e-6,
                     1.0e-12) &&
                std::all_of(
                    separatedWeighted.generalizedSupportForce.begin(),
                    separatedWeighted.generalizedSupportForce.end(),
                    [](const double force) { return force == 0.0; }),
            "15 micrometre weighted separation acquired support force");

    auto mismatchedModelContact = weightedContact;
    mismatchedModelContact.weightedWitness->modelFingerprint ^= 0x10u;
    const auto mismatchedModelDiagnostics =
        fixture.compile({mismatchedModelContact}, weightedAccepted);
    require(mismatchedModelDiagnostics.status ==
                    NumiHumanMuscleEquilibriumStatus::invalidDimensions &&
                weightedAccepted.supportNormalForce.size() == 1u &&
                near(weightedAccepted.supportNormalForce[0], fixture.weight()),
            "weighted witness from a different model identity was accepted");

    auto missingSourceGeometryContact = weightedContact;
    missingSourceGeometryContact.weightedWitness->sourceGeometryIndex =
        MR_INVALID_INDEX;
    const auto missingSourceGeometryDiagnostics =
        fixture.compile({missingSourceGeometryContact}, weightedAccepted);
    require(missingSourceGeometryDiagnostics.status ==
                    NumiHumanMuscleEquilibriumStatus::invalidDimensions &&
                near(weightedAccepted.supportNormalForce[0], fixture.weight()),
            "weighted witness without a source geometry identity was accepted");

    const auto duplicateWitnessDiagnostics =
        fixture.compile({weightedContact, weightedContact}, weightedAccepted);
    require(duplicateWitnessDiagnostics.status ==
                    NumiHumanMuscleEquilibriumStatus::invalidDimensions &&
                weightedAccepted.supportNormalForce.size() == 1u &&
                near(weightedAccepted.supportNormalForce[0], fixture.weight()),
            "duplicate weighted support rows were accepted");

    auto staleWitnessContact = weightedContact;
    staleWitnessContact.weightedWitness->referenceQ[0] += 1.0e-4;
    const auto staleWitnessDiagnostics =
        fixture.compile({staleWitnessContact}, weightedAccepted);
    require(staleWitnessDiagnostics.status ==
                    NumiHumanMuscleEquilibriumStatus::invalidDimensions &&
                weightedAccepted.supportNormalForce.size() == 1u &&
                near(weightedAccepted.supportNormalForce[0],
                     fixture.weight()),
            "stale weighted witness q was accepted or mutated output");

    NumiHumanMuscleEquilibriumResult replay;
    require(fixture.compile({touching, separated}, replay).succeeded() &&
                replay.q == accepted.q && replay.activation == accepted.activation &&
                replay.supportNormalForce == accepted.supportNormalForce &&
                replay.supportPlaneGapMeters == accepted.supportPlaneGapMeters,
            "static support compile did not replay exactly");

    NumiHumanMuscleEquilibriumResult airborne;
    fixture.config.supportForceRegularization = 0.0;
    require(fixture.compile({separated}, airborne).succeeded() &&
                !airborne.diagnostics.balanced &&
                airborne.supportNormalForce[0] == 0.0 &&
                near(airborne.diagnostics.maximumFloatingRootForceResidual,
                     fixture.weight()),
            "airborne mass received a fictitious ground reaction");

    // The runtime speculative band is not physical contact thickness.
    // A separated body must not acquire a static ground reaction,
    // even when its witness is inside that broad-phase band.
    for (const double gap : {1.0e-5, 5.0e-4, 1.0e-3, 1.9e-3}) {
        auto nearPlane = touching;
        nearPlane.localPoint[2] = gap;
        require(fixture.compile({nearPlane}, airborne).succeeded() &&
                    !airborne.diagnostics.balanced &&
                    airborne.supportNormalForce[0] == 0.0 &&
                    near(airborne.diagnostics.maximumFloatingRootForceResidual,
                         fixture.weight()),
                "near-plane separation carried a static reaction");
    }

    auto penetrating = touching;
    penetrating.localPoint[2] = -0.014;
    const auto rejected = fixture.compile({penetrating}, accepted);
    require(rejected.status == NumiHumanMuscleEquilibriumStatus::supportPenetration &&
                rejected.failingIndex == 0u && accepted.q == replay.q &&
                accepted.activation == replay.activation &&
                accepted.supportNormalForce == replay.supportNormalForce &&
                accepted.supportPlaneGapMeters == replay.supportPlaneGapMeters,
            "penetrating initial pose was admitted or mutated accepted output");

    // A shared world translation changes neither contact nor supported load.
    fixture.q[2] = 1.25;
    auto elevatedPlane = touching;
    elevatedPlane.planePoint[2] = 1.25;
    NumiHumanMuscleEquilibriumResult translated;
    require(fixture.compile({elevatedPlane}, translated).succeeded() &&
                translated.diagnostics.balanced &&
                near(translated.supportNormalForce[0], fixture.weight()) &&
                near(translated.supportPlaneGapMeters[0], 0.0),
            "authored nonzero plane was ignored");
    fixture.q[2] = 0.0;

    // The gap and force follow the authored normal, not a hard-coded z axis.
    fixture.model.world.gravityAndTimestep = {0.0f, -9.81f, 0.0f, 0.0001f};
    auto sidePlane = touching;
    sidePlane.normal = {0.0, 1.0, 0.0};
    NumiHumanMuscleEquilibriumResult rotated;
    require(fixture.compile({sidePlane}, rotated).succeeded() &&
                rotated.diagnostics.balanced &&
                near(rotated.generalizedSupportForce[1],
                     -2.5 * fixture.model.world.gravityAndTimestep.y),
            "rotated plane did not support the analytic load");

    // Numerical geometry tolerance is an explicit admission bound.
    auto withinTolerance = sidePlane;
    withinTolerance.localPoint[1] = -0.5 * fixture.config.supportGapToleranceMeters;
    require(fixture.compile({withinTolerance}, rotated).succeeded(),
            "bounded geometric roundoff was rejected");
    fixture.config.supportGapToleranceMeters = 0.0;
    require(fixture.compile({withinTolerance}, rotated).status ==
                NumiHumanMuscleEquilibriumStatus::supportPenetration,
            "zero tolerance was not enforced");
    fixture.config.supportGapToleranceMeters = -1.0;
    require(fixture.compile({sidePlane}, rotated).status ==
                NumiHumanMuscleEquilibriumStatus::invalidConfiguration,
            "negative support tolerance was accepted");
    fixture.config.supportGapToleranceMeters = std::numeric_limits<double>::quiet_NaN();
    require(fixture.compile({sidePlane}, rotated).status ==
                NumiHumanMuscleEquilibriumStatus::invalidConfiguration,
            "nonfinite support tolerance was accepted");
    fixture.config.supportGapToleranceMeters = 1.0e-6;
    sidePlane.planePoint[0] = std::numeric_limits<double>::quiet_NaN();
    require(fixture.compile({sidePlane}, rotated).status ==
                NumiHumanMuscleEquilibriumStatus::invalidDimensions,
            "nonfinite authored plane was accepted");
    // Offline placement changes only explicitly bounded coordinates, with
    // every unselected witness still checked against its authored plane.
    Fixture placement;
    placement.q[2] = 0.015;
    const std::vector<NumiHumanStaticSupportContact> placementContacts{touching, separated};
    const std::vector<std::uint32_t> activeContacts{0u};
    const std::vector<NumiHumanSupportPoseCoordinate> vertical{{2u, 0.02}};
    NumiHumanSupportPoseResult fitted;
    require(compileNumiHumanSupportPose(placement.model, 0u, placement.q, {},
                placementContacts, activeContacts, vertical, fitted).succeeded() &&
                near(fitted.q[2], 0.0, 1.0e-8) &&
                near(fitted.supportPlaneGapMeters[1], 0.02, 1.0e-8),
            "explicit offline placement did not reach the authored plane");
    for (std::size_t i = 0; i < fitted.q.size(); ++i) {
        require(i == 2u || fitted.q[i] == placement.q[i],
                "placement altered an unauthorized coordinate");
    }
    NumiHumanSupportPoseResult repeatedFit;
    require(compileNumiHumanSupportPose(placement.model, 0u, placement.q, {},
                placementContacts, activeContacts, vertical, repeatedFit).succeeded() &&
                repeatedFit.q == fitted.q &&
                repeatedFit.supportPlaneGapMeters == fitted.supportPlaneGapMeters &&
                repeatedFit.iterations == fitted.iterations,
            "offline support placement did not replay exactly");
    const std::vector<NumiHumanSupportPoseCoordinate> tooShort{{2u, 0.001}};
    require(compileNumiHumanSupportPose(placement.model, 0u, placement.q, {},
                placementContacts, activeContacts, tooShort, fitted).status ==
                NumiHumanMuscleEquilibriumStatus::supportPoseInfeasible &&
                fitted.q == repeatedFit.q &&
                fitted.supportPlaneGapMeters == repeatedFit.supportPlaneGapMeters,
            "infeasible placement exceeded its bound or changed accepted output");
    auto obstacle = touching;
    obstacle.localPoint[2] = -0.001;
    const std::vector<NumiHumanStaticSupportContact> obstructed{touching, obstacle};
    require(compileNumiHumanSupportPose(placement.model, 0u, placement.q, {},
                obstructed, activeContacts, vertical, fitted).status ==
                NumiHumanMuscleEquilibriumStatus::supportPoseInfeasible &&
                fitted.q == repeatedFit.q,
            "placement ignored an unselected penetrating witness");
    const std::vector<std::uint32_t> duplicates{0u, 0u};
    require(compileNumiHumanSupportPose(placement.model, 0u, placement.q, {},
                placementContacts, duplicates, vertical, fitted).status ==
                NumiHumanMuscleEquilibriumStatus::invalidSelection,
            "duplicate active contacts were admitted");
    const std::vector<NumiHumanSupportPoseCoordinate> yaw{{5u, 0.1}};
    require(compileNumiHumanSupportPose(placement.model, 0u, placement.q, {},
                placementContacts, activeContacts, yaw, fitted).status ==
                NumiHumanMuscleEquilibriumStatus::invalidSelection,
            "offline support placement changed an unconstrained root heading");

    // The bounded support fit can align a rigid supine plane by translating z
    // and applying world-frame root pitch/roll. It must preserve horizontal
    // root position, all body-local points, and the unit quaternion.
    auto tiltedModel = makeFreeBodyModel();
    std::vector<double> tiltedQ(
        tiltedModel.defaultQ.begin(), tiltedModel.defaultQ.end());
    tiltedQ[0] = -0.05;
    tiltedQ[1] = 0.20;
    tiltedQ[2] = 0.04;
    const double halfX = 0.06;
    const double halfY = -0.045;
    const double sx = std::sin(halfX), cx = std::cos(halfX);
    const double sy = std::sin(halfY), cy = std::cos(halfY);
    tiltedQ[3] = sx * cy;
    tiltedQ[4] = cx * sy;
    tiltedQ[5] = sx * sy;
    tiltedQ[6] = cx * cy;
    const std::vector<NumiHumanStaticSupportContact> tiltedSupports{
        {.bodyIndex=0u, .localPoint={0.0, 0.0, 0.0}},
        {.bodyIndex=0u, .localPoint={0.4, 0.0, 0.0}},
        {.bodyIndex=0u, .localPoint={0.0, 0.6, 0.0}},
        {.bodyIndex=0u, .localPoint={0.2, 0.25, 0.0}},
    };
    const std::vector<std::uint32_t> tiltedActive{0u, 1u, 2u};
    const std::vector<NumiHumanSupportPoseCoordinate> rigidStance{
        {2u, 0.2}, {3u, 0.2}, {4u, 0.2}};
    NumiHumanSupportPoseResult tiltedFit;
    require(compileNumiHumanSupportPose(tiltedModel, 0u, tiltedQ, {},
                tiltedSupports, tiltedActive, rigidStance, tiltedFit).succeeded() &&
                near(tiltedFit.q[0], tiltedQ[0]) &&
                near(tiltedFit.q[1], tiltedQ[1]) &&
                std::all_of(tiltedFit.supportPlaneGapMeters.begin(),
                    tiltedFit.supportPlaneGapMeters.end(),
                    [](const double gap) { return gap >= -1.0e-8 && std::abs(gap) <= 1.0e-7; }),
            "root pitch/roll plus height did not fit a noncollinear supported plane");
    const double fittedQuaternionNorm = std::sqrt(
        tiltedFit.q[3]*tiltedFit.q[3] + tiltedFit.q[4]*tiltedFit.q[4] +
        tiltedFit.q[5]*tiltedFit.q[5] + tiltedFit.q[6]*tiltedFit.q[6]);
    require(near(fittedQuaternionNorm, 1.0, 1.0e-10) &&
                tiltedFit.q != tiltedQ,
            "root support fit failed to publish a normalized changed orientation");
    NumiHumanSupportPoseResult tiltedReplay;
    require(compileNumiHumanSupportPose(tiltedModel, 0u, tiltedQ, {},
                tiltedSupports, tiltedActive, rigidStance, tiltedReplay).succeeded() &&
                tiltedReplay.q == tiltedFit.q &&
                tiltedReplay.supportPlaneGapMeters == tiltedFit.supportPlaneGapMeters &&
                tiltedReplay.iterations == tiltedFit.iterations,
            "root angular support fit did not replay deterministically");
    const std::vector<NumiHumanSupportPoseCoordinate> tooSmallTilt{
        {2u, 0.2}, {3u, 0.001}, {4u, 0.001}};
    require(compileNumiHumanSupportPose(tiltedModel, 0u, tiltedQ, {},
                tiltedSupports, tiltedActive, tooSmallTilt, tiltedFit).status ==
                NumiHumanMuscleEquilibriumStatus::supportPoseInfeasible &&
                tiltedFit.q == tiltedReplay.q,
            "root angular support fit exceeded bounds or mutated accepted output");
    NumiHumanSupportPoseConfig badFit;
    badFit.gapToleranceMeters = std::numeric_limits<double>::quiet_NaN();
    require(compileNumiHumanSupportPose(placement.model, 0u, placement.q, {},
                placementContacts, activeContacts, vertical, fitted, badFit).status ==
                NumiHumanMuscleEquilibriumStatus::invalidConfiguration,
            "offline placement admitted a nonfinite tolerance");
    auto rotatedPlane = touching;
    rotatedPlane.normal = {0.0, 1.0, 0.0};
    rotatedPlane.planePoint = {0.0, 1.0, 0.0};
    placement.q[1] = 1.01;
    const std::vector<NumiHumanStaticSupportContact> rotatedContacts{rotatedPlane};
    const std::vector<NumiHumanSupportPoseCoordinate> horizontal{{1u, 0.02}};
    require(compileNumiHumanSupportPose(placement.model, 0u, placement.q, {},
                rotatedContacts, activeContacts, horizontal, fitted).succeeded() &&
                near(fitted.q[1], 1.0, 1.0e-8) && fitted.q[2] == placement.q[2],
            "placement ignored a translated or rotated authored plane");
    // An analytic two-slider chain with q1 = 2*q0 must use the full
    // equality tangent: world witness displacement is 3*q0, not q0.
    EngineModel sliders;
    MRArticulationGPU sliderArt{};
    sliderArt.rootBody = 0u;
    sliderArt.rootType = MR_ROOT_FIXED;
    sliderArt.firstBody = 0u;
    sliderArt.bodyCount = 3u;
    sliderArt.firstJoint = 0u;
    sliderArt.jointCount = 2u;
    sliderArt.nq = 2u;
    sliderArt.nv = 2u;
    sliders.articulations.push_back(sliderArt);
    sliders.bodies.push_back(body(MR_INVALID_INDEX, MR_INVALID_INDEX, 1.0, {1.0, 1.0, 1.0}));
    for (std::uint32_t i = 0; i < 2; ++i) {
        sliders.bodies.push_back(body(i, i, 1.0, {1.0, 1.0, 1.0}));
        MRJointDescriptorGPU joint{};
        joint.parentBody = i;
        joint.childBody = i + 1;
        joint.jointType = MR_JOINT_PRISMATIC;
        joint.qOffset = i;
        joint.vOffset = i;
        joint.nq = 1u;
        joint.nv = 1u;
        joint.axis0 = f4(0.0, 1.0, 0.0);
        joint.parentRotation = f4(0.0, 0.0, 0.0, 1.0);
        joint.childRotation = f4(0.0, 0.0, 0.0, 1.0);
        sliders.joints.push_back(joint);
        MRDofPropertiesGPU dof{};
        dof.articulationIndex = 0;
        dof.jointIndex = i;
        dof.qIndex = i;
        dof.vIndex = i;
        dof.flags = MR_DOF_FLAG_POSITION_LIMIT;
        dof.limits = f4(-0.1, 0.1, 0.0);
        sliders.dofs.push_back(dof);
    }
    MRNumiHumanJointEqualityGPU equality{};
    equality.indices = {1u, 1u, 0u, 0u};
    equality.referencesAndCoefficients0 = f4(0.0, 0.0, 0.0, 2.0);
    const std::vector<MRNumiHumanJointEqualityGPU> sliderEqualities{equality};
    const std::vector<double> sliderQ{0.01, 0.0};
    const std::vector<NumiHumanStaticSupportContact> sliderContacts{
        {.bodyIndex = 2u, .normal = {0.0, 1.0, 0.0}}};
    const std::vector<NumiHumanSupportPoseCoordinate> sliderCoordinates{{0u, 0.08}};
    NumiHumanSupportPoseConfig singleIteration;
    singleIteration.maximumIterations = 1u;
    require(compileNumiHumanSupportPose(sliders, 0u, sliderQ, sliderEqualities,
                sliderContacts, activeContacts, sliderCoordinates, fitted,
                singleIteration).succeeded() && near(fitted.q[0], 0.0, 1.0e-8) &&
                near(fitted.q[1], 0.0, 1.0e-8),
            "placement omitted the exact source equality tangent");
    auto limitedContacts = sliderContacts;
    limitedContacts[0].planePoint[1] = 0.24;
    require(compileNumiHumanSupportPose(sliders, 0u, sliderQ, sliderEqualities,
                limitedContacts, activeContacts, sliderCoordinates, fitted).status ==
                NumiHumanMuscleEquilibriumStatus::supportPoseInfeasible,
            "placement violated an equality-dependent source joint limit");
    const std::vector<NumiHumanSupportPoseCoordinate> dependentSelection{{1u, 0.08}};
    require(compileNumiHumanSupportPose(sliders, 0u, sliderQ, sliderEqualities,
                sliderContacts, activeContacts, dependentSelection, fitted).status ==
                NumiHumanMuscleEquilibriumStatus::invalidSelection,
            "placement admitted direct actuation of an equality dependent");
    // The two serial, unit-mass sliders have M=[[2,1],[1,1]]. These
    // force/acceleration pairs distinguish complementarity from force clipping.
    Fixture reactions;
    reactions.model = sliders;
    reactions.q = {0.0, 0.0};
    reactions.model.world.gravityAndTimestep = f4(0, 0, 0, 0.0001);
    reactions.model.dofs[0].limits = f4(0, 1, 0);
    reactions.model.dofs[1].limits = f4(-10, 10, 0);
    std::vector<double> mass(4u);
    require(computeArticulatedMassMatrix(reactions.model, 0u, reactions.q, mass).succeeded() &&
            near(mass[0], 2) && near(mass[1], 1) && near(mass[2], 1) && near(mass[3], 1),
            "analytic coupled-slider mass changed");
    const auto compileReaction = [&](double f0, double f1,
                                    const std::vector<MRNumiHumanJointEqualityGPU>& eqs = {}) {
        const std::vector<NumiHumanPassiveCoordinateCoupling> loads{
            {0u, 0u, reactions.q[0] + f0, 1.0},
            {1u, 1u, reactions.q[1] + f1, 1.0}};
        NumiHumanMuscleEquilibriumResult result;
        const auto diagnostics = compileNumiHumanMuscleEquilibrium(
            reactions.model, 0u, reactions.q, reactions.sites, {}, reactions.muscles,
            reactions.architectures, eqs, {}, {}, loads, result, reactions.config);
        require(diagnostics.succeeded() && diagnostics.positionLimitKktResidual < 1.0e-8,
                "coupled reaction compile or physical KKT certificate failed");
        require(result.q == reactions.q, "reaction solve clamped coordinates");
        for (std::size_t row = 0u; row < 2u; ++row) {
            const double inertial = mass[2u * row] * result.generalizedAccelerationResidual[0] +
                mass[2u * row + 1u] * result.generalizedAccelerationResidual[1];
            require(near(inertial, result.generalizedForceResidual[row]),
                    "reported equality/stop reaction does not satisfy full M*a=f");
        }
        return result;
    };
    const auto intoStop = compileReaction(1, 3);
    require(near(intoStop.generalizedPositionLimitForce[0], 2) &&
            near(intoStop.generalizedAccelerationResidual[0], 0) &&
            near(intoStop.generalizedAccelerationResidual[1], 3) &&
            intoStop.diagnostics.activeStructuralLockCount == 0u &&
            intoStop.diagnostics.activeFiniteRangePositionLimitCount == 1u &&
            intoStop.diagnostics.maximumFiniteRangePositionLimitReactionDof == 0u &&
            near(intoStop.diagnostics.maximumFiniteRangePositionLimitReaction, 2),
            "positive coordinate force hid or misclassified a finite-range stop");
    const auto awayFromStop = compileReaction(-1, -3);
    require(near(awayFromStop.generalizedPositionLimitForce[0], 0) &&
            near(awayFromStop.generalizedAccelerationResidual[0], 2) &&
            near(awayFromStop.generalizedAccelerationResidual[1], -5) &&
            awayFromStop.diagnostics.activeStructuralLockCount == 0u &&
            awayFromStop.diagnostics.activeFiniteRangePositionLimitCount == 0u &&
            awayFromStop.diagnostics.maximumStructuralLockReactionDof == MR_INVALID_INDEX &&
            awayFromStop.diagnostics.maximumFiniteRangePositionLimitReactionDof == MR_INVALID_INDEX,
            "outward acceleration received or reported a spurious joint-stop force");
    reactions.model.dofs[0].limits = f4(-1, 0, 0);
    const auto upperStop = compileReaction(-1, -3);
    require(near(upperStop.generalizedPositionLimitForce[0], -2) &&
            near(upperStop.generalizedAccelerationResidual[0], 0) &&
            near(upperStop.generalizedAccelerationResidual[1], -3),
            "upper-stop reaction used the wrong sign");
    reactions.model.dofs[0].limits = f4(0, 0, 0);
    const auto collapsedRange = compileReaction(1, 3);
    require(near(collapsedRange.generalizedPositionLimitForce[0], 2) &&
            near(collapsedRange.generalizedAccelerationResidual[0], 0) &&
            collapsedRange.diagnostics.activeStructuralLockCount == 1u &&
            collapsedRange.diagnostics.activeFiniteRangePositionLimitCount == 0u &&
            collapsedRange.diagnostics.maximumStructuralLockReactionDof == 0u &&
            near(collapsedRange.diagnostics.maximumStructuralLockReaction, 2),
            "coincident lower and upper stops failed structural-lock classification");
    reactions.model.dofs[0].limits = f4(0, 1, 0);
    reactions.model.dofs[1].limits = f4(0, 1, 0);
    const auto bothStops = compileReaction(-3, -1);
    require(near(bothStops.generalizedPositionLimitForce[0], 3) &&
            near(bothStops.generalizedPositionLimitForce[1], 1) && bothStops.diagnostics.balanced,
            "reaction at one stop failed to activate the coupled second stop");
    reactions.model.dofs[0].limits = f4(-1, 1, 0);
    auto reversedEquality = equality;
    reversedEquality.referencesAndCoefficients0.w = -2.0f;
    const std::vector<MRNumiHumanJointEqualityGPU> reversedEqualities{reversedEquality};
    const auto dependentStop = compileReaction(2, 0, reversedEqualities);
    require(near(dependentStop.generalizedPositionLimitForce[1], 1) &&
            dependentStop.diagnostics.balanced &&
            near(dependentStop.generalizedJointEqualityForce[0], -2) &&
            near(dependentStop.generalizedJointEqualityForce[1], -1),
            "equality-dependent stop omitted its signed source tangent");
    reactions.model.dofs[1].limits = f4(-1, 1, 0);
    const auto freeEquality = compileReaction(2, 0, reversedEqualities);
    require(near(freeEquality.generalizedAccelerationResidual[0], 1) &&
            near(freeEquality.generalizedAccelerationResidual[1], -2) &&
            near(freeEquality.generalizedJointEqualityForce[0], -2) &&
            near(freeEquality.generalizedJointEqualityForce[1], -1),
            "equality acceleration was zeroed instead of lifted through the tangent");
    reactions.model.dofs[0].limits = f4(0, 1, 0);
    reactions.model.dofs[1].limits = f4(0, 1, 0);
    const auto redundantStops = compileReaction(-2, -1, sliderEqualities);
    require(redundantStops.diagnostics.balanced &&
            near(redundantStops.generalizedPositionLimitForce[0] +
                 2 * redundantStops.generalizedPositionLimitForce[1], 4),
            "redundant equality-linked source stops failed complementarity");
    const auto repeatedStops = compileReaction(-2, -1, sliderEqualities);
    require(redundantStops.generalizedPositionLimitForce == repeatedStops.generalizedPositionLimitForce &&
            redundantStops.generalizedAccelerationResidual == repeatedStops.generalizedAccelerationResidual,
            "coupled source-stop reaction replay changed");
    auto preservedReaction = redundantStops;
    reactions.q[0] = -0.01;
    const auto invalidInitial = compileNumiHumanMuscleEquilibrium(
        reactions.model, 0u, reactions.q, reactions.sites, {}, reactions.muscles,
        reactions.architectures, {}, {}, preservedReaction, reactions.config);
    require(invalidInitial.status == NumiHumanMuscleEquilibriumStatus::positionLimitViolation &&
            invalidInitial.failingIndex == 0u && preservedReaction.q == redundantStops.q &&
            preservedReaction.generalizedPositionLimitForce == redundantStops.generalizedPositionLimitForce,
            "penetrated initial joint received a static certificate or changed the destination");
    reactions.q[0] = 0.0;
    auto invalidEquality = equality;
    invalidEquality.indices.z = MR_INVALID_INDEX;
    invalidEquality.indices.w = MR_INVALID_INDEX;
    invalidEquality.referencesAndCoefficients0 = f4(0, 0, 2, 0);
    const std::vector<MRNumiHumanJointEqualityGPU> invalidEqualities{invalidEquality};
    const auto invalidDependent = compileNumiHumanMuscleEquilibrium(
        reactions.model, 0u, reactions.q, reactions.sites, {}, reactions.muscles,
        reactions.architectures, invalidEqualities, {}, preservedReaction, reactions.config);
    require(invalidDependent.status == NumiHumanMuscleEquilibriumStatus::positionLimitViolation &&
            invalidDependent.failingIndex == 1u && preservedReaction.q == redundantStops.q,
            "fixed equality projected a dependent outside its source limits");
    // Rotate the second slider: M=[[2,.8],[.8,1]] and the spanning
    // muscle changes f by [F,.8F]. The active-stop derivative [0,.8]
    // differs from the free derivative. Balance requires F=-3.75, lambda=2.75;
    // the activation regularizer permits a small, bounded residual.
    reactions.model.joints[1].axis0 = f4(0.6, 0.8, 0.0);
    reactions.muscles[0].gainParameters[2] = 10.0;
    reactions.muscles[0].biasParameters[2] = 10.0;
    reactions.model.dofs[1].limits = f4(-10, 10, 0);
    const std::vector<MujocoMuscleSite> recruitingSites{
        {0u, {0.0, 0.0, 0.0}}, {2u, {0.0, 1.0, 0.0}}};
    const std::vector<NumiHumanPassiveCoordinateCoupling> recruitingLoads{
        {0u, 0u, 1.0, 1.0}, {1u, 1u, 3.0, 1.0}};
    NumiHumanMuscleEquilibriumResult recruitedReaction;
    const auto recruitedDiagnostics = compileNumiHumanMuscleEquilibrium(
            reactions.model, 0u, reactions.q, recruitingSites, {}, reactions.muscles,
            reactions.architectures, {}, {}, {}, recruitingLoads,
            recruitedReaction, reactions.config);
    require(recruitedDiagnostics.succeeded() &&
            recruitedReaction.diagnostics.balanced &&
            recruitedReaction.activation[0] > 0.0 &&
            near(recruitedReaction.generalizedPositionLimitForce[0], 2.75, 5.0e-4),
            "recruitment did not balance a coupled joint-stop load");
    // An optional stop-load cost must never replace an already balanced
    // solution with an unbalanced one. Here lowering F reduces the stop
    // reaction, but leaves an acceleration on the second slider.
    auto stopConfig = reactions.config;
    stopConfig.poseSweeps = 0u;
    stopConfig.activationRegularization = 0.0;
    stopConfig.globalActivationPolishIterations = 12u;
    stopConfig.finiteRangePositionLimitResidualIncreaseTolerance = 1.0e-12;
    const auto compileStopPolicy = [&](const auto& model, const auto& config) {
        NumiHumanMuscleEquilibriumResult output;
        const auto status = compileNumiHumanMuscleEquilibrium(
            model, 0u, reactions.q, recruitingSites, {}, reactions.muscles,
            reactions.architectures, {}, {}, {}, recruitingLoads,
            output, config);
        require(status.succeeded(), "stop-load recruitment failed");
        return output;
    };
    const auto balancedStopBaseline = compileStopPolicy(reactions.model, stopConfig);
    require(balancedStopBaseline.diagnostics.balanced,
            "analytic stop-policy baseline lost balance");
    for (double penalty : {1e-5, 1e-3, 1.0, 1000.0}) {
        stopConfig.finiteRangePositionLimitReactionRegularization = penalty;
        const auto output = compileStopPolicy(reactions.model, stopConfig);
        std::cerr << "stop_policy_probe weight=" << penalty
                  << " residual=" << output.diagnostics.normalizedResidualRms
                  << " reaction=" << output.generalizedPositionLimitForce[0]
                  << " baseline=" << balancedStopBaseline.generalizedPositionLimitForce[0] << '\n';
        require(output.diagnostics.balanced &&
                output.diagnostics.normalizedResidualRms <= stopConfig.balanceTolerance &&
                output.diagnostics.normalizedResidualRms <=
                    balancedStopBaseline.diagnostics.normalizedResidualRms +
                        stopConfig.finiteRangePositionLimitResidualIncreaseTolerance,
                "optional stop-load penalty worsened the primary physical residual");
        require(output.q == balancedStopBaseline.q &&
                output.diagnostics.positionLimitKktResidual <= 1e-8 &&
                output.activation[0] >= 0.0 && output.activation[0] <= stopConfig.activationLimit,
                "stop-load refinement changed pose, feasibility or actuator limits");
        require(std::abs(output.generalizedPositionLimitForce[0]) <=
                std::abs(balancedStopBaseline.generalizedPositionLimitForce[0]) + 1e-8,
                "stop-load refinement increased the stop reaction");
        const auto replayed = compileStopPolicy(reactions.model, stopConfig);
        require(replayed.activation == output.activation && replayed.fiberLength == output.fiberLength &&
                replayed.generalizedForceResidual == output.generalizedForceResidual,
                "balance-preserving stop refinement did not replay exactly");
    }
    stopConfig.finiteRangePositionLimitReactionRegularization = 0.0;
    stopConfig.activationLimit = 0.001;
    const auto infeasibleBaseline = compileStopPolicy(reactions.model, stopConfig);
    require(!infeasibleBaseline.diagnostics.balanced,
            "analytic infeasible stop case unexpectedly balanced");
    stopConfig.finiteRangePositionLimitReactionRegularization = 1000.0;
    const auto infeasibleStop = compileStopPolicy(reactions.model, stopConfig);
    require(!infeasibleStop.diagnostics.balanced &&
            infeasibleStop.activation == infeasibleBaseline.activation &&
            infeasibleStop.generalizedAccelerationResidual == infeasibleBaseline.generalizedAccelerationResidual,
            "optional stop phase changed or promoted an infeasible baseline");

    // Redundant recruitment can unload a stop WITHOUT needing residual
    // tolerance: one route pulls both sliders, the other opposes the distal
    // component. This is an analytic force-sharing problem, not an oracle
    // made from the optimizer's reaction projection.
    auto redundantModel = reactions.model;
    redundantModel.joints[1].axis0 = f4(0, 1, 0);
    const std::vector<MujocoMuscleSite> unloadSites{
        {0u, {0,1,0}}, {2u, {0,0,0}}, {1u, {0,0,0}}, {2u, {0,1,0}}};
    std::vector<MujocoMuscleDefinition> unloadMuscles(2u, reactions.muscles[0]);
    unloadMuscles[0].route = {{MujocoRouteNodeType::site, 0u}, {MujocoRouteNodeType::site, 1u}};
    unloadMuscles[1].route = {{MujocoRouteNodeType::site, 2u}, {MujocoRouteNodeType::site, 3u}};
    const std::vector<MujocoCompliantMuscleArchitecture> unloadArchitectures(2u);
    const std::vector<NumiHumanPassiveCoordinateCoupling> unloadLoads{{0u, 0u, -1.0, 1.0}};
    auto unloadConfig = reactions.config;
    unloadConfig.activationRegularization = 0.0;
    unloadConfig.globalActivationPolishIterations = 24u;
    unloadConfig.finiteRangePositionLimitResidualIncreaseTolerance = -1.0;
    unloadConfig.finiteRangePositionLimitReactionRegularization = 1.0;
    NumiHumanMuscleEquilibriumResult unloaded;
    require(compileNumiHumanMuscleEquilibrium(redundantModel, 0u, reactions.q,
        unloadSites, {}, unloadMuscles, unloadArchitectures, {}, {}, {},
        unloadLoads, unloaded, unloadConfig).succeeded() && unloaded.diagnostics.balanced &&
        unloaded.diagnostics.normalizedResidualRms < 1e-6 &&
        std::abs(unloaded.generalizedPositionLimitForce[0]) < 1e-5 &&
        near(unloaded.muscleTendonForce[0], -1.0, 1e-5) &&
        near(unloaded.muscleTendonForce[1], -1.0, 1e-5),
        "redundant recruitment did not unload the analytic stop with real muscles");
    require(unloaded.q == reactions.q && unloaded.diagnostics.positionLimitKktResidual <= 1e-8,
        "analytic stop unloading changed pose or physical complementarity");
    // Collapsed structural locks carry legitimate reaction and cost zero.
    redundantModel.dofs[0].limits = f4(0, 0, 0);
    NumiHumanMuscleEquilibriumResult lockedBaseline, lockedPenalty;
    unloadConfig.finiteRangePositionLimitReactionRegularization = 0.0;
    require(compileNumiHumanMuscleEquilibrium(redundantModel, 0u, reactions.q,
        unloadSites, {}, unloadMuscles, unloadArchitectures, {}, {}, {},
        unloadLoads, lockedBaseline, unloadConfig).succeeded(), "locked baseline failed");
    unloadConfig.finiteRangePositionLimitReactionRegularization = 1000.0;
    require(compileNumiHumanMuscleEquilibrium(redundantModel, 0u, reactions.q,
        unloadSites, {}, unloadMuscles, unloadArchitectures, {}, {}, {},
        unloadLoads, lockedPenalty, unloadConfig).succeeded() &&
        lockedPenalty.activation == lockedBaseline.activation &&
        lockedPenalty.generalizedPositionLimitForce == lockedBaseline.generalizedPositionLimitForce,
        "stop-load preference penalized an authored structural lock");

    // Two coupled serial sliders: a proximal muscle supplies [-1,0]F and
    // a spanning muscle [-1,-1]F. The exact tension solution for loads [5,2]
    // is [3,2]. A single ordered sweep cannot resolve this force sharing.
    auto coupledModel = reactions.model;
    coupledModel.joints[1].axis0 = f4(0.0, 1.0, 0.0);
    coupledModel.dofs[0].limits = coupledModel.dofs[1].limits = f4(-10, 10, 0);
    const std::vector<MujocoMuscleSite> coupledSites{
        {0u, {0,0,0}}, {1u, {0,1,0}}, {2u, {0,1,0}}};
    std::vector<MujocoMuscleDefinition> coupledMuscles(2u, reactions.muscles[0]);
    coupledMuscles[0].route = {{MujocoRouteNodeType::site, 0u}, {MujocoRouteNodeType::site, 1u}};
    coupledMuscles[1].route = {{MujocoRouteNodeType::site, 0u}, {MujocoRouteNodeType::site, 2u}};
    const std::vector<MujocoCompliantMuscleArchitecture> coupledArchitectures(2u);
    // Recruitment through the compliant preparation owner: gravity supplies
    // [2,1] on two unit-mass sliders. Both muscle tensions must be exactly 1.
    auto compliantModel=coupledModel;compliantModel.world.gravityAndTimestep=f4(0,1,0,0.0001);
    NumiHumanCompliantEquilibriumConfig compliantConfig;
    compliantConfig.optimizeActivation=true;compliantConfig.accelerationTolerance=1e-6;
    const std::vector<double> coldActivation(2,0);
    NumiHumanCompliantEquilibriumResult compliantResult,compliantReplay;
    const auto prepareCompliant=[&](auto& output) {
        return compileNumiHumanCompliantEquilibrium(compliantModel,0,reactions.q,coldActivation,
            coupledSites,{},coupledMuscles,coupledArchitectures,{},{},{},output,compliantConfig);
    };
    require(prepareCompliant(compliantResult).succeeded() && compliantResult.state.diagnostics.balanced &&
        near(compliantResult.state.muscleTendonForce[0],-1,1e-6) && near(compliantResult.state.muscleTendonForce[1],-1,1e-6),
        "source-compliant recruitment missed analytic gravity balance");
    require(prepareCompliant(compliantReplay).succeeded() && compliantReplay.state.activation==compliantResult.state.activation &&
        compliantReplay.state.q==compliantResult.state.q,"compliant recruitment replay changed");
    compliantModel.world.gravityAndTimestep.y=1e6f;
    require(prepareCompliant(compliantReplay).succeeded() && !compliantReplay.state.diagnostics.balanced &&
        std::all_of(compliantReplay.state.activation.begin(),compliantReplay.state.activation.end(),[](double a){return a>=0 && a<=1;}),
        "infeasible compliant recruitment waived actuator bounds");
    const std::vector<NumiHumanPassiveCoordinateCoupling> coupledLoads{
        {0u, 0u, 5.0, 1.0}, {1u, 1u, 2.0, 1.0}};
    auto coupledConfig = reactions.config;
    coupledConfig.activationSweeps = 1u;
    coupledConfig.activationRegularization = 0.0;
    coupledConfig.globalActivationPolishIterations = 12u;
    const auto recruitCoupled = [&](const std::vector<MujocoMuscleDefinition>& definitions) {
        NumiHumanMuscleEquilibriumResult result;
        require(compileNumiHumanMuscleEquilibrium(coupledModel, 0u, reactions.q,
            coupledSites, {}, definitions, coupledArchitectures, {}, {}, {},
            coupledLoads, result, coupledConfig).succeeded(),
            "coupled recruitment proposal failed");
        return result;
    };
    const auto coupledResult = recruitCoupled(coupledMuscles);
    require(coupledResult.diagnostics.normalizedResidualRms < 1.0e-6 &&
            near(coupledResult.muscleTendonForce[0], -3.0, 1.0e-5) &&
            near(coupledResult.muscleTendonForce[1], -2.0, 1.0e-5),
            "coupled polish did not recover analytic muscle force sharing");
    std::swap(coupledMuscles[0], coupledMuscles[1]);
    const auto reversedResult = recruitCoupled(coupledMuscles);
    require(reversedResult.diagnostics.normalizedResidualRms < 1.0e-6 &&
            near(reversedResult.activation[1], coupledResult.activation[0], 1.0e-6) &&
            near(reversedResult.activation[0], coupledResult.activation[1], 1.0e-6),
            "coupled recruitment retained muscle ordering bias");
    const auto coupledReplay = recruitCoupled(coupledMuscles);
    require(coupledReplay.activation == reversedResult.activation &&
            coupledReplay.generalizedAccelerationResidual == reversedResult.generalizedAccelerationResidual,
            "coupled recruitment changed exact replay");
    coupledConfig.activationLimit = 0.05;
    const auto limitedRecruitment = recruitCoupled(coupledMuscles);
    require(!limitedRecruitment.diagnostics.balanced &&
            limitedRecruitment.activation[0] <= coupledConfig.activationLimit &&
            limitedRecruitment.activation[1] <= coupledConfig.activationLimit &&
            limitedRecruitment.q == reactions.q,
            "infeasible recruitment waived activation bounds or changed the posture");
    // With no generalized muscle moment arm, two independent spring loads
    // require both coordinates to move in the same accepted posture update.
    // One scalar trial alone cannot reach the analytic equilibrium [5,2].
    for (auto& definition : coupledMuscles) {
        definition.route = {{MujocoRouteNodeType::site, 0u}, {MujocoRouteNodeType::site, 1u}};
    }
    const std::vector<MujocoMuscleSite> postureSites{{0u,{0,0,0}}, {0u,{0,1,0}}};
    coupledConfig.poseSweeps = 1u;
    coupledConfig.poseStepFraction = 0.3;
    coupledConfig.maximumPoseStep = 6.0;
    coupledConfig.poseRegularization = 0.0;
    NumiHumanMuscleEquilibriumResult postureResult;
    require(compileNumiHumanMuscleEquilibrium(coupledModel, 0u, reactions.q,
        postureSites, {}, coupledMuscles, coupledArchitectures, {}, {}, {},
        coupledLoads, postureResult, coupledConfig).succeeded() &&
        postureResult.diagnostics.normalizedResidualRms < 1.0e-6 &&
        near(postureResult.q[0], 5.0, 1.0e-5) && near(postureResult.q[1], 2.0, 1.0e-5) &&
        postureResult.diagnostics.acceptedPoseSteps == 1u,
        "coupled posture proposal missed the analytic two-coordinate equilibrium");
    require(postureResult.searchTrace.size() == 3u &&
            postureResult.searchTrace[0].kind == 0u && postureResult.searchTrace[1].kind == 1u &&
            postureResult.searchTrace[1].coupledPoseProposal && postureResult.searchTrace[2].kind == 2u &&
            postureResult.searchTrace[1].objective < postureResult.searchTrace[0].objective &&
            near(postureResult.searchTrace.back().normalizedResidualRms, postureResult.diagnostics.normalizedResidualRms),
            "accepted search history lost a coupled update or disagreed with its certificate");
    // A captured external generalized load is an applied force term, bound
    // to one exact model and frozen pose. It remains separate from authored
    // muscle, support, passive, and gravity owners.
    Fixture externalLoadFixture;
    externalLoadFixture.model.world.gravityAndTimestep = {0.0f, 0.0f, 0.0f, 0.0001f};
    externalLoadFixture.config.poseSweeps = 0u;
    externalLoadFixture.config.activationSweeps = 1u;
    externalLoadFixture.config.globalActivationPolishIterations = 2u;
    const std::vector<NumiHumanStaticSupportContact> externalLoadSupports{
        {.bodyIndex = 0u, .localPoint = {0.0, 0.0, 0.0},
         .normal = {0.0, 0.0, 1.0}, .planePoint = {0.0, 0.0, 0.0}}};
    NumiHumanMuscleEquilibriumResult noExternalResult;
    require(compileNumiHumanMuscleEquilibrium(
        externalLoadFixture.model, 0u, externalLoadFixture.q,
        externalLoadFixture.sites, {}, externalLoadFixture.muscles,
        externalLoadFixture.architectures, {}, {}, externalLoadSupports, {},
        noExternalResult, externalLoadFixture.config).succeeded(),
        "frozen-pose no-load baseline failed");
    const std::vector<double> externalForce{0.0, 3.0, 0.0, 0.0, 0.0, 0.0};
    NumiHumanStaticExternalGeneralizedLoad externalLoad{
        externalForce, externalLoadFixture.q,
        numiHumanStaticSupportModelFingerprint(externalLoadFixture.model, 0u)};
    NumiHumanMuscleEquilibriumResult withExternalResult;
    require(compileNumiHumanMuscleEquilibrium(
        externalLoadFixture.model, 0u, externalLoadFixture.q,
        externalLoadFixture.sites, {}, externalLoadFixture.muscles,
        externalLoadFixture.architectures, {}, {}, externalLoadSupports, {},
        withExternalResult, externalLoadFixture.config, &externalLoad).succeeded() &&
        withExternalResult.generalizedForceResidual.size() == 6u &&
        near(withExternalResult.generalizedForceResidual[1] -
             noExternalResult.generalizedForceResidual[1], 3.0, 1.0e-5),
        "frozen FEM generalized load was not included once in physical balance");
    // A captured FEM generalized load is itself an external support wrench.
    // With no synthetic rigid support rows, it must still put the floating
    // root into the same force/acceleration certificate as internal DOFs.
    externalLoadFixture.model.world.gravityAndTimestep =
        {0.0f, 0.0f, -9.81f, 0.0001f};
    ArticulatedDynamicsConfig rootLoadDynamics;
    // Use the exact source Float32 gravity for the independent oracle.
    rootLoadDynamics.gravity = {
        externalLoadFixture.model.world.gravityAndTimestep.x,
        externalLoadFixture.model.world.gravityAndTimestep.y,
        externalLoadFixture.model.world.gravityAndTimestep.z,
    };
    rootLoadDynamics.timestep = externalLoadFixture.config.timestep;
    const std::vector<double> rootZero(6u, 0.0);
    std::vector<double> rootWeightLoad(6u, 0.0);
    require(computeArticulatedInverseDynamics(
        externalLoadFixture.model, 0u, externalLoadFixture.q,
        rootZero, rootZero, {}, rootWeightLoad, rootLoadDynamics).succeeded() &&
        near(rootWeightLoad[2], 2.5 * 9.81, 1.0e-5),
        "analytic floating-root weight reference changed");
    NumiHumanStaticExternalGeneralizedLoad rootWeightExternalLoad{
        rootWeightLoad, externalLoadFixture.q,
        numiHumanStaticSupportModelFingerprint(externalLoadFixture.model, 0u)};
    NumiHumanMuscleEquilibriumResult rootBalancedResult;
    const auto rootBalancedDiagnostics = compileNumiHumanMuscleEquilibrium(
        externalLoadFixture.model, 0u, externalLoadFixture.q,
        externalLoadFixture.sites, {}, externalLoadFixture.muscles,
        externalLoadFixture.architectures, {}, {}, {}, {},
        rootBalancedResult, externalLoadFixture.config, &rootWeightExternalLoad);
    require(rootBalancedDiagnostics.succeeded() &&
            rootBalancedResult.diagnostics.floatingRootIncluded &&
            rootBalancedResult.diagnostics.balanced &&
            rootBalancedResult.diagnostics.maximumFloatingRootForceResidual <= 1.0e-6 &&
            rootBalancedResult.diagnostics.maximumFloatingRootAccelerationResidual <= 1.0e-6,
            "external FEM root-weight load did not pass the no-synthetic-support certificate");

    auto wrongRootLoad = rootWeightExternalLoad;
    auto wrongRootForce = rootWeightLoad;
    wrongRootForce[2] = 0.0;
    wrongRootLoad.generalizedForce = wrongRootForce;
    NumiHumanMuscleEquilibriumResult wrongRootResult;
    const auto wrongRootDiagnostics = compileNumiHumanMuscleEquilibrium(
        externalLoadFixture.model, 0u, externalLoadFixture.q,
        externalLoadFixture.sites, {}, externalLoadFixture.muscles,
        externalLoadFixture.architectures, {}, {}, {}, {},
        wrongRootResult, externalLoadFixture.config, &wrongRootLoad);
    require(wrongRootDiagnostics.succeeded() &&
            wrongRootResult.diagnostics.floatingRootIncluded &&
            !wrongRootResult.diagnostics.balanced &&
            wrongRootResult.diagnostics.maximumFloatingRootForceResidual > 1.0 &&
            wrongRootResult.diagnostics.maximumFloatingRootAccelerationResidual > 0.1,
            "incorrect external FEM root load passed the no-synthetic-support certificate");

    auto wrongPose = externalLoad;
    std::vector<double> mismatchedQ = externalLoadFixture.q;
    mismatchedQ[0] += 0.01;
    wrongPose.referenceQ = mismatchedQ;
    NumiHumanMuscleEquilibriumResult rejectedExternalResult;
    require(compileNumiHumanMuscleEquilibrium(
        externalLoadFixture.model, 0u, externalLoadFixture.q,
        externalLoadFixture.sites, {}, externalLoadFixture.muscles,
        externalLoadFixture.architectures, {}, {}, externalLoadSupports, {},
        rejectedExternalResult, externalLoadFixture.config, &wrongPose).status ==
            NumiHumanMuscleEquilibriumStatus::invalidConfiguration,
        "external load accepted a mismatched source pose");
    auto wrongModel = externalLoad;
    wrongModel.modelFingerprint ^= 1u;
    require(compileNumiHumanMuscleEquilibrium(
        externalLoadFixture.model, 0u, externalLoadFixture.q,
        externalLoadFixture.sites, {}, externalLoadFixture.muscles,
        externalLoadFixture.architectures, {}, {}, externalLoadSupports, {},
        rejectedExternalResult, externalLoadFixture.config, &wrongModel).status ==
            NumiHumanMuscleEquilibriumStatus::invalidConfiguration,
        "external load accepted a mismatched source model");

    std::cout << "numi_human_static_support_test=passed"
              << " source_compliant_preparation=passed compliant_recruitment=passed"
              << " coupled_recruitment=passed recruitment_bounds=passed"
              << " coupled_posture=passed"
              << " accepted_external_generalized_load=passed"
              << " external_floating_root_certificate=passed"
              << " analytic_body_spatial_reference=passed"
              << " coupled_limit_reactions=passed dependent_acceleration=passed"
              << " balance_preserving_stop_refinement=passed redundant_stop_unloading=passed"
              << " analytic_weight_n=" << replay.supportNormalForce[0]
              << " replay=exact penetration=rejected airborne_force_n=0\n";
}

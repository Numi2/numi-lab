#!/usr/bin/env python3
"""Source contract for exact alpha-zero FEM force reuse.

This does not replace a native GPU equivalence test. It protects the narrow
control-flow contract until a focused GPU fixture is available.
"""
from pathlib import Path
import re
import unittest

ROOT = Path(__file__).resolve().parents[1]
RUNTIME = (ROOT / "src/runtime.mm").read_text()
FEM = (ROOT / "src/metal/fem.metalinc").read_text()
NATIVE = (ROOT / "tools/fgmres_true_residual_native_check.mm").read_text()


class AlphaZeroForceReuseContract(unittest.TestCase):
    def test_opt_in_is_strict_and_default_off(self):
        self.assertIn('"NM_FEM_ARMIJO_ZERO_ALPHA_FORCE_REUSE"', RUNTIME)
        self.assertRegex(RUNTIME, r'armijoZeroAlphaForceReuseSetting, "0"')
        self.assertRegex(RUNTIME, r'armijoZeroAlphaForceReuseSetting, "1"')
        self.assertIn("femArmijoZeroAlphaForceReuseRequested = false", RUNTIME)
        self.assertIn("armijoTrialLoopActive && environments == 1u", RUNTIME)
        for gate in ("!status5Selected", "!femCoupledTrialCaptureSelected",
                     "!femResidualArmijoTraceEnabled", "!femCoupledTrialSummaryMode",
                     "!state.femOperatorFDRichCaptureEnabled"):
            self.assertIn(gate, RUNTIME)

    def test_only_alpha_zero_can_empty_tetrahedron_dispatch(self):
        for name in ("nm_fem_armijo_begin_trial", "nm_fem_armijo_begin_bounded_trial"):
            body = FEM.split("kernel void " + name, 1)[1].split("\nkernel void ", 1)[0]
            self.assertIn("trialIndex == 0u", body)
            self.assertIn("environmentHealthy(baseStatuses, environment)", body)
            self.assertIn("reuseZeroAlphaForces", body)
            self.assertIn("accepted && (publishTrialDispatchMode & 1u)", body)
            if name.endswith("bounded_trial"):
                self.assertIn("alpha == 0.0f", body)
            else:
                self.assertIn("alpha == 0.0f", body)
            self.assertIn("nodeGroups", body)
            self.assertIn("tetrahedronGroups", body)
            self.assertIn("const float alpha =", body)
            self.assertLess(body.index("const float alpha ="),
                            body.index("const bool reuseZeroAlphaForces"))
            if name.endswith("begin_trial"):
                self.assertIn("skipAllTrialNodes", body)
            else:
                self.assertIn("accepted && (publishTrialDispatchMode & 1u)", body)
        prepare = FEM.split("inline NMFEMNodeStateGPU femTrialNodeAtAlpha", 1)[1].split("kernel void ", 1)[0]
        self.assertIn("!(alpha > 0.0f)", prepare)
        self.assertIn("return next", prepare)

    def test_copy_requires_healthy_base_and_trial_statuses(self):
        body = FEM.split("kernel void nm_fem_armijo_reuse_zero_alpha_internal_forces", 1)[1].split("\nkernel void ", 1)[0]
        self.assertIn("metrics[environment].z != 0.0f", body)
        self.assertIn("environmentHealthy(trialStatuses, environment)", body)
        self.assertIn("environmentHealthy(baseStatuses, environment)", body)
        self.assertIn("trialForces[global] = currentForces[global]", body)

    def test_native_fixture_covers_zero_positive_unhealthy_and_bounded_cases(self):
        self.assertIn("--armijo-zero-alpha-force-reuse-only", NATIVE)
        self.assertGreaterEqual(NATIVE.count("checkArmijoZeroAlphaForceReuse(device, queue, library)"), 2)
        for evidence in ("healthy alpha-zero trial", "positive-alpha first trial",
                         "unhealthy base status", "zero feasible alpha"):
            self.assertIn(evidence, NATIVE)

    def test_both_production_armijo_owners_reuse_only_fem_force(self):
        calls = [m.start() for m in re.finditer(r"reuseArmijoInternalForcesAtZeroAlpha\(\);", RUNTIME)]
        forces = [m.start() for m in re.finditer(r'dispatchThreads\(\s*"nm_fem_internal_forces"', RUNTIME)]
        self.assertEqual(len(calls), 2)
        self.assertGreaterEqual(len(forces), 2)
        for pos in calls:
            force = next((offset for offset in forces if offset > pos), None)
            self.assertIsNotNone(force)
            self.assertLess(force - pos, 5000)
            nearby = RUNTIME[force:force + 4000]
            self.assertIn("WorkDomain::armijoTrialTetrahedra", nearby)
        self.assertIn('"nm_fem_armijo_reuse_zero_alpha_internal_forces"', RUNTIME)
        self.assertGreater(RUNTIME.count('"nm_fem_armijo_validate_geometry"'), 0)
        for name in ("nm_fem_armijo_begin_trial", "nm_fem_armijo_begin_bounded_trial"):
            match = re.search(r'dispatchThreads\(\s*"' + name + r'"', RUNTIME)
            self.assertIsNotNone(match)
            region = RUNTIME[match.start():match.start() + 2400]
            self.assertIn("atIndex:10u", region)
        self.assertIn("femArmijoLaterTrialDispatchEnabledForCurrentRoot ? 1u : 0u", RUNTIME)
        self.assertIn("nm_fem_armijo_decide", FEM)
        self.assertIn("certifiedNoop", FEM)


if __name__ == "__main__":
    unittest.main(verbosity=2)

#!/usr/bin/env python3
"""Prepare or explicitly execute the bounded build182 row-32 low-word replay.

Default mode only writes immutable invocation metadata. Pass --execute to run
on the Numi host; this script was prepared without invoking the GPU.
"""
import argparse
import datetime
import hashlib
import json
import os
import pathlib
import subprocess
import sys
import time

ROOT = pathlib.Path("/Users/numi/numi-human-aortic-contact-opt-20261019")
EVIDENCE = ROOT / "matter/tools/evidence/human-resting-20261005/supported-continuation-20261020/metal-optimization-078"
SOURCE_INVOCATION = EVIDENCE / "build161-supported-prelude40-125us-simd32-prefix-icb-1/invocation.json"
PROVENANCE = EVIDENCE / "native-build182-source-provenance.json"
SOURCE_MANIFEST = EVIDENCE / "native-build182-source-manifest.json"
FROZEN = ROOT / "build-integrated-validation-20261019/perf078-build182-frozen"
OUT = EVIDENCE / "build182-supported-prelude31-row32-lowwords-1"


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def load_and_validate():
    provenance = json.loads(PROVENANCE.read_text())
    source_manifest = json.loads(SOURCE_MANIFEST.read_text())
    artifact_paths = {
        "numi-human-native": FROZEN / "numi-human-native",
        "NumiMatter.metallib": FROZEN / "NumiMatter.metallib",
        "libmetalrobo.dylib": FROZEN / "libmetalrobo.dylib",
        "metalrobo/MetalRobo.metallib": FROZEN / "metalrobo/MetalRobo.metallib",
        "metalrobo/NumiNeuron.metallib": FROZEN / "metalrobo/NumiNeuron.metallib",
    }
    for name, path in artifact_paths.items():
        expected = provenance["artifacts"][name]
        actual = sha256(path)
        if actual != expected:
            raise RuntimeError(f"frozen artifact hash mismatch for {name}: {actual} != {expected}")
    if sha256(SOURCE_MANIFEST) != provenance["artifacts"]["source-manifest.json"]:
        raise RuntimeError("build182 source-manifest hash does not match frozen provenance")
    src = json.loads(SOURCE_INVOCATION.read_text())
    return src, provenance, source_manifest


def prepare():
    source, provenance, source_manifest = load_and_validate()
    if OUT.exists():
        raise RuntimeError(f"refusing to overwrite existing evidence directory: {OUT}")
    OUT.mkdir(parents=True)
    argv = list(source["argv"])
    argv[0] = str(FROZEN / "numi-human-native")
    argv[4] = str(OUT / "output")
    env = dict(source["simulation_environment"])
    env["DYLD_LIBRARY_PATH"] = str(FROZEN)
    env["NUMI_MATTER_METALLIB_OVERRIDE"] = str(FROZEN / "NumiMatter.metallib")
    env["NUMI_HUMAN_RESTING_COMMON_FAILURE_RECEIPT"] = str(OUT / "common-field-failure.json")
    # The sole numerical treatment change is persistent vascular low-word state.
    env["NM_VASCULAR_PERSISTENT_LOW_WORDS"] = "1"
    # Target the known failed control step (root 29) and preserve row direction/JVP,
    # trial residual, and attempted-alpha records for the exact failing row 32.
    env.pop("NM_FEM_RESIDUAL_ARMIJO_TRACE_ROOT", None)
    env["NM_VASCULAR_TRACE_ROOT"] = "29"
    env["NUMI_MATTER_VASCULAR_ROW16_DIRECTION_TRACE"] = "1"
    env["NUMI_MATTER_WORK_COUNTERS"] = "1"
    env["NUMI_HUMAN_SUPPORTED_PRELUDE_STEPS"] = "31"
    if argv[argv.index("--muscle-step-count") + 1] != "1":
        raise RuntimeError("source invocation changed unexpectedly: measurement count is not one")
    record = {
        "argv": argv,
        "cwd": str(OUT),
        "binary": str(FROZEN / "numi-human-native"),
        "binary_sha256": provenance["artifacts"]["numi-human-native"],
        "source_head": provenance["base_revision"],
        "source_manifest": str(SOURCE_MANIFEST),
        "source_manifest_sha256": sha256(SOURCE_MANIFEST),
        "source_provenance": str(PROVENANCE),
        "source_provenance_sha256": sha256(PROVENANCE),
        "frozen_artifact_manifest_sha256": provenance["artifact_manifest_sha256"],
        "frozen_artifacts": provenance["artifacts"],
        "source_invocation": str(SOURCE_INVOCATION),
        "source_invocation_sha256": sha256(SOURCE_INVOCATION),
        "root_pose": source["root_pose"],
        "prelude_accepted_steps": 31,
        "measurement_steps": 1,
        "expected_total_accepted_steps": 32,
        "target_failure_control_step": 29,
        "target_vascular_failing_index": 32,
        "treatment_change": "NM_VASCULAR_PERSISTENT_LOW_WORDS=1",
        "diagnostics_only": {
            "NM_VASCULAR_TRACE_ROOT": "29",
            "NUMI_MATTER_VASCULAR_ROW16_DIRECTION_TRACE": "1",
            "NUMI_MATTER_WORK_COUNTERS": "1",
        },
        "simulation_environment": {k: env[k] for k in sorted(env) if k.startswith(("NM_", "NUMI_", "DYLD_"))},
        "prepared_utc": datetime.datetime.now(datetime.timezone.utc).isoformat().replace("+00:00", "Z"),
        "execution_status": "prepared_not_run",
    }
    (OUT / "invocation.json").write_text(json.dumps(record, indent=2) + "\n")
    plan = {
        "schema": 1,
        "status": "prepared_not_run",
        "run_script": str(pathlib.Path(__file__).resolve()),
        "evidence_directory": str(OUT),
        "source_manifest_sha256": sha256(SOURCE_MANIFEST),
        "source_provenance_sha256": sha256(PROVENANCE),
        "binary_sha256": provenance["artifacts"]["numi-human-native"],
        "prelude_roots": "31 attempted step slots cover roots 0 through 30, including root 29 and one subsequent root",
        "expected_total_accepted_steps_if_all_pass": 32,
        "time_budget_estimate_seconds": 180,
        "time_budget_basis": "build161 failed after 29 accepted steps in 164.34 s (about 5.48 s per attempted step); 31 prelude steps plus one measurement step estimates about 175 s, rounded to 180 s",
        "command": "python3 " + str(pathlib.Path(__file__).resolve()) + " --execute",
        "note": "No GPU command was issued while preparing this directory.",
    }
    (OUT / "replay-plan.json").write_text(json.dumps(plan, indent=2) + "\n")
    print(f"Prepared only: {OUT}")
    print(f"Binary SHA-256: {record['binary_sha256']}")
    print(f"Source manifest SHA-256: {record['source_manifest_sha256']}")
    print(f"Execute later with: python3 {pathlib.Path(__file__).resolve()} --execute")


def execute():
    source, provenance, _ = load_and_validate()
    record_path = OUT / "invocation.json"
    if not record_path.is_file():
        raise RuntimeError("prepared invocation is missing; run default prepare mode first")
    record = json.loads(record_path.read_text())
    if record.get("execution_status") != "prepared_not_run":
        raise RuntimeError("replay is not in prepared_not_run state")
    if record.get("binary_sha256") != provenance["artifacts"]["numi-human-native"]:
        raise RuntimeError("prepared binary identity differs from frozen provenance")
    for name in ("stdout.log", "stderr.log", "process.json"):
        if (OUT / name).exists():
            raise RuntimeError(f"refusing to overwrite existing run artifact: {name}")
    env = os.environ.copy()
    for key in list(env):
        if key.startswith(("NM_", "NUMI_", "DYLD_")):
            env.pop(key)
    env.update(record["simulation_environment"])
    started = datetime.datetime.now(datetime.timezone.utc).isoformat().replace("+00:00", "Z")
    t0 = time.monotonic()
    with open(OUT / "stdout.log", "w") as stdout, open(OUT / "stderr.log", "w") as stderr:
        try:
            code = subprocess.run(record["argv"], cwd=record["cwd"], env=env,
                                  stdout=stdout, stderr=stderr, timeout=600).returncode
        except subprocess.TimeoutExpired:
            code = "timeout_600s"
    process = {
        "exit_code": code,
        "wall_seconds": time.monotonic() - t0,
        "started_utc": started,
        "finished_utc": datetime.datetime.now(datetime.timezone.utc).isoformat().replace("+00:00", "Z"),
    }
    (OUT / "process.json").write_text(json.dumps(process, indent=2) + "\n")
    record["execution_status"] = "completed" if isinstance(code, int) else "timed_out"
    record["started_utc"] = started
    (OUT / "invocation.json").write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps(process, indent=2))
    return 0 if code == 0 else 1


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--execute", action="store_true", help="run the prepared GPU replay")
    args = parser.parse_args()
    if args.execute:
        raise SystemExit(execute())
    prepare()

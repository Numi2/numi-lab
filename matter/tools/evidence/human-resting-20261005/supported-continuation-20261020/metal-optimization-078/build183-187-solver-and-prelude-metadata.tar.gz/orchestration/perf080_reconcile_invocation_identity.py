from pathlib import Path
import hashlib,json,re
R=Path("/Users/numi/numi-human-aortic-contact-opt-20261019");E=R/"matter/tools/evidence/human-resting-20261005/supported-continuation-20261020/metal-optimization-078"
rows=[];verified={}
for d in sorted(E.iterdir()):
 if not d.is_dir() or not re.match(r"build(?:1[6-7][0-9]|18[0-3])-",d.name):continue
 p=d/"invocation.json"
 if not p.exists():continue
 inv=json.loads(p.read_text()); argv=inv.get("argv",[])
 if not argv:continue
 match=re.search(r"perf078-build(\d+)-frozen",argv[0])
 if not match:continue
 n=match[1];provpath=E/("native-build"+n+"-source-provenance.json")
 if not provpath.exists():continue
 prov=json.loads(provpath.read_text());f=Path(prov["frozen_artifact_directory"])
 if n not in verified:
  checks={}
  for rel,expected in prov["artifacts"].items():
   a=f/rel;actual=hashlib.file_digest(a.open("rb"),"sha256").hexdigest();assert actual==expected,(a,actual,expected);checks[rel]=actual
  verified[n]=checks
 expected=verified[n]["numi-human-native"]
 rows.append(dict(invocation=str(p.relative_to(E)),invocation_sha256=hashlib.file_digest(p.open("rb"),"sha256").hexdigest(),argv_binary=argv[0],actual_source_provenance=str(provpath.relative_to(E)),actual_base_revision=prov["base_revision"],actual_binary_sha256=expected,legacy_declared_binary_sha256=inv.get("binary_sha256"),legacy_declared_source_head=inv.get("source_head"),runner_cwd_not_inferred_from_legacy_field=True,legacy_fields_are_template_metadata=True,actual_frozen_artifacts_verified=True))
out=E/"build183-invocation-identity-reconciliation.json"
out.write_text(json.dumps(dict(note="Original invocation files are preserved. Several cohort runners inherited descriptive/hash/timestamp/cwd fields from an older template while replacing actual argv/environment and source_manifest. Use the verified per-build frozen provenance and actual argv/env as execution identities. No new start timestamp is fabricated. Exact argv paths and env remain original; source revision plus archived dirty closure are required together.",verified_frozen_artifacts=verified,runs=rows),indent=2)+"\n")
print("verified cohorts",len(verified),"invocations",len(rows),"legacy binary mismatches",sum(x["legacy_declared_binary_sha256"]!=x["actual_binary_sha256"] for x in rows))

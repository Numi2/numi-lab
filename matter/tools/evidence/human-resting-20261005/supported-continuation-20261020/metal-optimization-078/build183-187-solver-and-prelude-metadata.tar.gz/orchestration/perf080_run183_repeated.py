from pathlib import Path
import json,os,subprocess,time,sys,hashlib,datetime
r=Path('/Users/numi/numi-human-aortic-contact-opt-20261019');e=r/'matter/tools/evidence/human-resting-20261005/supported-continuation-20261020/metal-optimization-078';f=r/'build-integrated-validation-20261019/perf078-build183-frozen'
base=json.loads((e/'build165-indirect-mass-candidate-pair1/invocation.json').read_text())
cases=[]
if sys.argv[1]=='coarse-multiplicative':
 cases=[('full-coarse-multiplicative-control',dict(NM_FGMRES_PREFIX_PRECONDITIONER_ICB='0')),('full-coarse-multiplicative',dict(NM_FGMRES_PREFIX_PRECONDITIONER_ICB='0',NM_FEM_SELECTOR6_GLOBAL_COARSE='1',NM_FEM_SELECTOR6_GLOBAL_COARSE_COUPLED_TAILS='1',NM_FEM_SELECTOR6_GLOBAL_COARSE_MULTIPLICATIVE='1'))]
elif sys.argv[1]=='zero':
 base['argv'][base['argv'].index('--muscle-step-count')+1]='3'
 cases=[(name,flags) for pair in (2,3) for name,flags in ((f'zero-action-control-pair{pair}',{}),(f'zero-action-pair{pair}',dict(NM_FGMRES_SKIP_COMPLETED_ZERO_OPERATOR_ACTION='1')))]
elif sys.argv[1]=='optic192':
 cases=[('optic192-control',dict(NM_FEM_GRAPH_SOLVE_SIMD32='0',NM_FEM_HUMAN6_GRAPH_PATCH_NODES='32',NM_FEM_HUMAN6_GRAPH_ARENA_MIB='192')),('optic192',dict(NM_FEM_GRAPH_SOLVE_SIMD32='0',NM_FEM_HUMAN6_GRAPH_PATCH_NODES='32',NM_FEM_HUMAN6_GRAPH_ARENA_MIB='192',NM_FEM_HUMAN6_OPTIC_GRAPH_PATCHES='1'))]
elif sys.argv[1]=='optic-graph':
 cases=[('optic128-control',dict(NM_FEM_GRAPH_SOLVE_SIMD32='0')),('optic128',dict(NM_FEM_GRAPH_SOLVE_SIMD32='0',NM_FEM_HUMAN6_OPTIC_GRAPH_PATCHES='1'))]
elif sys.argv[1]=='typed-warm':
 base['argv'][base['argv'].index('--muscle-step-count')+1]='3'
 cases=[('three-root-typed-owner-control',dict(NUMI_HUMAN_IMPLICIT_BODY_SPRINGS='20',NUMI_HUMAN_EXACT_CANDIDATE_KINEMATICS='1',NM_FGMRES_COUPLED_BORROWED_ENCODER='0')),('three-root-typed-owner',dict(NUMI_HUMAN_IMPLICIT_BODY_SPRINGS='20',NUMI_HUMAN_EXACT_CANDIDATE_KINEMATICS='1',NM_FGMRES_COUPLED_BORROWED_ENCODER='1'))]
elif sys.argv[1]=='rap':
 cases=[('coarse-first-active-rap',dict(NM_FEM_SELECTOR6_GLOBAL_COARSE='1',NM_FEM_SELECTOR6_GLOBAL_COARSE_COUPLED_TAILS='1',NM_FEM_SELECTOR6_GLOBAL_COARSE_RAP_CAPTURE='1',NM_FGMRES_PREFIX_PRECONDITIONER_ICB='0'))]
elif sys.argv[1]=='warm-patch':
 base['argv'][base['argv'].index('--muscle-step-count')+1]='3'
 cases=[('three-root-patch32',dict(NM_FEM_HUMAN6_GRAPH_PATCH_NODES='32')),('three-root-patch16',dict(NM_FEM_HUMAN6_GRAPH_PATCH_NODES='16'))]
elif sys.argv[1]=='optic':
 cases=[('optic-preconditioner-control',{}),('optic-preconditioner',dict(NUMI_MATTER_HUMAN_PARTITIONED_PRECONDITIONER='1',NM_FEM_HUMAN_PARTITIONED_OPTIC_ONLY='1',NM_FEM_HUMAN_HYBRID_COORDINATES='0',NM_FEM_HUMAN_PARTITIONED_OPTIC_BINS='5'))]
elif sys.argv[1]=='optic-hybrid':
 base=json.loads((e/'build167-embedded-contact-boundary-3/invocation.json').read_text())
 cases=[('optic-only-hybrid',dict(NM_FGMRES_OPERATOR_ICB='1',NM_FGMRES_PREFIX_PRECONDITIONER_ICB='0',NM_FEM_HUMAN_PARTITIONED_OPTIC_ONLY='1',NM_FEM_HUMAN_PARTITIONED_OPTIC_BINS='5'))]
elif sys.argv[1]=='validate-owner':
 cases=[('implicit20-owner-api-validation',dict(NUMI_HUMAN_IMPLICIT_BODY_SPRINGS='20',NUMI_HUMAN_EXACT_CANDIDATE_KINEMATICS='1',NM_FGMRES_COUPLED_BORROWED_ENCODER='1',MTL_DEBUG_LAYER='1'))]
elif sys.argv[1]=='typed-owner':
 for mode in (0,1):
  cases.append((f'implicit20-typed-owner-{mode}',dict(NUMI_HUMAN_IMPLICIT_BODY_SPRINGS='20',NUMI_HUMAN_EXACT_CANDIDATE_KINEMATICS='1',NM_FGMRES_COUPLED_BORROWED_ENCODER=str(mode))))
elif sys.argv[1]=='targeted':
 base=json.loads((e/'build167-embedded-contact-boundary-3/invocation.json').read_text())
 cases=[('hybrid-targeted-shell',dict(NM_FGMRES_OPERATOR_ICB='1',NM_FGMRES_PREFIX_PRECONDITIONER_ICB='0',NM_FEM_HUMAN_PARTITIONED_OPTIC_BINS='10',NM_FEM_HUMAN_PARTITIONED_SPLIT_SKIN_TETS='24530,22879,19970',NM_FGMRES_COUPLED_BORROWED_ENCODER='0'))]
elif sys.argv[1]=='coarse':
 cases=[('coarse-control',{}),('coarse-vascular',dict(NM_FEM_SELECTOR6_GLOBAL_COARSE='1',NM_FEM_SELECTOR6_GLOBAL_COARSE_COUPLED_TAILS='1',NM_FGMRES_PREFIX_PRECONDITIONER_ICB='0'))]
elif sys.argv[1]=='stages':
 cases=[('stages-root0',dict(NUMI_MATTER_GPU_TIMING='1',NUMI_MATTER_GPU_TIMING_STAGES='1',NUMI_MATTER_GPU_TIMING_ROOT='0')),('stages-control',{})]
elif sys.argv[1]=='backsub':
 cases=[('backsub-control',dict(NM_FEM_GRAPH_PARALLEL_BACKSUBSTITUTION='0')),('backsub-parallel',dict(NM_FEM_GRAPH_PARALLEL_BACKSUBSTITUTION='1'))]
elif sys.argv[1]=='owner':
 for mode in (0,1):
  cases.append((f'implicit20-borrowed-{mode}',dict(NUMI_HUMAN_IMPLICIT_BODY_SPRINGS='20',NUMI_HUMAN_EXACT_CANDIDATE_KINEMATICS='1',NM_FGMRES_COUPLED_BORROWED_ENCODER=str(mode))))
elif sys.argv[1]=='refined':
 base=json.loads((e/'build167-embedded-contact-boundary-3/invocation.json').read_text())
 cases=[('hybrid-refined-anatomy',dict(NM_FGMRES_OPERATOR_ICB='1',NM_FGMRES_PREFIX_PRECONDITIONER_ICB='0',NM_FEM_HUMAN_PARTITIONED_OPTIC_BINS='10',NM_FEM_HUMAN_PARTITIONED_SPLIT_SKIN_TET='24451',NM_FGMRES_COUPLED_BORROWED_ENCODER='0'))]
elif sys.argv[1]=='patch':
 cases=[('patch32-control',dict(NM_FEM_HUMAN6_GRAPH_PATCH_NODES='32',NM_FGMRES_COUPLED_BORROWED_ENCODER='0')),('patch16-simd32',dict(NM_FEM_HUMAN6_GRAPH_PATCH_NODES='16',NM_FGMRES_COUPLED_BORROWED_ENCODER='0'))]
elif sys.argv[1]=='borrow':
 for pair in range(1,4):
  for mode in (0,1):
   cases.append((f'borrowed-{mode}-pair{pair}',dict(NM_FGMRES_COUPLED_BORROWED_ENCODER=str(mode))))
elif sys.argv[1]=='telemetry':
 cases=[('cpu-timing',dict(NUMI_MATTER_CPU_TIMING='1',NM_FGMRES_COUPLED_BORROWED_ENCODER='1')),('jacobi-8-counters',dict(NM_FEM_GRAPH_SOLVE_JACOBI_SWEEPS='8',NM_FGMRES_COUPLED_BORROWED_ENCODER='1'))]
elif sys.argv[1]=='operator':
 cases=[('assembled-simd',dict(NM_FEM_ASSEMBLED_XYZ_OPERATOR='1',NM_FEM_ASSEMBLED_XYZ_SIMD_ROW='1',NM_FGMRES_COUPLED_BORROWED_ENCODER='0')),('morton-cache',dict(NM_CONTACT_SURFACE_MORTON_ORDER_CACHE='1',NM_FGMRES_COUPLED_BORROWED_ENCODER='0'))]
elif sys.argv[1]=='warm':
 base['argv'][base['argv'].index('--muscle-step-count')+1]='3'
 cases=[('three-root-initial-throughput',dict(NM_FGMRES_COUPLED_BORROWED_ENCODER='0'))]
elif sys.argv[1]=='refine':
 base=json.loads((e/'build167-embedded-contact-boundary-3/invocation.json').read_text())
 cases=[('hybrid-refined-optic20',dict(NM_FGMRES_OPERATOR_ICB='1',NM_FGMRES_PREFIX_PRECONDITIONER_ICB='0',NM_FEM_HYBRID_RESIDUAL_REFINEMENT_TRACE=str(e/'coordinate-fidelity-build167-witness/build167-latest-active-final-cycle.jsonl'),NM_FGMRES_COUPLED_BORROWED_ENCODER='0'))]
elif sys.argv[1]=='hybrid':
 base=json.loads((e/'build167-embedded-contact-boundary-3/invocation.json').read_text())
 cases=[('hybrid-operator-icb',dict(NM_FGMRES_OPERATOR_ICB='1',NM_FGMRES_PREFIX_PRECONDITIONER_ICB='0',NM_FGMRES_COUPLED_BORROWED_ENCODER='0'))]
else:raise SystemExit('unknown trial cohort')
for name,overrides in cases:
 out=e/('build183-'+name);out.mkdir();cfg=json.loads(json.dumps(base));argv=cfg['argv'];argv[0]=str(f/'numi-human-native');argv[4]=str(out/'output')
 env=cfg['simulation_environment'];env['MTL_DEBUG_LAYER']=os.environ.get('MTL_DEBUG_LAYER','0');env.update(DYLD_LIBRARY_PATH=str(f),NUMI_MATTER_METALLIB_OVERRIDE=str(f/'NumiMatter.metallib'),NM_FEM_GRAPH_SOLVE_JACOBI_SWEEPS='0',NM_FGMRES_COUPLED_BORROWED_ENCODER='0');env.update(overrides)
 env['NUMI_HUMAN_RESTING_COMMON_FAILURE_RECEIPT']=str(out/'common-field-failure.json')
 provpath=e/'native-build183-source-provenance.json';prov=json.loads(provpath.read_text())
 for rel,expected in prov['artifacts'].items():
  actual=hashlib.file_digest((f/rel).open('rb'),'sha256').hexdigest()
  if actual!=expected:raise RuntimeError('frozen artifact mismatch: '+rel)
 cfg=dict(argv=argv,simulation_environment=env,cwd=str(r),binary=argv[0],binary_sha256=prov['artifacts']['numi-human-native'],source_head=prov['base_revision'],source_manifest=str(e/'native-build183-source-manifest.json'),source_provenance=str(provpath),source_provenance_sha256=hashlib.file_digest(provpath.open('rb'),'sha256').hexdigest(),source_archive_sha256=prov['source_archive_sha256'],source_patch_sha256=prov['source_patch_sha256'],artifact_sha256={str(f/k):v for k,v in prov['artifacts'].items()},started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),orchestration=__file__,orchestration_sha256=hashlib.file_digest(open(__file__,'rb'),'sha256').hexdigest(),template_invocation=str(e/'build165-indirect-mass-candidate-pair1/invocation.json'))
 (out/'invocation.json').write_text(json.dumps(cfg,indent=2));start=time.monotonic()
 with (out/'stdout.log').open('w') as so,(out/'stderr.log').open('w') as se:code=subprocess.run(argv,cwd=r,env={**os.environ,**env},stdout=so,stderr=se).returncode
 rec=dict(name=name,exit_code=code,wall_seconds=time.monotonic()-start);(out/'process.json').write_text(json.dumps(rec,indent=2));print(rec,flush=True)
 if code:raise SystemExit(code)

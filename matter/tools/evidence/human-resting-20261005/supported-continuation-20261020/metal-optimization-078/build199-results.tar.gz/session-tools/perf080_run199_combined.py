from pathlib import Path
import subprocess,json
r=Path('/Users/numi/numi-human-aortic-contact-opt-20261019');e=r/'matter/tools/evidence/human-resting-20261005/supported-continuation-20261020/metal-optimization-078'
for pair in range(1,4):
 cases=((('control','0'),('on','1')) if pair%2 else (('on','1'),('control','0')))
 for label,val in cases:
  name=f'build199-combined-compatible-{label}-{pair}'
  if (e/name/'process.json').exists(): continue
  cmd=['python3',str(r/'matter/tools/run_human_frozen_invocation.py'),'--template',str(e/'build186-uninstrumented-control/invocation.json'),'--provenance',str(e/'native-build199-source-provenance.json'),'--output',str(e/name),'--cwd',str(r),'--steps','3','--metal-validation','0','--env','NM_FGMRES_PREFIX_PRECONDITIONER_ICB=1','--env','NM_FGMRES_REUSE_CERTIFIED_EMPTY_RESTART_ACTION=0']
  for k in ('NM_FGMRES_FLAT_COLUMN_ICB','NM_FGMRES_SKIP_COMPLETED_GRAPH_WORK','NM_FGMRES_SKIP_COMPLETED_ZERO_OPERATOR_ACTION','NM_FGMRES_SKIP_COMPLETED_CYCLE_WORK'):cmd+=['--env',k+'='+val]
  p=subprocess.run(cmd);print(name,p.returncode,flush=True)
  if p.returncode:raise SystemExit(p.returncode)
 control=f'build199-combined-compatible-control-{pair}'
 subprocess.run(['python3','/tmp/perf080_compare_pair.py',control,f'build199-combined-compatible-on-{pair}',f'build199-combined-compatible-pair{pair}-comparison.json'],check=True,stdout=subprocess.DEVNULL)
 d=json.loads((e/f'build199-combined-compatible-pair{pair}-comparison.json').read_text())
 if not d['passed_1pct']:print('numeric gate failed; stopping',flush=True);raise SystemExit(2)


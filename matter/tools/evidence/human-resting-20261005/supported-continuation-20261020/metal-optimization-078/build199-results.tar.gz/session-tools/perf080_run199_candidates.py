from pathlib import Path
import subprocess,json
r=Path('/Users/numi/numi-human-aortic-contact-opt-20261019');e=r/'matter/tools/evidence/human-resting-20261005/supported-continuation-20261020/metal-optimization-078'
flags=('NM_FGMRES_FLAT_COLUMN_ICB','NM_FGMRES_GRAPH_FULL_PSD_CONTACT_BLOCKS','NM_FEM_GRAPH_PARALLEL_BACKSUB_PRODUCTS')
for label,values in [('control',(0,0,0)),('flat',(1,0,0))]:
 name='build199-'+label
 cmd=['python3',str(r/'matter/tools/run_human_frozen_invocation.py'),'--template',str(e/'build186-uninstrumented-control/invocation.json'),'--provenance',str(e/'native-build199-source-provenance.json'),'--output',str(e/name),'--cwd',str(r),'--steps','3','--metal-validation','1']
 for key,value in zip(flags,values):cmd+=['--env',key+'='+str(value)]
 subprocess.run(cmd,check=True)
 if label!='control':
  subprocess.run(['python3','/tmp/perf080_compare_pair.py','build199-control',name,name+'-comparison.json'],check=True,stdout=subprocess.DEVNULL)
  d=json.loads((e/(name+'-comparison.json')).read_text());print(name,'passed_1pct',d['passed_1pct'],'relative',d['relative'],flush=True)

from pathlib import Path
import subprocess,os,json
r=Path('/Users/numi/numi-human-aortic-contact-opt-20261019');b=r/'build-integrated-validation-20261019/profile-build-039';e=r/'matter/tools/evidence/human-resting-20261005/supported-continuation-20261020/metal-optimization-078'
for target in ('numi-matter-fem-material-frame-compiler-check','numi-matter-registered-skin-fat-reduction-labels-check'):
 p=subprocess.run([str(b/'matter'/target)],cwd=r,capture_output=True,text=True)
 (e/('build192-'+target+'.log')).write_text(p.stdout+p.stderr)
 print(target,p.returncode,flush=True)
 if p.returncode: raise SystemExit(p.returncode)
env=os.environ.copy();env['MTL_DEBUG_LAYER']='1'
p=subprocess.run([str(b/'matter/numi-matter-fgmres-true-residual-native-check'),'--completed-cycle-work-only'],cwd=r,env=env,capture_output=True,text=True)
(e/'build192-completed-cycle-native.log').write_text(p.stdout+p.stderr)
print('completed-cycle-native',p.returncode,p.stdout[-700:],p.stderr[-500:],flush=True)
if p.returncode: raise SystemExit(p.returncode)
subprocess.run(['python3','/tmp/perf080_build192_freeze.py'],check=True)

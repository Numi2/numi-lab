from pathlib import Path
import subprocess,json
r=Path('/Users/numi/numi-human-aortic-contact-opt-20261019');e=r/'matter/tools/evidence/human-resting-20261005/supported-continuation-20261020/metal-optimization-078'
for label,extra in (
 ('startup-control',[]),
 ('startup-cycle',['NM_FGMRES_SKIP_COMPLETED_CYCLE_WORK=1']),
 ('startup-clock',['NUMI_HUMAN_CONTACT_CONNECTED_CLOCK_LOCK=1']),
):
 cmd=['python3',str(r/'matter/tools/run_human_frozen_invocation.py'),'--template',str(e/'build186-uninstrumented-control/invocation.json'),'--provenance',str(e/'native-build192-source-provenance.json'),'--output',str(e/('build192-'+label)),'--cwd',str(r),'--steps','3','--metal-validation','1']
 for flag in extra: cmd+=['--env',flag]
 p=subprocess.run(cmd);print(label,p.returncode,flush=True)

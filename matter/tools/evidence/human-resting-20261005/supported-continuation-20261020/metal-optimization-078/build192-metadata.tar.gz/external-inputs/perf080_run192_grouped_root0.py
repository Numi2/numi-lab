from pathlib import Path
import subprocess,json
r=Path('/Users/numi/numi-human-aortic-contact-opt-20261019');e=r/'matter/tools/evidence/human-resting-20261005/supported-continuation-20261020/metal-optimization-078'
selection=json.loads(Path('/tmp/perf080-greedy-refinement-private/build171-selection.json').read_text())
for label,extra,unset in (
 ('grouped-staged-candidate-root0',dict(selection['compiler_environment'],NM_FGMRES_PREFIX_PRECONDITIONER_ICB='0',NM_FEM_HUMAN_HYBRID_COORDINATES='1',NM_FEM_HYBRID_RESIDUAL_WITNESS='1',NM_FEM_TRUE_RESIDUAL_ROOT='0',NM_FEM_HUMAN_HYBRID_EMBED_CONTACT_BOUNDARY='1',NM_FEM_HUMAN_PARTITIONED_OPTIC_BINS='10'),['NM_FEM_TRUE_RESIDUAL_CERTIFY']),
):
 cmd=['python3',str(r/'matter/tools/run_human_frozen_invocation.py'),'--template',str(e/'build192-staged-comparison-template.json'),'--provenance',str(e/'native-build192-source-provenance.json'),'--output',str(e/('build192-'+label)),'--cwd',str(r),'--steps','1','--metal-validation','1']
 for k,v in extra.items():cmd+=['--env',k+'='+v]
 for k in unset:cmd+=['--unset-env',k]
 p=subprocess.run(cmd);print(label,p.returncode,flush=True)

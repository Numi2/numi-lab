#!/usr/bin/env python3
"""Prepare or execute a matched build49 full-vs-Human-hybrid endpoint pair.

Default is dry-run and performs no simulation. Pass --execute only after the
build owner has released the GPU. Each run gets a fresh evidence directory;
failed outputs are retained and never overwritten.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path("/Users/numi/numi-human-aortic-contact-opt-20261019")
EVIDENCE = ROOT / "matter/tools/evidence/human-resting-20261005/supported-continuation-20261020/metal-optimization-078"
FROZEN = ROOT / "build-integrated-validation-20261019/perf078-build49-frozen"
PAIR_ROOT = EVIDENCE / "build49-optic-established-reference-pair"
FULL_INVOCATION = EVIDENCE / "global-icb-native-stateless-allnative-hier-tailicb-domain-tight3-work-coarse-block-femtangent-principal-cavity3-archive-build35-endpoint-full-enabled-1/invocation.json"
HYBRID_INVOCATION = EVIDENCE / "global-icb-native-stateless-allnative-hier-tailicb-domain-tight3-work-coarse-block-femtangent-hybrid-principal-cavity3-archive-build35-endpoint-hybrid-enabled-1/invocation.json"
COMPARATOR = ROOT / "apps/compare_human_fem_endpoint_fidelity.py"


def file_sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def load_pair() -> tuple[dict, dict]:
    full = json.loads(FULL_INVOCATION.read_text())
    hybrid = json.loads(HYBRID_INVOCATION.read_text())
    a, b = list(full["argv"]), list(hybrid["argv"])
    if len(a) != len(b) or len(a) <= 5:
        raise RuntimeError("retained endpoint invocations have incompatible argv layouts")
    # Existing matched pair differs only in executable/output paths and hybrid enablement.
    for i, (x, y) in enumerate(zip(a, b)):
        if i not in (0, 4) and x != y:
            raise RuntimeError(f"retained endpoint invocations diverge at argv[{i}]")
    ef, eh = full["simulation_environment"], hybrid["simulation_environment"]
    differences = {k for k in ef.keys() | eh.keys() if ef.get(k) != eh.get(k)}
    expected = {"NM_FEM_HUMAN_HYBRID_COORDINATES", "NUMI_HUMAN_RESTING_COMMON_FAILURE_RECEIPT"}
    if differences != expected or eh.get("NM_FEM_HUMAN_HYBRID_COORDINATES") != "1":
        raise RuntimeError(f"retained endpoint environments are not a matched full/hybrid pair: {sorted(differences)}")
    return full, hybrid


def build_record(label: str, base: dict, retained_env: dict, output: Path,
                 hybrid_enabled: bool) -> tuple[list[str], dict[str, str], dict]:
    argv = list(base["argv"])
    argv[0] = str(FROZEN / "numi-human-native")
    argv[4] = str(output / "output")
    env = os.environ.copy()
    # Remove ambient simulation and dynamic-library overrides before restoring the
    # retained run environment, so the exact prior cohort defines all other knobs.
    for key in list(env):
        if key.startswith(("NM_", "NUMI_", "DYLD_")):
            env.pop(key)
    env.update({str(k): str(v) for k, v in retained_env.items()})
    env["DYLD_LIBRARY_PATH"] = str(FROZEN)
    env["NUMI_MATTER_METALLIB_OVERRIDE"] = str(FROZEN / "NumiMatter.metallib")
    env["NUMI_MATTER_PIPELINE_ARCHIVE"] = str(
        ROOT / "build-integrated-validation-20261019/perf078-pipelines.metalar")
    env["NUMI_HUMAN_RESTING_COMMON_FAILURE_RECEIPT"] = str(output / "common-field-failure.json")
    if hybrid_enabled:
        env["NM_FEM_HUMAN_HYBRID_COORDINATES"] = "1"
    else:
        env.pop("NM_FEM_HUMAN_HYBRID_COORDINATES", None)
    env["NUMI_MATTER_HUMAN_PARTITIONED_PRECONDITIONER"] = "1"
    env["NUMI_HUMAN_PARTITIONED_REDUCTION_DIAGNOSTIC"] = "1" if hybrid_enabled else "0"
    env["NM_CONTACT_COMPACTION_ACTIVE_PREFIX"] = "1"
    env["NM_FEM_PARALLEL_BACKTRACKING"] = "1"
    env["NUMI_HUMAN_RESTING_OPTIC_NERVE_FEM"] = "1"
    env["NUMI_HUMAN_PARTITIONED_MASS_WHITEN"] = "1"
    # Force capture after inherited environment has been merged; both endpoints
    # must record the same-source nodes/tets and force/strain channels.
    env["NUMI_HUMAN_CAPTURE_FEM_ENDPOINT_STATE"] = "1"
    retained_keys = ("NM_", "NUMI_", "DYLD_")
    record = {
        "label": label,
        "argv": argv,
        "simulation_environment": {k: v for k, v in env.items() if k.startswith(retained_keys)},
        "retained_full_invocation": str(FULL_INVOCATION),
        "retained_full_invocation_sha256": file_sha(FULL_INVOCATION),
        "retained_hybrid_invocation": str(HYBRID_INVOCATION),
        "retained_hybrid_invocation_sha256": file_sha(HYBRID_INVOCATION),
        "retained_reference_source_head": base.get("source_head"),
        "retained_reference_input_invocation_sha256": base.get("input_invocation_sha256"),
        "retained_reference_host_source_manifest": base.get("host_source_manifest"),
        "retained_reference_shader_source_manifest": base.get("shader_source_manifest"),
        "build49_frozen_dir": str(FROZEN),
        "build49_manifest": json.loads((FROZEN / "manifest.json").read_text()),
        "build49_source_manifest_sha256": file_sha(FROZEN / "source-manifest.json"),
        "build49_source_patch_sha256": file_sha(FROZEN / "source.patch"),
        "shared_pipeline_archive": str(ROOT / "build-integrated-validation-20261019/perf078-pipelines.metalar"),
        "shared_pipeline_archive_sha256_before_case": file_sha(ROOT / "build-integrated-validation-20261019/perf078-pipelines.metalar"),
        "artifact_sha256": {name: file_sha(FROZEN / name) for name in
                             ("numi-human-native", "libmetalrobo.dylib", "NumiMatter.metallib")},
        "capture_forced_after_retained_env_merge": env["NUMI_HUMAN_CAPTURE_FEM_ENDPOINT_STATE"] == "1",
        "mass_whitening": env["NUMI_HUMAN_PARTITIONED_MASS_WHITEN"],
        "optic_nerve_source_fem": env["NUMI_HUMAN_RESTING_OPTIC_NERVE_FEM"],
        "hybrid_coordinates": env.get("NM_FEM_HUMAN_HYBRID_COORDINATES", "0"),
        "reference_solver_note": "Reference uses fine selector6 preconditioner, hybrid uses reduced coarse preconditioner; same physical mesh/loads, both compile identical Bq labels; engineering fidelity comparison, not equivalent-algorithm parity",
    }
    return argv, env, record


def run_one(label: str, base: dict, retained_env: dict, hybrid_enabled: bool) -> tuple[Path, int]:
    out = PAIR_ROOT / label
    out.mkdir(parents=True, exist_ok=False)
    (out / "output").mkdir()
    argv, env, record = build_record(label, base, retained_env, out, hybrid_enabled)
    (out / "invocation.json").write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    start = time.monotonic()
    with (out / "stdout.log").open("w") as stdout, (out / "stderr.log").open("w") as stderr:
        try:
            code = subprocess.run(argv, cwd=out, env=env, stdout=stdout,
                                  stderr=stderr, timeout=600).returncode
        except subprocess.TimeoutExpired:
            code = 124
    archive = ROOT / "build-integrated-validation-20261019/perf078-pipelines.metalar"
    (out / "process.json").write_text(json.dumps({
        "exit_code": code, "timed_out": code == 124,
        "wall_seconds": time.monotonic() - start,
        "shared_pipeline_archive_sha256_after_case": file_sha(archive) if archive.exists() else None,
    }, indent=2) + "\n")
    return out, code


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--execute", action="store_true",
                        help="run the two native cases; omitted means a no-launch dry run")
    args = parser.parse_args()
    full, hybrid = load_pair()
    base = full
    if not FROZEN.is_dir() or not (FROZEN / "numi-human-native").is_file():
        raise RuntimeError(f"frozen build49 artifacts are missing: {FROZEN}")
    frozen_manifest = json.loads((FROZEN / "manifest.json").read_text())
    for name, expected_sha in frozen_manifest.items():
        artifact = FROZEN / name
        if not artifact.is_file() or file_sha(artifact) != expected_sha:
            raise RuntimeError(f"frozen build49 manifest mismatch for {artifact}")
    # Save identical physical inputs; record the explicitly different numerical preconditioners.
    planned = []
    for label, enable in (("full-reference", False), ("combined-optic-hybrid", True)):
        case = PAIR_ROOT / label
        argv, env, record = build_record(label, base, full["simulation_environment"], case, enable)
        planned.append({"label": label, "argv": argv,
                        "capture": env["NUMI_HUMAN_CAPTURE_FEM_ENDPOINT_STATE"],
                        "whiten": env["NUMI_HUMAN_PARTITIONED_MASS_WHITEN"],
                        "hybrid": env.get("NM_FEM_HUMAN_HYBRID_COORDINATES", "0")})
    print(json.dumps({"dry_run": not args.execute, "pair_root": str(PAIR_ROOT),
                      "frozen_build": str(FROZEN),
                      "shared_pipeline_archive": str(ROOT / "build-integrated-validation-20261019/perf078-pipelines.metalar"),
                      "cases": [{k: v for k, v in item.items() if k != "argv"} |
                                {"argv_sha256": hashlib.sha256(json.dumps(item["argv"], separators=(",", ":")).encode()).hexdigest()}
                                for item in planned]}, indent=2))
    if not args.execute:
        return 0
    if PAIR_ROOT.exists():
        raise RuntimeError(f"pair output already exists; refusing to overwrite: {PAIR_ROOT}")
    PAIR_ROOT.mkdir(parents=True, exist_ok=False)
    full_out, full_code = run_one("full-reference", base,
                                  full["simulation_environment"], False)
    hybrid_out, hybrid_code = run_one("combined-optic-hybrid", base,
                                      full["simulation_environment"], True)
    if full_code or hybrid_code:
        return 1
    result = subprocess.run([sys.executable, str(COMPARATOR),
                             str(full_out / "stdout.log"),
                             str(hybrid_out / "stdout.log")],
                            cwd=PAIR_ROOT, capture_output=True, text=True)
    (PAIR_ROOT / "endpoint-comparison.json").write_text(result.stdout + "\n")
    (PAIR_ROOT / "endpoint-comparison.stderr.log").write_text(result.stderr)
    try:
        payload = json.loads(result.stdout).get("endpoint_fidelity")
    except json.JSONDecodeError:
        payload = None
    if isinstance(payload, dict) and "source" in payload:
        # Persist measured force and Green-strain/deformation data even when a
        # numerical gate fails; only unavailable comparisons lack metric data.
        metrics = {
            "source_identity": payload["source"],
            "matched_endpoint": payload["matched_endpoint"],
            "reaction_force_fidelity": payload["force_fidelity"],
            "accepted_anchor_reaction_history": payload["accepted_anchor_reaction_history"],
            "green_strain_deformation_fidelity": payload["green_strain_fidelity"],
            "mechanical_residual_impulse": payload["mechanical_residual_impulse"],
            "owner_coverage": payload["owner_coverage"],
            "gates": payload["gates"],
        }
        (PAIR_ROOT / "endpoint-pair-metrics.json").write_text(
            json.dumps(metrics, indent=2, sort_keys=True) + "\n")
    return result.returncode


if __name__ == "__main__":
    raise SystemExit(main())

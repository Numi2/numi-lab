# Current-source local-factor reuse qualification

SSH Numi, frozen build188. No visual verification. Mandatory physical residual
and acceptance rules unchanged; this option remains disabled by default.

The first attempt retained prefix preconditioner ICB and was correctly rejected
by admission before execution: graph factor lag is outside that ICB profile.
The subsequent matched pair disables that ICB in both control and candidate,
rather than bypassing admission. Candidate additionally sets
NM_FEM_HUMAN6_GRAPH_FACTOR_LAG=1.

Both runs accept three 125-microsecond roots. API validation enabled.
Control body seconds: 8.267944584, 6.181339375, 4.915867834.
Reuse: 8.166885083, 5.304718292, 5.406965625.
Post-first cost improves 11.097207209 to 10.711683917 seconds (about 3.6%
throughput), but maximum acceleration differs 4.9682%, anchor reaction 2.7818%,
and maximum J 2.2977%. The existing 1% comparison fails.

Control used columns/Newton begins: 1587/34, 345/58, 83/12.
Reuse: 1706/54, 299/59, 260/44.
Reusing factors reduces some build work but worsens later nonlinear progress.
This is measured evidence against promoting this particular lag policy,
not proof that all preconditioner reuse is ineffective.

No sustained supported-rest or end-to-end throughput claim follows.

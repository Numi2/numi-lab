from pathlib import Path
import subprocess
r=Path('/Users/numi/numi-human-aortic-contact-opt-20261019');e=r/'matter/tools/evidence/human-resting-20261005/supported-continuation-20261020/metal-optimization-078'
for pair in range(1,4):
 for on in ([False,True] if pair%2 else [True,False]):
  name=f'build207-combined-pair{pair}-'+('on' if on else 'control')
  cmd=['python3',str(r/'matter/tools/run_human_frozen_invocation.py'),'--template',str(e/'build186-uninstrumented-control/invocation.json'),'--provenance',str(e/'native-build207-source-provenance.json'),'--output',str(e/name),'--cwd',str(r),'--steps','3','--metal-validation','0','--env','NM_FEM_FRESH_RHS_PRECONDITIONER_PREFLIGHT=0','--env','NM_FEM_FRESH_DIRECTION_ALPHA_RESET=0']
  for key in ('NUMI_MATTER_HUMAN_PARTITIONED_FEM_TANGENT_PAIRED_PROJECT',):cmd+=['--env',key+'='+str(int(on))]
  p=subprocess.run(cmd);print(name,p.returncode,flush=True)
  if p.returncode:raise SystemExit(p.returncode)
 subprocess.run(['python3','/tmp/perf080_compare_pair.py',f'build207-combined-pair{pair}-control',f'build207-combined-pair{pair}-on',f'build207-combined-pair{pair}-comparison.json'],check=True,stdout=subprocess.DEVNULL)


from pathlib import Path
import subprocess,json
r=Path('/Users/numi/numi-human-aortic-contact-opt-20261019');e=r/'matter/tools/evidence/human-resting-20261005/supported-continuation-20261020/metal-optimization-078'
def run(name,env,steps=3,dt=None,template='build186-uninstrumented-control/invocation.json'):
 cmd=['python3',str(r/'matter/tools/run_human_frozen_invocation.py'),'--template',str(e/template),'--provenance',str(e/'native-build207-source-provenance.json'),'--output',str(e/name),'--cwd',str(r),'--steps',str(steps),'--metal-validation','1']
 if dt:cmd+=['--step-seconds',str(dt)]
 for key,value in env.items():cmd+=['--env',key+'='+str(value)]
 p=subprocess.run(cmd);print(json.dumps({'case':name,'returncode':p.returncode}),flush=True)
 if p.returncode==0 and steps==3:
  subprocess.run(['python3','/tmp/perf080_compare_pair.py','build202-control',name,name+'-comparison.json'],stdout=subprocess.DEVNULL,check=True)
 return p.returncode
run('build207-paired-project',{'NUMI_MATTER_HUMAN_PARTITIONED_FEM_TANGENT_PAIRED_PROJECT':1,'NM_FEM_FRESH_RHS_PRECONDITIONER_PREFLIGHT':0})
run('build207-preflight-verify',{'NM_FEM_FRESH_RHS_PRECONDITIONER_PREFLIGHT':1,'NM_FEM_FRESH_RHS_PREFLIGHT_VERIFY':1,'NM_FEM_FRESH_RHS_PREFLIGHT_DIAGNOSTIC':0,'NM_FEM_FRESH_RHS_PREFLIGHT_SKIP_DOMAIN_DIAGNOSTIC':0})
run('build207-root11-limiter-trace',{'NM_VASCULAR_PERSISTENT_LOW_WORDS':1,'NM_FEM_FRESH_DIRECTION_ALPHA_RESET':0,'NM_FEM_FRESH_RHS_PRECONDITIONER_PREFLIGHT':0,'NUMI_HUMAN_CONTACT_CONNECTED_CLOCK_LOCK':0},steps=12,dt=3.125e-5,template='build201-root11trace-lowword-31p25us-12/invocation.json')

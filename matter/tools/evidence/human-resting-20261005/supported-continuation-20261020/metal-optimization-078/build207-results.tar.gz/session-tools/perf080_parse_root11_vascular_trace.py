#!/usr/bin/env python3
"""Decode existing vascular_iterate stderr snapshots for rows 5, 27, and 28."""
from __future__ import annotations
import argparse, json, struct
from pathlib import Path
ROWS=(5,27,28)
VECTORS=("accepted","candidate","residual","solution")
def f32(raw: str, index: int) -> float:
    b=bytes.fromhex(raw); off=index*4
    if len(b)<off+4: raise ValueError("short scalar arena")
    return struct.unpack_from("<f",b,off)[0]
def f4(raw: str, row: int):
    b=bytes.fromhex(raw); off=row*16
    if len(b)<off+16: return None
    return struct.unpack_from("<4f",b,off)
def dd(v): return {"hi":v[0],"lo":v[1],"value":v[0]+v[1],"z":v[2],"w":v[3]}
def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("stderr",type=Path); ap.add_argument("--root",type=int,default=11); ap.add_argument("--json-out",type=Path)
    args=ap.parse_args(); records=[]
    for line_no,line in enumerate(args.stderr.read_text(errors="replace").splitlines(),1):
        marker="vascular_iterate="; at=line.find(marker)
        if at<0: continue
        try: d=json.loads(line[at+len(marker):])
        except json.JSONDecodeError as e: raise SystemExit(f"bad trace JSON at line {line_no}: {e}")
        if d.get("root")!=args.root: continue
        arenas=d.get("arenas",{}); n=len(arenas.get("accepted",""))//32
        item={"line":line_no,"root":d.get("root"),"microtick":d.get("microtick"),"iteration":d.get("iteration"),"stage":d.get("stage"),"unknown_count":n,"alpha":f32(arenas.get("alpha",""),0),"rows":{}}
        for row in ROWS:
            q={}
            for key in VECTORS:
                v=f4(arenas.get(key,""),row); q[key]=None if v is None else dd(v)
            ws=bytes.fromhex(arenas.get("working_set",""))
            q["working_set"]=struct.unpack_from("<I",ws,row*4)[0] if len(ws)>=row*4+4 else None
            item["rows"][str(row)]=q
        records.append(item)
    if not records: raise SystemExit(f"no vascular_iterate snapshots found for root={args.root} in {args.stderr}")
    report={"trace_file":str(args.stderr),"root":args.root,"record_count":len(records),"records":records}
    if args.json_out: args.json_out.write_text(json.dumps(report,indent=2)+"\n")
    print("root microtick iter stage alpha | row: accepted candidate residual solution working_set")
    for d in records:
        print(f"{d['root']:>4} {d['microtick']:>8} {d['iteration']:>4} {d['stage']:<14} {d['alpha']:.9g}")
        for row in ROWS:
            q=d["rows"][str(row)]
            def val(k):
                x=q[k]
                return "missing" if x is None else f"{x['value']:.9g}[{x['hi']:.7g},{x['lo']:.3g}]"
            print(f"  row{row:02d} acc={val('accepted')} cand={val('candidate')} res={val('residual')} dx={val('solution')} ws={q['working_set']}")
    print(f"decoded {len(records)} snapshots; row 5 is the flagged vascular equation, rows 27/28 are its incident flow equations.")
if __name__=="__main__": main()

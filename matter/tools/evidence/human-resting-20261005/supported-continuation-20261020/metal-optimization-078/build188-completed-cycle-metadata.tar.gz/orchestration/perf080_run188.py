from pathlib import Path
import subprocess
r=Path('/Users/numi/numi-human-aortic-contact-opt-20261019')
e=r/'matter/tools/evidence/human-resting-20261005/supported-continuation-20261020/metal-optimization-078'
Path('/tmp/perf080_build188_freeze.py').write_text(Path('/tmp/perf080_build187_freeze.py').read_text().replace('187','188'))
subprocess.run(['python3','/tmp/perf080_build188_freeze.py'],check=True)
for label,flags in (
 ('cycle-control',[]),
 ('cycle-skip',['NM_FGMRES_SKIP_COMPLETED_CYCLE_WORK=1']),
 ('cycle-skip-zero',['NM_FGMRES_SKIP_COMPLETED_CYCLE_WORK=1','NM_FGMRES_SKIP_COMPLETED_ZERO_OPERATOR_ACTION=1']),
):
 cmd=['python3',str(r/'matter/tools/run_human_frozen_invocation.py'),
      '--template',str(e/'build186-uninstrumented-control/invocation.json'),
      '--provenance',str(e/'native-build188-source-provenance.json'),
      '--output',str(e/('build188-'+label)),'--cwd',str(r),
      '--steps','3','--metal-validation','1']
 for flag in flags:cmd+=['--env',flag]
 subprocess.run(cmd,check=True)


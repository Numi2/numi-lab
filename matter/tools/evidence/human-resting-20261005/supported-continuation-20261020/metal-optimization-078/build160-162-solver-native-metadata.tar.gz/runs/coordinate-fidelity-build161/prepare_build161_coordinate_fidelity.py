#!/usr/bin/env python3
"""Prepare paired build161 full-coordinate and 605-witness hybrid run plans.

This script only validates frozen inputs and writes immutable invocation plans.
It never launches numi-human-native or mutates a frozen build/evidence trial.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

ROOT = Path("/Users/numi/numi-human-aortic-contact-opt-20261019")
EVIDENCE = ROOT / "matter/tools/evidence/human-resting-20261005/supported-continuation-20261020/metal-optimization-078"
PLAN_DIR = EVIDENCE / "coordinate-fidelity-build161"
FULL_BASE = EVIDENCE / "coordinate-fidelity-build155/global-native-stateless-allnative-hier-tailicb-domain-tight3-work-compact-parallelbt-plainpso-build155-block-coarse-femtangent-principal-cavity3-graph-coupled-strictinit-strictrows-stages-capture-fullcoord-matched-refined-certified/invocation.json"
HYBRID_BASE = EVIDENCE / "coordinate-fidelity-build152/global-native-stateless-allnative-hier-tailicb-domain-tight3-work-compact-parallelbt-plainpso-build152-block-coarse-femtangent-principal-cavity3-graph-coupled-strictinit-strictrows-stages-capture-hybrid-pair3-mandatorycert/invocation.json"
WITNESS = EVIDENCE / "coordinate-fidelity-build152/global-native-stateless-allnative-hier-tailicb-domain-tight3-work-compact-parallelbt-plainpso-build152-block-coarse-femtangent-principal-cavity3-graph-coupled-strictinit-strictrows-stages-capture-hybrid-pair3-mandatorycert/refinement-witness-build152-final-newton23-selected-record.jsonl"
WITNESS_ANALYSIS = WITNESS.with_name("refinement-witness-build152-final-newton23-analysis.json")
EXPECTED_WITNESS_SHA = "121f0c5afe09a021bc54a536bc230d3206d38eb06e6e3ca7cd21a999a2fcd20c"


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def read_json(path: Path) -> dict:
    return json.loads(path.read_text())


def require_file(path: Path) -> None:
    if not path.is_file():
        raise SystemExit(f"required file is missing: {path}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--bundle", type=Path, default=ROOT / "build-integrated-validation-20261019/perf078-build161-frozen")
    args = parser.parse_args()
    bundle = args.bundle.resolve()
    binary = bundle / "numi-human-native"
    metallib = bundle / "NumiMatter.metallib"
    dylib = bundle / "libmetalrobo.dylib"
    artifact_manifest = bundle / "manifest.json"
    source_manifest = bundle / "source-manifest.json"
    for path in (FULL_BASE, HYBRID_BASE, WITNESS, WITNESS_ANALYSIS):
        require_file(path)
    for path in (binary, metallib, dylib, artifact_manifest, source_manifest):
        require_file(path)

    manifest = read_json(artifact_manifest)
    for rel, path in (("numi-human-native", binary), ("NumiMatter.metallib", metallib), ("libmetalrobo.dylib", dylib), ("source-manifest.json", source_manifest)):
        actual = sha(path)
        expected = manifest.get(rel)
        if expected != actual:
            raise SystemExit(f"frozen manifest mismatch for {rel}: expected={expected!r} actual={actual}")
    witness_sha = sha(WITNESS)
    if witness_sha != EXPECTED_WITNESS_SHA:
        raise SystemExit(f"605-node witness hash changed: {witness_sha}")
    witness_meta = read_json(WITNESS_ANALYSIS)
    if witness_meta.get("trace_file_sha256") != witness_sha or witness_meta.get("nonzero_sampled_node_count") != 605 or witness_meta.get("sampled_node_count") != 605:
        raise SystemExit("selected witness metadata does not prove the expected intact 605-node record")

    full_base = read_json(FULL_BASE)
    hybrid_base = read_json(HYBRID_BASE)
    full_argv = list(full_base["argv"])
    hybrid_argv = list(full_argv)
    full_argv[0] = str(binary)
    hybrid_argv[0] = str(binary)
    full_run = PLAN_DIR / "full-coordinate-matched"
    hybrid_run = PLAN_DIR / "hybrid-coordinate-refined605"
    for run_dir in (full_run, hybrid_run):
        if run_dir.exists() and any(run_dir.iterdir()):
            raise SystemExit(f"refusing to overwrite existing trial/plan contents: {run_dir}")
        run_dir.mkdir(parents=True, exist_ok=True)
    full_argv[4] = str(full_run / "output")
    hybrid_argv[4] = str(hybrid_run / "output")

    # Full and hybrid runs use identical model/payload arguments; only output differs.
    if [x for i, x in enumerate(full_argv) if i != 4] != [x for i, x in enumerate(hybrid_argv) if i != 4]:
        raise SystemExit("internal error: matched argv diverged outside the output directory")
    for token in full_argv[1:]:
        if token.startswith("/") and token != full_argv[4]:
            require_file(Path(token))

    common_env = dict(full_base["simulation_environment"])
    common_env["DYLD_LIBRARY_PATH"] = str(bundle)
    common_env["NUMI_MATTER_METALLIB_OVERRIDE"] = str(metallib)
    full_env = dict(common_env)
    full_env["NM_FEM_TRUE_RESIDUAL_CERTIFY"] = "1"
    full_env["NUMI_HUMAN_CAPTURE_FEM_ENDPOINT_STATE"] = "1"
    full_env["NUMI_HUMAN_RESTING_COMMON_FAILURE_RECEIPT"] = str(full_run / "common-field-failure.json")

    hybrid_env = dict(common_env)
    # The production coupled full certificate remains mandatory. The legacy
    # standalone diagnostic switch is incompatible with hybrid admission.
    hybrid_env.pop("NM_FEM_TRUE_RESIDUAL_CERTIFY", None)
    hybrid_env["NM_FEM_HUMAN_HYBRID_COORDINATES"] = "1"
    hybrid_env["NM_FEM_HYBRID_RESIDUAL_WITNESS"] = "1"
    hybrid_env["NM_FEM_TRUE_RESIDUAL_ROOT"] = "0"
    hybrid_env["NM_FEM_HYBRID_RESIDUAL_REFINEMENT_MIN_RATIO"] = "2"
    hybrid_env["NM_FEM_HYBRID_RESIDUAL_REFINEMENT_TRACE"] = str(WITNESS)
    hybrid_env["NUMI_HUMAN_CAPTURE_FEM_ENDPOINT_STATE"] = "1"
    hybrid_env["NUMI_HUMAN_RESTING_COMMON_FAILURE_RECEIPT"] = str(hybrid_run / "common-field-failure.json")

    frozen_manifest_sha = sha(artifact_manifest)
    source_manifest_sha = sha(source_manifest)
    common = {
        "schema": 1,
        "status": "prepared_not_launched",
        "launch_policy": "plan-only; no process launched by this tool",
        "build_id": 161,
        "frozen_bundle": str(bundle),
        "frozen_artifact_manifest": str(artifact_manifest),
        "frozen_artifact_manifest_sha256": frozen_manifest_sha,
        "source_manifest": str(source_manifest),
        "source_manifest_sha256": source_manifest_sha,
        "binary": str(binary),
        "binary_sha256": sha(binary),
        "metallib": str(metallib),
        "metallib_sha256": sha(metallib),
        "runtime_dylib": str(dylib),
        "runtime_dylib_sha256": sha(dylib),
        "witness": str(WITNESS),
        "witness_sha256": witness_sha,
        "witness_analysis": str(WITNESS_ANALYSIS),
        "witness_layout_fingerprint": witness_meta.get("basis_layout_fingerprint_fnv1a64"),
        "witness_source_physics_fingerprint": witness_meta.get("source_physics_fingerprint"),
        "witness_node_count": witness_meta.get("sampled_node_count"),
        "witness_nonzero_node_count": witness_meta.get("nonzero_sampled_node_count"),
        "witness_region_count": witness_meta.get("region_count"),
        "witness_mode_count": witness_meta.get("mode_count"),
        "witness_control_step": witness_meta.get("control_step"),
        "witness_newton_iteration": witness_meta.get("newton_iteration"),
        "base_full_invocation": str(FULL_BASE),
        "base_full_invocation_sha256": sha(FULL_BASE),
        "base_hybrid_invocation": str(HYBRID_BASE),
        "base_hybrid_invocation_sha256": sha(HYBRID_BASE),
        "endpoint_capture": "NUMI_HUMAN_CAPTURE_FEM_ENDPOINT_STATE=1 across the complete run history",
        "mandatory_full_physical_certificate": "retained by the existing production coupled solver path; do not replace with a diagnostic-only environment switch",
    }
    plans = (
        (full_run / "invocation-plan.json", "full_coordinate_reference", full_argv, full_env, "Matched full-coordinate reference cloned from the accepted build155 full invocation."),
        (hybrid_run / "invocation-plan.json", "hybrid_coordinates_refined_from_605_node_witness", hybrid_argv, hybrid_env, "Hybrid candidate uses the unchanged verified 605-node build152 witness; full physical certification and endpoint-history capture remain active."),
    )
    for path, treatment, argv, env, purpose in plans:
        payload = dict(common)
        payload.update({
            "treatment": treatment,
            "purpose": purpose,
            "cwd": str(path.parent),
            "argv": argv,
            "simulation_environment": env,
            "expected_output_directory": str(path.parent / "output"),
        })
        path.write_text(json.dumps(payload, indent=2) + "\n")
    print(json.dumps({"plans": [str(item[0]) for item in plans], "binary_sha256": sha(binary), "metallib_sha256": sha(metallib), "source_manifest_sha256": source_manifest_sha, "witness_sha256": witness_sha, "launched": False}, indent=2))

if __name__ == "__main__":
    main()

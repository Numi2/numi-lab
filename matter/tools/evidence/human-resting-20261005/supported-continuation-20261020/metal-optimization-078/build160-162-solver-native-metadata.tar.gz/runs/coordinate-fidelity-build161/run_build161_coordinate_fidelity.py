#!/usr/bin/env python3
"""Run a prepared build161 fidelity plan only with an explicit --launch."""
import argparse, hashlib, json, os, subprocess, time
from datetime import datetime, timezone
from pathlib import Path

def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(1048576), b""):
            h.update(chunk)
    return h.hexdigest()

p = argparse.ArgumentParser()
p.add_argument("plan", type=Path)
p.add_argument("--launch", action="store_true")
a = p.parse_args()
plan_path = a.plan.resolve()
plan = json.loads(plan_path.read_text())
if plan.get("schema") != 1 or plan.get("build_id") != 161:
    raise SystemExit("unexpected plan schema or build ID")
for path_key, hash_key in (("binary", "binary_sha256"), ("metallib", "metallib_sha256"), ("runtime_dylib", "runtime_dylib_sha256"), ("frozen_artifact_manifest", "frozen_artifact_manifest_sha256"), ("source_manifest", "source_manifest_sha256"), ("witness", "witness_sha256")):
    if sha(plan[path_key]) != plan[hash_key]:
        raise SystemExit("frozen input changed: " + plan[path_key])
manifest = json.loads(Path(plan["frozen_artifact_manifest"]).read_text())
for rel, expected in (("numi-human-native", plan["binary_sha256"]), ("NumiMatter.metallib", plan["metallib_sha256"]), ("libmetalrobo.dylib", plan["runtime_dylib_sha256"]), ("source-manifest.json", plan["source_manifest_sha256"])):
    if manifest.get(rel) != expected:
        raise SystemExit("artifact manifest mismatch: " + rel)
if Path(plan["argv"][0]).resolve() != Path(plan["binary"]).resolve():
    raise SystemExit("argv binary mismatch")
if plan["simulation_environment"].get("DYLD_LIBRARY_PATH") != str(Path(plan["frozen_bundle"])):
    raise SystemExit("runtime path is not frozen bundle")
if plan["simulation_environment"].get("NUMI_MATTER_METALLIB_OVERRIDE") != plan["metallib"]:
    raise SystemExit("Metal override is not frozen artifact")
if plan.get("treatment", "").startswith("hybrid_coordinates"):
    envp = plan["simulation_environment"]
    if envp.get("NM_FEM_HUMAN_HYBRID_COORDINATES") != "1" or envp.get("NM_FEM_HYBRID_RESIDUAL_WITNESS") != "1":
        raise SystemExit("hybrid controls missing")
    if "NM_FEM_TRUE_RESIDUAL_CERTIFY" in envp:
        raise SystemExit("legacy certificate switch conflicts with hybrid")
    if envp.get("NM_FEM_HYBRID_RESIDUAL_REFINEMENT_TRACE") != plan["witness"]:
        raise SystemExit("wrong refinement witness")
run_dir = Path(plan["cwd"])
out_dir = Path(plan["expected_output_directory"])
if out_dir.exists():
    raise SystemExit("refusing to overwrite trial output: " + str(out_dir))
for arg in plan["argv"][1:]:
    if arg.startswith("/") and arg != str(out_dir) and not Path(arg).exists():
        raise SystemExit("planned input disappeared: " + arg)
if not a.launch:
    print(json.dumps({"status":"preflight_passed_not_launched","treatment":plan["treatment"],"output":str(out_dir)}, indent=2))
    raise SystemExit(0)
run_dir.mkdir(parents=True, exist_ok=True)
receipt = dict(plan)
receipt.update({"status":"launched","plan_path":str(plan_path),"plan_sha256":sha(plan_path),"started_utc":datetime.now(timezone.utc).isoformat(),"launched_binary_sha256":sha(plan["binary"]),"launched_metallib_sha256":sha(plan["metallib"])})
inv = run_dir / "invocation.json"
if inv.exists():
    raise SystemExit("refusing to overwrite invocation receipt")
inv.write_text(json.dumps(receipt, indent=2) + "\n")
env = os.environ.copy()
env.update(plan["simulation_environment"])
t0 = time.monotonic()
with (run_dir / "stdout.log").open("x") as so, (run_dir / "stderr.log").open("x") as se:
    try:
        code = subprocess.run(plan["argv"], cwd=run_dir, env=env, stdout=so, stderr=se, timeout=900).returncode
    except subprocess.TimeoutExpired:
        code = "censored_900s"
result = {"exit_code":code,"process_wall_seconds":time.monotonic()-t0,"finished_utc":datetime.now(timezone.utc).isoformat(),"output_directory":str(out_dir)}
(run_dir / "process.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
if code != 0:
    raise SystemExit(1)

#!/usr/bin/env python3
"""Select one intact final-Newton witness from a completed hybrid run.

Default mode is a read-only dry run. With --write, emits the raw selected
fem_true_residual_cycle record and a follow-up build161 invocation plan.
"""
import argparse, hashlib, json
from pathlib import Path

ROOT = Path("/Users/numi/numi-human-aortic-contact-opt-20261019")
PLAN_ROOT = ROOT / "matter/tools/evidence/human-resting-20261005/supported-continuation-20261020/metal-optimization-078/coordinate-fidelity-build161"
PREFIX = "fem_true_residual_cycle="

def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(1048576), b""):
            h.update(chunk)
    return h.hexdigest()

def load_records(run_dir):
    process = json.loads((run_dir / "process.json").read_text())
    if process.get("exit_code") == "censored_900s":
        raise SystemExit("refusing censored trial without an explicit manual review")
    invocation = json.loads((run_dir / "invocation.json").read_text())
    if invocation.get("build_id") != 161 or not invocation.get("treatment", "").startswith("hybrid_coordinates"):
        raise SystemExit("input is not a build161 hybrid run")
    env = invocation.get("simulation_environment", {})
    if env.get("NM_FEM_HUMAN_HYBRID_COORDINATES") != "1" or env.get("NM_FEM_HYBRID_RESIDUAL_WITNESS") != "1":
        raise SystemExit("hybrid witness capture was not enabled")
    stderr_path = run_dir / "stderr.log"
    if not stderr_path.is_file():
        raise SystemExit("completed run has no stderr witness source")
    source_hash = sha(stderr_path)
    candidates = []
    for line_number, line in enumerate(stderr_path.read_text(errors="strict").splitlines(), 1):
        if not line.startswith(PREFIX):
            continue
        try:
            record = json.loads(line[len(PREFIX):])
        except json.JSONDecodeError:
            continue
        if not record.get("final_cycle") or record.get("operator_scope") != "full_coupled_hybrid_projected_operator":
            continue
        if int(record.get("root", -1)) != 0:
            continue
        envs = record.get("environments") or []
        if not envs:
            continue
        measured = envs[0]
        witness = measured.get("hybrid_physical_residual_witness")
        full = measured.get("full_physical_linear_residual") or {}
        components = measured.get("hybrid_coordinate_residual_components") or {}
        if not isinstance(witness, dict) or not full.get("finite") or not components.get("finite") or not components.get("domain_closed"):
            continue
        if int(measured.get("solver_status_code", 1)) != 0 or int(measured.get("operator_status_code", 1)) != 0:
            continue
        regions = witness.get("regions") or []
        nodes = [node for region in regions for node in (region.get("nodes") or [])]
        if not nodes or len(nodes) != len({int(n["global_node"]) for n in nodes}):
            continue
        if any(len(region.get("nodes") or []) > int(witness.get("top_per_region_limit", 0)) for region in regions):
            continue
        values = [float(n["residual_l2"]) for n in nodes]
        if not all(v >= 0.0 and v < float("inf") for v in values):
            continue
        full_l2 = float(full.get("l2", float("nan")))
        max_node_l2 = max(values)
        if not (full_l2 >= 0.0 and full_l2 < float("inf")):
            continue
        if max_node_l2 > full_l2 + max(1.0e-12, abs(full_l2) * 8.0e-6):
            continue
        score = sum(values)
        if score <= 0.0:
            continue
        candidates.append({"line_number_1based": line_number, "record": record, "line": line.rstrip("\n"), "score": score, "sampled_node_count": len(nodes), "nonzero_sampled_node_count": sum(v > 0.0 for v in values), "max_sample_node_l2": max_node_l2, "full_physical_residual_l2": full_l2})
    if not candidates:
        raise SystemExit("no finite, closed, healthy, nonzero final-cycle witness found")
    newest_iteration = max(int(c["record"].get("newton_iteration", -1)) for c in candidates)
    final_group = [c for c in candidates if int(c["record"].get("newton_iteration", -1)) == newest_iteration]
    # Choose a single intact microtick record. Microtick is not serialized, so
    # never aggregate values across records; stable line order breaks score ties.
    selected = sorted(final_group, key=lambda c: (-c["score"], c["line_number_1based"]))[0]
    meta = {
        "schema": 1,
        "source_run_directory": str(run_dir),
        "source_invocation_sha256": sha(run_dir / "invocation.json"),
        "source_stderr": str(stderr_path),
        "source_stderr_sha256": source_hash,
        "selected_line_number_1based": selected["line_number_1based"],
        "selected_newton_iteration": newest_iteration,
        "selection": "highest sum of recorded per-region top-node residual L2 values among healthy finite final-cycle records at the newest Newton iteration; intact record only",
        "microtick": "not serialized; selected record is preserved intact and not merged with other records",
        "candidate_final_cycle_records_at_newest_iteration": [{k: c[k] for k in ("line_number_1based", "score", "sampled_node_count", "nonzero_sampled_node_count", "max_sample_node_l2", "full_physical_residual_l2")} for c in final_group],
        "basis_layout_fingerprint_fnv1a64": selected["record"]["environments"][0]["hybrid_physical_residual_witness"].get("basis_layout_fingerprint_fnv1a64"),
        "source_physics_fingerprint": selected["record"]["environments"][0]["hybrid_physical_residual_witness"].get("source_physics_fingerprint"),
        "object_index": selected["record"]["environments"][0]["hybrid_physical_residual_witness"].get("object_index"),
        "basis_node_count": selected["record"]["environments"][0]["hybrid_physical_residual_witness"].get("basis_node_count"),
        "region_count": selected["record"]["environments"][0]["hybrid_physical_residual_witness"].get("region_count"),
        "mode_count": selected["record"]["environments"][0]["hybrid_physical_residual_witness"].get("mode_count"),
        "sampled_node_count": selected["sampled_node_count"],
        "nonzero_sampled_node_count": selected["nonzero_sampled_node_count"],
        "selection_score": selected["score"],
        "max_sample_node_l2": selected["max_sample_node_l2"],
        "full_physical_residual_l2": selected["full_physical_residual_l2"],
    }
    return invocation, process, selected, meta

def main():
    p = argparse.ArgumentParser()
    p.add_argument("run_directory", type=Path)
    p.add_argument("--base-plan", type=Path)
    p.add_argument("--write", action="store_true", help="write selected trace, analysis, and follow-up invocation plan")
    a = p.parse_args()
    run_dir = a.run_directory.resolve()
    invocation, process, selected, meta = load_records(run_dir)
    if not a.write:
        print(json.dumps({"status":"selected_not_written","line":selected["line_number_1based"],"newton_iteration":meta["selected_newton_iteration"],"sampled_nodes":meta["sampled_node_count"],"nonzero_nodes":meta["nonzero_sampled_node_count"],"source_stderr_sha256":meta["source_stderr_sha256"],"score":meta["selection_score"],"exit_code":process.get("exit_code")}, indent=2))
        return
    base_plan_path = a.base_plan.resolve() if a.base_plan else Path(invocation["plan_path"]).resolve()
    base_plan = json.loads(base_plan_path.read_text())
    if base_plan.get("build_id") != 161 or not base_plan.get("treatment", "").startswith("hybrid_coordinates"):
        raise SystemExit("follow-up base plan is not a build161 hybrid plan")
    trace_path = run_dir / "refinement-witness-fresh-final-newton.jsonl"
    analysis_path = run_dir / "refinement-witness-fresh-final-newton-analysis.json"
    followup_dir = PLAN_ROOT / "hybrid-coordinate-refined-from-fresh-final-newton"
    plan_path = followup_dir / "invocation-plan.json"
    for path in (trace_path, analysis_path, plan_path):
        if path.exists():
            raise SystemExit("refusing to overwrite existing follow-up artifact: " + str(path))
    followup_dir.mkdir(parents=True, exist_ok=False)
    trace_path.write_text(selected["line"] + "\n")
    meta["trace_file"] = str(trace_path)
    meta["trace_file_sha256"] = sha(trace_path)
    analysis_path.write_text(json.dumps(meta, indent=2) + "\n")
    new_plan = dict(base_plan)
    new_plan.update({"status":"prepared_not_launched","treatment":"hybrid_coordinates_refined_from_fresh_final_newton","purpose":"Fresh same-run final-Newton residual witness follow-up; original 605-witness trial remains unchanged.","based_on_hybrid_run":str(run_dir),"based_on_hybrid_invocation_sha256":sha(run_dir / "invocation.json"),"witness":str(trace_path),"witness_sha256":sha(trace_path),"witness_analysis":str(analysis_path),"witness_node_count":meta["sampled_node_count"],"witness_nonzero_node_count":meta["nonzero_sampled_node_count"],"witness_layout_fingerprint":meta["basis_layout_fingerprint_fnv1a64"],"witness_source_physics_fingerprint":meta["source_physics_fingerprint"],"cwd":str(followup_dir),"expected_output_directory":str(followup_dir / "output")})
    new_plan["argv"] = list(base_plan["argv"])
    new_plan["argv"][4] = str(followup_dir / "output")
    new_env = dict(base_plan["simulation_environment"])
    new_env["NM_FEM_HYBRID_RESIDUAL_REFINEMENT_TRACE"] = str(trace_path)
    new_env["NUMI_HUMAN_RESTING_COMMON_FAILURE_RECEIPT"] = str(followup_dir / "common-field-failure.json")
    new_plan["simulation_environment"] = new_env
    plan_path.write_text(json.dumps(new_plan, indent=2) + "\n")
    print(json.dumps({"status":"fresh_witness_and_followup_plan_prepared_not_launched","trace":str(trace_path),"trace_sha256":sha(trace_path),"analysis":str(analysis_path),"plan":str(plan_path),"selected_line":selected["line_number_1based"],"sampled_nodes":meta["sampled_node_count"],"nonzero_nodes":meta["nonzero_sampled_node_count"]}, indent=2))

if __name__ == "__main__":
    main()

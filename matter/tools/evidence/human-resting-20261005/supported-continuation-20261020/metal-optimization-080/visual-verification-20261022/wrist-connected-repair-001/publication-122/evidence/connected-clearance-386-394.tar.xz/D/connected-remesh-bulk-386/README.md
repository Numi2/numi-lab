# Connected remesh 386 recovery and checkpoint owner

This isolated runner is a copy of the 383 construction pipeline with accepted-round checkpoints. It does not launch automatically. Each checkpoint is written only after a complete exact 130 self audit with zero pairs and a complete 185-typed-bank 159 audit with strict per-bank nonincrease and positive total reduction. Candidate and audit files are copied and hash-verified before the checkpoint directory is atomically published.

The recovered round 1 below reconstructs saved 383 outputs without rerunning geometry. Round 2 is preserved as a failure: the raw proposal had 122 self pairs, and its self-safe subset returned to the round-1 candidate, yielding strict 159 reduction zero. This task ran no geometry.

All results are fixed-coordinate construction evidence only. They do not qualify physical or native behavior.

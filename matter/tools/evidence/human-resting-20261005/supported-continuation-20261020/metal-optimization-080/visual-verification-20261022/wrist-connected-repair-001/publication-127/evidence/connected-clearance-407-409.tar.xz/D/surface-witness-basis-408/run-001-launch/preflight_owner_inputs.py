from pathlib import Path
import json,hashlib,numpy as np,sys,importlib.util
D=Path('/Users/numi/Work/numi-human-connected-surface-069');p=D/'D/surface-witness-basis-408';plan=p/'run-001-launch';a=json.load(open(plan/'argv.json'));sha=lambda x:hashlib.sha256(Path(x).read_bytes()).hexdigest()
def arg(k):return a[a.index(k)+1]
c=Path(arg('--base-candidate'));assert sha(c)=='6c115d5beef83989bed2af6309771b8d34cece7e30eaaf3f99f397ee3a304fda'
assert sha(arg('--self-pairs'))=='7dd79041c164c79e89a4c79bde047c7dcee21c7d22cbc9add91bae556df82f85'
assert sha(arg('--point-target-npz'))=='47b0e729f6fb36c3cf5698044038262d1ccb3ecd97ebabc02533c542cffc8b6f'
assert sha(arg('--face-target-npz'))=='24157d873f79ec039a9e3e3c7cedcc0e4131c89de1521b762e428d3d59466b6e'
assert sha(arg('--fixed-boundary-npz'))=='711957268a457a17071fdffbc5bb05344edea6d18b28cba9783c6774628fe9e8'
assert sha(arg('--point-depth-rows-npz'))=='ff8258b5fd6844271ba9023d9fc0778d2ab16e996c058b136f3bb630294118a9'
assert all(arg(k)==v for k,v in {'--trust-mm':'1','--source-cap-mm':'12','--area-floor':'0.1','--max-edge-gradient':'0.5','--fixed-prefix-nodes':'0','--time-limit-s':'90','--retained-gain-fraction':'0.95','--area-scp-iterations':'1'}.items())
for flag in ['--immediate-parent-basis','--fine-point-controls','--fine-surface-controls']:assert flag in a
z=np.load(c);assert np.array_equal(z['source_O_faces'],z['area_reference_037_source_O_faces'])
r=D/'D/postfit-backtrack-405-topology-full-audits/run-001';j=json.load(open(r/'audit-130/summary.json'));s=json.load(open(r/'audit-159/report.json'));assert j['candidate_sha256']==sha(c) and j['complete_surface_audit'] and j['exact_PLC_surface_pairs']==0
assert s['complete'] and len(s['banks'])==185 and sum((b.get('result')or{}).get('count',0)for b in s['banks'])==3324
seed=Path(arg('--self-pairs')).parent/'report.json';assert seed.exists(),'await refreshed seed receipt'
seedj=json.load(open(seed));assert sha(arg('--self-pairs')) in json.dumps(seedj)
paths={str(c),a[0],a[1],str(seed),str(r/'audit-130/summary.json'),str(r/'audit-159/report.json')}
for v in a[2:]:
 if v.startswith('/Users/') and v!=arg('--output'):paths.add(v)
for n in ['fine_point_basis_405.py','surface_witness_basis_408.py','precision_phase_one_integration_396.py']:paths.add(str(p/n))
paths.add(str(D/'D/connected-fixed-boundary-314/emit_introduced_skin_bone_barriers_314.py'))
manifest={s:dict(sha256=sha(s),bytes=Path(s).stat().st_size)for s in sorted(paths)}
out=dict(status='PASS_FROZEN_408_INPUT_AND_OWNER_PREFLIGHT',argv_sha256=sha(plan/'argv.json'),argv=a,input_manifest=manifest,candidate_sha256=sha(c),self_seed_count=len(np.load(arg('--self-pairs'))),surface_targets=3324,inside_targets=438,typed_anchor_count=len(z['typed_coarse_anchor_output_rows_018']),matched037_faces=True,native_admission=False,accepted_physical_steps=0)
(plan/'preflight.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if k not in ['argv','input_manifest']}))

from pathlib import Path
import importlib.util,json,hashlib,numpy as np,subprocess
D=Path('/Users/numi/Work/numi-human-connected-surface-069');H=D/'barycentric-connected-clearance-170';f=D/'D/coherent-support-continuation-360/run_coherent_target_continuation_360.py'
assert hashlib.sha256(f.read_bytes()).hexdigest()=='fa33220b2e2e9d3e96e344f03366a21ccc8ce2ffb841917c9f7d3ef1ccf98c64'
sp=importlib.util.spec_from_file_location('recovery360',f);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
r=H/'coherent-support-continuation-362';state=m.read(H/'joint-boundary-continuation-322/selected-result.json');trial=r/'round-001/attempt-001/proposal/candidate.npz';raw=np.load(trial.parent/'raw-lp-candidate.npz',allow_pickle=False)
keys=[k for k in raw.files if k.endswith('_lp_delta_mm_f64')];assert len(keys)==1,keys
prefix=keys[0][:-len('delta_mm_f64')];support=np.asarray(raw[prefix+'support_rows'],dtype=np.int64)
m.ensure_fit_scope(Path(state['candidate']),trial,support)
out=r/'saved-candidate-local-recovery';out.mkdir()
m.write(out/'input-recovery.json',dict(reason='successreport basis_coordinates ndarray serialization; saved candidate audited without LP rerun',source_sha256=m.sha(f),trial=str(trial),trial_sha256=m.sha(trial),support_rows=len(support),native_admission=False,accepted_physical_steps=0))
selected=m.run_backtracker(state,trial,out/'global-275',m.LOCAL_HELPER_339,'reduce_witness_node_scales_with_edge_gradient',6,24,support)
m.write(out/'completed.json',dict(selected=str(selected)if selected else None,native_admission=False,accepted_physical_steps=0));print(selected)

#!/usr/bin/env python3
from __future__ import annotations
import hashlib, importlib.util, json, sys, time
from pathlib import Path
import numpy as np

ROOT=Path("/Users/numi/Work/numi-human-connected-surface-069")
HERE=Path(__file__).resolve().parent
M405=HERE/"cross_seam_search_405.py"
OWNER402=HERE.parent/"local-two-parent-retriangulation-402"/"two_parent_patch_flips_402.py"
PRED=Path("/Users/numi/numi-human-aortic-contact-opt-20261019/matter/tools/evidence/human-resting-20261005/supported-continuation-20261020/metal-optimization-080/visual-verification-20261022/wrist-connected-repair-001/source-route-weighting-owner-385/validation/src/numilab_human/cardiac_cavity_intersections.py")

def loadmod(n,p):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);sys.modules[n]=m;s.loader.exec_module(m);return m

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def main():
 import argparse
 ap=argparse.ArgumentParser();ap.add_argument("--candidate",required=True);ap.add_argument("--output-dir",required=True);ap.add_argument("--max-trials",type=int,default=80);ap.add_argument("--max-accept",type=int,default=4);ap.add_argument("--time-limit-s",type=float,default=180)
 a=ap.parse_args(); cp=Path(a.candidate); od=Path(a.output_dir)
 if od.exists():raise FileExistsError(od)
 od.mkdir(parents=True)
 m=loadmod("cross_seam_search_405",M405); b=loadmod("two_parent_patch_flips_402",OWNER402)
 search=loadmod("exact_local_flip_search_402",HERE.parent/"local-two-parent-retriangulation-402"/"exact_local_flip_search_402.py");search.PRED=PRED
 exact=search.exact_owner()
 with np.load(cp,allow_pickle=False) as z:c={k:z[k] for k in z.files}
 b.validate_candidate(c)
 details={9570,9577}
 out={k:np.array(v,copy=True) for k,v in c.items()}
 locks,outer,between,_=m.boundary_locks(out,m.detail_csr(out,details),details)
 _,_,base_rep,pairs=m.audit_group(exact,out,0)
 current_pairs=pairs.copy();logs=[];accepted=[];start=time.monotonic();tested_total=0
 for step in range(a.max_accept):
  if not len(current_pairs) or tested_total>=a.max_trials or time.monotonic()-start>=a.time_limit_s:break
  nodes=set(map(int,out["source_O_faces"][current_pairs].ravel()))
  active=set(map(int,np.flatnonzero(np.any(np.isin(out["source_O_faces"],np.asarray(sorted(nodes),dtype=np.int64)),axis=1))))
  drows=m.detail_csr(out,details)
  active={r for r in active if m.group_of(drows[r])==0}
  em=b.edge_map(out["source_O_faces"]); dedup={}
  for row in sorted(active):
   for x,y in zip(out["source_O_faces"][row],np.roll(out["source_O_faces"][row],-1)):
    e=(min(int(x),int(y)),max(int(x),int(y)))
    inc=em.get(e,[])
    if len(inc)==2 and e not in dedup:dedup[e]=inc
  eligible=[]
  for e,inc in sorted(dedup.items()):
   if tested_total>=a.max_trials or time.monotonic()-start>=a.time_limit_s:break
   op,why=m.propose_one(out,e,inc,locks)
   if op is None:
    logs.append({"step":step+1,"edge":list(e),"status":"REJECTED_GEOMETRY_OR_SCOPE","reason":why});continue
   eligible.append((op,e,inc))
  eligible.sort(key=lambda q:(-float(q[0]["angle_gain_deg"]),q[1]))
  best=None
  for op,e,inc in eligible:
   if tested_total>=a.max_trials or time.monotonic()-start>=a.time_limit_s:break
   tested_total+=1; trial=m.apply_op(out,op)
   _,scope,rep,pp=m.audit_group(exact,trial,0)
   before=set(map(tuple,current_pairs.tolist()));after=set(map(tuple,pp.tolist()))
   rec={"step":step+1,"edge":list(e),"face_rows":op["face_rows"],"expected_old_faces":out["source_O_faces"][op["face_rows"]].tolist(),"new_faces":op["new_faces"],
        "before_pairs":len(current_pairs),"after_pairs":len(pp),"introduced_pairs":[list(q) for q in sorted(after-before)],"removed_pairs":[list(q) for q in sorted(before-after)],
        "detail_face_union":op["detail_face_union"],"subface_union":op["subface_union"],"immediate_parent_union":op["immediate_parent_union"],
        "angle_gain_deg":float(op["angle_gain_deg"]),"exact_scope_faces":len(scope),"exact_selected_faces":int(rep.get("selected_face_count",-1)),
        "exact_complete_faces":int(rep.get("complete_surface_face_count",-1)),"status":"ACCEPTED" if len(pp)<len(current_pairs) else "REJECTED_EXACT_LOCAL"}
   logs.append(rec)
   if len(pp)<len(current_pairs):
    score=(len(pp),-float(op["angle_gain_deg"]),e)
    if best is None or score<best[0]:best=(score,trial,op,pp,rec)
  if best is None:break
  _,out,op,current_pairs,rec=best;accepted.append(rec)
  locks2,outer2,between2,_=m.boundary_locks(out,m.detail_csr(out,details),details)
  if outer2!=outer or between2!=between:raise RuntimeError("fixed patch outer boundary changed")
 _,scope,final_rep,final_pairs=m.audit_group(exact,out,0)
 outp=od/"candidate.npz";np.savez_compressed(outp,**out)
 report={"status":"CURRENT_405_WITNESS_LOCAL_SEARCH_COMPLETE" if accepted else "NO_LOCAL_EXACT_REDUCTION",
  "geometry_admitted":False,"accepted_physical_steps":0,"input_path":str(cp),"input_sha256":sha(cp),"output_path":str(outp),"output_sha256":sha(outp),
  "builder_sha256":sha(Path(__file__)),"cross_seam_owner_sha256":sha(M405),"patch_owner_402_sha256":sha(OWNER402),"predicate_sha256":sha(PRED),
  "patch_detail_rows":[9570,9577],"initial_pair_count":len(pairs),"initial_pairs":pairs.tolist(),"final_pair_count":len(final_pairs),"final_pairs":final_pairs.tolist(),
  "accepted_flip_count":len(accepted),"accepted_flips":accepted,"trial_count":len(logs),"trials":logs,"exact_scope_face_count":len(scope),
  "complete_predicate_face_count":int(final_rep.get("complete_surface_face_count",-1)),"fixed_outer_edges_preserved":True,"between_group_boundary_preserved":True,
  "points_bitwise_unchanged":b.array_identical(c["points_world_m"],out["points_world_m"]),
  "matched_037_faces_synchronized":bool(np.array_equal(out["source_O_faces"],out["area_reference_037_source_O_faces"])),
  "all185_and_full_surface_gates_required":True,"physical_acceptance":"NOT_CLAIMED","elapsed_seconds":time.monotonic()-start}
 (od/"report.json").write_text(json.dumps(report,indent=2,sort_keys=True,allow_nan=False)+"\n")
 print(json.dumps({k:v for k,v in report.items() if k not in ("initial_pairs","final_pairs","accepted_flips","trials")},indent=2))
if __name__=="__main__":main()

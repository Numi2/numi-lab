#!/usr/bin/env python3
"""Refresh self-separation pair identities for selected 408 pass-003 at fixed topology.
Construction guards only; exact self and 185-bank audits remain separate authorities.
"""
from pathlib import Path
import hashlib, importlib.util, json
import numpy as np

D=Path('/Users/numi/Work/numi-human-connected-surface-069')
C=D/'D/postfit-backtrack-408/run-001/backtrack-373/pass-003/candidate.npz'
TOPO=D/'D/local-two-parent-retriangulation-405/run-011-replay-405-four-flips/candidate.npz'
SEEDS=D/'D/self-witness-refresh-408/run-001/merged-self-pair-seeds.npy'
SEED_REPORT=D/'D/self-witness-refresh-408/run-001/report.json'
AUD130=D/'D/postfit-backtrack-408/run-001/backtrack-373/pass-003/audit-130/summary.json'
AUD159=D/'D/postfit-backtrack-408/run-001/backtrack-373/pass-003/audit-159/report.json'
OWNER=D/'barycentric-connected-clearance-170/connected-local-continuation-189-run001/round-005/proposal/round-001/fit/self_separation_026.py'
OUT=D/'D/self-witness-refresh-410/run-001'
EXPECTED={
 'candidate':'a661a0ac9ff4690a5e67b1dc06753289b7cf267c188d8b812b929297ae7fecbe',
 'topology':'6c115d5beef83989bed2af6309771b8d34cece7e30eaaf3f99f397ee3a304fda',
 'seeds':'7dd79041c164c79e89a4c79bde047c7dcee21c7d22cbc9add91bae556df82f85',
 'seed_report':'e594f111d511bcca999f118051d7cb494ba0f5a69d75dc77e5458156147ebded',
 'audit130':'265eace7cd35e2e954527e0e01b8192859309ccb8e3e7aa931ad90f35392941b',
 'audit159':'b498988d21224bdcfd23e47b9330656a0789d14c165d71fc66dd20766f24ccba',
 'owner':'c67daf7c9fd2292e32ae88dba215a74350e1cbf83c669bc299a64b86d12e99f3',
 'pass001_candidate':'bee61a0ef7121b816f0147ed14d829ab287b428a2d19d8c895f0032cd3d2a794',
 'pass001_summary':'4364efec70a1618f805bb59f6cb7bb344c76e0790a5caba6a7ebbf5716df4ea2',
 'pass001_pairs':'b83dea4b3c0125b55a7f7f96cc9a0d298dbbeafa74143343ef60a39a50a34bb9',
 'pass002_candidate':'92f2705ce4f3759587ccf0fe0f8c63ac3478d6808308a1ff55ead45f1f4e5545',
 'pass002_summary':'ed9d59f3cdd28d9761443a9e487b040787893c5cfa6d4419b9914402769e7118',
 'pass002_pairs':'ba1ce3d244ff77282df41eb0bfc2379e37f82c955d46b0a0dd8b750654a55bb8',
}
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def require(path,key):
    got=sha(path)
    if got!=EXPECTED[key]: raise ValueError(f'{key} SHA mismatch: {got}')
    return got
def load_json(p): return json.loads(Path(p).read_text())
def save_npy_x(path,a):
    with Path(path).open('xb') as f: np.save(f,a,allow_pickle=False)
def save_json_x(path,obj):
    with Path(path).open('x') as f: json.dump(obj,f,indent=2,sort_keys=True); f.write('\n')
def count_surface_pairs(report):
    """Null-safe 185-bank count copied from the tested 409 refresh owner."""
    if not isinstance(report,dict) or report.get('complete') is not True:
        raise ValueError('159 report is incomplete')
    banks=report.get('banks')
    if not isinstance(banks,list) or len(banks)!=185 or int(report.get('bank_count',-1))!=185 or int(report.get('expected_bank_count',-1))!=185:
        raise ValueError('159 report does not contain exactly 185 banks')
    keys=set(); total=0
    for b in banks:
        key=(int(b['body']),int(b['stable_bone_id']))
        if key in keys: raise ValueError('duplicate typed 159 bank key')
        keys.add(key)
        result=b.get('result')
        if result is None:
            if int(b.get('skin_aabb_active',-1))!=0 or int(b.get('bank_aabb_active',-1))!=0:
                raise ValueError('null 159 result on a bank with active AABBs')
            continue
        count=int(result.get('count',-1)); pairs=result.get('triangle_pairs')
        if count<0 or not isinstance(pairs,list) or len(pairs)!=count:
            raise ValueError('159 result pair count does not match explicit rows')
        total+=count
    return total
def topology_equal(a,b,label):
    if not np.array_equal(a['source_O_faces'],b['source_O_faces']):
        raise ValueError(f'{label}: source_O_faces topology differs')
    # These are the only coordinate-dependent arrays changed by the fitted 408
    # state relative to the frozen four-flip topology. All ancestry/typed identity
    # arrays and every other candidate field must remain byte-identical.
    coordinate_derived={'points_world_m','node_parent_coarse_edge_parameter','refinement_face_parent_barycentric'}
    if set(a.files)!=set(b.files): raise ValueError(f'{label}: candidate key set differs')
    changed=[]
    for k in a.files:
        if a[k].shape!=b[k].shape: raise ValueError(f'{label}: shape changed for {k}')
        if not np.array_equal(a[k],b[k]):
            changed.append(k)
            if k not in coordinate_derived: raise ValueError(f'{label}: unexpected non-coordinate array change: {k}')
    if label=='selected candidate' and not {'points_world_m','node_parent_coarse_edge_parameter','refinement_face_parent_barycentric'}.issubset(changed):
        raise ValueError(f'{label}: expected coordinate and derived projection fields to differ; got {changed}')
    return changed

for key,path in [('candidate',C),('topology',TOPO),('seeds',SEEDS),('seed_report',SEED_REPORT),('audit130',AUD130),('audit159',AUD159),('owner',OWNER)]: require(path,key)
OUT.mkdir(parents=True,exist_ok=False)
cur=np.load(C,allow_pickle=False); topo=np.load(TOPO,allow_pickle=False); old=np.load(SEEDS,allow_pickle=False)
seed_report=load_json(SEED_REPORT); s130=load_json(AUD130); s159=load_json(AUD159)
changed_candidate_arrays=topology_equal(topo,cur,'selected candidate')
if seed_report.get('candidate_sha256')!=EXPECTED['topology'] or int(seed_report.get('expanded_unique_pair_count',-1))!=len(old):
    raise ValueError('408 seed report does not identify its 6c115 topology-domain seed file')
if old.ndim!=2 or old.shape[1]!=2 or len(old)!=17983 or np.any(old<0) or np.any(old>=len(cur['source_O_faces'])):
    raise ValueError('unexpected 408 seed shape/domain')
if s130.get('candidate_sha256')!=EXPECTED['candidate'] or int(s130.get('exact_PLC_surface_pairs',-1))!=0:
    raise ValueError('matched 130 report is not the exact-zero self audit for selected 408 candidate')
if s159.get('candidate_sha256')!=EXPECTED['candidate'] or s159.get('complete') is not True or int(s159.get('bank_count',-1))!=185 or int(s159.get('expected_bank_count',-1))!=185:
    raise ValueError('matched 159 report is not complete/matched across 185 banks')
current_surface_pairs=count_surface_pairs(s159)
# Add all exact self-pair witnesses from failed 408 passes 001 and 002.
extra_arrays=[]; extra_receipts=[]
for tag in ('001','002'):
    p=D/f'D/postfit-backtrack-408/run-001/backtrack-373/pass-{tag}'
    cp=p/'candidate.npz'; sp=p/'audit-130/summary.json'; pp=p/'audit-130/surface-self-pairs.npy'
    candidate_key=f'pass{tag}_candidate'; summary_key=f'pass{tag}_summary'; pairs_key=f'pass{tag}_pairs'
    for path,key in ((cp,candidate_key),(sp,summary_key),(pp,pairs_key)): require(path,key)
    cand=np.load(cp,allow_pickle=False); summary=load_json(sp); pairs=np.load(pp,allow_pickle=False)
    # Coordinate-derived fields may differ; topology and all non-coordinate
    # source/ancestry identities are checked by topology_equal.
    topology_equal(topo,cand,f'failed 408 pass {tag}')
    if summary.get('candidate_sha256')!=EXPECTED[candidate_key] or int(summary.get('exact_PLC_surface_pairs',-1))!=len(pairs):
        raise ValueError(f'408 pass {tag} exact self-pair audit mismatch')
    if pairs.ndim!=2 or pairs.shape[1]!=2 or len(pairs)==0 or np.any(pairs<0) or np.any(pairs>=len(cur['source_O_faces'])) or np.any(pairs[:,0]>=pairs[:,1]):
        raise ValueError(f'408 pass {tag} malformed pair indices')
    extra_arrays.append(pairs.astype(np.int64,copy=False))
    extra_receipts.append({'pass':tag,'candidate_path':str(cp),'candidate_sha256':EXPECTED[candidate_key],'summary_path':str(sp),'summary_sha256':EXPECTED[summary_key],'pairs_path':str(pp),'pairs_sha256':EXPECTED[pairs_key],'pair_count':int(len(pairs)),'topology_equal_to_selected':True})
merged_before=np.unique(np.sort(old.astype(np.int64,copy=False),axis=1),axis=0)
expanded=np.unique(np.sort(np.concatenate([merged_before,*extra_arrays],axis=0),axis=1),axis=0)
if expanded.ndim!=2 or expanded.shape[1]!=2 or len(expanded)<len(merged_before) or np.any(expanded[:,0]>=expanded[:,1]):
    raise ValueError('malformed expanded self-pair seed identities')
if not set(map(tuple,merged_before.tolist())).issubset(set(map(tuple,expanded.tolist()))):
    raise ValueError('historical 408 seed identities were not preserved')
# Regenerate all separator rows at the selected 408 coordinates: old linear
# coefficients are never reused from another candidate. Feasibility is measured
# explicitly because the 408 source report had a null serialized maximum.
sp=importlib.util.spec_from_file_location('self_separation_026_refresh410',OWNER)
mod=importlib.util.module_from_spec(sp); sp.loader.exec_module(mod)
rows,records=mod.build_pair_rows(cur['points_world_m'].astype(np.float64)*1000.0,cur['source_O_faces'],expanded,margin_fraction=0.25)
max_rhs=max((float(r['lower']) for r in rows),default=0.0)
if max_rhs>2e-8: raise ValueError(f'zero-step regenerated self rows infeasible at selected 408 state: {max_rhs} mm')
seed_out=OUT/'merged-self-pair-seeds.npy'; save_npy_x(seed_out,expanded)
new_count=int(len(expanded)-len(merged_before))
report={
 'schema':'numi.human.self-witness-refresh-410.v1','status':'PASS_REBUILT_CONSTRUCTION_SEEDS_ONLY',
 'candidate_path':str(C),'candidate_sha256':EXPECTED['candidate'],'candidate_points_shape':list(cur['points_world_m'].shape),'candidate_faces_shape':list(cur['source_O_faces'].shape),
 'topology_reference_path':str(TOPO),'topology_reference_sha256':EXPECTED['topology'],'selected_vs_topology_changed_arrays':changed_candidate_arrays,
 'input_seed_path':str(SEEDS),'input_seed_sha256':EXPECTED['seeds'],'input_seed_report_path':str(SEED_REPORT),'input_seed_report_sha256':EXPECTED['seed_report'],'input_pair_count':int(len(merged_before)),
 'added_failed_408_pass_witnesses':extra_receipts,'added_pair_rows_before_dedup':int(sum(x['pair_count'] for x in extra_receipts)),'new_unique_pair_count':new_count,'expanded_unique_pair_count':int(len(expanded)),
 'matched_audit_130_path':str(AUD130),'matched_audit_130_sha256':EXPECTED['audit130'],'matched_audit_130_exact_self_pairs':0,
 'matched_audit_159_path':str(AUD159),'matched_audit_159_sha256':EXPECTED['audit159'],'matched_audit_159_complete':True,'matched_audit_159_bank_count':185,'matched_audit_159_face_bank_pairs':int(current_surface_pairs),
 'pair_owner_path':str(OWNER),'pair_owner_sha256':EXPECTED['owner'],'pair_owner_test_path':str(D/'D/test_refresh_self_witnesses_409.py'),'pair_owner_test_sha256':'d2d040e664749d34daa93b083edb6d3c6b1f82e6edf06aed71005875d544dc8f',
 'rebuilt_linear_row_count':int(len(rows)),'rebuilt_record_count':int(len(records)),'margin_fraction':0.25,'zero_step_max_rhs_mm':max_rhs,'zero_step_feasible':bool(max_rhs<=2e-8),
 'output_pairs_path':str(seed_out),'output_pairs_sha256':sha(seed_out),
 'replay_method':'408 seed set already uses selected four-flip face topology; failed pass 001/002 pair row IDs were verified against byte-identical source_O_faces, unioned without guessed remapping, then all 026 rows were regenerated at selected pass-003 F32 points.',
 'limitations':['Historical pair identities are construction constraints only, not a complete self-intersection certificate.','Matched exact selected-candidate audits remain the authority; every fitted trial requires fresh exact audits.','The 408 input report serialized its prior zero-step maximum as null; this run rebuilds every 026 row at the selected coordinates and records the actual maximum.','No physical, native, or material admission is claimed.'],
 'input_hashes':EXPECTED,
}
report_path=OUT/'report.json'; save_json_x(report_path,report)
print(json.dumps({k:report[k] for k in ['status','input_pair_count','added_pair_rows_before_dedup','new_unique_pair_count','expanded_unique_pair_count','rebuilt_linear_row_count','zero_step_max_rhs_mm','output_pairs_sha256']}))

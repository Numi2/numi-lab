#!/usr/bin/env python3
import hashlib,json,subprocess,time
from pathlib import Path
import numpy as np
D=Path('/Users/n/Work/numi-human-connected-surface-069')
H=D/'barycentric-connected-clearance-170'
BASE=D/'D/postfit-backtrack-403/run-001/backtrack-373/pass-002/candidate.npz'
BASE_STATE=D/'D/retained-gain-continuation-404/baseline-403-selected.json'
POINT=D/'D/postfit-backtrack-403/run-001/backtrack-373/pass-002/audit-130/summary.json'
SURFACE=D/'D/postfit-backtrack-403/run-001/backtrack-373/pass-002/audit-159/report.json'
FITDIR=H/'retained-gain-continuation-404/run-001'
FIT=FITDIR/'candidate.npz'; FIT_REPORT=FITDIR/'report.json'
FIT_OWNER=D/'D/retained-gain-continuation-401/propose_joint_clearance_witnesses_401.py'
SEEDS=D/'D/self-witness-refresh-403/merged-self-pair-seeds.npy'
SEED_REPORT=D/'D/self-witness-refresh-403/report-403-adapter.json'
PAIR_OWNER=H/'connected-local-continuation-189-run001/round-005/proposal/round-001/fit/self_separation_026.py'
BACKTRACKER=H/'no-progress-backtracker-373/run_local_witness_backtracking_373.py'
POLICY=H/'no-progress-backtracker-373/backtracking_policy_373.py'
GLOBAL=H/'global_step_backtracking_275.py'
AREA=D/'barycentric-connected-clearance-170/combined-clearance-394/run-001/candidate.npz'
OUT=D/'D/postfit-backtrack-404/run-001'
PY='/Users/n/numi-human-prep-venv-20261005/bin/python'
PINS={
'base':'442f80600304c9474794aa034f4efe8418c15cfe1256ee364c11ac586853ca98',
'base_state':'5ae8d190c142f5b7015c947279999feea3afc567ec1aa6c1b445e26687191c33',
'point':'3614d5e4670541943a1f7b4d6681c1522596959e689ee0b6897970a6d96950bd',
'surface':'60d23546bb945e36d1f30475575f75763ffd33ab26b9bfb832c4ac1e70c1618a',
'fit':'b687723fd3e22cd5c9e26d2703ddbf7825051a6a438193bda54ba8c453a982b6',
'fit_report':'23190df3fe72add811fdecd5ecac1a22386bcc834248e5552b8f50f71c2c960f',
'fit_owner':'2f1eda3f0d46d0f5497a1a04075b5dc2c3b37afe906d0389ff636fca8abc5869',
'seed_pairs':'528a72d9c48adbebdca960b37fbd1e124448ae80bf43cb6642f4389aacc209f4',
'seed_report':'328c81381e5c5bbc74d420fdb1c39e0e0f536664d43342acd1e967f203a9ea4f',
'pair_owner':'c67daf7c9fd2292e32ae88dba215a74350e1cbf83c669bc299a64b86d12e99f3',
'area_reference':'251b7e0a8c39d2e1e3ef57b2654bf4912cfb3e62bc9cc38fb9ee4d7a9a52e8c3',
'backtracker':'a91b410c979701a29ab32f376637db566abb745e066b629c000f6a37fea13212',
'policy':'94d1c929745a5db95569bc58f96acf2b82579998a6a408d3f12ddf181366ab19',
'global':'18891b1f700592563e139edfc8bd1361d230ff6fd5af2ae5ee036c9625c1826a',
}
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p): return json.loads(Path(p).read_text())
def must(path,key):
 p=Path(path); assert p.is_file(),f'missing {key}: {p}'; got=sha(p); assert got==PINS[key],f'{key} hash mismatch: {got}'; return got

def validate():
 must(BASE,'base'); must(BASE_STATE,'base_state'); must(POINT,'point'); must(SURFACE,'surface')
 must(FIT,'fit'); must(FIT_REPORT,'fit_report'); must(FIT_OWNER,'fit_owner')
 must(SEEDS,'seed_pairs'); must(SEED_REPORT,'seed_report'); must(PAIR_OWNER,'pair_owner')
 must(AREA,'area_reference'); must(BACKTRACKER,'backtracker'); must(POLICY,'policy'); must(GLOBAL,'global')
 state=read(BASE_STATE); point=read(POINT); surface=read(SURFACE); report=read(FIT_REPORT)
 assert state['candidate_sha256']==PINS['base'] and state['accepted_physical_steps']==0 and state['native_admission'] is False
 assert state['point_summary_sha256']==PINS['point'] and state['surface_report_sha256']==PINS['surface']
 assert point['candidate_sha256']==surface.get('candidate_sha256',PINS['base'])==PINS['base']
 assert point.get('exact_PLC_surface_pairs')==0 and point.get('complete_surface_audit') is True
 assert surface.get('status')=='COMPLETE_TYPED_BANK_SURFACE_CROSSING_AUDIT' and surface.get('bank_count')==185
 assert int(surface.get('matched_surface_bank_triangle_pairs',surface.get('crossing_pairs',-1)))==3338
 assert report.get('status')=='CONSTRUCTION_PROPOSAL_WRITTEN_UNADMITTED'
 assert report.get('candidate_admission')=='BLOCKED_PENDING_EXACT_GLOBAL_SELF_AND_OTHER_GATES'
 assert report.get('native_admission') is False and report.get('accepted_physical_steps')==0
 assert report.get('exact_global_self_audit')=='NOT_RUN_REQUIRED' and report.get('all_185_bank_point_query')=='NOT_RUN' and report.get('full_surface_bone_audit')=='NOT_RUN'
 assert Path(report.get('candidate_path','')).resolve()==FIT.resolve() and report.get('candidate_sha256')==PINS['fit']
 inputs=report.get('inputs',{})
 assert Path(inputs.get('base_candidate','')).resolve()==BASE.resolve() and inputs.get('base_candidate_sha256')==PINS['base']
 assert Path(inputs.get('raw_trial','')).resolve()==BASE.resolve() and inputs.get('raw_trial_sha256')==PINS['base']
 assert Path(inputs.get('self_pairs','')).resolve()==SEEDS.resolve() and inputs.get('self_pairs_sha256')==PINS['seed_pairs']
 assert Path(inputs.get('area_reference','')).resolve()==AREA.resolve() and inputs.get('area_reference_sha256')==PINS['area_reference']
 assert Path(inputs.get('pair_owner','')).resolve()==PAIR_OWNER.resolve() and inputs.get('pair_owner_sha256')==PINS['pair_owner']
 seed=read(SEED_REPORT); pairs=np.load(SEEDS,allow_pickle=False)
 assert seed.get('output_pairs_sha256')==PINS['seed_pairs'] and seed.get('merged_pair_count')==17832 and len(seed.get('sources',[]))==14
 assert seed.get('native_admission') is False and seed.get('accepted_physical_steps')==0
 assert pairs.shape==(17832,2) and pairs.dtype.kind in 'iu' and np.all(pairs[:,0]<pairs[:,1])
 assert len(np.unique(pairs,axis=0))==len(pairs) and np.array_equal(pairs,np.asarray(sorted(map(tuple,pairs.tolist())),dtype=np.int64))
 with np.load(BASE,allow_pickle=False) as b,np.load(FIT,allow_pickle=False) as t:
  bp=np.asarray(b['points_world_m']); tp=np.asarray(t['points_world_m']); faces=np.asarray(b['source_O_faces'])
  assert bp.dtype==tp.dtype==np.float32 and bp.shape==tp.shape==(20889,3) and faces.shape==(41733,3)
  assert np.array_equal(faces,t['source_O_faces']) and int(pairs.max())<len(faces)
  for key in b.files:
   if key=='points_world_m': continue
   assert key in t.files and b[key].dtype==t[key].dtype and b[key].shape==t[key].shape and np.ascontiguousarray(b[key]).tobytes()==np.ascontiguousarray(t[key]).tobytes(),f'noncoordinate field changed: {key}'
  support=np.asarray(t['local_witness_cluster_222_support_rows'],dtype=np.int64)
  anchors=np.asarray(b['typed_coarse_anchor_output_rows_018'],dtype=np.int64)
  changed=np.flatnonzero(np.any(bp.view(np.uint32)!=tp.view(np.uint32),axis=1))
  assert len(np.unique(support))==len(support) and np.all(np.isin(changed,support))
  assert len(anchors)==237 and np.array_equal(bp[anchors].view(np.uint32),tp[anchors].view(np.uint32))
  assert report['support']['support_nodes']==len(support) and report['support']['fixed_anchor_rows_total']==len(anchors)
  assert report['support']['threatened_pairs']==len(pairs) and report['support']['fixed_prefix_nodes']==0
 gates=report.get('emitted_f32_checks',{})
 assert gates.get('strict_f32_emission_gate',{}).get('pass') is True
 assert gates.get('full_mesh_area_gate',{}).get('pass') is True
 assert report.get('maximum_source_displacement_mm',99)<=12.000001
 assert gates.get('strict_f32_emission_gate',{}).get('maximum_node_step_mm',99)<=1.000001
 assert report.get('solver',{}).get('success') is True
 assert not OUT.exists(),f'backtrack output already exists: {OUT}'
 return {'base_candidate_sha256':PINS['base'],'base_selected_state_sha256':PINS['base_state'],'fit_candidate_sha256':PINS['fit'],'fit_report_sha256':PINS['fit_report'],'seed_pairs_sha256':PINS['seed_pairs'],'seed_pair_count':len(pairs),'fit_support_count':len(support),'fit_changed_rows_count':len(changed),'anchor_count':len(anchors),'topology':[len(bp),len(faces)],'input_validation':'PASS','native_admission':False,'accepted_physical_steps':0}

def main():
 proof=validate(); OUT.mkdir(parents=True,exist_ok=False); bo=read(FIT_REPORT)['support']; with_npz=np.load(FIT,allow_pickle=False); support=np.asarray(with_npz['local_witness_cluster_222_support_rows'],dtype=np.int64).tolist()
 cfg={'state':{'candidate':str(BASE),'point_summary':str(POINT),'surface_report':str(SURFACE),'parent_fit':str(FIT_REPORT)},'trial':str(FIT),'out':str(OUT/'backtrack-373'),'parent_fit':str(FIT_REPORT),'helper':str(GLOBAL),'helper_sha256':PINS['global'],'helper_entry':'reduce_global_step_scales','initial_scale':1.0,'zero_below':1.0/64.0,'maximum_exact_audits':8,'maximum_construction_passes':32,'fixed_prefix_nodes':0,'fit_support_rows':support,'uniform_failure_backtracking':True,'area_reference_npz':str(AREA),'area_reference_sha256':PINS['area_reference'],'area_reference_points_key':'area_reference_037_points_world_m_f64','area_reference_faces_key':'area_reference_037_source_O_faces','fit_report_sha256':PINS['fit_report'],'fit_candidate_sha256':PINS['fit'],'self_pair_seed_path':str(SEEDS),'self_pair_seed_sha256':PINS['seed_pairs'],'self_pair_seed_report_sha256':PINS['seed_report'],'self_pair_seed_count':17832}
 (OUT/'adapter-preflight.json').write_text(json.dumps(proof,indent=2)+'\n');(OUT/'backtrack-config.json').write_text(json.dumps(cfg,indent=2)+'\n')
 cmd=[PY,str(BACKTRACKER),str(OUT/'backtrack-config.json')]
 with (OUT/'backtracker.log').open('x') as log: result=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 (OUT/'execution.json').write_text(json.dumps({'command':cmd,'returncode':result.returncode,'fit_report_sha256':PINS['fit_report'],'fit_candidate_sha256':PINS['fit'],'self_pair_seed_sha256':PINS['seed_pairs'],'native_admission':False,'accepted_physical_steps':0},indent=2)+'\n')
 if result.returncode: raise SystemExit(result.returncode)
 selected=OUT/'backtrack-373/selected-result.json'
 if selected.is_file():
  s=read(selected); candidate=Path(s['candidate']); ps=Path(s['point_summary']); sr=Path(s['surface_report']); pm=read(ps); sm=read(sr)
  assert sha(candidate)==s['candidate_sha256'] and pm.get('candidate_sha256')==s['candidate_sha256']
  assert pm.get('exact_PLC_surface_pairs')==0 and pm.get('complete_surface_audit') is True
  assert sm.get('candidate_sha256')==s['candidate_sha256'] and sm.get('status')=='COMPLETE_TYPED_BANK_SURFACE_CROSSING_AUDIT' and sm.get('bank_count')==185
  assert s.get('native_admission') is False and s.get('accepted_physical_steps')==0
  receipt={'status':s.get('status'),'selected_candidate':str(candidate),'selected_candidate_sha256':sha(candidate),'point_summary_sha256':sha(ps),'surface_report_sha256':sha(sr),'point_pairs':pm.get('inside_node_bank_pairs'),'surface_pairs':sm.get('matched_surface_bank_triangle_pairs',sm.get('crossing_pairs')),'exact_self_pairs':pm.get('exact_PLC_surface_pairs'),'joint_merit':s.get('joint_merit'),'depth_merit':s.get('depth_merit'),'source_cap_mm':s.get('maximum_source_displacement_mm'),'native_admission':False,'accepted_physical_steps':0}
  (OUT/'postcheck-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
  print(json.dumps({'status':'POSTCHECK_SELECTED','receipt':str(OUT/'postcheck-receipt.json'),'selected_candidate_sha256':receipt['selected_candidate_sha256'],'point_pairs':receipt['point_pairs'],'surface_pairs':receipt['surface_pairs'],'self_pairs':receipt['exact_self_pairs'],'merit':receipt['joint_merit'] or receipt['depth_merit'],'native_admission':False,'accepted_physical_steps':0},indent=2),flush=True)
 else:
  result=read(OUT/'backtrack-373/result.json')
  print(json.dumps({'status':result.get('status'),'backtrack_result':str(OUT/'backtrack-373/result.json'),'native_admission':False,'accepted_physical_steps':0},indent=2),flush=True)
if __name__=='__main__':main()

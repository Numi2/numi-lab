#!/usr/bin/env python3
"""Bounded 037 elbow fit: minimax L2 LP outer approximation plus exact 036 gates."""
from __future__ import annotations
import hashlib, importlib.util, json, time
from pathlib import Path
import numpy as np
from scipy.sparse import csr_matrix, coo_matrix, hstack, vstack
from scipy.sparse.csgraph import dijkstra
from scipy.optimize import linprog

RUN=Path("/Users/n/numi-human-aortic-contact-opt-20261019/matter/tools/evidence/human-resting-20261005/supported-continuation-20261020/metal-optimization-080/visual-verification-20261022/wrist-connected-repair-001/joint-region-roi-014/elbow-rest-coordinate-fit-019")
OA_SCRIPT=RUN/"solve_036_minimax_l2_outer_approximation.py"
FIT_SCRIPT=RUN/"fit_elbow_rest_coordinates_036_closed_solid_cutting_plane.py"
OA_REPORT=RUN/"elbow-rest-coordinate-fit-036-minimax-l2-oa.json"
OUT=RUN/"elbow-rest-coordinate-fit-037b-minimax-exact.json"
PARTIAL=RUN/"elbow-rest-coordinate-fit-037b-minimax-exact.partial.json"
MAX_SECONDS=300.0
MAX_GEOMETRY_OUTER=4
RADIUS_SCALE=1.02
LP_TOL=1e-9

def sha(path):
    h=hashlib.sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda:f.read(1<<20),b""): h.update(block)
    return h.hexdigest()

def module(path,name):
    spec=importlib.util.spec_from_file_location(name,path)
    obj=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(obj)
    return obj

def save_json(path,obj):
    Path(path).write_text(json.dumps(obj,indent=2,sort_keys=True)+"\n")

def oa_solve_persist(C,b,radii,max_solves,deadline,fit_ids,callback_prefix):
    """Same minimax LP OA as 036, persisting every optimal LP vector before metrics."""
    C=csr_matrix(C,dtype=np.float64);b=np.asarray(b,dtype=np.float64);radii=np.asarray(radii,dtype=np.float64)
    nv=len(radii);ncoord=3*nv
    dirs=[[(1.,0.,0.),(-1.,0.,0.),(0.,1.,0.),(0.,-1.,0.),(0.,0.,1.),(0.,0.,-1.)] for _ in range(nv)]
    history=[];best=None;status="iteration limit";t0=time.monotonic()
    for solve_index in range(max_solves):
        if time.monotonic()>=deadline:status="wall-time limit";break
        rr=[];cc=[];vv=[];br=[];row=0
        for vi,ndirs in enumerate(dirs):
            for normal in ndirs:
                for axis in range(3):
                    if normal[axis]:
                        rr.append(row);cc.append(3*vi+axis);vv.append(normal[axis])
                rr.append(row);cc.append(ncoord);vv.append(-radii[vi]);br.append(0.0);row+=1
        Aball=csr_matrix((vv,(rr,cc)),shape=(row,ncoord+1))
        Alinear=hstack((-C,csr_matrix((C.shape[0],1))),format="csr")
        Aub=vstack((Alinear,Aball),format="csr");bub=np.r_[-b,np.asarray(br,dtype=np.float64)]
        objective=np.r_[np.zeros(ncoord),1.0];bounds=[(None,None)]*ncoord+[(0.0,None)]
        remaining=deadline-time.monotonic()
        if remaining<=0:status="wall-time limit";break
        lp=linprog(objective,A_ub=Aub,b_ub=bub,bounds=bounds,method="highs",
            options={"time_limit":max(0.1,float(remaining)),"dual_feasibility_tolerance":LP_TOL,
                     "primal_feasibility_tolerance":LP_TOL})
        rec={"solve":solve_index+1,"status":int(lp.status),"message":str(lp.message),
             "support_plane_count":int(row),"wall_elapsed_seconds":time.monotonic()-t0}
        if lp.x is not None:
            # Durable raw solver vector first; no norm, cap, geometry, or acceptance metric has run yet.
            point_path=RUN/f"{callback_prefix}-lp-point-{solve_index+1:02d}.npz"
            if point_path.exists():raise RuntimeError(f"refusing overwrite {point_path}")
            np.savez_compressed(point_path,source_vertex_ids=np.asarray(fit_ids,dtype=np.uint32),
                lp_displacement_coordinates_mm=np.asarray(lp.x[:-1],dtype=np.float64),
                lp_rho=np.asarray([lp.x[-1]],dtype=np.float64))
            rec["point_archive"]={"path":str(point_path),"sha256":sha(point_path),"status":"raw solver vector persisted before metrics"}
        if not lp.success or lp.x is None:
            history.append(rec);status="LP did not return optimum";break
        x=lp.x[:ncoord].reshape(nv,3);rho=float(lp.x[-1])
        norms=np.linalg.norm(x,axis=1);ratios=norms/radii;maxratio=float(ratios.max(initial=0.0))
        rec.update({"rho_lp_lower_bound":rho,"max_vertex_norm_over_radius":maxratio,
            "max_norm_over_radius_excess_over_rho":float(maxratio-rho),
            "vertices_violating_current_soc_epigraph":int(np.count_nonzero(ratios>rho+LP_TOL)),
            "linear_cut_max_violation_mm":float(np.max(b-np.asarray(C@x.ravel()).ravel(),initial=0.0)),
            "new_support_planes":0})
        history.append(rec);best={"x":x.copy(),"rho":rho,"maxratio":maxratio}
        if maxratio<=rho+LP_TOL:
            status="SOC epigraph converged";break
        added=0
        for vi in np.flatnonzero(ratios>rho+LP_TOL):
            norm=float(norms[vi])
            if norm==0.0:continue
            normal=x[vi]/norm
            nd=tuple(float(z) for z in normal)
            if not any(float(np.dot(normal,np.asarray(prev)))>1.0-1e-12 for prev in dirs[int(vi)]):
                dirs[int(vi)].append(nd);added+=1
        history[-1]["new_support_planes"]=added
        if added==0:
            status="stalled: no new supporting directions";break
    return {"status":status,"history":history,"best":best,"directions":dirs}

def candidate_state(ctx,x,serial,tag,radii_new,lp_rho):
    oa,m,lbs,geo,d0,d,F,face_side,face_region,fit_ids,radii_old,C,b,info,poses,fr=ctx
    coords=np.asarray(x,dtype=np.float64)
    if coords.shape!=(len(fit_ids),3) or not np.isfinite(coords).all():raise ValueError("candidate displacement shape/nonfinite failure")
    src=np.asarray(d0["vertices_f"])[fit_ids,:3].astype(np.float32)
    rest=(src.astype(np.float64)+coords/1000.0).astype(np.float32)
    actual_mm=(rest.astype(np.float64)-src.astype(np.float64))*1000.0
    path=RUN/f"elbow-rest-coordinate-fit-037b-trial-{serial:02d}-{tag}.npz"
    if path.exists():raise RuntimeError(f"refusing overwrite {path}")
    # Persist vector and Float32 rest coordinates before calculating any gate metrics.
    np.savez_compressed(path,source_vertex_ids=fit_ids.astype(np.uint32),
        lp_rest_delta_mm=coords.astype(np.float32),actual_f32_rest_delta_mm=actual_mm.astype(np.float32),
        trial_rest_xyz_f32_m=rest,existing_036_tapered_radius_mm=radii_old.astype(np.float32),
        expanded_037_tapered_radius_mm=radii_new.astype(np.float32),lp_rho=np.asarray([lp_rho],dtype=np.float64))
    norms=np.linalg.norm(actual_mm,axis=1)
    dtrial=dict(d);vt=np.asarray(d0["vertices_f"]).copy();vt[fit_ids,:3]=rest;dtrial["vertices_f"]=vt
    return dtrial,actual_mm,{"serial":serial,"tag":tag,"candidate_archive":str(path),"candidate_archive_sha256":sha(path),
        "max_l2_ratio_old_budget":float(np.max(norms/radii_old,initial=0)),
        "max_l2_ratio_new_budget":float(np.max(norms/radii_new,initial=0)),
        "max_actual_displacement_mm":float(np.max(norms,initial=0)),
        "inside_036_tapered_radius_strict":bool(np.all(norms<=radii_old)),
        "inside_037_tapered_radius_with_existing_slop":bool(np.all(norms<=radii_new+1e-5)),
        "outside_fit_support_untouched":True}

def exact_assess(ctx,dtrial):
    oa,m,lbs,geo,d0,d,F,face_side,face_region,fit_ids,radii_old,C,b,info,poses,fr=ctx
    m.lbs=lbs
    _,_,records,bv,bi,anchors=geo.load_bones()
    counts={};witnesses={}
    for pname in (m.BASE,m.ACTIVE):
        _,ct,wt=m.geometry_counts(dtrial,poses[pname],F,face_region,face_side,records,bv,bi,anchors,geo)
        counts[pname]=m.exact_gate_flat(ct);witnesses[pname]=wt
    refs={p:lbs.posed(d,poses[p]) for p in poses};affected=np.flatnonzero(np.any(np.isin(F,fit_ids),axis=1))
    orient_ok,orient=m.posed_orientation_gate(dtrial,poses,refs,F,affected,lbs)
    src=np.asarray(d0["vertices_f"]);trial=np.asarray(dtrial["vertices_f"]);outside=np.ones(len(src),dtype=bool);outside[fit_ids]=False
    all_zero=all(counts[p][s][g]==0 for p in counts for s in ("left","right")
        for g in ("skin_self","skin_roi_vs_other_fullbody_skin","skin_roi_vs_humerus_ulna_radius"))
    return {"exact_counts":counts,"all_neutral_and_active_intersections_zero":bool(all_zero),
        "pose_orientation_gate_pass":bool(orient_ok),"pose_orientation":orient,
        "outside_fit_support_bitwise_unchanged":bool(np.array_equal(trial[outside],src[outside])),
        "trial_all_finite":bool(np.isfinite(trial).all()),"witnesses":witnesses}

def build_owner(ctx):
    oa,m,lbs,geo,d0,d,F,face_side,face_region,fit_ids,radii_old,C,b,info,poses,fr=ctx
    m.lbs=lbs
    _,raw_b,records,bv,bi,anchors=geo.load_bones()
    solids={}
    for pname in (m.BASE,m.ACTIVE):
        solids[pname]={}
        for side in ("left","right"):
            solids[pname][side]=m.build_closed_solids(poses[pname],side,records,bv,bi,anchors,geo)[0]
    source=np.asarray(d0["vertices_f"][:,:3],dtype=np.float32);nvertex=len(source)
    edge=np.concatenate((F[:,[0,1]],F[:,[1,2]],F[:,[2,0]]),axis=0);edge=np.unique(np.sort(edge,axis=1),axis=0)
    edge_len=np.linalg.norm(source[edge[:,0]].astype(np.float64)-source[edge[:,1]].astype(np.float64),axis=1)
    var_side={};distances={}
    for side in ("left","right"):
        faces=np.asarray(fr["fit_support"]["direct_active_bone_witness_source_faces"][side],dtype=np.int64)
        seeds=np.unique(F[faces].ravel())
        rr=np.concatenate((edge[:,0],edge[:,1],np.full(len(seeds),nvertex,dtype=np.int64)))
        cc=np.concatenate((edge[:,1],edge[:,0],seeds));dd=np.concatenate((edge_len,edge_len,np.zeros(len(seeds))))
        graph=csr_matrix((dd,(rr,cc)),shape=(nvertex+1,nvertex+1))
        distances[side]=dijkstra(graph,directed=False,indices=nvertex)[:nvertex]
        roi=np.flatnonzero((face_side==side)&np.isin(face_region,["upper_arm","elbow_forearm"]))
        rv=np.unique(F[roi].ravel());var_side[side]=rv[distances[side][rv]<m.FIT_RADIUS_M]
    loc=np.full(nvertex,-1,dtype=np.int64);loc[fit_ids]=np.arange(len(fit_ids))
    As={p:m.build_A(d,poses[p],lbs) for p in poses}
    return records,bv,bi,anchors,solids,var_side,loc,As

def seed_bank(info):
    bank={}
    for i,item in enumerate(info):
        bank[("saved-036",int(i))]={"pose":str(item["pose"]),"side":str(item["side"]),"bone":str(item["bone"]),
            "face":int(item["source_face"]),"vertex_ids":[int(x) for x in item["vertex_ids"]],
            "barycentric":[float(x) for x in item["barycentric"]],
            "preferred_bone_face_local":int(item["preferred_face"]),"first_source":str(item["first_source"]),"source_count":1}
    return bank

def linearize_new_cuts(ctx,owner,dtrial,current_mm,bank,new_keys):
    oa,m,lbs,geo,d0,d,F,face_side,face_region,fit_ids,radii_old,C,b,info,poses,fr=ctx
    records,bv,bi,anchors,solids,var_side,loc,As=owner
    evals={}
    combos=sorted({(bank[k]["pose"],bank[k]["side"],bank[k]["bone"]) for k in new_keys})
    for pname,side,bone in combos:
        evals.update(m.cut_eval(dtrial,pname,poses[pname],side,bone,bank,solids[pname][side][bone],F,lbs))
    accepted=[];uncontrolled=[]
    for key in new_keys:
        c=bank[key];ev=evals.get(key)
        if ev is None:continue
        sdmm=float(ev["signed_distance_m"])*1000.0
        if sdmm>m.TARGET_GAP_M*1000.0+m.CUT_NEAR_GAP_MM:continue
        grad=np.asarray(ev["gradient_outward"],dtype=np.float64);accum={}
        for vid,w in zip(c["vertex_ids"],c["barycentric"]):
            li=int(loc[int(vid)])
            if li<0 or abs(float(w))<1e-12:continue
            accum[li]=accum.get(li,np.zeros(3,dtype=np.float64))+float(w)*(grad@As[c["pose"]][int(vid)])
        if not accum:
            if sdmm<m.TARGET_GAP_M*1000.0:
                uncontrolled.append({"cut_key":repr(key),"pose":c["pose"],"side":c["side"],"bone":c["bone"],
                  "signed_gap_mm":sdmm,"reason":"near/penetrating witness has no rest-coordinate variable in fit support"})
            continue
        rhs=float(m.TARGET_GAP_M*1000.0-sdmm+sum(float(v@current_mm[li]) for li,v in accum.items()))
        accepted.append((key,c,ev,accum,rhs,sdmm))
    rows=[];cols=[];vals=[];rhs=[]
    for ri,(key,c,ev,accum,bval,sdmm) in enumerate(accepted):
        for li,vec in accum.items():
            for axis in range(3):
                if vec[axis]:rows.append(ri);cols.append(3*li+axis);vals.append(float(vec[axis]))
        rhs.append(bval)
    Cnew=csr_matrix((np.asarray(vals,dtype=np.float64),(np.asarray(rows,dtype=np.int64),np.asarray(cols,dtype=np.int64))),shape=(len(accepted),C.shape[1]))
    metadata={"new_cut_count":len(new_keys),"new_linear_rows":len(accepted),"new_linear_nonzeros":int(Cnew.nnz),
        "uncontrolled":uncontrolled,"linearized_witnesses":[{"cut_key":repr(k),"pose":c["pose"],"side":c["side"],"bone":c["bone"],
        "signed_distance_mm":sd,"state":ev["state"],"source_face":int(c["face"]),"vertex_ids":list(map(int,c["vertex_ids"])),
        "barycentric":list(map(float,c["barycentric"])),"rhs_mm":float(bval)} for k,c,ev,acc,bval,sd in accepted]}
    return Cnew,np.asarray(rhs,dtype=np.float64),metadata

def main():
    start=time.monotonic();deadline=start+MAX_SECONDS
    if OUT.exists() or PARTIAL.exists():raise SystemExit("refusing to overwrite 037 evidence")
    oa=module(OA_SCRIPT,"minimax_oa");ctx=(oa,*oa.reconstruct())
    m,lbs,geo,d0,d,F,face_side,face_region,fit_ids,radii_old,C,b,info,poses,fr=ctx;m.lbs=lbs
    oldrep=json.loads(OA_REPORT.read_text())
    if oldrep["solver_status"]!="iteration limit" or len(oldrep["iterations"])!=30:raise ValueError("036 minimax source report changed")
    radii_new=radii_old*RADIUS_SCALE
    output={"schema":"numi.human.elbow-rest-coordinate-fit-037b-minimax-exact.v1","status":"running",
      "scope":"Evidence-only local rest-coordinate candidate from saved 036 linearized cuts and matched neutral/elbow static poses. No payload/header/runtime/FEM/physics changes. Exact final gate requires every neutral and active own-bone, skin-self, and ROI/fullbody-skin intersection count to be zero.",
      "inputs":{"037b_script_sha256":sha(Path(__file__).resolve()),"036_report_sha256":sha(RUN/"elbow-rest-coordinate-fit-036.json"),"036_oa_report_sha256":sha(OA_REPORT),
        "036_oa_script_sha256":sha(OA_SCRIPT),"036_exact_script_sha256":sha(FIT_SCRIPT),
        "skin_payload_sha256":sha(m.PAYLOAD),"binary_sha256":fr["inputs"]["binary_sha256"],
        "rigid_sha256":fr["inputs"]["rigid_sha256"],"pose_snapshot_sha256":fr["inputs"]["pose_snapshot_sha256"]},
      "construction_budget":{"old_036_maximum_mm":5.0,"new_037_maximum_mm":5.1,
        "same_geodesic_taper":True,"per_vertex_radius_scale":RADIUS_SCALE,
        "minimum_old_radius_mm":float(radii_old.min()),"maximum_old_radius_mm":float(radii_old.max()),
        "minimum_new_radius_mm":float(radii_new.min()),"maximum_new_radius_mm":float(radii_new.max()),
        "purpose":"mesh construction budget only; physical/user acceptance gates, collision gates, and numerical tolerances unchanged"},
      "limits":{"wall_seconds":MAX_SECONDS,"maximum_geometry_outer_iterations":MAX_GEOMETRY_OUTER,
        "maximum_lp_solves_each_outer":30,"lp_tolerance":LP_TOL},
      "recovery":{"method":"reused the durable final point from the immediately preceding 037 recovery attempt, whose script had already persisted all 30 raw HiGHS vectors before metric checks; no rerun or new-radius optimization before first exact geometry test",
        "old_report_rho_lower_bound":oldrep["final_lp_result"]["lower_bound_rho"],
        "old_report_max_norm_over_radius":oldrep["final_lp_result"]["candidate_max_l2_over_radius"],
        "lp_replay":None},"trials":[],"outer_iterations":[]}
    save_json(PARTIAL,output)
    recovery_archive=RUN/"elbow-rest-coordinate-fit-037-recovery-lp-point-30.npz"
    if not recovery_archive.is_file():raise FileNotFoundError("retained 037 recovery point archive is missing")
    with np.load(recovery_archive,allow_pickle=False) as stored:
        rawpoint=np.asarray(stored["lp_displacement_coordinates_mm"],dtype=np.float64)
        recovered_x=rawpoint.reshape(len(fit_ids),3).copy()
        rho=float(np.asarray(stored["lp_rho"],dtype=np.float64)[0])
    ratio=float(np.max(np.linalg.norm(recovered_x,axis=1)/radii_old,initial=0))
    cut_violation=float(np.max(b-np.asarray(C@recovered_x.ravel()).ravel(),initial=0))
    if abs(rho-oldrep["final_lp_result"]["lower_bound_rho"])>1e-8 or abs(ratio-oldrep["final_lp_result"]["candidate_max_l2_over_radius"])>1e-8:
        raise RuntimeError(f"persisted 036 OA vector mismatches retained metrics rho={rho} ratio={ratio}")
    if cut_violation>1e-7:raise RuntimeError(f"persisted 036 OA vector violates saved cut bank by {cut_violation} mm")
    output["recovery"]["lp_replay"]={"status":"recovered from durable prior 037 solver output","solve_count":30,
      "rho_lower_bound":rho,"max_norm_over_old_radius":ratio,"max_saved_cut_violation_mm":cut_violation,
      "matches_retained_metrics":True,"vector_archive":str(recovery_archive),"vector_archive_sha256":sha(recovery_archive),
      "originating_failed_wrapper_run_script_sha256":sha(RUN/"run_elbow_rest_coordinate_037_minimax.py")}
    owner=build_owner(ctx)
    dtrial,actual_mm,meta=candidate_state(ctx,recovered_x,0,"recovered-minimax-point",radii_new,rho)
    trial={"construction":meta,"old_minimax_rho_lower_bound":rho}
    output["trials"].append(trial);save_json(PARTIAL,output)
    exact=exact_assess(ctx,dtrial);witness_path=RUN/"elbow-rest-coordinate-fit-037b-trial-00-exact-witnesses.json"
    save_json(witness_path,exact["witnesses"])
    trial["exact_assessment"]={k:v for k,v in exact.items() if k!="witnesses"}
    trial["exact_assessment"]["witness_archive"]=str(witness_path)
    trial["exact_assessment"]["witness_archive_sha256"]=sha(witness_path)
    first_pass=bool(meta["inside_037_tapered_radius_with_existing_slop"] and exact["all_neutral_and_active_intersections_zero"] and
      exact["pose_orientation_gate_pass"] and exact["outside_fit_support_bitwise_unchanged"] and exact["trial_all_finite"])
    trial["final_acceptance_gate_pass"]=first_pass;save_json(PARTIAL,output)
    if first_pass:
        output["status"]="candidate passes unchanged final exact geometry and orientation gates under 5.1mm construction cap"
        output["candidate_archive"]=meta["candidate_archive"];output["candidate_archive_sha256"]=meta["candidate_archive_sha256"]
    else:
        records,bv,bi,anchors,solids,var_side,loc,As=owner
        bank=seed_bank(info)
        _,wit,newkeys=m.collect_current_cuts(dtrial,poses,F,face_region,face_side,var_side,bank,solids,records,bv,bi,anchors,geo,lbs)
        output["initial_witness_cut_addition"]={"cut_bank_size":len(bank),"new_cut_count":len(newkeys),
          "counts":trial["exact_assessment"]["exact_counts"]}
        current_src=np.asarray(d0["vertices_f"])[fit_ids,:3].astype(np.float32)
        current_rest=np.asarray(dtrial["vertices_f"])[fit_ids,:3].astype(np.float32)
        current_mm=(current_rest.astype(np.float64)-current_src.astype(np.float64))*1000.0
        Cnew,bnew,cutmeta=linearize_new_cuts(ctx,owner,dtrial,current_mm,bank,newkeys)
        output["initial_witness_cut_addition"].update(cutmeta)
        Ctotal=C.copy();btotal=b.copy()
        if Cnew.shape[0]:Ctotal=vstack((Ctotal,Cnew),format="csr");btotal=np.r_[btotal,bnew]
        if Cnew.shape[0]==0:
            output["status"]="stopped: exact failure supplied no controllable new linearized witness cuts"
        else:
            for outer in range(1,MAX_GEOMETRY_OUTER+1):
                if time.monotonic()>=deadline:
                    output["status"]="stopped: five-minute wall cap";break
                prefix=f"elbow-rest-coordinate-fit-037b-outer-{outer:02d}"
                result=oa_solve_persist(Ctotal,btotal,radii_new,30,deadline,fit_ids,prefix)
                if result["best"] is None:
                    output["status"]="stopped: witness-constrained minimax LP had no optimal point";break
                x=result["best"]["x"];rho_new=float(result["best"]["rho"])
                dtrial,actual_mm,meta=candidate_state(ctx,x,outer,f"outer-{outer:02d}",radii_new,rho_new)
                item={"outer_iteration":outer,"lp_status":result["status"],"lp_history":result["history"],
                  "lp_solve_count":len(result["history"]),"rho_lower_bound":rho_new,
                  "candidate":meta,"linear_constraint_count":int(Ctotal.shape[0]),"exact_assessment":"not run"}
                output["outer_iterations"].append(item);save_json(PARTIAL,output)
                if not meta["inside_037_tapered_radius_with_existing_slop"]:
                    item["exact_assessment"]="not run: Float32 candidate exceeds existing tapered 5.1mm construction cap and slop"
                    output["status"]="stopped: LP point exceeds explicit 5.1mm tapered construction cap"
                    save_json(PARTIAL,output);break
                exact=exact_assess(ctx,dtrial)
                witness_path=RUN/f"elbow-rest-coordinate-fit-037b-trial-{outer:02d}-exact-witnesses.json"
                save_json(witness_path,exact["witnesses"])
                item["exact_assessment"]={k:v for k,v in exact.items() if k!="witnesses"}
                item["exact_assessment"]["witness_archive"]=str(witness_path)
                item["exact_assessment"]["witness_archive_sha256"]=sha(witness_path)
                passed=bool(exact["all_neutral_and_active_intersections_zero"] and exact["pose_orientation_gate_pass"] and
                    exact["outside_fit_support_bitwise_unchanged"] and exact["trial_all_finite"])
                item["final_acceptance_gate_pass"]=passed;save_json(PARTIAL,output)
                if passed:
                    output["status"]="candidate passes unchanged final exact geometry and orientation gates under 5.1mm construction cap"
                    output["candidate_archive"]=meta["candidate_archive"];output["candidate_archive_sha256"]=meta["candidate_archive_sha256"]
                    break
                before=set(bank)
                _,wit,added=m.collect_current_cuts(dtrial,poses,F,face_region,face_side,var_side,bank,solids,records,bv,bi,anchors,geo,lbs)
                fresh=[key for key in added if key not in before]
                new_delta=(np.asarray(dtrial["vertices_f"])[fit_ids,:3].astype(np.float64)-current_src.astype(np.float64))*1000.0
                Cnew,bnew,cutmeta=linearize_new_cuts(ctx,owner,dtrial,new_delta,bank,fresh)
                item["witness_cut_addition"]={"new_cut_count":len(fresh),**cutmeta};save_json(PARTIAL,output)
                if Cnew.shape[0]==0:
                    output["status"]="stopped: exact failure yielded no additional controllable cuts";save_json(PARTIAL,output);break
                Ctotal=vstack((Ctotal,Cnew),format="csr");btotal=np.r_[btotal,bnew]
                if outer==MAX_GEOMETRY_OUTER:
                    output["status"]="stopped after four witness-constrained outer iterations without zero exact gates"
    output["wall_elapsed_seconds"]=time.monotonic()-start
    output["candidate_emitted"]=bool(output.get("status","").startswith("candidate passes"))
    if output["candidate_emitted"]:output["claim_limit"]="Exact geometry candidate only; not FEM/contact/dynamic/biological qualification."
    save_json(PARTIAL,output);OUT.write_text(json.dumps(output,indent=2,sort_keys=True)+"\n")
    print(json.dumps({"status":output["status"],"report":str(OUT),"sha256":sha(OUT),
      "candidate_emitted":output["candidate_emitted"],"trial_count":1+len(output["outer_iterations"]),
      "wall_elapsed_seconds":output["wall_elapsed_seconds"]},sort_keys=True),flush=True)

if __name__=="__main__":main()

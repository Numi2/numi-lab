#!/usr/bin/env python3
"""Bounded HiGHS LP outer approximation of the 036 minimax L2 radius."""
from __future__ import annotations
import hashlib, importlib.util, json, time
from pathlib import Path
import numpy as np
from scipy.sparse import coo_matrix, csr_matrix, hstack, vstack
from scipy.sparse.csgraph import dijkstra
from scipy.optimize import linprog

RUN=Path("/Users/n/numi-human-aortic-contact-opt-20261019/matter/tools/evidence/human-resting-20261005/supported-continuation-20261020/metal-optimization-080/visual-verification-20261022/wrist-connected-repair-001/joint-region-roi-014/elbow-rest-coordinate-fit-019")
SCRIPT=Path(__file__).resolve()
DIAG=RUN/"diagnose_036_l1_ball_feasibility.py"
SOURCE=RUN/"fit_elbow_rest_coordinates_036_closed_solid_cutting_plane.py"
FIT=RUN/"elbow-rest-coordinate-fit-036.json"
OUT=RUN/"elbow-rest-coordinate-fit-036-minimax-l2-oa.json"
PARTIAL=RUN/"elbow-rest-coordinate-fit-036-minimax-l2-oa.partial.json"
TRIAL=RUN/"elbow-rest-coordinate-fit-036-minimax-l2-oa-trial.npz"
MAX_SOLVES=30
MAX_SECONDS=300.0
LP_TOL=1e-9

def sha(p):
    h=hashlib.sha256()
    with Path(p).open("rb") as f:
        for block in iter(lambda:f.read(1<<20),b""): h.update(block)
    return h.hexdigest()

def oa_solve(C,b,radii,max_solves=30,deadline=None,progress=None):
    """Minimize rho with accumulated supporting planes of each L2 ball."""
    C=csr_matrix(C,dtype=np.float64); b=np.asarray(b,dtype=np.float64); radii=np.asarray(radii,dtype=np.float64)
    nv=len(radii); ncoord=3*nv
    if C.shape!=(len(b),ncoord) or np.any(radii<=0) or not np.isfinite(C.data).all() or not np.isfinite(b).all():
        raise ValueError("invalid minimax LP dimensions or values")
    dirs=[[(1.,0.,0.),(-1.,0.,0.),(0.,1.,0.),(0.,-1.,0.),(0.,0.,1.),(0.,0.,-1.)] for _ in range(nv)]
    history=[]; best=None; status="iteration limit"
    for solve_index in range(max_solves):
        if deadline is not None and time.monotonic()>=deadline:
            status="wall-time limit"; break
        rr=[];cc=[];vv=[];br=[]
        row=0
        for vi,ndirs in enumerate(dirs):
            for n in ndirs:
                for ax in range(3):
                    if n[ax]:
                        rr.append(row);cc.append(3*vi+ax);vv.append(n[ax])
                rr.append(row);cc.append(ncoord);vv.append(-radii[vi]);br.append(0.0);row+=1
        Aball=csr_matrix((vv,(rr,cc)),shape=(row,ncoord+1))
        Alinear=hstack((-C,csr_matrix((C.shape[0],1))),format="csr")
        Aub=vstack((Alinear,Aball),format="csr")
        bub=np.r_[-b,np.asarray(br,dtype=np.float64)]
        objective=np.r_[np.zeros(ncoord),1.0]
        bounds=[(None,None)]*ncoord+[(0.0,None)]
        remaining=(deadline-time.monotonic()) if deadline is not None else 300.0
        if remaining<=0:
            status="wall-time limit";break
        lp=linprog(objective,A_ub=Aub,b_ub=bub,bounds=bounds,method="highs",
                   options={"time_limit":max(0.1,float(remaining)),"dual_feasibility_tolerance":1e-9,
                            "primal_feasibility_tolerance":1e-9})
        rec={"solve":solve_index+1,"status":int(lp.status),"message":str(lp.message),
             "support_plane_count":int(row),"wall_elapsed_seconds":time.monotonic()-(deadline-MAX_SECONDS if deadline is not None else time.monotonic())}
        if not lp.success or lp.x is None:
            history.append(rec);status="LP did not return optimum";break
        x=lp.x[:ncoord].reshape(nv,3);rho=float(lp.x[-1])
        norms=np.linalg.norm(x,axis=1);ratios=norms/radii;maxratio=float(ratios.max(initial=0.0))
        rec.update({"rho_lp_lower_bound":rho,"max_vertex_norm_over_radius":maxratio,
                    "max_norm_over_radius_excess_over_rho":float(maxratio-rho),
                    "vertices_violating_current_soc_epigraph":int(np.count_nonzero(ratios>rho+LP_TOL)),
                    "linear_cut_max_violation_mm":float(np.max(b-np.asarray(C@x.ravel()).ravel(),initial=0.0)),
                    "new_support_planes":0})
        history.append(rec);best={"x":x.copy(),"rho":rho,"maxratio":maxratio}
        if progress is not None: progress(history,best)
        if maxratio<=rho+LP_TOL:
            status="SOC epigraph converged"
            break
        new_count=0
        for vi in np.flatnonzero(ratios>rho+LP_TOL):
            norm=float(norms[vi])
            if norm==0.0: continue
            n=x[vi]/norm
            nd=tuple(float(z) for z in n)
            if not any(float(np.dot(n,np.asarray(prev)))>1.0-1e-12 for prev in dirs[int(vi)]):
                dirs[int(vi)].append(nd);new_count+=1
        history[-1]["new_support_planes"]=new_count
        if new_count==0:
            status="stalled: no new supporting directions";break
    return {"status":status,"history":history,"best":best,"directions":dirs}

def synthetic_smoke():
    # One unit ball with x+y >= 2 has exact minimax radius sqrt(2).
    C=csr_matrix(([1.0,1.0],([0,0],[0,1])),shape=(1,3))
    out=oa_solve(C,np.array([2.0]),np.array([1.0]),max_solves=30)
    if out["best"] is None: raise RuntimeError("synthetic minimax LP returned no point")
    lower=out["best"]["rho"]; ratio=out["best"]["maxratio"]
    if lower>np.sqrt(2)+1e-7 or ratio<np.sqrt(2)-1e-5 or ratio>np.sqrt(2)+1e-5:
        raise AssertionError(f"synthetic SOCP check failed: lower={lower}, ratio={ratio}, status={out['status']}")
    # Axis-aligned lower bound is exact immediately: x >= 1.1 in radius 1.
    C2=csr_matrix(([1.0],([0],[0])),shape=(1,3))
    out2=oa_solve(C2,np.array([1.1]),np.array([1.0]),max_solves=3)
    if out2["best"] is None or abs(out2["best"]["rho"]-1.1)>1e-8:
        raise AssertionError("axis-aligned synthetic lower-bound check failed")
    return {"diagonal_case":{"status":out["status"],"lp_lower_bound":lower,"actual_normalized_norm":ratio,"expected":float(np.sqrt(2))},
            "axis_case":{"status":out2["status"],"lp_lower_bound":out2["best"]["rho"],"expected":1.1}}

def reconstruct():
    if not FIT.is_file() or not SOURCE.is_file() or not DIAG.is_file(): raise FileNotFoundError("required immutable 036 inputs missing")
    fr=json.loads(FIT.read_text())
    if fr.get("status")!="stopped: sparse closed-solid QP residual limit": raise ValueError("unexpected 036 source status")
    spec=importlib.util.spec_from_file_location("fit036",SOURCE);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    decode,lbs,geo=m.setup_imports()
    d0=decode(m.PAYLOAD.read_bytes());F=np.asarray(d0["indices"],dtype=np.int64).reshape(-1,3)
    W0=np.asarray(d0["full_weights"],dtype=np.float32).copy();bind=np.asarray(d0["bindings_u"][:,0],dtype=np.int64)
    source=np.asarray(d0["vertices_f"][:,:3],dtype=np.float32);nvertex=len(W0)
    manifest=json.loads(geo.MAN.read_text());names={int(x["core_body_index"]):str(x["myosim_body"]).lower() for x in manifest["source"]["anchors"]}
    slotname=[names[int(x)] for x in bind];slot={n:i for i,n in enumerate(slotname)}
    owner=[slotname[int(i)] for i in np.argmax(W0,axis=1)]
    vside=np.asarray([geo.side(n) for n in owner]);vreg=np.asarray([geo.skin_region(n) for n in owner])
    face_side=np.asarray([geo.majority(vside[t]) for t in F])
    face_region=np.asarray([geo.majority(vreg[t]) for t in F])
    owner=[slotname[int(i)] for i in np.argmax(W0,axis=1)];vside=np.asarray([geo.side(n) for n in owner]);vreg=np.asarray([geo.skin_region(n) for n in owner])
    face_side=np.asarray([geo.majority(vside[t]) for t in F]);face_region=np.asarray([geo.majority(vreg[t]) for t in F])
    wr=json.loads(m.WEIGHT_REPORT.read_text());exact=json.loads(m.EXACT.read_text())
    active_pair=exact["pose_pairs"]["elbow-shoulder010"]["active"]["sides"]
    legacy_seeds={}
    for side in ("left","right"):
        fsids=set()
        for key in ("skin_self","skin_roi_vs_other_fullbody_skin","skin_roi_vs_nearby_bone"):
            for group in active_pair[side][key].get("witnesses_by_owner_pair",{}).values():
                for w in group:
                    fsids.add(int(w["face_a"]))
                    if key=="skin_self": fsids.add(int(w["face_b"]))
        eligible=np.asarray(sorted(i for i in fsids if 0<=i<len(F) and face_side[i]==side and face_region[i] in ("upper_arm","elbow_forearm")),dtype=np.int64)
        if len(eligible)!=wr["seed_counts"][side]["faces"]: raise ValueError("legacy seed map changed")
        legacy_seeds[side]=np.unique(F[eligible].ravel())
    edge=np.concatenate((F[:,[0,1]],F[:,[1,2]],F[:,[2,0]]));edge=np.unique(np.sort(edge,axis=1),axis=0)
    elen=np.linalg.norm(source[edge[:,0]].astype(float)-source[edge[:,1]].astype(float),axis=1)
    weight_dist={}
    for side in ("left","right"):
        seeds=legacy_seeds[side];rr=np.concatenate((edge[:,0],edge[:,1],np.full(len(seeds),nvertex,dtype=np.int64)))
        cc=np.concatenate((edge[:,1],edge[:,0],seeds));dd=np.concatenate((elen,elen,np.zeros(len(seeds))))
        g=csr_matrix((dd,(rr,cc)),shape=(nvertex+1,nvertex+1));weight_dist[side]=dijkstra(g,directed=False,indices=nvertex)[:nvertex]
    chain={side:np.asarray([slot["humerus_"+side[0]],slot["ulna_"+side[0]],slot["radius_"+side[0]]],dtype=np.int64) for side in ("left","right")}
    W=W0.copy()
    for side in ("left","right"):
        ids=chain[side];dist=weight_dist[side];t=np.clip(dist/m.WEIGHT_RADIUS_M,0.0,1.0)
        alpha=(1.0/3.0*(1.0-t)**2*(1.0+2.0*t)).astype(np.float32);ch=W0[:,ids];cs=ch.sum(axis=1)
        off=np.maximum(W0.sum(axis=1)-cs,0.0);select=(dist<m.WEIGHT_RADIUS_M)&(cs>1e-8)
        original=W0[select];new=original*(1.0-alpha[select,None])
        new[:,ids]=original[:,ids]+alpha[select,None]*(off[select,None]*ch[select]/cs[select,None]);W[select]=new
    d=dict(d0);d["full_weights"]=W
    pose_names=(m.BASE,m.ACTIVE);poses={n:json.loads((m.R/n/"registered-skin-poses.json").read_text()) for n in pose_names}
    As={p:m.build_A(d,poses[p],lbs) for p in poses}
    var_side={};geom_dist={}
    for side in ("left","right"):
        faces=np.asarray(fr["fit_support"]["direct_active_bone_witness_source_faces"][side],dtype=np.int64)
        seeds=np.unique(F[faces].ravel());rr=np.concatenate((edge[:,0],edge[:,1],np.full(len(seeds),nvertex,dtype=np.int64)))
        cc=np.concatenate((edge[:,1],edge[:,0],seeds));dd=np.concatenate((elen,elen,np.zeros(len(seeds))))
        g=csr_matrix((dd,(rr,cc)),shape=(nvertex+1,nvertex+1));geom_dist[side]=dijkstra(g,directed=False,indices=nvertex)[:nvertex]
        roi=np.flatnonzero((face_side==side)&np.isin(face_region,["upper_arm","elbow_forearm"]))
        rv=np.unique(F[roi].ravel());var_side[side]=rv[geom_dist[side][rv]<m.FIT_RADIUS_M]
    fit_ids=np.asarray(sorted(set(var_side["left"].tolist()+var_side["right"].tolist())),dtype=np.int64);loc=np.full(nvertex,-1,dtype=np.int64)
    loc[fit_ids]=np.arange(len(fit_ids));side_sets={s:set(var_side[s].tolist()) for s in var_side}
    vd=np.asarray([min(geom_dist[s][i] for s in ("left","right") if i in side_sets[s]) for i in fit_ids])
    radii=5.0*np.clip((m.FIT_RADIUS_M-vd)/(m.FIT_RADIUS_M-m.CORE_RADIUS_M),0.0,1.0);radii=np.where(vd<=m.CORE_RADIUS_M,5.0,radii)
    if len(fit_ids)!=fr["fit_support"]["variable_vertex_count"] or {s:len(var_side[s]) for s in var_side}!=fr["fit_support"]["variable_vertex_count_by_side"]:
        raise ValueError("reconstructed support differs from saved 036")
    info=fr["iterations"][0]["sparse_qp"]["constraint_info"];rows=[];cols=[];vals=[];rhs=[]
    for ri,item in enumerate(info):
        accum={};grad=np.asarray(item["gradient_outward"],dtype=np.float64);beta=np.asarray(item["barycentric"],dtype=np.float64)
        ids=np.asarray(item["vertex_ids"],dtype=np.int64);A=As[item["pose"]]
        for vid,w in zip(ids,beta):
            li=int(loc[int(vid)])
            if li<0 or abs(float(w))<1e-12: continue
            accum[li]=accum.get(li,np.zeros(3,dtype=np.float64))+float(w)*(grad@A[int(vid)])
        if not accum: raise ValueError("a saved constraint has no support variables")
        for li,vec in accum.items():
            for axis in range(3):
                if vec[axis]: rows.append(ri);cols.append(3*li+axis);vals.append(float(vec[axis]))
        rhs.append(m.TARGET_GAP_M*1000.0-float(item["signed_gap_mm"]))
    C=csr_matrix((np.asarray(vals),(np.asarray(rows),np.asarray(cols))),shape=(len(info),3*len(fit_ids)))
    b=np.asarray(rhs,dtype=np.float64)
    if len(info)!=fr["iterations"][0]["sparse_qp"]["constraint_count"]: raise ValueError("constraint bank length mismatch")
    return m,lbs,geo,d0,d,F,face_side,face_region,fit_ids,radii,C,b,info,poses,fr

def exact_trial(ctx,x):
    m,lbs,geo,d0,d,F,face_side,face_region,fit_ids,radii,C,b,info,poses,fr=ctx
    dtrial=dict(d);vt=np.asarray(d["vertices_f"]).copy()
    rest=(np.asarray(d["vertices_f"])[fit_ids,:3].astype(np.float64)+x/1000.0).astype(np.float32)
    vt[fit_ids,:3]=rest;dtrial["vertices_f"]=vt
    m.lbs=lbs
    bone_data=geo.load_bones();_,raw_b,records,bv,bi,anchors=bone_data
    result={}
    for pname in (m.BASE,m.ACTIVE):
        _,counts,wit=m.geometry_counts(dtrial,poses[pname],F,face_region,face_side,records,bv,bi,anchors,geo)
        result[pname]={"counts":counts,"witnesses":wit}
    pose_refs={p:lbs.posed(d,poses[p]) for p in poses};affected=np.flatnonzero(np.any(np.isin(F,fit_ids),axis=1))
    orient_ok,orient=m.posed_orientation_gate(dtrial,poses,pose_refs,F,affected,lbs)
    zero=all(result[p]["counts"][side][gate]==0 for p in result for side in ("left","right")
             for gate in ("skin_self","skin_roi_vs_other_fullbody_skin","skin_roi_vs_humerus_ulna_radius"))
    return dtrial,rest,{"poses":result,"all_exact_counts_zero":bool(zero),
        "posed_orientation_gate_pass":bool(orient_ok),"posed_orientation":orient,
        "all_rest_coordinates_finite":bool(np.isfinite(vt).all()),
        "outside_fit_support_bitwise_unchanged":bool(np.array_equal(vt[np.setdiff1d(np.arange(len(vt)),fit_ids)],np.asarray(d0["vertices_f"])[np.setdiff1d(np.arange(len(vt)),fit_ids)]))}

def main():
    t0=time.monotonic();smoke=synthetic_smoke();ctx=reconstruct()
    m,lbs,geo,d0,d,F,face_side,face_region,fit_ids,radii,C,b,info,poses,fr=ctx
    if OUT.exists() or PARTIAL.exists() or TRIAL.exists(): raise SystemExit("refusing to overwrite prior minimax evidence")
    deadline=t0+MAX_SECONDS
    output={"schema":"numi.human.elbow-rest-coordinate-minimax-l2-outer-approximation.v1",
        "status":"running","interpretation":"LP outer approximations provide lower bounds for the minimum rho in ||d_i||2 <= rho*r_i. rho_lower > 1 proves the saved linearized cut bank cannot fit inside the allowed L2 balls, subject to LP numerics. A candidate is emitted for exact geometry only if its measured norms satisfy every existing radius without relaxing tolerances.",
        "inputs":{"036_report_sha256":sha(FIT),"036_script_sha256":sha(SOURCE),"diagnostic_reconstruction_sha256":sha(DIAG),
                  "payload_sha256":sha(m.PAYLOAD),"weights_report_sha256":sha(m.WEIGHT_REPORT),
                  "pose_snapshot_sha256":fr["inputs"]["pose_snapshot_sha256"],"binary_sha256":fr["inputs"]["binary_sha256"],
                  "rigid_sha256":fr["inputs"]["rigid_sha256"]},
        "dimensions":{"linear_cut_count":int(C.shape[0]),"linear_cut_nonzeros":int(C.nnz),"variable_vertices":int(len(fit_ids)),
                      "coordinate_variables":int(C.shape[1]),"radius_mm_min":float(radii.min()),"radius_mm_max":float(radii.max())},
        "synthetic_smoke":smoke,"limits":{"max_lp_solves":MAX_SOLVES,"wall_seconds":MAX_SECONDS,"lp_primal_dual_tolerance":LP_TOL},
        "iterations":[]}
    def write_partial():
        PARTIAL.write_text(json.dumps(output,indent=2,sort_keys=True)+"\n")
    oa=oa_solve(C,b,radii,MAX_SOLVES,deadline,lambda h,best:(output.__setitem__("iterations",h.copy()),write_partial()))
    output["iterations"]=oa["history"];output["solver_status"]=oa["status"]
    best=oa["best"];candidate_json=None
    if best is not None:
        x=best["x"];rho=float(best["rho"]);ratio=float(best["maxratio"])
        output["final_lp_result"]={"lower_bound_rho":rho,"candidate_max_l2_over_radius":ratio,
            "all_linearized_cuts_satisfied":bool(np.max(b-np.asarray(C@x.ravel()).ravel(),initial=0.0)<=1e-7),
            "inside_existing_l2_radii_strict":bool(np.all(np.linalg.norm(x,axis=1)<=radii)),
            "lower_bound_proves_outside_radius":bool(rho>1.0)}
        if np.all(np.linalg.norm(x,axis=1)<=radii) and output["final_lp_result"]["all_linearized_cuts_satisfied"]:
            dtrial,rest,exact=exact_trial(ctx,x)
            np.savez_compressed(TRIAL,source_vertex_ids=fit_ids.astype(np.uint32),rest_delta_mm=x.astype(np.float32),
                linearized_trial_rest_xyz_f32_m=rest,per_vertex_existing_radius_mm=radii.astype(np.float32),
                minimax_lp_lower_bound_rho=np.asarray([rho],dtype=np.float64))
            candidate_json={"archive":str(TRIAL),"archive_sha256":sha(TRIAL),"exact_geometry":exact,
                "evidence_class":"exact geometry diagnostic; not FEM or physical qualification",
                "pass_all_exact_diagnostic_gates":bool(exact["all_exact_counts_zero"] and exact["posed_orientation_gate_pass"] and exact["all_rest_coordinates_finite"] and exact["outside_fit_support_bitwise_unchanged"])}
            output["exact_candidate_assessment"]=candidate_json
    output["wall_elapsed_seconds"]=time.monotonic()-t0
    output["status"]="completed"
    PARTIAL.write_text(json.dumps(output,indent=2,sort_keys=True)+"\n")
    # Complete output is a stable alias copied only once after all results are durable.
    OUT.write_text(json.dumps(output,indent=2,sort_keys=True)+"\n")
    print(json.dumps({"status":output["solver_status"],"report":str(OUT),"sha256":sha(OUT),
        "wall_elapsed_seconds":output["wall_elapsed_seconds"],"iterations":len(output["iterations"]),
        "final_lp_result":output.get("final_lp_result"),"exact_candidate_assessment":candidate_json},sort_keys=True),flush=True)
if __name__=="__main__": main()

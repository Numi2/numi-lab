#!/usr/bin/env python3
import copy, hashlib, importlib.util, json, sys
from pathlib import Path
import numpy as np
D=Path('/Users/numi/Work/numi-human-connected-surface-069')
C404=D/'D/postfit-backtrack-404/run-002/backtrack-373/pass-003/candidate.npz'
G406R=D/'D/fixed-bone-guards-406/run-003/report.json'; G406N=G406R.parent/'introduced-skin-bone-barriers.npz'
C407=D/'D/local-two-parent-retriangulation-405/run-011-replay-405-four-flips/candidate.npz'; F407R=C407.parent/'report.json'
A407=D/'D/postfit-backtrack-405-topology-full-audits/run-001/audit-159/report.json'
P314=D/'publication-113/sources/connected-fixed-boundary-314/emit_introduced_skin_bone_barriers_314.py'
P313=D/'publication-113/sources/connected-fixed-boundary-313/fixed_bone_triangle_rows_313.py'
P401=D/'D/retained-gain-continuation-401/propose_joint_clearance_witnesses_401.py'
P026=D/'barycentric-connected-clearance-170/connected-local-continuation-189-run001/round-005/proposal/round-001/fit/self_separation_026.py'
OUT=D/'D/fixed-bone-guards-407/run-001'
PINS={'c404':'b41c56ac6ec2a99f7e1f2c6a02db10cf61b6cd04730f7a6bcdea65e224f80e52','g406r':'f7972b76a4f546c20bb8eec2689088aac13124b000b4e4cb637906a9f82feab3','g406n':'32c32e6b00b6c02bb8a4afa9e2083f5582e9f6b6b716e48c8eac9f56d68c8934','c407':'6c115d5beef83989bed2af6309771b8d34cece7e30eaaf3f99f397ee3a304fda','f407':'97d3b316003bceb7edf992809490a6fa0f05841326c6f7c4a4e280f61c11547a','a407':'ec081def995f7fd59050e0c5f9e858b13177f3b53f416a81727c4b0b7c9238f0'}
CHANGED={13167,13168,14855,14860,20891,20896,20924,20925}
ROW_DIFFS={'points_world_m','source_O_faces','area_reference_037_source_O_faces','refinement_face_parent_face_row','refinement_face_parent_barycentric','refinement_face_parent_barycentric_semantics'}
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return h.hexdigest()
def arrsha(a):return hashlib.sha256(np.ascontiguousarray(a).view(np.uint8)).hexdigest()
def mod(name,path):
 s=importlib.util.spec_from_file_location(name,path); m=importlib.util.module_from_spec(s);sys.modules[name]=m;s.loader.exec_module(m);return m
def load(p):
 with np.load(p,allow_pickle=False) as z:return {k:z[k].copy() for k in z.files}
def csr(ip,ix,r):return np.asarray(ix[int(ip[r]):int(ip[r+1])])
def sig(a,r):
 keys=('source_O_faces','face_kind','parent_coarse_face_row','parent_fine_detail_face_row','parent_fine_subface_row','parent_source_face_marker','refinement_face_parent_face_row','refinement_face_parent_barycentric')
 s=[(k,np.ascontiguousarray(a[k][r]).tobytes()) for k in keys if k in a]
 for ip,ix in (('face_source_ancestry_indptr','face_source_ancestry_face_rows'),('face_fine_subface_ancestry_indptr','face_fine_subface_ancestry_rows')):
  if ip in a and ix in a:s.append((ip,csr(a[ip],a[ix],r).tobytes()))
 return tuple(s)
def main():
 paths={'c404':C404,'g406r':G406R,'g406n':G406N,'c407':C407,'f407':F407R,'a407':A407}
 for k,p in paths.items():
  if sha(p)!=PINS[k]:raise ValueError(f'{k} SHA mismatch {sha(p)}')
 if OUT.exists():raise FileExistsError(OUT)
 old,cur=load(C404),load(C407)
 diffs=[k for k in old if old[k].shape!=cur[k].shape or old[k].dtype!=cur[k].dtype or np.ascontiguousarray(old[k]).tobytes()!=np.ascontiguousarray(cur[k]).tobytes()]
 if set(diffs)!=ROW_DIFFS:raise ValueError(f'unexpected common-array diff {diffs}')
 points,faces=cur['points_world_m'],cur['source_O_faces']
 if points.shape!=(20889,3) or points.dtype!=np.float32 or faces.shape!=(41733,3) or not np.array_equal(faces,cur['area_reference_037_source_O_faces']):raise ValueError('bad candidate/matched-037')
 flip=json.loads(F407R.read_text())
 changed=set(map(int,flip['changed_face_rows']))
 if changed!=CHANGED or len(flip['operations'])!=4 or flip['candidate_output_sha256']!=PINS['c407']:raise ValueError('flip receipt mismatch')
 opmap={}
 for op in flip['operations']:
  rr=list(map(int,op['face_rows']))
  if len(rr)!=2 or any(r in opmap for r in rr):raise ValueError('bad flip face group')
  for r,fo,fn in zip(rr,op['expected_old_faces'],op['new_faces']):
   if not np.array_equal(old['source_O_faces'][r],fo) or not np.array_equal(faces[r],fn):raise ValueError(f'flip row mismatch {r}')
   an=csr(cur['refinement_face_parent_ancestry_indptr'],cur['refinement_face_parent_ancestry_face_rows'],r)
   if sorted(map(int,an))!=sorted(map(int,op['immediate_parent_union'])):raise ValueError(f'parent ancestry mismatch {r}')
   opmap[r]=op
 for r in set(range(len(faces)))-changed:
  if sig(old,r)!=sig(cur,r):raise ValueError(f'unexpected ancestry mutation on unchanged row {r}')
 oldg,oldr=load(G406N),json.loads(G406R.read_text())
 phase=mod('phase401',P401)
 phase.validate_fixed_boundary_payload(oldg,oldr,candidate_sha256=sha(C404),candidate_points=old['points_world_m'],candidate_faces=old['source_O_faces'],npz_path=G406N)
 oldset=set()
 for f,b,bo,t in zip(oldg['skin_face_rows'],oldg['bank_body'],oldg['stable_bone_id'],oldg['bank_triangle_stable_id']):
  k=(int(b),int(bo),int(f),int(t))
  if k in oldset:raise ValueError('duplicate source guard')
  oldset.add(k)
 if len(oldset)!=963:raise ValueError('406 guard count mismatch')
 expanded={}
 for b,bo,f,t in sorted(oldset):
  dest=sorted(map(int,opmap[f]['face_rows'])) if f in changed else [f]
  method='explicit_flip_pair_expansion' if f in changed else 'unchanged_exact_identity'
  for d in dest:expanded.setdefault((b,bo,d,t),[]).append({'source_404_face_row':f,'mapping':method,'flip_group':dest if f in changed else []})
 ex=mod('em314',P314); fit=mod('fit026',P026); fx=mod('fx313',P313)
 bh=mod('bank314',ex.BANK_HELPER); T,ids,_g,_b,M,off,pos,bkeys,bpins,_=bh.read_bank_inputs(ex.BANK_DIR,ex.BANK_EVIDENCE)
 expected=tuple((int(x[0]),int(x[1])) for x in np.asarray(bkeys))
 if len(expected)!=185 or len(set(expected))!=185:raise ValueError('incomplete bank inventory')
 audit=json.loads(A407.read_text())
 current=ex.validate_audit_report(audit,candidate_sha256=PINS['c407'],point_count=len(points),face_count=len(faces),expected_bank_keys=expected,expected_script_sha256=sha(ex.AUDIT_159),expected_predicate_sha256=sha(ex.EXACT_159))
 rc=sum(int((x.get('result') or {}).get('count',0)) for x in audit['banks'])
 if len(current)!=3324 or rc!=len(current):raise ValueError(f'current report pair count mismatch {len(current)}/{rc}')
 removed=set(expanded)&current; kept=set(expanded)-current
 arrays=ex.make_barrier_arrays(sorted(kept),ex.typed_triangle_lookup(T,ids),{int(b):(M[int(b)],off[int(b)],pos[int(b)]) for b in M})
 order=sorted(range(len(arrays['skin_face_rows'])),key=lambda i:(int(arrays['skin_face_rows'][i]),int(arrays['bank_body'][i]),int(arrays['stable_bone_id'][i]),int(arrays['bank_triangle_stable_id'][i])))
 arrays={k:np.asarray(v)[order].copy() for k,v in arrays.items()}
 records=[dict(skin_face_row=int(arrays['skin_face_rows'][i]),bank_body=int(arrays['bank_body'][i]),stable_bone_id=int(arrays['stable_bone_id'][i]),bank_triangle_stable_id=int(arrays['bank_triangle_stable_id'][i]),fixed_triangle_world_mm=arrays['fixed_triangles_world_mm'][i]) for i in range(len(order))]
 rows,typed=phase.build_fixed_boundary_barriers(points.astype(np.float64)*1000.,faces,records,fit,fx,margin_fraction=.25)
 if len(rows)!=6*len(kept) or len(typed)!=len(kept):raise ValueError('313 row count mismatch')
 OUT.mkdir(parents=True); npz=OUT/'introduced-skin-bone-barriers.npz';np.savez_compressed(npz,**arrays)
 typedlist=[dict(skin_face_row=f,bank_body=b,stable_bone_id=bo,bank_triangle_stable_id=t) for b,bo,f,t in sorted(kept)]
 om=[dict(skin_face_row=k[2],bank_body=k[0],stable_bone_id=k[1],bank_triangle_stable_id=k[3],source_406_mapping=expanded[k],reason='PRESENT_IN_COMPLETE_CURRENT_407_159_AUDIT') for k in sorted(removed)]
 report=copy.deepcopy(oldr)
 report.update(status='COMPLETE_TYPED_INTRODUCED_SKIN_BONE_BARRIER_EXPORT',schema='numi.fixed_skin_bone_barriers.v1',
  filtered_builder_path=str(Path(__file__)),filtered_builder_sha256=sha(__file__),base_candidate_path=str(C407),base_candidate_sha256=sha(C407),
  candidate_points_world_m_array_sha256=arrsha(points),skin_faces_array_sha256=arrsha(faces),point_count=len(points),face_count=len(faces),
  candidate_points_world_m_shape=list(points.shape),skin_faces_shape=list(faces.shape),bank_count=185,expected_bank_count=185,
  bank_source_pins=bpins,bank_source_paths={n:(ex.BANK_DIR/n).as_posix() for n in bpins},introduced_pair_count=len(kept),typed_pairs=typedlist,
  fixed_triangles_units='mm',fixed_triangles_frame='world',output_npz=npz.name,output_npz_sha256=sha(npz),geometry_or_native_admission=False,
  inputs=[dict(role='base',candidate_path=str(C407),candidate_sha256=sha(C407),report_path=str(A407),report_sha256=sha(A407),npz_path=npz.name,npz_sha256=sha(npz),pair_count=len(current)),
          dict(role='guard_source_406_at_404',candidate_path=str(C404),candidate_sha256=sha(C404),report_path=str(G406R),report_sha256=sha(G406R),npz_path=str(G406N),npz_sha256=sha(G406N),pair_count=len(oldset)),
          dict(role='four_flip_mapping',candidate_path=str(C407),candidate_sha256=sha(C407),report_path=str(F407R),report_sha256=sha(F407R),pair_count=len(changed))],
  source_topology_transition=dict(source_candidate_404_sha256=sha(C404),target_candidate_407_sha256=sha(C407),changed_face_rows=sorted(changed),
   changed_face_groups=[op['face_rows'] for op in flip['operations']],unchanged_guard_pair_count=sum(f not in changed for _,_,f,_ in oldset),
   old_guard_pairs_directly_on_changed_rows=sum(f in changed for _,_,f,_ in oldset),expanded_guard_pair_identities=len(expanded),
   changed_guard_mappings=[v for v in []],mapping_policy='Only exact unchanged rows are carried as-is; a guard directly on a replaced face expands to the two replacement rows named in the four-flip receipt; no nearest/geometric row matching.',
   changed_face_parent_unions=flip['changed_face_parent_unions'],changed_face_source_unions=flip['changed_face_source_unions'],changed_face_subface_unions=flip['changed_face_subface_unions'],matched_037_faces_equal=True),
  current_407_159_pair_count=len(current),removed_current_407_pairs=om,
  construction_scope=dict(selection_scope='406_GUARDS_EXACT_ROW_CARRY_OR_EXPLICIT_FLIP_EXPANSION_MINUS_COMPLETE_407_159',source_406_guard_pairs=len(oldset),
   expanded_guard_pairs=len(expanded),current_407_pairs_removed=len(removed),filtered_guard_pairs=len(kept),rows_emitted_by_313=len(rows),
   current_407_audit_complete_typed_banks_validated=True,current_407_audit_path=str(A407),current_407_audit_sha256=sha(A407),
   four_flip_report_path=str(F407R),four_flip_report_sha256=sha(F407R),is_complete_current_159_pair_set=False,
   interpretation='Incremental construction guard subset; complete current 407 159 report remains authoritative and absence from this subset does not establish clearance.',
   historical_406_payload_validated_at_404=True,all_rows_built_at_candidate_407_coordinates=True),
  limitations=['Incremental construction guard subset; full current 407 159 report remains authoritative.','Absence from this subset does not establish clearance.','No native, physical, or anatomy qualification.'])
 # Preserve complete explicit records for changed-row remapping/omission audit.
 report['source_topology_transition']['remapped_guard_records']=[
  dict(source_face_row_404=v['source_404_face_row'],target_face_row_407=k[2],bank_body=k[0],stable_bone_id=k[1],bank_triangle_stable_id=k[3],mapping=v['mapping'])
  for k,vals in sorted(expanded.items()) for v in vals if v['mapping']!='unchanged_exact_identity']
 rp=OUT/'report.json';rp.write_text(json.dumps(report,indent=2,sort_keys=True,default=lambda x:x.item() if isinstance(x,np.generic) else str(x))+'\n')
 rec,receipt=phase.validate_fixed_boundary_payload(load(npz),report,candidate_sha256=sha(C407),candidate_points=points,candidate_faces=faces,npz_path=npz)
 rebuilt,typed2=phase.build_fixed_boundary_barriers(points.astype(np.float64)*1000.,faces,rec,fit,fx,margin_fraction=.25)
 zero=all(float(x['lower'])<=2e-8 for x in rebuilt)
 if not zero or len(rebuilt)!=len(rows) or len(typed2)!=len(typed):raise ValueError('401/313 zero-baseline validation failed')
 vp=OUT/'validation.json'
 vp.write_text(json.dumps({'status':'PASS_401_FIXED_BOUNDARY_PAYLOAD_AND_313_ROW_VALIDATION','candidate_sha256':sha(C407),'npz_sha256':sha(npz),'report_sha256':sha(rp),'filtered_guard_pairs':len(rec),'313_rows':len(rebuilt),'all_rows_zero_feasible':zero,'receipt':receipt},indent=2,sort_keys=True)+'\n')
 print(json.dumps({'status':'PASS','npz':str(npz),'npz_sha256':sha(npz),'report':str(rp),'report_sha256':sha(rp),'validation':str(vp),'validation_sha256':sha(vp),'old406_pairs':len(oldset),'directly_changed_rows':sum(f in changed for _,_,f,_ in oldset),'expanded_pairs':len(expanded),'current_pairs':len(current),'removed':len(removed),'final_pairs':len(rec),'rows':len(rebuilt)},indent=2))
if __name__=='__main__':main()

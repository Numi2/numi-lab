#!/usr/bin/env python3
"""Bounded evidence-only elbow rest-coordinate cutting-plane fit using closed-solid winding.

Starts from the exact 1/3 chain-only weight counterfactual in 018, rebuilds
current exact witnesses with source-face ancestry, and fits rest-coordinate
increments against signed local humerus/ulna/radius surface gaps in the matched
neutral and elbow=.8 poses. Exact skin/self/bone predicates remain hard gates.
No NHSKIN, runtime, FEM, mechanical layer, or source asset is written.
"""
from __future__ import annotations
import csv, hashlib, json, math, sys, time
from fractions import Fraction
from pathlib import Path
import numpy as np
from scipy.sparse import coo_matrix, csr_matrix, eye, kron
from scipy.sparse.linalg import factorized
from scipy.sparse.csgraph import dijkstra
from scipy.spatial import cKDTree

ROOT=Path('/Users/n/numi-human-aortic-contact-opt-20261019')
E=ROOT/'matter/tools/evidence/human-resting-20261005/supported-continuation-20261020/metal-optimization-080/visual-verification-20261022/wrist-connected-repair-001'
R=E/'joint-region-roi-014/elbow-shoulder-posture-diagnostics-017'
RUN=E/'joint-region-roi-014/elbow-rest-coordinate-fit-019'
OUT=RUN/'elbow-rest-coordinate-fit-036.json'
PARTIAL=RUN/'elbow-rest-coordinate-fit-036.partial.json'
NPZ=RUN/'elbow-rest-coordinate-fit-036-candidate.npz'
PAYLOAD=E/'finger-profile-069i-left-ring-web-retreat/replacement-bilateral-hands038.nhskin'
EXACT=R/'elbow-posture-exact-roi-audit.json'
WEIGHT_REPORT=R/'chain-only-counterfactual-018/chain-only-counterfactual-018.json'
WEIGHT_SCRIPT=R/'repair_elbow_chain_weights_local_018.py'
SOLID_REPORT=RUN/'elbow-rest-coordinate-fit-033-welded-solid-witness-classification.json'
SOLID_TOPOLOGY=RUN/'elbow-rest-coordinate-fit-030-exact-f32-bone-weld-topology.json'
BASE='shoulder010-neutral'; ACTIVE='shoulder010-elbow080'
WEIGHT_RADIUS_M=0.020
FIT_RADIUS_M=0.018
CORE_RADIUS_M=0.015
MAX_DELTA_M=0.005
TARGET_GAP_M=0.00024
MAX_OUTER_ITERATIONS=4
MAX_WALL_SECONDS=1200
SMOOTHNESS=2.0
CUT_GRID_DENOMINATOR=8
CUT_NEAR_GAP_MM=2.5
MAX_CUTS=20000
MAX_ADMM_ITERATIONS=30000



def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(1<<20),b''):h.update(block)
    return h.hexdigest()

def write_json(path,obj):
    Path(path).write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')

def setup_imports():
    sys.path[:0]=['/Users/n/numi-human-anatomy-finish-1378/src',str(E),str(R.parent)]
    from numilab_human.skin_source_payload_preflight import decode_payload
    from numilab_human.compiled_quotient_embeddedness import coordinate_quotient
    from numilab_human.cardiac_cavity_intersections import _aabb_candidate_pairs,triangle_intersection_points,_allowed_shared_point
    import audit_bilateral_skin_retained_poses_002 as seam
    import audit_bilateral_skin_reweighted_candidate_016 as lbs
    import audit_exact_joint_region_intersections_015 as geo
    geo.coordinate_quotient=coordinate_quotient
    geo._aabb_candidate_pairs=_aabb_candidate_pairs
    geo.triangle_intersection_points=triangle_intersection_points
    geo._allowed_shared_point=_allowed_shared_point
    geo.records_nonzero=seam.records_nonzero
    return decode_payload,lbs,geo

def triangle_volume(vertices,faces):
    t=np.asarray(vertices,dtype=np.float64)[np.asarray(faces,dtype=np.int64)]
    return float(np.einsum('ij,ij->i',t[:,0],np.cross(t[:,1],t[:,2])).sum()/6.0)

def bone_local_orientation(manifest,records,bv,bi,anchors,bone):
    rows=[]
    for rec,anc in zip(records,anchors):
        if str(anc['myosim_body']).lower()!=bone:continue
        body,fv,nv,fi,ni,stable,tx,ty,tz,qx,qy,qz,qw,scale,_=rec
        local_faces=bi[fi//3:(fi+ni)//3].astype(np.int64)-int(fv)
        local_vertices=bv[fv:fv+nv].astype(np.float64)*float(scale)
        vol=triangle_volume(local_vertices,local_faces)
        rows.append({'source_record_index':int(anc['source_record_index']),'signed_volume_m3':vol,'face_count':int(len(local_faces))})
    if not rows:raise ValueError(f'no source bone record for {bone}')
    signs={int(np.sign(x['signed_volume_m3'])) for x in rows}
    if len(signs)!=1 or 0 in signs:raise ValueError(f'inconsistent source winding for {bone}: {rows}')
    return int(next(iter(signs))),rows

def edge_boundary_counts(faces):
    f=np.asarray(faces,dtype=np.int64)
    e=np.concatenate((f[:,[0,1]],f[:,[1,2]],f[:,[2,0]]),axis=0)
    _,c=np.unique(np.sort(e,axis=1),axis=0,return_counts=True)
    return {'boundary_edges':int(np.sum(c==1)),'nonmanifold_edges':int(np.sum(c>2))}

def build_surface_queries(pose,side,records,bv,bi,anchors,geo,orientation):
    V,F,owners=geo.bone_scene(pose,'elbow',side,records,bv,bi,anchors)
    result={}; metadata={}
    for bone in (f'humerus_{side[0]}',f'ulna_{side[0]}',f'radius_{side[0]}'):
        fi=np.flatnonzero(np.asarray(owners)==bone)
        faces=np.asarray(F[fi],dtype=np.int64)
        vertices=np.asarray(V,dtype=np.float64)
        tri=vertices[faces]
        tree=cKDTree(tri.mean(axis=1))
        sign,src_rows=orientation[bone]
        edges=np.concatenate((faces[:,[0,1]],faces[:,[1,2]],faces[:,[2,0]]),axis=0)
        unique_edges,edge_use=np.unique(np.sort(edges,axis=1),axis=0,return_counts=True)
        boundary_set={tuple(map(int,x)) for x in unique_edges[edge_use==1]}
        boundary_mask=np.zeros(len(faces),dtype=bool)
        for fi,face in enumerate(faces):
            boundary_mask[fi]=any(tuple(sorted((int(face[a]),int(face[b])))) in boundary_set for a,b in ((0,1),(1,2),(2,0)))
        result[bone]={'vertices':vertices,'faces':faces,'triangles':tri,'tree':tree,'outward_sign':sign,'centroids':tri.mean(axis=1),'boundary_face_mask':boundary_mask}
        metadata[bone]={'faces':int(len(faces)),'orientation_sign_from_source_volume':int(sign),'source_records':src_rows,'boundary_faces':int(np.count_nonzero(boundary_mask)),**edge_boundary_counts(faces)}
    return result,metadata

def closest_signed(points,surface,k=256):
    P=np.asarray(points,dtype=np.float64)
    tri=surface['triangles'];nf=len(tri)
    kk=min(k,nf)
    _,idx=surface['tree'].query(P,k=kk)
    if kk==1:idx=np.asarray(idx)[:,None]
    T=tri[idx]
    A=T[:,:,0,:];B=T[:,:,1,:];C=T[:,:,2,:]
    AB=B-A;AC=C-A;AP=P[:,None,:]-A
    d00=np.einsum('...i,...i->...',AB,AB);d01=np.einsum('...i,...i->...',AB,AC);d11=np.einsum('...i,...i->...',AC,AC)
    d20=np.einsum('...i,...i->...',AP,AB);d21=np.einsum('...i,...i->...',AP,AC)
    den=d00*d11-d01*d01
    U=np.divide(d11*d20-d01*d21,den,out=np.zeros_like(den),where=den>1e-30)
    W=np.divide(d00*d21-d01*d20,den,out=np.zeros_like(den),where=den>1e-30)
    inside=(U>=0)&(W>=0)&(U+W<=1)
    proj=A+U[...,None]*AB+W[...,None]*AC
    def edge_closest(X,Y):
        XY=Y-X
        t=np.einsum('...i,...i->...',P[:,None,:]-X,XY)/np.maximum(np.einsum('...i,...i->...',XY,XY),1e-30)
        t=np.clip(t,0,1)
        return X+t[...,None]*XY
    q1=edge_closest(A,B);q2=edge_closest(B,C);q3=edge_closest(C,A)
    Q=np.stack((proj,q1,q2,q3),axis=2)
    ds=np.sum((Q-P[:,None,None,:])**2,axis=-1)
    ds[:,:,0]=np.where(inside,ds[:,:,0],np.inf)
    edgeidx=np.argmin(ds,axis=2);candidate=np.argmin(np.min(ds,axis=2),axis=1)
    row=np.arange(len(P));col=candidate;which=edgeidx[row,col];q=Q[row,col,which]
    local_face=idx[row,col]
    ft=tri[local_face]
    n=np.cross(ft[:,1]-ft[:,0],ft[:,2]-ft[:,0])
    n/=np.maximum(np.linalg.norm(n,axis=1)[:,None],1e-30)
    n*=surface['outward_sign']
    signed=np.einsum('ij,ij->i',P-q,n)
    dist=np.sqrt(np.maximum(np.min(ds[row,col],axis=1),0))*np.sign(signed)
    return dist,q,n,local_face

def build_A(d,pose,lbs):
    W=np.asarray(d['full_weights'],dtype=np.float64)
    B=np.asarray(d['bindings_u'][:,0],dtype=np.int64)
    BF=np.asarray(d['bindings_f'],dtype=np.float64)
    state={int(x['body_index']):x for x in pose['bodies']}
    A=np.zeros((len(W),3,3),dtype=np.float64)
    for j,b in enumerate(B):
        cur=state[int(b)]['current']
        Rcur=lbs.mat(cur['orientation_world_xyzw'])
        Rbind=lbs.mat(BF[j,4:8])
        M=float(BF[j,8])*(Rbind.T@Rcur.T)
        A+=W[:,j,None,None]*M[None,:,:]
    return A

def exact_float32_triangle(points):
    # Convert the exact Float32 collision coordinates to their exact binary rationals.
    a=np.asarray(points,dtype=np.float32)
    return tuple(tuple(Fraction.from_float(float(x)) for x in row) for row in a)

def geometry_counts(d,pose,F,face_region,face_side,records,bv,bi,anchors,geo):
    V=lbs.posed(d,pose);pts,qf=geo.exact_scene(V,F);result={};witnesses={}
    for side in ('left','right'):
        roi=np.flatnonzero((face_side==side)&np.isin(face_region,['upper_arm','elbow_forearm']))
        other=np.setdiff1d(np.arange(len(F),dtype=np.int64),roi,assume_unique=True)
        selfr=geo.exact_pair_audit(pts,qf,roi,None,same_surface=True,keep=100)
        cross=geo.exact_pair_audit(pts,qf,roi,other,label_a=lambda i:f'{side}/{face_region[i]}',label_b=lambda i:f'{face_side[i]}/{face_region[i]}',keep=100)
        bV,bF,bown=geo.bone_scene(pose,'elbow',side,records,bv,bi,anchors)
        u=np.unique(F[roi].ravel());remap=np.full(len(V),-1,dtype=np.int64);remap[u]=np.arange(len(u));sf=remap[F[roi]]
        cv=np.vstack((V[u],bV)).astype(np.float32);cf=np.vstack((sf,bF+len(u))).astype(np.int64)
        cp,cq=geo.exact_scene(cv,cf);n=len(sf)
        bone=geo.exact_pair_audit(cp,cq,np.arange(n,dtype=np.int64),np.arange(n,len(cf),dtype=np.int64),label_a=lambda i:f'{side}/{face_region[int(roi[i])]}',label_b=lambda i:bown[i-n],keep=100000)
        result[side]={'skin_self':int(selfr['intersection_pairs']),'skin_roi_vs_other_fullbody_skin':int(cross['intersection_pairs']),'skin_roi_vs_humerus_ulna_radius':int(bone['intersection_pairs']),'bone_by_owner_pair':bone['intersections_by_owner_pair']}
        mapped=[]
        for key,arr in bone.get('witnesses_by_owner_pair',{}).items():
            for w in arr:
                local_skin=int(w['face_a']);local_bone=int(w['face_b'])-n
                if not (0<=local_skin<len(roi) and 0<=local_bone<len(bown)):continue
                source_face=int(roi[local_skin]);bone_owner=str(bown[local_bone])
                hits=geo.triangle_intersection_points(exact_float32_triangle(V[F[source_face]]),exact_float32_triangle(bV[bF[local_bone]]))
                hit_points=[];hit_bary=[]
                for hit in hits:
                    hp=np.asarray([float(x) for x in hit],dtype=np.float64)
                    hit_points.append(hp.tolist());hit_bary.append(barycentric(hp,V[F[source_face]]).tolist())
                mapped.append({'source_skin_face':source_face,'bone_face_local':local_bone,'bone_owner':bone_owner,'owner_pair':key,'intersection_points_world_m':hit_points,'intersection_barycentric':hit_bary})
        witnesses[side]={'bone':mapped,'self':selfr.get('witnesses_by_owner_pair',{}),'outside':cross.get('witnesses_by_owner_pair',{})}
    return V,result,witnesses

def penetration_metric(d,poses,surfaces_by_pose,ids_by_side,As):
    values={};total=0.0;violations=0;worst=0.0;closest={}
    margin=TARGET_GAP_M*1000.0
    for pname,pose in poses.items():
        V=lbs.posed(d,pose)
        for side in ('left','right'):
            ids=ids_by_side[side]
            for bone,surface in surfaces_by_pose[pname][side].items():
                sd,_,_,face=closest_signed(V[ids],surface)
                deficit=np.maximum(margin-sd*1000.0,0.0)
                total+=float(np.dot(deficit,deficit));violations+=int(np.count_nonzero(deficit>0));worst=max(worst,float(np.max(deficit,initial=0)))
                values[f'{pname}/{side}/{bone}']={'vertices_below_target':int(np.count_nonzero(deficit>0)),'min_signed_gap_mm':float(np.min(sd,initial=np.inf)),'max_deficit_mm':float(np.max(deficit,initial=0))}
    return {'squared_deficit_mm2':total,'vertices_below_target_total':violations,'maximum_deficit_mm':worst,'by_pose_side_bone':values}

def barycentric(point,triangle):
    p=np.asarray(point,dtype=np.float64);t=np.asarray(triangle,dtype=np.float64)
    a,b,c=t;ab=b-a;ac=c-a;ap=p-a
    d00=float(ab@ab);d01=float(ab@ac);d11=float(ac@ac);d20=float(ap@ab);d21=float(ap@ac)
    den=d00*d11-d01*d01
    if den<=1e-30:raise ValueError('degenerate skin face for barycentric cut')
    u=(d11*d20-d01*d21)/den;v=(d00*d21-d01*d20)/den
    beta=np.asarray([1-u-v,u,v],dtype=np.float64)
    residual=float(np.linalg.norm(beta@t-p))
    if residual>2e-6 or np.min(beta)<-2e-5 or np.max(beta)>1+2e-5:
        raise ValueError(f'exact bone/skin intersection is not on mapped skin face: bary={beta.tolist()} residual_m={residual}')
    beta=np.clip(beta,0.0,1.0);beta/=beta.sum()
    return beta

def barycentric_grid(n):
    return [np.asarray([i,j,n-i-j],dtype=np.float64)/n for i in range(1,n) for j in range(1,n-i) if n-i-j>0]

def weld_exact_f32(vertices,faces):
    v=np.asarray(vertices,dtype=np.float32);f=np.asarray(faces,dtype=np.int64)
    ids=np.unique(f.ravel());keymap={};coords=[];remap=np.full(len(v),-1,dtype=np.int64)
    for raw_id in ids:
        row=v[int(raw_id)];key=tuple(0.0 if float(x)==0.0 else float(x) for x in row)
        if key not in keymap:keymap[key]=len(coords);coords.append(key)
        remap[int(raw_id)]=keymap[key]
    wf=remap[f]
    if np.any(wf<0) or np.any(wf[:,0]==wf[:,1]) or np.any(wf[:,1]==wf[:,2]) or np.any(wf[:,2]==wf[:,0]):
        raise ValueError('exact Float32 coordinate weld produced a degenerate face')
    edges=np.concatenate((wf[:,[0,1]],wf[:,[1,2]],wf[:,[2,0]]),axis=0)
    undirected=np.sort(edges,axis=1);uniq,inv,cnt=np.unique(undirected,axis=0,return_inverse=True,return_counts=True)
    if np.any(cnt!=2):raise ValueError(f'exact-weld bone surface not closed manifold: boundaries={int(np.sum(cnt==1))}, nonmanifold={int(np.sum(cnt>2))}')
    forward=np.zeros(len(uniq),dtype=np.int64);reverse=np.zeros(len(uniq),dtype=np.int64)
    for e,k in zip(edges,inv):
        if e[0]<e[1]:forward[k]+=1
        else:reverse[k]+=1
    if np.any(forward!=1) or np.any(reverse!=1):raise ValueError('exact-weld bone surface has inconsistent shared-edge orientation')
    wv=np.asarray(coords,dtype=np.float32);tri=wv[wf].astype(np.float64)
    vol=float(np.einsum('ij,ij->i',tri[:,0]-tri[:,0].mean(axis=0),np.cross(tri[:,1]-tri[:,0].mean(axis=0),tri[:,2]-tri[:,0].mean(axis=0))).sum()/6.0)
    if not math.isfinite(vol) or abs(vol)<1e-15:raise ValueError(f'exact-weld bone volume invalid: {vol}')
    cross=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]);norm=np.linalg.norm(cross,axis=1)
    if np.any(norm<=1e-15):raise ValueError('exact-weld bone contains zero-area triangles')
    normals=cross/norm[:,None]*float(np.sign(vol))
    return {'triangles':tri,'outward_normals':normals,'orientation_sign':int(np.sign(vol)),'signed_volume_m3':vol,'welded_vertex_count':int(len(wv)),'face_count':int(len(wf)),'welded_faces':wf}

def build_closed_solids(pose,side,records,bv,bi,anchors,geo):
    bV,bF,bown=geo.bone_scene(pose,'elbow',side,records,bv,bi,anchors);out={}
    for bone in (f'humerus_{side[0]}',f'ulna_{side[0]}',f'radius_{side[0]}'):
        ids=np.flatnonzero(np.asarray(bown)==bone);faces=np.asarray(bF[ids],dtype=np.int64)
        solid=weld_exact_f32(bV,faces);solid['global_bone_face_ids']=ids.astype(np.int64)
        solid['global_to_local_face']={int(g):int(i) for i,g in enumerate(ids)}
        solid['triangle_bounds_min']=solid['triangles'].min(axis=1);solid['triangle_bounds_max']=solid['triangles'].max(axis=1)
        out[bone]=solid
    return out,bV,bF,np.asarray(bown)

def solid_winding(points,solid):
    P=np.asarray(points,dtype=np.float64).reshape(-1,3);tri=solid['triangles'];out=np.empty(len(P),dtype=np.float64)
    for i,p in enumerate(P):
        r0=tri[:,0]-p;r1=tri[:,1]-p;r2=tri[:,2]-p
        n0=np.linalg.norm(r0,axis=1);n1=np.linalg.norm(r1,axis=1);n2=np.linalg.norm(r2,axis=1)
        num=np.einsum('ij,ij->i',r0,np.cross(r1,r2))
        den=n0*n1*n2+np.einsum('ij,ij->i',r0,r1)*n2+np.einsum('ij,ij->i',r1,r2)*n0+np.einsum('ij,ij->i',r2,r0)*n1
        out[i]=float(np.sum(2*np.arctan2(num,den))/(4*math.pi))
    return out

def exact_closest_points(points,solid,batch_size=8):
    P=np.asarray(points,dtype=np.float64).reshape(-1,3);T=solid['triangles'];nf=len(T)
    best_d=np.empty(len(P),dtype=np.float64);best_q=np.empty((len(P),3),dtype=np.float64);best_f=np.empty(len(P),dtype=np.int64)
    a=T[:,0];b=T[:,1];c=T[:,2];ab=b-a;ac=c-a
    d00=np.einsum('ij,ij->i',ab,ab);d01=np.einsum('ij,ij->i',ab,ac);d11=np.einsum('ij,ij->i',ac,ac);den=d00*d11-d01*d01
    for start in range(0,len(P),batch_size):
        pp=P[start:start+batch_size];ap=pp[:,None,:]-a[None,:,:]
        d20=np.einsum('bti,ti->bt',ap,ab);d21=np.einsum('bti,ti->bt',ap,ac)
        u=np.divide(d11[None,:]*d20-d01[None,:]*d21,den[None,:],out=np.zeros_like(d20),where=den[None,:]>1e-30)
        v=np.divide(d00[None,:]*d21-d01[None,:]*d20,den[None,:],out=np.zeros_like(d21),where=den[None,:]>1e-30)
        proj=a[None,:,:]+u[:,:,None]*ab[None,:,:]+v[:,:,None]*ac[None,:,:]
        proj_ok=(u>=0)&(v>=0)&(u+v<=1)
        def edge_q(x,y):
            xy=y-x;denom=np.einsum('ti,ti->t',xy,xy)
            t=np.divide(np.einsum('bti,ti->bt',pp[:,None,:]-x[None,:,:],xy),denom[None,:],out=np.zeros((len(pp),nf),dtype=np.float64),where=denom[None,:]>1e-30)
            t=np.clip(t,0,1);return x[None,:,:]+t[:,:,None]*xy[None,:,:]
        q1=edge_q(a,b);q2=edge_q(b,c);q3=edge_q(c,a)
        q=np.stack((proj,q1,q2,q3),axis=2)
        d2=np.sum((q-pp[:,None,None,:])**2,axis=3);d2[:,:,0]=np.where(proj_ok,d2[:,:,0],np.inf)
        feature=np.argmin(d2,axis=2);tri_d=np.min(d2,axis=2);face=np.argmin(tri_d,axis=1)
        rows=np.arange(len(pp));which=feature[rows,face]
        best_d[start:start+len(pp)]=np.sqrt(np.maximum(tri_d[rows,face],0.0));best_q[start:start+len(pp)]=q[rows,face,which];best_f[start:start+len(pp)]=face
    return best_d,best_q,best_f

def solid_signed_distance(points,solid,preferred_faces=None):
    P=np.asarray(points,dtype=np.float64).reshape(-1,3);dist,q,face=exact_closest_points(P,solid)
    wind=solid_winding(P,solid);inside=np.abs(wind)>0.5;boundary=(np.abs(np.abs(wind)-0.5)<1e-6)
    signed=np.where(inside,-dist,dist);signed=np.where(boundary,0.0,signed)
    grad=np.zeros_like(P);away=P-q
    nz=dist>1e-10
    grad[nz]=away[nz]/dist[nz,None]*np.where(inside[nz],-1.0,1.0)[:,None]
    surface=(~nz)|boundary
    if preferred_faces is not None:
        pref=np.asarray(preferred_faces,dtype=np.int64);use=(pref>=0)&surface
        face[use]=pref[use]
    grad[surface]=solid['outward_normals'][face[surface]]
    return {'signed_distance_m':signed,'winding_number':wind,'state':np.where(boundary,'boundary_ambiguous',np.where(inside,'inside','outside')),'gradient_outward':grad,'closest_point_m':q,'nearest_face_local':face,'unsigned_distance_m':dist}

def add_cut(bank,pose,side,bone,face,ids,beta,source_label,preferred_face=-1):
    ids=np.asarray(ids,dtype=np.int64);beta=np.asarray(beta,dtype=np.float64)
    if len(ids)!=3 or len(beta)!=3 or not np.isfinite(beta).all() or abs(float(beta.sum())-1.0)>1e-8:raise ValueError('invalid barycentric cut')
    if face<0:token=('v',int(ids[0]))
    else:token=('f',int(face),tuple(np.round(beta,7).tolist()))
    key=(pose,side,bone,token,int(preferred_face))
    if key not in bank:
        if len(bank)>=MAX_CUTS:raise RuntimeError(f'cut bank reached bounded capacity {MAX_CUTS}')
        bank[key]={'pose':pose,'side':side,'bone':bone,'face':int(face),'vertex_ids':ids.tolist(),'barycentric':beta.tolist(),'preferred_bone_face_local':int(preferred_face),'first_source':source_label,'source_count':1}
    else:
        bank[key]['source_count']+=1
    return key

def cut_world_points(d,pose,cutbank,F,lbs):
    V=lbs.posed(d,pose);points=[];keys=[];prefs=[]
    for key,c in cutbank.items():
        if c['pose']!=pose:continue
        ids=np.asarray(c['vertex_ids'],dtype=np.int64);beta=np.asarray(c['barycentric'],dtype=np.float64)
        points.append(beta@V[ids].astype(np.float64));keys.append(key);prefs.append(int(c['preferred_bone_face_local']))
    return np.asarray(points,dtype=np.float64).reshape(-1,3),keys,np.asarray(prefs,dtype=np.int64)

def cut_eval(d,pose_name,pose_state,side,bone,cutbank,solid,F,lbs):
    subset=[(k,c) for k,c in cutbank.items() if c['pose']==pose_name and c['side']==side and c['bone']==bone]
    if not subset:return {}
    V=lbs.posed(d,pose_state);points=[];prefs=[]
    for k,c in subset:
        ids=np.asarray(c['vertex_ids'],dtype=np.int64);beta=np.asarray(c['barycentric'],dtype=np.float64)
        points.append(beta@V[ids].astype(np.float64));prefs.append(int(c['preferred_bone_face_local']))
    sdf=solid_signed_distance(np.asarray(points),solid,np.asarray(prefs,dtype=np.int64))
    return {k:{'point_m':sdf_point.tolist(),'signed_distance_m':float(sdf['signed_distance_m'][i]),'winding_number':float(sdf['winding_number'][i]),'state':str(sdf['state'][i]),'gradient_outward':sdf['gradient_outward'][i].tolist(),'nearest_face_local':int(sdf['nearest_face_local'][i])} for i,(k,sdf_point) in enumerate(zip([x[0] for x in subset],points))}

def collect_current_cuts(d,poses,F,face_region,face_side,var_side,cutbank,solid_surfaces,records,bv,bi,anchors,geo,lbs):
    pose_data={};pose_witnesses={};new_keys=[];limit=TARGET_GAP_M+CUT_NEAR_GAP_MM/1000.0
    for pname,pose in poses.items():
        V,counts,wit=geometry_counts(d,pose,F,face_region,face_side,records,bv,bi,anchors,geo)
        pose_data[pname]={'counts':counts,'posed_vertices':V};pose_witnesses[pname]={}
        for side in ('left','right'):
            pose_witnesses[pname][side]=[]
            for bone,solid in solid_surfaces[pname][side].items():
                ids=np.asarray(var_side[side],dtype=np.int64);pts=V[ids].astype(np.float64)
                sdf=solid_signed_distance(pts,solid)
                pose_data[pname].setdefault('vertex_sdf',{}).setdefault(side,{})[bone]={'ids':ids,'sdf':sdf}
                for j,vid in enumerate(ids):
                    if sdf['signed_distance_m'][j] <= limit:
                        key=add_cut(cutbank,pname,side,bone,-1,[int(vid)]*3,[1.,0.,0.],'support_vertex_near_solid')
                        if key not in new_keys:new_keys.append(key)
            # Every exact own-bone pair contributes its actual exact hit points and a true-winding barycentric face stencil.
            face_bones={}
            for w in wit[side]['bone']:
                face=int(w['source_skin_face']);bone=str(w['bone_owner']);bface=int(w['bone_face_local'])
                fb=face_bones.setdefault((bone,face),{'bone_faces':[],'pair_witnesses':[]})
                if bface not in fb['bone_faces']:fb['bone_faces'].append(bface)
                fb['pair_witnesses'].append(w)
                solid=solid_surfaces[pname][side][bone]
                pref=int(solid['global_to_local_face'].get(bface,-1))
                for hp,beta in zip(w.get('intersection_points_world_m',[]),w.get('intersection_barycentric',[])):
                    key=add_cut(cutbank,pname,side,bone,face,F[face],beta,'exact_skin_bone_intersection',pref)
                    if key not in new_keys:new_keys.append(key)
            for (bone,face),group in face_bones.items():
                solid=solid_surfaces[pname][side][bone];tri=V[F[face]].astype(np.float64);grid_n=32 if pname==ACTIVE and face==95142 and bone=='radius_r' else CUT_GRID_DENOMINATOR
                barys=barycentric_grid(grid_n);points=np.asarray([b@tri for b in barys],dtype=np.float64)
                sdf=solid_signed_distance(points,solid)
                inside_bary=[];near_bary=[]
                for j,beta in enumerate(barys):
                    if sdf['state'][j]=='inside':inside_bary.append(beta.tolist())
                    if sdf['signed_distance_m'][j] <= limit:
                        near_bary.append({'barycentric':beta.tolist(),'signed_distance_mm':float(sdf['signed_distance_m'][j]*1000),'winding_number':float(sdf['winding_number'][j]),'state':str(sdf['state'][j])})
                        key=add_cut(cutbank,pname,side,bone,face,F[face],beta,'inside_or_near_skin_face_barycentric_sample',-1)
                        if key not in new_keys:new_keys.append(key)
                group['face_barycentric_grid']={'denominator':grid_n,'sample_count':len(barys),'inside_sample_barycentrics':inside_bary,'near_gap_samples':near_bary}
                # Add outside-support face vertices as auditable cuts too; the QP later identifies their fixed status.
                vtx_sdf=solid_signed_distance(tri,solid)
                for vi,vid in enumerate(F[face]):
                    if vtx_sdf['signed_distance_m'][vi] <= limit:
                        key=add_cut(cutbank,pname,side,bone,-1,[int(vid)]*3,[1.,0.,0.],'intersecting_face_vertex',-1)
                        if key not in new_keys:new_keys.append(key)
                pose_witnesses[pname].setdefault(side,[]).append({'source_skin_face':face,'bone_owner':bone,'bone_face_local_indices':sorted(group['bone_faces']),'exact_pair_count':len(group['pair_witnesses']),'pairs':[{'bone_face_local':int(x['bone_face_local']),'intersection_points_world_m':x['intersection_points_world_m'],'intersection_barycentric':x['intersection_barycentric']} for x in group['pair_witnesses']],'face_barycentric_grid':group['face_barycentric_grid']})
    if len(cutbank)>MAX_CUTS:raise RuntimeError('cut-bank bound exceeded')
    return pose_data,pose_witnesses,new_keys

def metric_from_current(d,pose_data,poses,solid_surfaces,var_side,cutbank,F,lbs,delta,As):
    inside=0;depth_e=0.0;deficit_e=0.0;maxdepth=0.0;by={};ambiguous=0
    for pname in poses:
        for side in ('left','right'):
            for bone,entry in pose_data[pname]['vertex_sdf'][side].items():
                sdf=entry['sdf'];sd=sdf['signed_distance_m']*1000.0;dep=np.maximum(-sd,0.0);defi=np.maximum(TARGET_GAP_M*1000.0-sd,0.0)
                count=int(np.count_nonzero(sdf['state']=='inside'));amb=int(np.count_nonzero(sdf['state']=='boundary_ambiguous'))
                inside+=count;ambiguous+=amb;depth_e+=float(dep@dep);deficit_e+=float(defi@defi);maxdepth=max(maxdepth,float(np.max(dep,initial=0)))
                by[f'{pname}/{side}/{bone}']={'support_vertices':int(len(sd)),'inside_count':count,'boundary_ambiguous_count':amb,'maximum_penetration_depth_mm':float(np.max(dep,initial=0)),'minimum_signed_distance_mm':float(np.min(sd,initial=np.inf))}
    cut_evals={};cut_count=0
    for pname in poses:
        for side in ('left','right'):
            for bone,solid in solid_surfaces[pname][side].items():
                ev=cut_eval(d,pname,poses[pname],side,bone,cutbank,solid,F,lbs);cut_evals.update(ev)
                for k,x in ev.items():
                    c=cutbank[k]
                    if c['face']<0:continue
                    sd=float(x['signed_distance_m']*1000);dep=max(-sd,0.0);defi=max(TARGET_GAP_M*1000.0-sd,0.0)
                    inside+=int(x['state']=='inside');ambiguous+=int(x['state']=='boundary_ambiguous');depth_e+=dep*dep;deficit_e+=defi*defi;maxdepth=max(maxdepth,dep);cut_count+=1
    delta_mm=np.asarray(delta,dtype=np.float64)[np.asarray(list(set(np.concatenate(list(var_side.values())).tolist())),dtype=np.int64)]*1000.0
    distortion=float(np.sum(delta_mm*delta_mm));merit=depth_e+0.1*deficit_e+0.01*inside+1e-3*distortion
    return {'inside_sample_count_including_support_vertices':inside,'boundary_ambiguous_sample_count':ambiguous,'support_and_bary_sample_count':sum(len(x['ids']) for p in pose_data.values() for s in p['vertex_sdf'].values() for x in s.values())+cut_count,'unique_barycentric_cut_count':cut_count,'sum_squared_penetration_depth_mm2':depth_e,'sum_squared_target_clearance_deficit_mm2':deficit_e,'maximum_penetration_depth_mm':maxdepth,'rest_displacement_squared_mm2':distortion,'declared_merit':merit,'merit_definition':'sum(depth_mm^2)+0.1*sum(max(target_gap_mm-signed_gap_mm,0)^2)+0.01*inside_sample_count+0.001*sum(rest_delta_mm^2); inside count is reported and may trade against reduced depth as intermediate cuts accumulate','by_pose_side_bone':by,'cut_evaluations':cut_evals}

def sparse_cut_qp(lbs,cutbank,cut_evaluations,poses,solid_surfaces,As,F,loc,fit_ids,current_delta,radius_mm,edgevar,edgefixed):
    rows=[];lower=[];info=[];uncontrolled=[];current_mm=current_delta[fit_ids]*1000.0;nvar=len(fit_ids);ncoord=3*nvar
    for key,c in cutbank.items():
        pname=c['pose'];side=c['side'];bone=c['bone'];solid=solid_surfaces[pname][side][bone]
        ev=cut_evaluations.get(key)
        if ev is None:continue
        sdmm=ev['signed_distance_m']*1000.0
        if sdmm>TARGET_GAP_M*1000.0+CUT_NEAR_GAP_MM:continue
        grad=np.asarray(ev['gradient_outward'],dtype=np.float64)
        ids=np.asarray(c['vertex_ids'],dtype=np.int64);beta=np.asarray(c['barycentric'],dtype=np.float64)
        accum={}
        for vi,weight in zip(ids,beta):
            if abs(float(weight))<1e-12:continue
            li=int(loc[int(vi)])
            if li<0:continue
            coef=float(weight)*(grad@As[pname][int(vi)])
            accum[li]=accum.get(li,np.zeros(3,dtype=np.float64))+coef
        if not accum:
            if sdmm<TARGET_GAP_M*1000.0:uncontrolled.append({'cut':str(key),'signed_gap_mm':sdmm,'reason':'penetrating point has no rest-coordinate variable in fit support'})
            continue
        norm=math.sqrt(sum(float(v@v) for v in accum.values()))
        if not math.isfinite(norm) or norm<1e-7:
            uncontrolled.append({'cut':str(key),'signed_gap_mm':sdmm,'reason':'near-zero LBS Jacobian along true solid-distance gradient'});continue
        row_id=len(rows);row={}
        for li,vec in accum.items():row[li]=vec
        rows.append(row);rhs=TARGET_GAP_M*1000.0-sdmm
        for li,vec in row.items():rhs+=float(vec@current_mm[li])
        lower.append(rhs);info.append({'cut_key':str(key),'pose':pname,'side':side,'bone':bone,'source_face':c['face'],'vertex_ids':ids.astype(int).tolist(),'barycentric':beta.tolist(),'signed_gap_mm':float(sdmm),'winding_number':float(ev['winding_number']),'state':ev['state'],'gradient_outward':grad.tolist(),'preferred_face':c['preferred_bone_face_local'],'first_source':c['first_source']})
    if not rows: return None,{'constraint_count':0,'uncontrolled':uncontrolled,'info':info}
    rr=[];cc=[];vv=[];b=np.asarray(lower,dtype=np.float64)
    for ri,row in enumerate(rows):
        for li,vec in row.items():
            rr.extend([ri,ri,ri]);cc.extend((3*int(li)+np.arange(3)).tolist());vv.extend(np.asarray(vec,dtype=np.float64).tolist())
    C=coo_matrix((np.asarray(vv,dtype=np.float64),(np.asarray(rr,dtype=np.int64),np.asarray(cc,dtype=np.int64))),shape=(len(rows),ncoord)).tocsr()
    hr=list(range(nvar));hc=list(range(nvar));hv=[1.0]*nvar;lam=float(SMOOTHNESS)
    for a,bvtx in edgevar:
        a=int(a);bvtx=int(bvtx);hr.extend((a,bvtx,a,bvtx));hc.extend((a,bvtx,bvtx,a));hv.extend((lam,lam,-lam,-lam))
    for a in edgefixed:
        a=int(a);hr.append(a);hc.append(a);hv.append(lam)
    Hvertex=coo_matrix((np.asarray(hv,dtype=np.float64),(np.asarray(hr,dtype=np.int64),np.asarray(hc,dtype=np.int64))),shape=(nvar,nvar)).tocsc()
    H=kron(Hvertex,eye(3,format='csc'),format='csc');rho=10.0;abs_tol=1e-5;rel_tol=1e-5
    K=(H+rho*(C.T@C+2*eye(ncoord,format='csc'))).tocsc();solve=factorized(K)
    x=np.zeros(ncoord,dtype=np.float64);yg=np.maximum(np.asarray(C@x).ravel(),b);yb=np.zeros((nvar,3));yc=np.zeros((nvar,3));ug=np.zeros(len(rows));ub=np.zeros((nvar,3));uc=np.zeros((nvar,3));converged=False
    primal=dual=epsp=epsd=float('inf');rho_updates=[];it=0
    for it in range(1,MAX_ADMM_ITERATIONS+1):
        rhs=rho*(np.asarray(C.T@(yg-ug)).ravel()+(yb-ub).ravel()+(yc-uc).ravel())
        x=np.asarray(solve(rhs),dtype=np.float64);cx=np.asarray(C@x).ravel();yg0=yg.copy();yb0=yb.copy();yc0=yc.copy()
        yg=np.maximum(cx+ug,b);shift=x.reshape(nvar,3)+ub;norm=np.linalg.norm(shift,axis=1);scale=np.minimum(1.0,np.divide(radius_mm,norm,out=np.ones_like(norm),where=norm>0));yb=shift*scale[:,None];yc=np.clip(x.reshape(nvar,3)+uc,-radius_mm[:,None],radius_mm[:,None])
        rg=cx-yg;rb=x.reshape(nvar,3)-yb;rc=x.reshape(nvar,3)-yc;ug+=rg;ub+=rb;uc+=rc
        primal=float(np.sqrt(rg@rg+np.sum(rb*rb)+np.sum(rc*rc)));dyg=yg-yg0;dyb=yb-yb0;dyc=yc-yc0
        dual=float(rho*np.linalg.norm(np.asarray(C.T@dyg).ravel()+dyb.ravel()+dyc.ravel()))
        ax=float(np.sqrt(cx@cx+2*(x@x)));yn=float(np.sqrt(yg@yg+np.sum(yb*yb)+np.sum(yc*yc)))
        epsp=float(abs_tol*np.sqrt(len(rows)+2*ncoord)+rel_tol*max(ax,yn));aty=float(np.linalg.norm(np.asarray(C.T@ug).ravel()+ub.ravel()+uc.ravel()));epsd=float(abs_tol*np.sqrt(ncoord)+rel_tol*rho*aty)
        if primal<=epsp and dual<=epsd:converged=True;break
        if it%250==0:
            old=rho
            if primal>5*dual:rho=min(2*rho,1e5)
            elif dual>5*primal:rho=max(rho/2,1e-4)
            if rho!=old:
                scale_u=old/rho;ug*=scale_u;ub*=scale_u;uc*=scale_u;K=(H+rho*(C.T@C+2*eye(ncoord,format='csc'))).tocsc();solve=factorized(K);rho_updates.append({'iteration':it,'old_rho':old,'new_rho':rho,'primal':primal,'dual':dual})
        if it%1000==0:print(json.dumps({'solver':'sparse-cut-admm','iterations':it,'constraints':len(rows),'rho':rho,'primal':primal,'dual':dual},sort_keys=True),flush=True)
    radial=radius_mm**2-np.sum(x.reshape(nvar,3)**2,axis=1);box=radius_mm[:,None]-np.abs(x.reshape(nvar,3));slack=np.asarray(C@x).ravel()-b
    return x.reshape(nvar,3),{'constraint_count':len(rows),'constraint_nonzeros':int(C.nnz),'hessian_nonzeros':int(H.nnz),'success':converged,'iterations':it,'rho':rho,'primal_residual':primal,'primal_tolerance':epsp,'dual_residual':dual,'dual_tolerance':epsd,'objective':0.5*float(x@(H@x)),'minimum_linear_slack_mm':float(np.min(slack,initial=np.inf)),'minimum_radial_slack_mm2':float(np.min(radial,initial=np.inf)),'minimum_box_slack_mm':float(np.min(box,initial=np.inf)),'rho_updates':rho_updates,'uncontrolled':uncontrolled,'constraint_info':info,'matrix_shape':[len(rows),ncoord]}

def metric_summary(metric):
    return {k:v for k,v in metric.items() if k!='cut_evaluations'}

def exact_gate_flat(counts):
    return {s:{k:int(counts[s][k]) for k in ('skin_self','skin_roi_vs_other_fullbody_skin','skin_roi_vs_humerus_ulna_radius')} for s in counts}

def posed_orientation_gate(dtrial,poses,pose_refs,F,affected_faces,lbs):
    finite=bool(np.isfinite(np.asarray(dtrial['vertices_f'])).all());summary={};ok=finite
    for pname,pose in poses.items():
        V=lbs.posed(dtrial,pose).astype(np.float64);ref=pose_refs[pname].astype(np.float64)
        f=np.asarray(F[affected_faces],dtype=np.int64)
        a=V[f];b=ref[f]
        c0=np.cross(b[:,1]-b[:,0],b[:,2]-b[:,0]);c1=np.cross(a[:,1]-a[:,0],a[:,2]-a[:,0])
        area=np.linalg.norm(c1,axis=1);dot=np.einsum('ij,ij->i',c0,c1)
        local=bool(np.isfinite(V).all() and np.all(area>1e-14) and np.all(dot>0.0))
        summary[pname]={'finite':bool(np.isfinite(V).all()),'affected_face_count':int(len(f)),'zero_or_tiny_area_count':int(np.count_nonzero(area<=1e-14)),'orientation_reversal_count':int(np.count_nonzero(dot<=0.0)),'minimum_normal_dot':float(np.min(dot,initial=np.inf)),'minimum_trial_double_area_m2':float(np.min(area,initial=np.inf))}
        ok &= local
    return bool(ok),summary

# modules are initialized before function calls

def main():
    global lbs
    if not RUN.is_dir():raise SystemExit(f'evidence directory missing: {RUN}')
    if OUT.exists() or PARTIAL.exists() or NPZ.exists():raise SystemExit('refusing to overwrite fit evidence')
    start=time.monotonic();decode_payload,lbs,geo=setup_imports()
    raw=PAYLOAD.read_bytes();d0=decode_payload(raw);F=np.asarray(d0['indices'],dtype=np.int64).reshape(-1,3)
    W0=np.asarray(d0['full_weights'],dtype=np.float32).copy();bind=np.asarray(d0['bindings_u'][:,0],dtype=np.int64)
    source=np.asarray(d0['vertices_f'][:,:3],dtype=np.float32).copy();manifest=json.loads(geo.MAN.read_text())
    names={int(x['core_body_index']):str(x['myosim_body']).lower() for x in manifest['source']['anchors']}
    slotname=[names[int(x)] for x in bind];slot={n:i for i,n in enumerate(slotname)}
    owner=[slotname[int(i)] for i in np.argmax(W0,axis=1)]
    vside=np.asarray([geo.side(n) for n in owner]);vreg=np.asarray([geo.skin_region(n) for n in owner])
    face_side=np.asarray([geo.majority(vside[t]) for t in F]);face_region=np.asarray([geo.majority(vreg[t]) for t in F])
    poses={n:json.loads((R/n/'registered-skin-poses.json').read_text()) for n in (BASE,ACTIVE)}
    inv={n:json.loads((R/n/'invocation.json').read_text()) for n in (BASE,ACTIVE)}
    res={n:json.loads((R/n/'result.json').read_text()) for n in (BASE,ACTIVE)}
    for n in (BASE,ACTIVE):
        if res[n].get('registered_rows')!=61950 or not res[n].get('paired_pose_snapshot_valid'):raise ValueError(f'incomplete matched static capture: {n}')
        if inv[n]['binary_sha256']!='d6fb67d0bf16ffb6bed04a5887cf3916ab67e152d10006bb0eb0da47e1d5cd95':raise ValueError(f'clean014 binary identity mismatch: {n}')
        if inv[n]['candidate_rigid_sha256']!='c10924a45efc1cfb3916bd22baabeeca491da5e412bbaad37b1328fe364db53d':raise ValueError(f'rigid identity mismatch: {n}')
        if inv[n]['skin_payload_sha256']!=sha(PAYLOAD):raise ValueError(f'skin payload identity mismatch: {n}')
    weight_report=json.loads(WEIGHT_REPORT.read_text())
    if sha(WEIGHT_SCRIPT)!=weight_report['assessor_script_sha256']:raise ValueError('018 weight script changed')

    # Reconstruct the exact 1/3 W counterfactual from immutable 018 parameters.
    exact_old=json.loads(EXACT.read_text());legacy_seeds={};legacy_faces={}
    active_pair=exact_old['pose_pairs']['elbow-shoulder010']['active']['sides']
    for side in ('left','right'):
        fsids=set()
        for key in ('skin_self','skin_roi_vs_other_fullbody_skin','skin_roi_vs_nearby_bone'):
            for groups in active_pair[side][key].get('witnesses_by_owner_pair',{}).values():
                for w in groups:
                    fsids.add(int(w['face_a']))
                    if key=='skin_self':fsids.add(int(w['face_b']))
        eligible=np.asarray(sorted(i for i in fsids if 0<=i<len(F) and face_side[i]==side and face_region[i] in ('upper_arm','elbow_forearm')),dtype=np.int64)
        expected=weight_report['seed_counts'][side]['faces']
        if len(eligible)!=expected:raise ValueError(f'legacy 018 seed attribution changed for {side}: {len(eligible)} != {expected}')
        legacy_faces[side]=eligible;legacy_seeds[side]=np.unique(F[eligible].ravel())
    source_edges=np.concatenate((F[:,[0,1]],F[:,[1,2]],F[:,[2,0]]),axis=0)
    source_edges=np.unique(np.sort(source_edges,axis=1),axis=0)
    edge_len=np.linalg.norm(source[source_edges[:,0]].astype(np.float64)-source[source_edges[:,1]].astype(np.float64),axis=1)
    nvertex=len(W0);weight_dist={}
    for side in ('left','right'):
        seeds=legacy_seeds[side]
        rr=np.concatenate((source_edges[:,0],source_edges[:,1],np.full(len(seeds),nvertex,dtype=np.int64)))
        cc=np.concatenate((source_edges[:,1],source_edges[:,0],seeds))
        dd=np.concatenate((edge_len,edge_len,np.zeros(len(seeds))))
        graph=coo_matrix((dd,(rr,cc)),shape=(nvertex+1,nvertex+1)).tocsr()
        weight_dist[side]=dijkstra(graph,directed=False,indices=nvertex)[:nvertex]
    chain={side:np.asarray([slot[f'humerus_{side[0]}'],slot[f'ulna_{side[0]}'],slot[f'radius_{side[0]}']],dtype=np.int64) for side in ('left','right')}
    W=W0.copy();
    for side in ('left','right'):
        ids=chain[side];dist=weight_dist[side];t=np.clip(dist/WEIGHT_RADIUS_M,0.0,1.0)
        alpha=(1.0/3.0*(1.0-t)**2*(1.0+2.0*t)).astype(np.float32)
        ch=W0[:,ids];cs=ch.sum(axis=1);off=np.maximum(W0.sum(axis=1)-cs,0.0)
        select=(dist<WEIGHT_RADIUS_M)&(cs>1e-8)
        original=W0[select];local_alpha=alpha[select,None];new=original*(1.0-local_alpha)
        new[:,ids]=original[:,ids]+local_alpha*(off[select,None]*ch[select]/cs[select,None])
        W[select]=new
    if not np.isfinite(W).all() or W.min()<0 or np.max(np.abs(W.sum(axis=1)-1))>4e-7:raise ValueError('reconstructed 018 W failed finite/partition checks')
    weight_changed=np.flatnonzero(np.any(W!=W0,axis=1))
    if len(weight_changed)!=weight_report['variants'][0]['weight_checks']['changed_source_rows']:raise ValueError('reconstructed weight support differs from 018')
    dbase=dict(d0);dbase['full_weights']=W

    # Current exact witnesses: map the pair auditor's ROI-local face IDs back
    # through roi[] to immutable source-face IDs before constructing the patch.
    base_geometry={};active_geometry={};direct_seedfaces={side:set() for side in ('left','right')}
    for pname in (BASE,ACTIVE):
        _,counts,wit=geometry_counts(dbase,poses[pname],F,face_region,face_side,*geo.load_bones()[2:],geo)
        if pname==BASE:base_geometry=counts
        else:
            active_geometry=counts
            for side in ('left','right'):
                for w in wit[side]['bone']:direct_seedfaces[side].add(w['source_skin_face'])
    base_flat={s:{k:base_geometry[s][k] for k in ('skin_self','skin_roi_vs_other_fullbody_skin','skin_roi_vs_humerus_ulna_radius')} for s in base_geometry}
    active_flat={s:{k:active_geometry[s][k] for k in ('skin_self','skin_roi_vs_other_fullbody_skin','skin_roi_vs_humerus_ulna_radius')} for s in active_geometry}
    expected_active={'left':139,'right':128}
    if any(active_flat[s]['skin_roi_vs_humerus_ulna_radius']!=expected_active[s] for s in expected_active):
        raise ValueError(f'1/3 exact starting geometry differs from retained 018: {active_flat}')
    if any(base_flat[s]['skin_self'] or base_flat[s]['skin_roi_vs_other_fullbody_skin'] or base_flat[s]['skin_roi_vs_humerus_ulna_radius'] for s in base_flat):
        raise ValueError(f'1/3 matched neutral exact baseline is not clear: {base_flat}')
    if any(active_flat[s]['skin_self'] or active_flat[s]['skin_roi_vs_other_fullbody_skin'] for s in active_flat):
        raise ValueError(f'1/3 matched active exact skin gates are not clear: {active_flat}')

    # Coordinate-fit support uses exact current collision source faces, not the
    # stale broad-report face indices used only to reproduce the 018 weights.
    geom_dist={};roi_faces={};roi_vertices={};var_side={};fit_ids=[]
    for side in ('left','right'):
        faces=np.asarray(sorted(direct_seedfaces[side]),dtype=np.int64)
        if len(faces)==0:raise ValueError(f'no direct current bone witnesses for {side}')
        if np.any(face_side[faces]!=side) or np.any(~np.isin(face_region[faces],['upper_arm','elbow_forearm'])):raise ValueError(f'current witness source-face attribution invalid for {side}')
        seeds=np.unique(F[faces].ravel())
        rr=np.concatenate((source_edges[:,0],source_edges[:,1],np.full(len(seeds),nvertex,dtype=np.int64)))
        cc=np.concatenate((source_edges[:,1],source_edges[:,0],seeds))
        dd=np.concatenate((edge_len,edge_len,np.zeros(len(seeds))))
        graph=coo_matrix((dd,(rr,cc)),shape=(nvertex+1,nvertex+1)).tocsr()
        geom_dist[side]=dijkstra(graph,directed=False,indices=nvertex)[:nvertex]
        roi_faces[side]=np.flatnonzero((face_side==side)&np.isin(face_region,['upper_arm','elbow_forearm']))
        roi_vertices[side]=np.unique(F[roi_faces[side]].ravel())
        var_side[side]=roi_vertices[side][geom_dist[side][roi_vertices[side]]<FIT_RADIUS_M]
        fit_ids.extend(var_side[side].tolist())
    fit_ids=np.asarray(sorted(set(fit_ids)),dtype=np.int64)
    loc=np.full(nvertex,-1,dtype=np.int64);loc[fit_ids]=np.arange(len(fit_ids))
    variable_distance=np.asarray([min(geom_dist[s][i] for s in ('left','right') if i in set(var_side[s].tolist())) for i in fit_ids])
    radius_mm=MAX_DELTA_M*1000.0*np.clip((FIT_RADIUS_M-variable_distance)/(FIT_RADIUS_M-CORE_RADIUS_M),0.0,1.0)
    radius_mm=np.where(variable_distance<=CORE_RADIUS_M,MAX_DELTA_M*1000.0,radius_mm)
    if np.any(radius_mm<=0):raise ValueError('zero-radius variable unexpectedly included')

    # Preserve the existing nearest-face query only as a comparison artifact;
    # the cutting-plane objective below uses separately verified exact-weld closed solids.
    bone_data=geo.load_bones();manifest_b,raw_b,records,bv,bi,anchors=bone_data
    orientation={};orientation_report={}
    for side in ('left','right'):
        for bone in (f'humerus_{side[0]}',f'ulna_{side[0]}',f'radius_{side[0]}'):
            sign,rows=bone_local_orientation(manifest_b,records,bv,bi,anchors,bone)
            orientation[bone]=(sign,rows)
    surfaces_by_pose={};surface_metadata={}
    for pname in (BASE,ACTIVE):
        surfaces_by_pose[pname]={};surface_metadata[pname]={}
        for side in ('left','right'):
            surfaces_by_pose[pname][side],surface_metadata[pname][side]=build_surface_queries(poses[pname],side,records,bv,bi,anchors,geo,orientation)
    orientation_report={'per_pose_side_bone':surface_metadata,'legacy_local_halfspace_query_retained_for_comparison_only':True,'cutting_plane_solid_classification':'closed-shell exact Float32-coordinate weld, cross-checked against retained 030 edge-incidence audit; all six shells must be closed, consistently oriented, and nondegenerate.'}
    solid_report=json.loads(SOLID_REPORT.read_text());topology_report=json.loads(SOLID_TOPOLOGY.read_text())
    if solid_report['inputs']['weld_topology_report_sha256']!=sha(SOLID_TOPOLOGY):raise ValueError('033 solid classifier is not bound to current 030 exact-weld topology report')
    if solid_report['inputs']['witness_report_sha256']!=sha(RUN/'elbow-rest-coordinate-fit-027-current-witness-classification.json'):raise ValueError('033 solid classifier is not bound to current 027 exact witness report')
    if solid_report['inputs']['rigid_sha256']!=inv[BASE]['candidate_rigid_sha256'] or solid_report['inputs']['binary_sha256']!=inv[BASE]['binary_sha256'] or solid_report['inputs']['pose_sha256']!=res[ACTIVE]['paired_pose_snapshot_sha256']:
        raise ValueError('033 solid classifier source identity differs from paired active scene')
    solid_surfaces_by_pose={};solid_metadata={};bone_scene_cache={}
    for pname in (BASE,ACTIVE):
        solid_surfaces_by_pose[pname]={};solid_metadata[pname]={}
        for side in ('left','right'):
            solids,bV0,bF0,bown0=build_closed_solids(poses[pname],side,records,bv,bi,anchors,geo)
            solid_surfaces_by_pose[pname][side]=solids;bone_scene_cache[(pname,side)]=(bV0,bF0,bown0)
            for bone,solid in solids.items():
                tp=topology_report['bones'][side][bone]
                if not tp['closed_consistently_oriented_after_exact_weld'] or tp['edge_incidence_after_exact_weld']['boundary_edges'] or tp['edge_incidence_after_exact_weld']['nonmanifold_edges'] or tp['edge_incidence_after_exact_weld']['inconsistently_oriented_shared_edges'] or tp['degenerate_faces_after_weld']:
                    raise ValueError(f'030 exact-weld topology gate failed for {side}/{bone}')
                solid_metadata[pname+'/'+side+'/'+bone]={'face_count':solid['face_count'],'welded_vertex_count':solid['welded_vertex_count'],'orientation_sign':solid['orientation_sign'],'signed_volume_m3':solid['signed_volume_m3'],'closed_topology_matches_030':True}

    dbase['vertices_f']=np.asarray(d0['vertices_f']).copy()
    current_delta=np.zeros((nvertex,3),dtype=np.float64)  # metres from immutable source rest coordinates
    ids_by_side={s:var_side[s] for s in ('left','right')}
    As={pname:build_A(dbase,poses[pname],lbs) for pname in (BASE,ACTIVE)}
    # Verify analytical per-vertex rest-coordinate Jacobian against native LBS owner.
    test_i=int(fit_ids[len(fit_ids)//2]);test_eps=1e-2  # Float32 output needs a resolvable affine perturbation.
    dtest=dict(dbase);vf=np.asarray(dtest['vertices_f']).copy();vf[test_i,0]+=test_eps;dtest['vertices_f']=vf
    v0=lbs.posed(dbase,poses[ACTIVE])[test_i].astype(np.float64);v1=lbs.posed(dtest,poses[ACTIVE])[test_i].astype(np.float64)
    jac_err=float(np.max(np.abs((v1-v0)/test_eps-As[ACTIVE][test_i,0])))
    if jac_err>1e-5:raise ValueError(f'analytical affine rest-coordinate Jacobian failed finite difference: {jac_err}')

    report={'schema':'numi.human.local-elbow-rest-coordinate-fit.v4','status':'running','scope':'Evidence-only local rest-coordinate fit over matched static shoulder=.1 neutral and elbow=.8 poses; 1/3 chain-only weight counterfactual reconstructed exactly from 018. No payload/header/runtime/FEM/mechanical/source asset modified; not dynamic-contact or clinical qualification.','inputs':{'skin_payload_path':str(PAYLOAD),'skin_payload_sha256':sha(PAYLOAD),'weight_counterfactual_script_sha256':sha(WEIGHT_SCRIPT),'weight_counterfactual_report_sha256':sha(WEIGHT_REPORT),'exact_audit_sha256':sha(EXACT),'bone_manifest_sha256':sha(geo.MAN),'bone_payload_sha256':sha(raw_b),'binary_sha256':inv[BASE]['binary_sha256'],'rigid_sha256':inv[BASE]['candidate_rigid_sha256'],'native_csv_sha256':{n:res[n]['registered_csv_sha256'] for n in (BASE,ACTIVE)},'pose_snapshot_sha256':{n:res[n]['paired_pose_snapshot_sha256'] for n in (BASE,ACTIVE)},'native_exit_codes':{n:res[n]['native_exit_code'] for n in (BASE,ACTIVE)},'requested_q':{n:inv[n]['requested_q'] for n in (BASE,ACTIVE)}},'weight_counterfactual':{'fraction':1/3,'changed_source_rows':int(len(weight_changed)),'legacy_weight_patch_seed_faces':{s:legacy_faces[s].astype(int).tolist() for s in legacy_faces},'legacy_weight_patch_seed_vertices':{s:int(len(legacy_seeds[s])) for s in legacy_seeds},'starting_exact_neutral':base_flat,'starting_exact_active':active_flat},'fit_support':{'direct_active_bone_witness_source_faces':{s:sorted(map(int,direct_seedfaces[s])) for s in direct_seedfaces},'direct_witness_face_count':{s:int(len(direct_seedfaces[s])) for s in direct_seedfaces},'fit_radius_mm':FIT_RADIUS_M*1000,'fixed_outer_boundary_collar_mm':(20.0-FIT_RADIUS_M*1000),'variable_vertex_count':int(len(fit_ids)),'variable_vertex_count_by_side':{s:int(len(var_side[s])) for s in var_side},'source_ancestry':'source face and vertex indices/topology are unchanged; only rest xyz rows in the local fit support are varied; vertices outside the fit support are kept bitwise equal to source payload xyz.'},'surface_orientation':orientation_report,'method':{'objective':'minimum rest-coordinate step with Euclidean displacement and edge-neighbor smoothness penalties','smoothness_weight':SMOOTHNESS,'target_local_signed_gap_mm':TARGET_GAP_M*1000,'max_cumulative_rest_delta_mm':MAX_DELTA_M*1000,'outer_iteration_cap':MAX_OUTER_ITERATIONS,'wall_time_cap_s':MAX_WALL_SECONDS,'pose_union':['matched neutral','matched elbow=.8 with shoulder=.1'],'hard_exact_acceptance':'matched neutral and active self/outside-skin counts stay zero; neutral own-bone count stays zero; active own-bone count may not increase; penetration-deficit energy must decrease. Exact predicates are rerun before accepting a line-search candidate.','signed_surface_rule':'for each local fit vertex, constrain outward-normal signed distance from nearest same-side humerus, ulna, and radius triangle to at least the declared local target in both poses; outward orientation from source local signed-volume winding; cut-open mesh limits the interpretation to local surface half-spaces.'},'jacobian_check':{'finite_difference_max_abs_error':jac_err,'step_m':test_eps},'iterations':[]}
    report['schema']='numi.human.elbow-rest-coordinate-cutting-plane-036.v1'
    report['status']='running bounded closed-solid cutting-plane attempt'
    report['scope']='Evidence-only local rest-coordinate cutting-plane attempt from unchanged one-third ipsilateral chain weights, 18mm geodesic support, and 5mm tapered cap. Uses exact-weld closed bone solids, winding inside tests, exact intersection points, and barycentric samples. No payload/header/runtime/FEM/source asset is modified; no physical/contact qualification.'
    report['inputs']['solid_witness_classification_report_sha256']=sha(SOLID_REPORT)
    report['inputs']['solid_topology_report_sha256']=sha(SOLID_TOPOLOGY)
    report['inputs']['prior_vertex_only_fit_report_sha256']=sha(RUN/'elbow-rest-coordinate-fit-025.json')
    report['inputs']['prior_vertex_only_fit_script_sha256']=sha(RUN/'fit_elbow_rest_coordinates_025_feasible_positive_margin.py')
    report['solid_shell_build_metadata']=solid_metadata
    report['method']={'objective':'sparse QP minimizes cumulative rest-coordinate displacement plus edge smoothness under linearized exact closed-solid signed-distance cuts; line acceptance uses solid-angle winding, penetration depth, target-gap deficit, and bounded displacement','smoothness_weight':SMOOTHNESS,'target_closed_solid_gap_mm':TARGET_GAP_M*1000.0,'maximum_cumulative_local_rest_displacement_mm':MAX_DELTA_M*1000.0,'support_geodesic_radius_mm':FIT_RADIUS_M*1000.0,'outer_iteration_cap':MAX_OUTER_ITERATIONS,'wall_time_cap_s':MAX_WALL_SECONDS,'pose_union':['matched neutral','matched elbow=.8 with shoulder=.1'],'cut_sources':['fit-support vertices near closed solids','exact skin/bone intersection points in skin barycentrics','winding-inside/near-gap barycentric samples on every crossing face; denominator 32 for retained right-radius face 95142 and 8 otherwise','cuts persist through rejected and accepted line-search trials'],'merit':'inside classification comes from generalized solid-angle winding; merit reports inside count, squared true penetration depth, squared target-gap deficit, and cumulative rest distortion. Active exact pair counts may increase on an intermediate candidate when true depth merit falls.','intermediate_hard_gates':'zero neutral own-bone/self/outside-skin counts; zero active self/outside-skin counts; finite and orientation-preserving posed triangles; original per-vertex tapered 5mm cap. Active own-bone pair counts may evolve during cutting-plane iterations.','final_admission':'all neutral and active own-bone, skin-self, and ROI-vs-fullbody-skin counts zero; finite coordinates; no affected posed triangle degeneracy/orientation reversal; topology/ancestry unchanged; displacement cap respected.'}
    feasibility_path=RUN/'elbow-rest-coordinate-fit-022-feasibility.json'
    report['optimizer_target_basis']={'feasibility_diagnostic_path':str(feasibility_path),'feasibility_diagnostic_sha256':sha(feasibility_path),'infeasible_vertex_source_id':46764,'critical_uniform_gap_target_mm':0.2420997194246896,'selected_uniform_positive_gap_target_mm':TARGET_GAP_M*1000.0,'reason':'The retained 0.25mm-margin attempt was infeasible by 0.00790028mm at one vertex within the unchanged 5mm component bound. This distinct diagnostic run lowers only the optimization target to 0.24mm, above the calculated feasibility threshold; all neutral/active exact collision gates and displacement bounds are unchanged.'}
    report['schema']='numi.human.elbow-rest-coordinate-cutting-plane-036.v1'
    report['status']='running bounded closed-solid cutting-plane attempt'
    report['scope']='Evidence-only local rest-coordinate cutting-plane attempt from the unchanged one-third ipsilateral humerus/radius/ulna chain-weight counterfactual and the unchanged 025 18mm support/5mm tapered construction cap. Uses exact-weld closed bone solids, solid-angle inside classification, exact triangle intersection points, and inside barycentric face samples. No NHSKIN/header/runtime/FEM asset is modified; no physical/contact qualification.'
    report['inputs']['solid_witness_classification_report_sha256']=sha(SOLID_REPORT)
    report['inputs']['solid_topology_report_sha256']=sha(SOLID_TOPOLOGY)
    report['inputs']['prior_vertex_only_fit_report_sha256']=sha(RUN/'elbow-rest-coordinate-fit-025.json')
    report['inputs']['prior_vertex_only_fit_script_sha256']=sha(RUN/'fit_elbow_rest_coordinates_025_feasible_positive_margin.py')
    report['solid_shell_build_metadata']=solid_metadata
    report['method']={'objective':'sparse convex QP minimizes cumulative squared rest-coordinate displacement plus source-edge smoothness subject to linearized true closed-solid signed-distance constraints; line acceptance uses true solid-angle winding, penetration depth, target-gap deficit, and displacement merit','smoothness_weight':SMOOTHNESS,'target_closed_solid_gap_mm':TARGET_GAP_M*1000.0,'maximum_cumulative_local_rest_displacement_mm':MAX_DELTA_M*1000.0,'support_geodesic_radius_mm':FIT_RADIUS_M*1000.0,'outer_iteration_cap':MAX_OUTER_ITERATIONS,'wall_time_cap_s':MAX_WALL_SECONDS,'line_search_alphas':[1.0,0.5,0.25,0.125],'pose_union':['matched neutral','matched elbow=.8 with shoulder=.1'],'cut_sources':['all fit-support vertices with true signed gap within 2.5mm of target','actual exact skin/bone intersection points converted to skin-face barycentrics','true-solid-inside/near-target barycentric samples on every current crossing face; denominator 32 for retained right-radius face 95142, denominator 8 otherwise','all cuts accumulated across rejected and accepted trials'],'merit':'closed-solid winding determines inside state; merit sums squared true penetration depth, target-gap deficits, a small inside-sample count term, and cumulative rest displacement; exact triangle-pair counts may rise on an intermediate candidate if measured true penetration merit falls','intermediate_acceptance':'requires true merit reduction, finite/oriented candidate, unchanged tapered displacement bounds, zero neutral own-bone/self/outside-skin intersections, and zero active self/outside-skin intersections. Active own-bone exact pair counts may rise temporarily; only final all-zero exact own-bone/self/outside gates can emit candidate evidence.','final_admission':'neutral and active exact own-bone, skin-self, and ROI-vs-fullbody-skin intersection counts all zero; finite coordinates; no affected posed skin triangle degeneracy or orientation reversal; unchanged source ancestry/topology; all per-vertex tapered bounds and 5mm maximum respected.'}
    feasibility_path=RUN/'elbow-rest-coordinate-fit-022-feasibility.json'
    report['optimizer_target_basis']={'feasibility_diagnostic_path':str(feasibility_path),'feasibility_diagnostic_sha256':sha(feasibility_path),'infeasible_vertex_source_id':46764,'critical_uniform_gap_target_mm':0.2420997194246896,'selected_target_gap_mm':TARGET_GAP_M*1000.0,'reason':'Retains the previously selected 0.24mm target and the original per-vertex 5mm construction bound; the new run changes the constraint set to true closed-solid witness cuts and does not rerun the old vertex-only optimizer.'}
    write_json(PARTIAL,report)
    cut_bank={}
    pose_data_current,witnesses_current,initial_new=collect_current_cuts(dbase,poses,F,face_region,face_side,var_side,cut_bank,solid_surfaces_by_pose,records,bv,bi,anchors,geo,lbs)
    current_metric=metric_from_current(dbase,pose_data_current,poses,solid_surfaces_by_pose,var_side,cut_bank,F,lbs,current_delta,As)
    report['starting_closed_solid_metric']=metric_summary(current_metric)
    report['starting_cut_bank']={'cut_count':len(cut_bank),'new_cut_count':len(initial_new),'witnesses_by_pose_side':witnesses_current}
    report['initial_exact_counts']={p:exact_gate_flat(pose_data_current[p]['counts']) for p in poses}
    report['affected_source_faces']=np.flatnonzero(np.any(np.isin(F,fit_ids),axis=1)).astype(int).tolist()
    write_json(PARTIAL,report)
    pose_refs={p:lbs.posed(dbase,poses[p]) for p in poses}
    affected_faces=np.flatnonzero(np.any(np.isin(F,fit_ids),axis=1))
    prev_active=exact_gate_flat(pose_data_current[ACTIVE]['counts'])

    # Undirected source-mesh edge regularization; edges to fixed vertices taper
    # the local displacement to exactly zero at the unchanged 18mm support boundary.
    edgevar=[];edgefixed=[]
    for a,b in source_edges:
        ia=int(loc[a]);ib=int(loc[b])
        if ia>=0 and ib>=0:edgevar.append((ia,ib))
        elif ia>=0:edgefixed.append(ia)
        elif ib>=0:edgefixed.append(ib)
    edgevar=np.asarray(edgevar,dtype=np.int64).reshape(-1,2);edgefixed=np.asarray(edgefixed,dtype=np.int64)

    for iteration in range(1,MAX_OUTER_ITERATIONS+1):
        if time.monotonic()-start>MAX_WALL_SECONDS:
            report['status']='stopped at 20-minute wall cap';break
        dcur=dict(dbase);vcur=np.asarray(d0['vertices_f']).copy();vcur[fit_ids,:3]=(source[fit_ids].astype(np.float64)+current_delta[fit_ids]).astype(vcur.dtype);dcur['vertices_f']=vcur
        pose_data_current,witnesses_current,added_now=collect_current_cuts(dcur,poses,F,face_region,face_side,var_side,cut_bank,solid_surfaces_by_pose,records,bv,bi,anchors,geo,lbs)
        current_metric=metric_from_current(dcur,pose_data_current,poses,solid_surfaces_by_pose,var_side,cut_bank,F,lbs,current_delta,As)
        qp_target,solver=sparse_cut_qp(lbs,cut_bank,current_metric['cut_evaluations'],poses,solid_surfaces_by_pose,As,F,loc,fit_ids,current_delta,radius_mm,edgevar,edgefixed)
        item={'outer_iteration':iteration,'starting_cut_bank_size':len(cut_bank),'new_current_cut_count':len(added_now),'current_true_solid_metric':metric_summary(current_metric),'current_exact_counts':{p:exact_gate_flat(pose_data_current[p]['counts']) for p in poses},'current_witnesses_by_pose_side':witnesses_current,'sparse_qp':solver,'accepted':False,'line_search':[]}
        report['iterations'].append(item);write_json(PARTIAL,report)
        if qp_target is None:
            item['failure']='no controllable true closed-solid cut rows';report['status']='stopped: no controllable closed-solid cuts';write_json(PARTIAL,report);break
        if not solver['success']:
            item['failure']='sparse cutting-plane ADMM residual tolerances not met';report['status']='stopped: sparse closed-solid QP residual limit';write_json(PARTIAL,report);break
        proposed_mm=np.asarray(qp_target,dtype=np.float64)
        qp_archive=RUN/f'elbow-rest-coordinate-fit-036-outer-{iteration:02d}-qp-proposal.npz'
        proposed_xyz=(source[fit_ids].astype(np.float64)+proposed_mm/1000.0).astype(np.float32)
        np.savez_compressed(qp_archive,source_vertex_ids=fit_ids.astype(np.uint32),qp_proposed_cumulative_delta_mm=proposed_mm.astype(np.float32),qp_proposed_rest_xyz_f32_m=proposed_xyz)
        item['qp_proposal_archive']={'path':str(qp_archive),'sha256':sha(qp_archive)}
        current_mm=current_delta[fit_ids]*1000.0
        accepted=False
        for trial_index,alpha in enumerate((1.0,0.5,0.25,0.125),start=1):
            candidate_mm=current_mm+float(alpha)*(proposed_mm-current_mm)
            cumulative=np.linalg.norm(candidate_mm,axis=1)
            if np.any(cumulative>radius_mm+1e-5):
                item['line_search'].append({'alpha':alpha,'accepted':False,'reason':'unchanged tapered per-vertex cumulative displacement bound exceeded','max_delta_mm':float(cumulative.max(initial=0))});write_json(PARTIAL,report);continue
            trial_delta=current_delta.copy();trial_delta[fit_ids]=candidate_mm/1000.0
            dtrial=dict(dbase);vt=np.asarray(d0['vertices_f']).copy();vt[fit_ids,:3]=(source[fit_ids].astype(np.float64)+trial_delta[fit_ids]).astype(vt.dtype);dtrial['vertices_f']=vt
            if not np.isfinite(vt).all():
                item['line_search'].append({'alpha':alpha,'accepted':False,'reason':'nonfinite trial rest coordinates'});write_json(PARTIAL,report);continue
            before_keys=set(cut_bank)
            trial_pose_data,trial_witnesses,added_trial=collect_current_cuts(dtrial,poses,F,face_region,face_side,var_side,cut_bank,solid_surfaces_by_pose,records,bv,bi,anchors,geo,lbs)
            # Re-evaluate the current point against the same union of cuts discovered by this trial.
            current_rebased=metric_from_current(dcur,pose_data_current,poses,solid_surfaces_by_pose,var_side,cut_bank,F,lbs,current_delta,As)
            trial_metric=metric_from_current(dtrial,trial_pose_data,poses,solid_surfaces_by_pose,var_side,cut_bank,F,lbs,trial_delta,As)
            newkeys=[str(k) for k in cut_bank if k not in before_keys]
            neutral_exact=exact_gate_flat(trial_pose_data[BASE]['counts']);active_exact=exact_gate_flat(trial_pose_data[ACTIVE]['counts'])
            neutral_hard=all(neutral_exact[s][k]==0 for s in neutral_exact for k in ('skin_self','skin_roi_vs_other_fullbody_skin','skin_roi_vs_humerus_ulna_radius'))
            active_skin_hard=all(active_exact[s]['skin_self']==0 and active_exact[s]['skin_roi_vs_other_fullbody_skin']==0 for s in active_exact)
            orient_ok,orient_summary=posed_orientation_gate(dtrial,poses,pose_refs,F,affected_faces,lbs)
            merit_improved=trial_metric['declared_merit']<current_rebased['declared_merit']-1e-8
            exact_pair_delta={s:active_exact[s]['skin_roi_vs_humerus_ulna_radius']-exact_gate_flat(pose_data_current[ACTIVE]['counts'])[s]['skin_roi_vs_humerus_ulna_radius'] for s in active_exact}
            actual_xyz=vt[fit_ids,:3].astype(np.float32).copy()
            trial_archive=RUN/f'elbow-rest-coordinate-fit-036-outer-{iteration:02d}-alpha-{trial_index:02d}-trial.npz'
            np.savez_compressed(trial_archive,source_vertex_ids=fit_ids.astype(np.uint32),alpha=np.asarray([alpha],dtype=np.float32),trial_cumulative_delta_mm=((actual_xyz.astype(np.float64)-source[fit_ids].astype(np.float64))*1000).astype(np.float32),trial_rest_xyz_f32_m=actual_xyz)
            trial_record={'alpha':alpha,'accepted':False,'trial_archive':{'path':str(trial_archive),'sha256':sha(trial_archive)},'new_cut_count':len(newkeys),'new_cut_keys':newkeys,'added_cut_keys_count_reported_by_collector':len(added_trial),'closed_solid_merit_before_on_union':current_rebased['declared_merit'],'closed_solid_merit_trial':trial_metric['declared_merit'],'merit_improved':bool(merit_improved),'neutral_exact':neutral_exact,'active_exact':active_exact,'active_own_bone_pair_delta':exact_pair_delta,'neutral_hard_gates_pass':bool(neutral_hard),'active_skin_hard_gates_pass':bool(active_skin_hard),'posed_finite_orientation_gate':{'pass':bool(orient_ok),'poses':orient_summary},'max_rest_delta_mm':float(cumulative.max(initial=0)),'witnesses_by_pose_side':trial_witnesses,'rejected_constraints_retained':True}
            exact_hard=neutral_hard and active_skin_hard and orient_ok
            if merit_improved and exact_hard:
                trial_record['accepted']=True;trial_record['acceptance_reason']='true closed-solid winding merit decreased; neutral own-bone/self/outside and active self/outside gates remain zero; active own-bone intersections are allowed to evolve during cutting-plane iterations'
                current_delta=trial_delta;current_metric=trial_metric;pose_data_current=trial_pose_data;witnesses_current=trial_witnesses;prev_active=active_exact;accepted=True
            else:
                trial_record['reason']='merit did not decrease or an unchanged intermediate hard gate failed; cuts and trial coordinates retained'
            item['line_search'].append(trial_record);item['accepted']=bool(accepted);item['accepted_alpha']=alpha if accepted else None;item['cut_bank_size_after_trial']=len(cut_bank)
            write_json(PARTIAL,report)
            print(json.dumps({'outer_iteration':iteration,'alpha':alpha,'accepted':accepted,'new_cuts':len(newkeys),'cut_bank':len(cut_bank),'solid_merit':trial_metric['declared_merit'],'inside_samples':trial_metric['inside_sample_count_including_support_vertices'],'active_exact_bone':{s:active_exact[s]['skin_roi_vs_humerus_ulna_radius'] for s in active_exact}},sort_keys=True),flush=True)
            if accepted:break
            if time.monotonic()-start>MAX_WALL_SECONDS:
                report['status']='stopped at 20-minute wall cap during line search';break
        if report.get('status','').startswith('stopped at 20-minute'):break
        if not accepted:
            report['status']='stopped: no line-search trial improved closed-solid penetration/depth merit while preserving intermediate hard gates';break
        active_now=exact_gate_flat(pose_data_current[ACTIVE]['counts'])
        if all(active_now[s][k]==0 for s in active_now for k in ('skin_self','skin_roi_vs_other_fullbody_skin','skin_roi_vs_humerus_ulna_radius')):
            report['status']='candidate reached active exact gates; final neutral and independent gates still required';break
    else:
        report['status']='reached four-iteration cutting-plane cap'

    # Final independent readback on both matched poses; only emit a candidate if every exact final gate is zero.
    dfinal=dict(dbase);vfinal=np.asarray(d0['vertices_f']).copy();vfinal[fit_ids,:3]=(source[fit_ids].astype(np.float64)+current_delta[fit_ids]).astype(vfinal.dtype);dfinal['vertices_f']=vfinal
    final_pose_data,final_witnesses,final_added=collect_current_cuts(dfinal,poses,F,face_region,face_side,var_side,cut_bank,solid_surfaces_by_pose,records,bv,bi,anchors,geo,lbs)
    final_metric=metric_from_current(dfinal,final_pose_data,poses,solid_surfaces_by_pose,var_side,cut_bank,F,lbs,current_delta,As)
    final_counts={p:exact_gate_flat(final_pose_data[p]['counts']) for p in poses}
    final_orientation_pass,final_orientation=posed_orientation_gate(dfinal,poses,pose_refs,F,affected_faces,lbs)
    rest_finite=bool(np.isfinite(vfinal).all());rest_outside=np.ones(nvertex,dtype=bool);rest_outside[fit_ids]=False
    outside_unchanged=bool(np.array_equal(vfinal[rest_outside],np.asarray(d0['vertices_f'])[rest_outside]))
    cumulative=np.linalg.norm((vfinal[fit_ids,:3].astype(np.float64)-source[fit_ids].astype(np.float64))*1000,axis=1)
    radial_pass=bool(np.all(cumulative<=radius_mm+1e-5) and np.max(cumulative,initial=0)<=MAX_DELTA_M*1000+1e-5)
    final_exact=all(final_counts[p][side][k]==0 for p in poses for side in ('left','right') for k in ('skin_self','skin_roi_vs_other_fullbody_skin','skin_roi_vs_humerus_ulna_radius'))
    final_admission=bool(final_exact and rest_finite and final_orientation_pass and outside_unchanged and radial_pass)
    changed=np.flatnonzero(np.any(vfinal[:,:3]!=np.asarray(d0['vertices_f'])[:,:3],axis=1))
    report['final']={'exact_counts':final_counts,'true_closed_solid_metric':metric_summary(final_metric),'new_final_cut_count':len(final_added),'final_witnesses_by_pose_side':final_witnesses,'changed_rest_vertex_count':int(len(changed)),'changed_rest_vertex_ids':changed.astype(int).tolist(),'maximum_final_rest_delta_mm':float(np.max(cumulative,initial=0)),'all_rest_coordinates_finite':rest_finite,'posed_triangle_orientation_gate':{'pass':final_orientation_pass,'poses':final_orientation},'per_vertex_tapered_5mm_displacement_cap_pass':radial_pass,'rest_geometry_outside_fit_support_bitwise_unchanged':outside_unchanged,'topology_and_source_ancestry_unchanged':True,'all_neutral_active_exact_gates_zero':bool(final_exact),'final_anatomical_admission':final_admission,'accepted_cutting_plane_iteration_count':sum(bool(x.get('accepted')) for x in report['iterations'])}
    report['candidate_emitted']=final_admission
    if final_admission:
        np.savez_compressed(NPZ,weight_patch_vertex_indices=weight_changed.astype(np.uint32),weight_patch_rows=W[weight_changed].astype(np.float32),rest_vertex_indices=fit_ids.astype(np.uint32),rest_xyz_delta_mm=((vfinal[fit_ids,:3].astype(np.float64)-source[fit_ids].astype(np.float64))*1000).astype(np.float32),rest_xyz_candidate_m=vfinal[fit_ids,:3].astype(np.float32))
        report['candidate_evidence_path']=str(NPZ);report['candidate_evidence_sha256']=sha(NPZ);report['status']='matched neutral and active exact anatomical geometry gates passed; evidence-only candidate, not a physical/FEM qualification'
    else:
        report['candidate_evidence_path']=None;report['candidate_evidence_sha256']=None
        if report.get('status','').startswith('running') or report.get('status','').startswith('candidate reached'):
            report['status']='bounded cutting-plane attempt ended without clearing all final exact gates'
    report['assessor_script']=str(Path(__file__).resolve());report['assessor_script_sha256']=sha(Path(__file__).resolve());report['wall_elapsed_seconds']=time.monotonic()-start
    write_json(OUT,report);PARTIAL.unlink(missing_ok=True)
    print('REPORT='+str(OUT),flush=True)

if __name__=='__main__':
    try:main()
    except Exception as exc:
        p=Path('/Users/n/numi-human-aortic-contact-opt-20261019/matter/tools/evidence/human-resting-20261005/supported-continuation-20261020/metal-optimization-080/visual-verification-20261022/wrist-connected-repair-001/joint-region-roi-014/elbow-rest-coordinate-fit-019/elbow-rest-coordinate-fit-036.failure.json')
        write_json(p,{'status':'failed','error_type':type(exc).__name__,'error':str(exc),'script':str(Path(__file__).resolve()),'script_sha256':sha(Path(__file__).resolve()),'wall_timestamp_unix':time.time()})
        raise

#!/usr/bin/env python3
"""Sparse explicit-slack feasibility diagnosis for the retained 036 linearized cuts."""
from __future__ import annotations
import hashlib, importlib.util, json, sys, time
from pathlib import Path
import numpy as np
from scipy.sparse import coo_matrix, csr_matrix, hstack, vstack
from scipy.sparse.csgraph import dijkstra
from scipy.optimize import linprog
RUN=Path("/Users/n/numi-human-aortic-contact-opt-20261019/matter/tools/evidence/human-resting-20261005/supported-continuation-20261020/metal-optimization-080/visual-verification-20261022/wrist-connected-repair-001/joint-region-roi-014/elbow-rest-coordinate-fit-019")
SCRIPT=Path(__file__).resolve()
SOURCE=RUN/"fit_elbow_rest_coordinates_036_closed_solid_cutting_plane.py"
FIT=RUN/"elbow-rest-coordinate-fit-036.json"
OUT=RUN/"elbow-rest-coordinate-fit-036-l1-ball-feasibility.json"
if OUT.exists(): raise SystemExit("refusing overwrite diagnostic")
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
    t0=time.monotonic()
    if not FIT.is_file() or not SOURCE.is_file(): raise FileNotFoundError("036 inputs are missing")
    fr=json.loads(FIT.read_text())
    if fr["status"]!="stopped: sparse closed-solid QP residual limit": raise ValueError("unexpected 036 solver status")
    spec=importlib.util.spec_from_file_location("fit036",SOURCE);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    decode,lbs,geo=m.setup_imports()
    d0=decode(m.PAYLOAD.read_bytes());F=np.asarray(d0["indices"],dtype=np.int64).reshape(-1,3);W0=np.asarray(d0["full_weights"],dtype=np.float32).copy();bind=np.asarray(d0["bindings_u"][:,0],dtype=np.int64);source=np.asarray(d0["vertices_f"][:,:3],dtype=np.float32);nvertex=len(W0)
    manifest=json.loads(geo.MAN.read_text());names={int(x["core_body_index"]):str(x["myosim_body"]).lower() for x in manifest["source"]["anchors"]};slotname=[names[int(x)] for x in bind];slot={n:i for i,n in enumerate(slotname)}
    owner=[slotname[int(i)] for i in np.argmax(W0,axis=1)];vside=np.asarray([geo.side(n) for n in owner]);vreg=np.asarray([geo.skin_region(n) for n in owner]);face_side=np.asarray([geo.majority(vside[t]) for t in F]);face_region=np.asarray([geo.majority(vreg[t]) for t in F])
    weight_report=json.loads(m.WEIGHT_REPORT.read_text());exact_old=json.loads(m.EXACT.read_text());active_pair=exact_old["pose_pairs"]["elbow-shoulder010"]["active"]["sides"]
    legacy_seeds={}
    for side in ("left","right"):
        fsids=set()
        for key in ("skin_self","skin_roi_vs_other_fullbody_skin","skin_roi_vs_nearby_bone"):
            for group in active_pair[side][key].get("witnesses_by_owner_pair",{}).values():
                for w in group:
                    fsids.add(int(w["face_a"]))
                    if key=="skin_self": fsids.add(int(w["face_b"]))
        eligible=np.asarray(sorted(i for i in fsids if 0<=i<len(F) and face_side[i]==side and face_region[i] in ("upper_arm","elbow_forearm")),dtype=np.int64)
        if len(eligible)!=weight_report["seed_counts"][side]["faces"]: raise ValueError("legacy 018 seed map changed")
        legacy_seeds[side]=np.unique(F[eligible].ravel())
    edge=np.concatenate((F[:,[0,1]],F[:,[1,2]],F[:,[2,0]]));edge=np.unique(np.sort(edge,axis=1),axis=0);elen=np.linalg.norm(source[edge[:,0]].astype(float)-source[edge[:,1]].astype(float),axis=1)
    weight_dist={}
    for side in ("left","right"):
        seeds=legacy_seeds[side];rr=np.concatenate((edge[:,0],edge[:,1],np.full(len(seeds),nvertex,dtype=np.int64)));cc=np.concatenate((edge[:,1],edge[:,0],seeds));dd=np.concatenate((elen,elen,np.zeros(len(seeds))));g=coo_matrix((dd,(rr,cc)),shape=(nvertex+1,nvertex+1)).tocsr();weight_dist[side]=dijkstra(g,directed=False,indices=nvertex)[:nvertex]
    chain={side:np.asarray([slot["humerus_"+side[0]],slot["ulna_"+side[0]],slot["radius_"+side[0]]],dtype=np.int64) for side in ("left","right")};W=W0.copy()
    for side in ("left","right"):
        ids=chain[side];dist=weight_dist[side];t=np.clip(dist/m.WEIGHT_RADIUS_M,0.0,1.0);alpha=(1.0/3.0*(1.0-t)**2*(1.0+2.0*t)).astype(np.float32);ch=W0[:,ids];cs=ch.sum(axis=1);off=np.maximum(W0.sum(axis=1)-cs,0.0);select=(dist<m.WEIGHT_RADIUS_M)&(cs>1e-8)
        original=W0[select];new=original*(1.0-alpha[select,None]);new[:,ids]=original[:,ids]+alpha[select,None]*(off[select,None]*ch[select]/cs[select,None]);W[select]=new
    d=dict(d0);d["full_weights"]=W;poses={n:json.loads((m.R/n/"registered-skin-poses.json").read_text()) for n in (m.BASE,m.ACTIVE)};As={p:m.build_A(d,poses[p],lbs) for p in poses}
    var_side={};geom_dist={}
    for side in ("left","right"):
        faces=np.asarray(fr["fit_support"]["direct_active_bone_witness_source_faces"][side],dtype=np.int64);seeds=np.unique(F[faces].ravel());rr=np.concatenate((edge[:,0],edge[:,1],np.full(len(seeds),nvertex,dtype=np.int64)));cc=np.concatenate((edge[:,1],edge[:,0],seeds));dd=np.concatenate((elen,elen,np.zeros(len(seeds))));g=coo_matrix((dd,(rr,cc)),shape=(nvertex+1,nvertex+1)).tocsr();geom_dist[side]=dijkstra(g,directed=False,indices=nvertex)[:nvertex];roi=np.flatnonzero((face_side==side)&np.isin(face_region,["upper_arm","elbow_forearm"]));rv=np.unique(F[roi].ravel());var_side[side]=rv[geom_dist[side][rv]<m.FIT_RADIUS_M]
    fit_ids=np.asarray(sorted(set(var_side["left"].tolist()+var_side["right"].tolist())),dtype=np.int64);loc=np.full(nvertex,-1,dtype=np.int64);loc[fit_ids]=np.arange(len(fit_ids));side_sets={s:set(var_side[s].tolist()) for s in var_side};vd=np.asarray([min(geom_dist[s][i] for s in ("left","right") if i in side_sets[s]) for i in fit_ids]);radii=5.0*np.clip((m.FIT_RADIUS_M-vd)/(m.FIT_RADIUS_M-m.CORE_RADIUS_M),0.0,1.0);radii=np.where(vd<=m.CORE_RADIUS_M,5.0,radii)
    if len(fit_ids)!=fr["fit_support"]["variable_vertex_count"] or {s:len(var_side[s]) for s in var_side}!=fr["fit_support"]["variable_vertex_count_by_side"]: raise ValueError("reconstructed fit support differs from 036")
    info=fr["iterations"][0]["sparse_qp"]["constraint_info"];rows=[];cols=[];vals=[];rhs=[];labels=[];rowids=[]
    for ri,item in enumerate(info):
        accum={};grad=np.asarray(item["gradient_outward"],dtype=np.float64);beta=np.asarray(item["barycentric"],dtype=np.float64);ids=np.asarray(item["vertex_ids"],dtype=np.int64);A=As[item["pose"]]
        for vid,w in zip(ids,beta):
            li=int(loc[int(vid)])
            if li<0 or abs(float(w))<1e-12: continue
            accum[li]=accum.get(li,np.zeros(3,dtype=np.float64))+float(w)*(grad@A[int(vid)])
        if not accum: raise ValueError("saved constraint has no reconstructed variable row")
        for li,vec in accum.items():
            for axis in range(3):
                val=float(vec[axis])
                if val: rows.append(ri);cols.append(3*li+axis);vals.append(val)
        rhs.append(m.TARGET_GAP_M*1000.0-float(item["signed_gap_mm"]))
        labels.append((str(item["pose"]),str(item["side"]),str(item["bone"])));rowids.append(item)
    C=csr_matrix((np.asarray(vals),(np.asarray(rows),np.asarray(cols))),shape=(len(info),3*len(fit_ids)))
    if len(info)!=fr["iterations"][0]["sparse_qp"]["constraint_count"]: raise ValueError("reconstructed row count differs from native QP receipt")
    b=np.asarray(rhs,dtype=np.float64)
    def solve(name,selected,group_kind,bound_mode):
        ids=np.flatnonzero(selected);groups=[labels[i][0] if group_kind=="pose" else labels[i] for i in ids];group_names=sorted(set(groups));gindex=np.asarray([group_names.index(x) for x in groups],dtype=np.int64);S=csr_matrix((np.ones(len(ids)),(np.arange(len(ids)),gindex)),shape=(len(ids),len(group_names)));CC=C[ids];bb=b[ids];Aub=hstack((-CC,-S),format="csr");bub=-bb;ncoord=C.shape[1]
        if bound_mode=="actual_per_vertex_linf": coord_r=np.repeat(radii,3);xbounds=[(-float(x),float(x)) for x in coord_r]
        elif bound_mode=="uniform_5mm_linf": xbounds=[(-5.0,5.0)]*ncoord
        elif bound_mode=="unbounded": xbounds=[(None,None)]*ncoord
        else: raise ValueError(bound_mode)
        res=linprog(np.r_[np.zeros(ncoord),np.ones(len(group_names))],A_ub=Aub,b_ub=bub,bounds=xbounds+[(0.0,None)]*len(group_names),method="highs",options={"time_limit":120.0})
        rec={"name":name,"row_count":int(len(ids)),"variable_vertex_count":int(len(fit_ids)),"grouping":group_kind,"groups":[],"linprog_status":int(res.status),"linprog_message":str(res.message),"success":bool(res.success),"objective_sum_group_slack_mm":float(res.fun) if res.fun is not None else None,"bound_mode":bound_mode,"bound_interpretation":"coordinatewise box is a superset of per-vertex Euclidean-ball feasibility"}
        if res.x is not None and len(res.x)==ncoord+len(group_names):
            x=res.x[:ncoord];sl=res.x[ncoord:];viol=bb-np.asarray(CC@x).ravel();norms=np.linalg.norm(x.reshape(-1,3),axis=1);excess=norms-radii
            rec["coordinate_box_solution_l2"]={"max_vertex_norm_mm":float(norms.max(initial=0)),"max_radius_excess_mm":float(excess.max(initial=0)),"vertices_over_l2_radius":int(np.count_nonzero(excess>1e-7))}
            for j,gname in enumerate(group_names):
                mask=gindex==j;worst=int(np.argmax(viol[mask])) if np.any(mask) else -1;ix=np.flatnonzero(mask);rowix=int(ids[ix[worst]]) if worst>=0 else None
                rec["groups"].append({"group":list(gname) if isinstance(gname,tuple) else str(gname),"uniform_gap_slack_mm":float(sl[j]),"max_unrelaxed_required_gap_mm":float(np.max(bb[mask],initial=-np.inf)),"max_residual_after_solution_mm":float(np.max(viol[mask],initial=-np.inf)),"rows_above_slack_1e-7":int(np.count_nonzero(viol[mask]-sl[j]>1e-7)),"worst_row_index":rowix,"worst_row":rowids[rowix] if rowix is not None else None})
        return rec
    selected=np.ones(len(info),dtype=bool);pose_neutral=np.asarray([x[0]==m.BASE for x in labels]);pose_active=np.asarray([x[0]==m.ACTIVE for x in labels]);outputs=[]
    outputs.append(solve("neutral_only_actual_tapered_box",pose_neutral,"detail","actual_per_vertex_linf"))
    outputs.append(solve("active_only_actual_tapered_box",pose_active,"detail","actual_per_vertex_linf"))
    outputs.append(solve("all_poses_actual_tapered_box_by_pose",selected,"pose","actual_per_vertex_linf"))
    outputs.append(solve("all_poses_actual_tapered_box_by_pose_side_bone",selected,"detail","actual_per_vertex_linf"))
    outputs.append(solve("all_poses_uniform_5mm_box_by_pose",selected,"pose","uniform_5mm_linf"))
    outputs.append(solve("all_poses_unbounded_by_pose",selected,"pose","unbounded"))
    # One conservative L1-ball feasibility LP. Each per-vertex L1 ball is a subset of the accepted L2 ball.
    ncoord=C.shape[1];nv=len(fit_ids);pose_groups=sorted(set(x[0] for x in labels));pose_index=np.asarray([pose_groups.index(x[0]) for x in labels],dtype=np.int64);Sp=csr_matrix((np.ones(len(labels)),(np.arange(len(labels)),pose_index)),shape=(len(labels),len(pose_groups)));zero_n=csr_matrix((len(info),ncoord));zero_v=csr_matrix((nv,nv));Ip=csr_matrix(np.eye(ncoord));Ineg=-Ip;Zgroup=csr_matrix((ncoord,len(pose_groups)))
    Alinear=hstack((-C,zero_n,-Sp),format="csr");blinear=-b
    Aabs1=hstack((Ip,-Ip,Zgroup),format="csr");Aabs2=hstack((Ineg,-Ip,Zgroup),format="csr")
    rr=np.repeat(np.arange(nv,dtype=np.int64),3);cc=np.arange(ncoord,dtype=np.int64);Bsum=csr_matrix((np.ones(ncoord),(rr,cc)),shape=(nv,ncoord));Zvn=csr_matrix((nv,ncoord));Zvg=csr_matrix((nv,len(pose_groups)));Aball=hstack((Zvn,Bsum,Zvg),format="csr");bball=radii
    bounds=[(None,None)]*ncoord+[(0.0,None)]*ncoord+[(0.0,None)]*len(pose_groups);cslack=np.r_[np.zeros(2*ncoord),np.ones(len(pose_groups))]
    Astage1=vstack((Alinear,Aabs1,Aabs2,Aball),format="csr");bstage1=np.r_[blinear,np.zeros(2*ncoord),bball]
    stage1=linprog(cslack,A_ub=Astage1,b_ub=bstage1,bounds=bounds,method="highs",options={"time_limit":120.0})
    l1={"stage1_status":int(stage1.status),"stage1_message":str(stage1.message),"stage1_minimum_group_slack_sum_mm":float(stage1.fun) if stage1.fun is not None else None,"group_names":pose_groups,"constraint_count":int(C.shape[0]),"constraint_nonzeros":int(C.nnz),"bound":"per-vertex L1 ball radius equals existing tapered per-vertex L2 radius; conservative subset"}
    l1_trial=None
    if stage1.success and stage1.x is not None:
        slack_opt=float(stage1.fun);Zsl=csr_matrix((1,2*ncoord));A_slack=hstack((csr_matrix((1,2*ncoord)),csr_matrix(np.ones((1,len(pose_groups))))),format="csr");A_slack=hstack((csr_matrix((1,2*ncoord)),csr_matrix(np.ones((1,len(pose_groups))))),format="csr")
        A2=vstack((Astage1,A_slack),format="csr");b2=np.r_[bstage1,slack_opt+1e-8];c_l1=np.r_[np.zeros(ncoord),np.ones(ncoord),np.zeros(len(pose_groups))]
        final_lp=linprog(c_l1,A_ub=A2,b_ub=b2,bounds=bounds,method="highs",options={"time_limit":120.0})
        l1["stage2_status"]=int(final_lp.status);l1["stage2_message"]=str(final_lp.message);l1["minimum_l1_displacement_mm"]=float(final_lp.fun) if final_lp.fun is not None else None
        if final_lp.success and final_lp.x is not None:
            x=final_lp.x[:ncoord];t=final_lp.x[ncoord:2*ncoord];sl=final_lp.x[2*ncoord:];xv=x.reshape(nv,3);l1n=np.sum(np.abs(xv),axis=1);l2n=np.linalg.norm(xv,axis=1);linear_short=b-np.asarray(C@x).ravel()
            l1["group_slacks_mm"]={pose_groups[j]:float(sl[j]) for j in range(len(pose_groups))};l1["max_l1_radius_excess_mm"]=float(np.max(l1n-radii,initial=0));l1["max_l2_radius_excess_mm"]=float(np.max(l2n-radii,initial=0));l1["vertices_over_l1_radius"]=int(np.count_nonzero(l1n>radii+1e-7));l1["max_linearized_required_slack_mm"]=float(np.max(linear_short-np.asarray([sl[pose_index[i]] for i in range(len(info))]),initial=0));l1["zero_group_slack_pass"]=bool(np.max(sl,initial=0)<=1e-7);l1["l1_ball_pass"]=bool(np.max(l1n-radii,initial=0)<=1e-7)
            trial_path=RUN/"elbow-rest-coordinate-fit-036-l1-ball-linearized-trial.npz";rest_trial=(source[fit_ids].astype(np.float64)+xv/1000.0).astype(np.float32);np.savez_compressed(trial_path,source_vertex_ids=fit_ids.astype(np.uint32),linearized_rest_delta_mm=xv.astype(np.float32),linearized_trial_rest_xyz_f32_m=rest_trial,per_vertex_l1_radius_mm=radii.astype(np.float32),per_vertex_l2_radius_mm=radii.astype(np.float32));l1["linearized_trial_archive"]={"path":str(trial_path),"sha256":sha(trial_path),"status":"diagnostic proposal only; never promoted"}
            if l1["zero_group_slack_pass"] and l1["l1_ball_pass"]:
                dtrial=dict(d);vt=np.asarray(d["vertices_f"]).copy();vt[fit_ids,:3]=rest_trial;dtrial["vertices_f"]=vt;m.lbs=lbs;bone_data=geo.load_bones();_,raw_b,records,bv,bi,anchors=bone_data;exact_pose={};pose_refs={p:lbs.posed(d,poses[p]) for p in poses};affected=np.flatnonzero(np.any(np.isin(F,fit_ids),axis=1))
                for pname in (m.BASE,m.ACTIVE):
                    _,counts,wit=m.geometry_counts(dtrial,poses[pname],F,face_region,face_side,records,bv,bi,anchors,geo);exact_pose[pname]=m.exact_gate_flat(counts)
                orient_ok,orient=m.posed_orientation_gate(dtrial,poses,pose_refs,F,affected,lbs);all_zero=all(exact_pose[p][side][gate]==0 for p in exact_pose for side in ("left","right") for gate in ("skin_self","skin_roi_vs_other_fullbody_skin","skin_roi_vs_humerus_ulna_radius"));l1["exact_geometry_trial"]={"neutral_active_exact_counts":exact_pose,"all_exact_counts_zero":bool(all_zero),"posed_orientation_gate_pass":bool(orient_ok),"posed_orientation":orient,"all_rest_coordinates_finite":bool(np.isfinite(vt).all()),"outside_fit_support_bitwise_unchanged":bool(np.array_equal(vt[np.setdiff1d(np.arange(len(vt)),fit_ids)],np.asarray(d0["vertices_f"])[np.setdiff1d(np.arange(len(vt)),fit_ids)])),"evidence_class":"exact geometry diagnostic only; not mechanical/FEM/physical qualification"}
    # End one L1 diagnostic; the earlier sparse ADMM failure remains unchanged.
    row_max=np.zeros(len(info),dtype=np.float64)
    for r in range(C.shape[0]):
        ix=C.indices[C.indptr[r]:C.indptr[r+1]];vv=C.data[C.indptr[r]:C.indptr[r+1]];byvar={}
        for col,val in zip(ix,vv):
            li=int(col//3);byvar[li]=byvar.get(li,np.zeros(3));byvar[li][int(col%3)]=float(val)
        row_max[r]=sum(float(np.linalg.norm(vec))*float(radii[li]) for li,vec in byvar.items())
    unavoidable=np.maximum(b-row_max,0.0);counts={}
    for gname in sorted(set(labels)):
        ix=np.asarray([i for i,x in enumerate(labels) if x==gname],dtype=np.int64);bad=ix[unavoidable[ix]>1e-7];counts["/".join(gname)]={"row_count":int(len(ix)),"individually_unreachable_rows_with_tapered_l2_balls":int(len(bad)),"max_required_gap_mm":float(np.max(b[ix],initial=-np.inf)),"max_individual_unavoidable_slack_mm":float(np.max(unavoidable[ix],initial=0.0)),"worst_unreachable_rows":[{"row_index":int(i),"required_gap_mm":float(b[i]),"maximum_progress_mm":float(row_max[i]),"unavoidable_slack_mm":float(unavoidable[i]),"cut":rowids[i]} for i in sorted(bad,key=lambda z:-unavoidable[z])[:5]]}
    output={"schema":"numi.human.elbow-rest-coordinate-sparse-feasibility-diagnostic.v1","status":"diagnostic only; no candidate or physical claim","source_report_sha256":sha(FIT),"source_report_script_sha256":fr["assessor_script_sha256"],"diagnostic_script":str(SCRIPT),"diagnostic_script_sha256":sha(SCRIPT),"inputs":{"skin_payload_sha256":m.sha(m.PAYLOAD),"weight_counterfactual_report_sha256":m.sha(m.WEIGHT_REPORT),"matched_pose_snapshot_sha256":fr["inputs"]["pose_snapshot_sha256"],"binary_sha256":fr["inputs"]["binary_sha256"],"rigid_sha256":fr["inputs"]["rigid_sha256"]},"reconstruction":{"variable_vertex_count":int(len(fit_ids)),"variable_vertex_count_by_side":{s:int(len(var_side[s])) for s in var_side},"linear_constraint_count":int(C.shape[0]),"linear_constraint_nonzeros":int(C.nnz),"row_order_matches_036":True,"minimum_tapered_radius_mm":float(radii.min()),"maximum_tapered_radius_mm":float(radii.max()),"maximum_individual_unavoidable_slack_by_group":counts},"scenarios":outputs,"one_conservative_l1_ball_diagnostic":l1,"interpretation":"Each solve minimizes one nonnegative uniform clearance slack per selected group under the saved linearized LBS cuts. Coordinatewise bounds deliberately relax each per-vertex spherical displacement cap; positive slack therefore proves those linearized rows infeasible even in the larger box. A zero slack is only box-feasible, not proof of the tighter ball-constrained nonlinear geometry. Unbounded slack identifies contradictions in the local linearized fixed-LBS map independently of the 5mm cap. Separate neutral and active solves compare per-pose feasibility; combined-pose slack indicates a rest-shape compromise conflict.","wall_elapsed_seconds":time.monotonic()-t0}
    OUT.write_text(json.dumps(output,indent=2,sort_keys=True)+"\n")
    print(json.dumps({"report":str(OUT),"sha256":sha(OUT),"wall_elapsed_seconds":output["wall_elapsed_seconds"],"scenarios":[{"name":x["name"],"status":x["linprog_status"],"objective_slack_mm":x["objective_sum_group_slack_mm"]} for x in outputs]},sort_keys=True),flush=True)
if __name__=="__main__": main()

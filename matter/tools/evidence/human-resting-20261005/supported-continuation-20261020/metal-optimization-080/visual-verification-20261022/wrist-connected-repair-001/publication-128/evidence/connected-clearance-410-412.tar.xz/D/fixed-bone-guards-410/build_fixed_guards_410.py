#!/usr/bin/env python3
"""Refresh construction-only fixed-bone guards for selected 408 coordinates."""
import hashlib,importlib.util,json,sys
from pathlib import Path
import numpy as np
D=Path("/Users/numi/Work/numi-human-connected-surface-069")
C405=D/"D/local-two-parent-retriangulation-405/run-011-replay-405-four-flips/candidate.npz"
A405=D/"D/postfit-backtrack-405-topology-full-audits/run-001/audit-159/report.json"
G407R=D/"D/fixed-bone-guards-407/run-001/report.json"
G407N=G407R.parent/"introduced-skin-bone-barriers.npz"
C408=D/"D/postfit-backtrack-408/run-001/backtrack-373/pass-003/candidate.npz"
A408=D/"D/postfit-backtrack-408/run-001/backtrack-373/pass-003/audit-159/report.json"
P314=D/"publication-113/sources/connected-fixed-boundary-314/emit_introduced_skin_bone_barriers_314.py"
P313=D/"publication-113/sources/connected-fixed-boundary-313/fixed_bone_triangle_rows_313.py"
P401=D/"D/retained-gain-continuation-401/propose_joint_clearance_witnesses_401.py"
P026=D/"publication-101/evidence/204/source/fit/self_separation_026.py"
OUT=D/"D/fixed-bone-guards-410/run-002"
PINS={"c405":"6c115d5beef83989bed2af6309771b8d34cece7e30eaaf3f99f397ee3a304fda",
 "a405":"ec081def995f7fd59050e0c5f9e858b13177f3b53f416a81727c4b0b7c9238f0",
 "g407r":"4804c37a394fea060ba250ffb3ea5a3353d194e787c43a0271253fea93fc6b3c",
 "g407n":"711957268a457a17071fdffbc5bb05344edea6d18b28cba9783c6774628fe9e8",
 "c408":"a661a0ac9ff4690a5e67b1dc06753289b7cf267c188d8b812b929297ae7fecbe",
 "a408":"b498988d21224bdcfd23e47b9330656a0789d14c165d71fc66dd20766f24ccba"}
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def arrsha(a):return hashlib.sha256(np.ascontiguousarray(a).view(np.uint8)).hexdigest()
def mod(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);sys.modules[name]=m;s.loader.exec_module(m);return m
def load(p):
 with np.load(p,allow_pickle=False) as z:return {k:np.asarray(z[k]).copy() for k in z.files}
def audit_set(report):
 j=json.loads(Path(report).read_text());s=set()
 for b in j["banks"]:
  for f,t in ((b.get("result") or {}).get("triangle_pairs") or []):
   s.add((int(b["body"]),int(b["stable_bone_id"]),int(f),int(t)))
 return j,s
def main():
 if OUT.exists():raise FileExistsError(OUT)
 for k,p in (("c405",C405),("a405",A405),("g407r",G407R),("g407n",G407N),("c408",C408),("a408",A408)):
  got=sha(p)
  if got!=PINS[k]:raise ValueError(f"{k} SHA mismatch: {got}")
 old,cur=load(C405),load(C408)
 points=cur["points_world_m"];faces=cur["source_O_faces"]
 if points.dtype!=np.float32 or points.shape!=(20889,3) or faces.shape!=(41733,3):raise ValueError("408 point/face schema mismatch")
 if not np.array_equal(old["source_O_faces"],faces):raise ValueError("408 face-row identity differs from 405; do not carry old guard rows")
 if not np.array_equal(faces,cur["area_reference_037_source_O_faces"]):raise ValueError("408 current faces differ from embedded matched-037 source faces")
 oldr=json.loads(G407R.read_text());oldn=load(G407N)
 phase=mod("phase401_guard410",P401);fit=mod("fit026_guard410",P026);ex=mod("em314_guard410",P314);fx=mod("fx313_guard410",P313)
 source_arrays,source_receipt=phase.validate_fixed_boundary_payload(oldn,oldr,candidate_sha256=PINS["c405"],candidate_points=old["points_world_m"],candidate_faces=old["source_O_faces"],npz_path=G407N)
 oldset=set()
 for f,b,bo,t in zip(oldn["skin_face_rows"],oldn["bank_body"],oldn["stable_bone_id"],oldn["bank_triangle_stable_id"]):
  k=(int(b),int(bo),int(f),int(t))
  if k in oldset:raise ValueError("duplicate historical 407 guard identity")
  oldset.add(k)
 if len(oldset)!=942:raise ValueError(f"expected 942 historical guard pairs, got {len(oldset)}")
 j405,s405=audit_set(A405);j408,s408=audit_set(A408)
 if j405.get("complete") is not True or j405.get("bank_count")!=185 or j405.get("expected_bank_count")!=185 or j405.get("candidate_sha256")!=PINS["c405"]:raise ValueError("405 baseline audit incomplete/mismatched")
 if j408.get("complete") is not True or j408.get("bank_count")!=185 or j408.get("expected_bank_count")!=185 or j408.get("candidate_sha256")!=PINS["c408"]:raise ValueError("408 current audit incomplete/mismatched")
 delta_new=s408-s405;delta_removed=s405-s408
 if len(s405)!=3324 or len(s408)!=3302 or len(delta_new)!=72 or len(delta_removed)!=94:raise ValueError(f"unexpected exact typed-pair delta {len(s405)}/{len(s408)}/{len(delta_new)}/{len(delta_removed)}")
 if len(delta_new-s408)!=0:raise ValueError("introduced typed-pair delta not contained in current audit")
 union=oldset|delta_new;removed=union&s408;kept=union-s408
 if len(kept)!=942:raise ValueError(f"expected 942 feasible historical guards after current-crossing filter, got {len(kept)}")
 bank=mod("bankreader410",ex.BANK_HELPER)
 T,ids,_g,_b,M,off,pos,bkeys,bpins,_=bank.read_bank_inputs(ex.BANK_DIR,ex.BANK_EVIDENCE)
 bank_keys=tuple((int(x[0]),int(x[1])) for x in np.asarray(bkeys))
 if len(bank_keys)!=185 or len(set(bank_keys))!=185:raise ValueError("source bank inventory is not 185 unique typed banks")
 current=ex.validate_audit_report(j408,candidate_sha256=PINS["c408"],point_count=len(points),face_count=len(faces),expected_bank_keys=bank_keys,expected_script_sha256=sha(ex.AUDIT_159),expected_predicate_sha256=sha(ex.EXACT_159))
 if current!=s408:raise ValueError("validated current pair set differs from extracted identity set")
 transforms={int(b):(M[int(b)],off[int(b)],pos[int(b)]) for b in M}
 arrays=ex.make_barrier_arrays(sorted(kept),ex.typed_triangle_lookup(T,ids),transforms)
 order=sorted(range(len(arrays["skin_face_rows"])),key=lambda i:(int(arrays["skin_face_rows"][i]),int(arrays["bank_body"][i]),int(arrays["stable_bone_id"][i]),int(arrays["bank_triangle_stable_id"][i])))
 arrays={k:np.asarray(v)[order].copy() for k,v in arrays.items()}
 records=[{"skin_face_row":int(arrays["skin_face_rows"][i]),"bank_body":int(arrays["bank_body"][i]),"stable_bone_id":int(arrays["stable_bone_id"][i]),"bank_triangle_stable_id":int(arrays["bank_triangle_stable_id"][i]),"fixed_triangle_world_mm":arrays["fixed_triangles_world_mm"][i]} for i in range(len(order))]
 points_mm=points.astype(np.float64)*1000.
 rows,typed=phase.build_fixed_boundary_barriers(points_mm,faces,records,fit,fx,margin_fraction=.25)
 if len(rows)!=6*len(kept) or len(typed)!=len(kept):raise ValueError("313 row count mismatch")
 OUT.mkdir(parents=True,exist_ok=False)
 npz=OUT/"introduced-skin-bone-barriers.npz";np.savez_compressed(npz,**arrays)
 typedlist=[{"skin_face_row":f,"bank_body":b,"stable_bone_id":bo,"bank_triangle_stable_id":t} for b,bo,f,t in sorted(kept)]
 removedlist=[{"skin_face_row":f,"bank_body":b,"stable_bone_id":bo,"bank_triangle_stable_id":t,"source":"historical_guard" if (b,bo,f,t) in oldset else "introduced_408_vs_405","reason":"PRESENT_IN_COMPLETE_CURRENT_408_159_AUDIT"} for b,bo,f,t in sorted(removed)]
 report={"status":"COMPLETE_TYPED_INTRODUCED_SKIN_BONE_BARRIER_EXPORT","schema":"numi.fixed_skin_bone_barriers.v1",
  "filtered_builder_path":str(Path(__file__)),"filtered_builder_sha256":sha(__file__),
  "base_candidate_path":str(C408),"base_candidate_sha256":PINS["c408"],
  "candidate_points_world_m_array_sha256":arrsha(points),"skin_faces_array_sha256":arrsha(faces),
  "candidate_points_world_m_shape":list(points.shape),"skin_faces_shape":list(faces.shape),"point_count":len(points),"face_count":len(faces),
  "bank_count":185,"expected_bank_count":185,"bank_source_pins":bpins,"bank_source_paths":{n:(ex.BANK_DIR/n).as_posix() for n in bpins},
  "exact_predicate_path":str(ex.EXACT_159),"exact_predicate_sha256":sha(ex.EXACT_159),"audit_script_path":str(ex.AUDIT_159),"audit_script_sha256":sha(ex.AUDIT_159),
  "bank_reader_path":str(ex.BANK_HELPER),"bank_reader_sha256":sha(ex.BANK_HELPER),"fixed_triangles_units":"mm","fixed_triangles_frame":"world",
  "output_npz":npz.name,"output_npz_sha256":sha(npz),"introduced_pair_count":len(kept),"typed_pairs":typedlist,"geometry_or_native_admission":False,
  "inputs":[{"role":"base","candidate_path":str(C408),"candidate_sha256":PINS["c408"],"report_path":str(A408),"report_sha256":PINS["a408"],"pair_count":len(s408)},
   {"role":"historical_guard_subset_407","candidate_sha256":PINS["c405"],"report_path":str(G407R),"report_sha256":PINS["g407r"],"npz_path":str(G407N),"npz_sha256":PINS["g407n"],"pair_count":len(oldset)},
   {"role":"baseline_405_surface_set","candidate_path":str(C405),"candidate_sha256":PINS["c405"],"report_path":str(A405),"report_sha256":PINS["a405"],"pair_count":len(s405)}],
  "construction_scope":{"selection_scope":"HISTORICAL_407_GUARDS_UNION_EXACT_408_MINUS_405_TYPED_PAIR_DELTA_MINUS_CURRENT_COMPLETE_408_159",
   "historical_407_guard_pairs":len(oldset),"new_typed_pairs_408_vs_405":len(delta_new),"new_typed_pairs_408_vs_405_in_current_408":len(delta_new&s408),
   "new_typed_pairs_filtered_as_current":len(delta_new&s408),"old_guard_pairs_filtered_as_current":len(oldset&s408),"union_pairs_before_current_filter":len(union),
   "current_408_pairs_removed":len(removed),"filtered_guard_pairs":len(kept),"rows_emitted_by_313":len(rows),"current_408_audit_complete_typed_banks_validated":True,
   "current_408_audit_path":str(A408),"current_408_audit_sha256":PINS["a408"],"baseline_405_pair_count":len(s405),"current_408_pair_count":len(s408),
   "pair_delta_new":len(delta_new),"pair_delta_removed":len(delta_removed),"matched_037_faces_equal":True,"same_405_face_rows_verified":True,
   "interpretation":"Incremental construction guard subset. Complete current 408 159 report remains authoritative; current typed crossings are excluded from zero-feasible guard constraints and absence from this subset does not establish clearance."},
  "new_pairs_408_vs_405":[{"bank_body":b,"stable_bone_id":bo,"skin_face_row":f,"bank_triangle_stable_id":t,"current_crossing":True,"constraint_emitted":False} for b,bo,f,t in sorted(delta_new)],
  "removed_current_408_pairs":removedlist,
  "limitations":["Incremental construction guard subset; complete current 408 159 report remains authoritative.","Absence from this subset does not establish clearance.","No native, physical, or anatomy qualification."]}
 rp=OUT/"report.json";rp.write_text(json.dumps(report,indent=2,sort_keys=True,default=lambda x:x.item() if isinstance(x,np.generic) else str(x))+"\n")
 rec,receipt=phase.validate_fixed_boundary_payload(load(npz),report,candidate_sha256=PINS["c408"],candidate_points=points,candidate_faces=faces,npz_path=npz)
 rebuilt,typed2=phase.build_fixed_boundary_barriers(points_mm,faces,rec,fit,fx,margin_fraction=.25)
 zero=all(float(x["lower"])<=2e-8 for x in rebuilt)
 if not zero or len(rebuilt)!=len(rows) or len(typed2)!=len(typed):raise ValueError("401/313 zero-baseline validation failed")
 vp=OUT/"validation.json"
 vp.write_text(json.dumps({"status":"PASS_401_FIXED_BOUNDARY_PAYLOAD_AND_313_ROW_VALIDATION","candidate_sha256":PINS["c408"],"npz_sha256":sha(npz),"report_sha256":sha(rp),"filtered_guard_pairs":len(rec),"313_rows":len(rebuilt),"all_rows_zero_feasible":zero,"receipt":receipt},indent=2,sort_keys=True)+"\n")
 print(json.dumps({"status":"PASS","npz":str(npz),"npz_sha256":sha(npz),"report":str(rp),"report_sha256":sha(rp),"validation":str(vp),"validation_sha256":sha(vp),"historical_pairs":len(oldset),"new_pairs_408_vs_405":len(delta_new),"new_current_filtered":len(delta_new&s408),"current_pairs":len(s408),"old_guard_removed":len(oldset&s408),"final_pairs":len(rec),"rows":len(rebuilt)},indent=2))
if __name__=="__main__":main()

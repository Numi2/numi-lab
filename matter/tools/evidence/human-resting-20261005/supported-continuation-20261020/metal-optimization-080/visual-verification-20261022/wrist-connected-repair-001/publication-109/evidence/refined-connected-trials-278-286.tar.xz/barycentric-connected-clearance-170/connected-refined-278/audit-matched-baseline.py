from pathlib import Path
import subprocess,json,time,hashlib
D=Path('/Users/numi/Work/numi-human-connected-surface-069');H=D/'barycentric-connected-clearance-170';o=H/'connected-refined-278';py='/Users/n/numi-human-prep-venv-20261005/bin/python'
for script,out in [('audit_connected_outer_geometry_130.py','audit-130'),('audit_skin_bone_surfaces_159.py','audit-159')]:
 cmd=[py,'/tmp/numi-human-geometry-slot.py',py,str(D/script),str(o/'candidate.npz'),str(o/out)]
 if out=='audit-159':cmd+=['--max-seconds','600']
 t=time.monotonic()
 with (o/(out+'.log')).open('x') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 (o/(out+'.execution.json')).write_text(json.dumps(dict(command=cmd,returncode=r.returncode,wall_seconds=time.monotonic()-t),indent=2))
 assert r.returncode==0
 if out=='audit-130':
  j=json.loads((o/'audit-130/summary.json').read_text());assert j['complete_surface_audit'] and j['exact_PLC_surface_pairs']==0
base=json.loads((H/'outward-surface-resume-264/selected-result.json').read_text())
state=dict(candidate=str(o/'candidate.npz'),point_summary=str(o/'audit-130/summary.json'),surface_report=str(o/'audit-159/report.json'),parent_fit=base['parent_fit'],status='MATCHED_REFINED_BASELINE_ONLY_NOT_PROGRESS',geometry_admitted=False,accepted_physical_steps=0)
(o/'baseline-state.json').write_text(json.dumps(state,indent=2))

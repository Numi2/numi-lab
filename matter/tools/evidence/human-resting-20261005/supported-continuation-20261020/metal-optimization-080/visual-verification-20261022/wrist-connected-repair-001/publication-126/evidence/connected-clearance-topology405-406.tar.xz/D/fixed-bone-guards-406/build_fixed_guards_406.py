#!/usr/bin/env python3
from __future__ import annotations
import hashlib, importlib.util, json, sys
from pathlib import Path
import numpy as np
D=Path('/Users/n/Work/numi-human-connected-surface-069')
C394=D/'barycentric-connected-clearance-170/combined-clearance-394/run-001/candidate.npz'
OLD_REPORT=D/'D/fixed-bone-guards-394/run-003/report.json'
OLD_NPZ=OLD_REPORT.parent/'introduced-skin-bone-barriers.npz'
C403=D/'D/postfit-backtrack-403/run-001/backtrack-373/pass-002/candidate.npz'
R403=D/'D/postfit-backtrack-403/run-001/backtrack-373/pass-002/audit-159/report.json'
C404=D/'D/postfit-backtrack-404/run-002/backtrack-373/pass-003/candidate.npz'
P404=D/'D/postfit-backtrack-404/run-002/backtrack-373/pass-003/audit-159/report.json'
P405_3=D/'D/postfit-backtrack-405/run-001/backtrack-373/pass-003'
C405_3=P405_3/'candidate.npz'; R405_3=P405_3/'audit-159/report.json'
P405_4=D/'D/postfit-backtrack-405/run-001/backtrack-373/pass-004'
C405_4=P405_4/'candidate.npz'; R405_4=P405_4/'audit-159/report.json'
P364=D/'D/connected-remesh-reuse-364/remap_legacy_face_constraints_364.py'
P314=D/'publication-113/sources/connected-fixed-boundary-314/emit_introduced_skin_bone_barriers_314.py'
P313=D/'publication-113/sources/connected-fixed-boundary-313/fixed_bone_triangle_rows_313.py'
P401=D/'D/retained-gain-continuation-401/propose_joint_clearance_witnesses_401.py'
P026=D/'barycentric-connected-clearance-170/connected-local-continuation-189-run001/round-005/proposal/round-001/fit/self_separation_026.py'
OUT=D/'D/fixed-bone-guards-406/run-003'
EXPECTED={
 'c394':'251b7e0a8c39d2e1e3ef57b2654bf4912cfb3e62bc9cc38fb9ee4d7a9a52e8c3',
 'oldreport':'0c97d66fa7b251097dcc4b2e0ba3a7cb2d64c0481bc0e28260447a1ca3264b1a',
 'oldnpz':'9888d3113a120a3de3f666f46e3c67d56993c483a77bd6407cc0ed8410098bed',
 'c403':'442f80600304c9474794aa034f4efe8418c15cfe1256ee364c11ac586853ca98',
 'r403':'60d23546bb945e36d1f30475575f75763ffd33ab26b9bfb832c4ac1e70c1618a',
 'c404':'b41c56ac6ec2a99f7e1f2c6a02db10cf61b6cd04730f7a6bcdea65e224f80e52',
 'r404':'b3567831166e8fc4ccb9abf1a41ff6568fe62d66560f3002d47073aa2bb45e76',
 'c405_3':'1d5d617f5fa75cbad176a7dbd971877740b26c5226f2813bef847e075a35ecf8',
 'r405_3':'3859c61a1a61d41c81070e08658ca0a40f5c5a6d6eb784c5152be1e7e54607c9',
 'c405_4':'93217e36ee488479623590cc59e5c3450903e765bc4bff3a4557d0e0ca2b60a1',
 'r405_4':'7aafaca6b6e35543ca383b86f6fe22117024a97fd902974b776d87adbca2be9e',
}
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''): h.update(b)
 return h.hexdigest()
def arrsha(a):return hashlib.sha256(np.ascontiguousarray(a).view(np.uint8)).hexdigest()
def loadmod(name,path):
 spec=importlib.util.spec_from_file_location(name,path)
 if spec is None or spec.loader is None: raise ImportError(path)
 m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
def readnpz(path):
 with np.load(path,allow_pickle=False) as z:return {k:np.asarray(z[k]).copy() for k in z.files}
def json_default(v):
 if isinstance(v,np.generic):return v.item()
 if isinstance(v,Path):return v.as_posix()
 raise TypeError(type(v).__name__)
def report_pairs(report):
 out=set()
 for b in report['banks']:
  r=b.get('result')
  if r is None:continue
  for p in r.get('triangle_pairs',[]):out.add((int(b['body']),int(b['stable_bone_id']),int(p[0]),int(p[1])))
 return out
def main():
 pins={'c394':C394,'oldreport':OLD_REPORT,'oldnpz':OLD_NPZ,'c403':C403,'r403':R403,'c404':C404,'r404':P404,'c405_3':C405_3,'r405_3':R405_3,'c405_4':C405_4,'r405_4':R405_4}
 for k,p in pins.items():
  got=sha(p)
  if got!=EXPECTED[k]:raise ValueError(f'{k} SHA mismatch: {got}')
 if OUT.exists():raise FileExistsError(OUT)
 remap=loadmod('remap_364_406',P364); ex=loadmod('emit_314_406',P314); fx=loadmod('fixed_owner_313_406',P313); fit=loadmod('fit_owner_026_406',P026); phase=loadmod('phase_one_401_406',P401)
 c394=readnpz(C394); cur=readnpz(C404)
 if set(c394)!=set(cur):raise ValueError('394/404 array inventory mismatch')
 changed=[k for k in sorted(cur) if c394[k].shape!=cur[k].shape or c394[k].dtype!=cur[k].dtype or np.ascontiguousarray(c394[k]).tobytes()!=np.ascontiguousarray(cur[k]).tobytes()]
 if changed!=['points_world_m']:raise ValueError(f'404 changed unexpected arrays relative to 394: {changed}')
 points=np.asarray(cur['points_world_m']); faces=np.asarray(cur['source_O_faces'])
 if points.dtype!=np.float32 or points.shape!=(20889,3) or faces.shape!=(41733,3) or not np.array_equal(faces,cur['area_reference_037_source_O_faces']):raise ValueError('invalid 404 points/topology/matched-037 faces')
 for label,cp in (('405_pass003',C405_3),('405_pass004',C405_4)):
  d=readnpz(cp)
  diff=[k for k in sorted(cur) if cur[k].shape!=d[k].shape or cur[k].dtype!=d[k].dtype or np.ascontiguousarray(cur[k]).tobytes()!=np.ascontiguousarray(d[k]).tobytes()]
  if diff!=['points_world_m']:raise ValueError(f'{label} not same 404 topology/ancestry: changed arrays={diff}')
 oldreport=json.loads(OLD_REPORT.read_text()); olda=readnpz(OLD_NPZ)
 if oldreport.get('output_npz_sha256')!=sha(OLD_NPZ):raise ValueError('394 guard report does not pin payload')
 phase.validate_fixed_boundary_payload(olda,oldreport,candidate_sha256=sha(C394),candidate_points=c394['points_world_m'],candidate_faces=c394['source_O_faces'],npz_path=OLD_NPZ)
 histn=len(olda['skin_face_rows'])
 histset={(int(b),int(bo),int(f),int(t)) for f,b,bo,t in zip(olda['skin_face_rows'],olda['bank_body'],olda['stable_bone_id'],olda['bank_triangle_stable_id'])}
 if len(histset)!=histn:raise ValueError('duplicate historical guard identities')
 changedfaces=np.flatnonzero(np.any(c394['source_O_faces']!=faces,axis=1)).astype(np.int64)
 meta=remap._metadata_changed(c394,cur,len(faces))
 ident=remap.filter_constraint_rows(c394['source_O_faces'],c394['source_O_faces'],faces,changedfaces,np.empty((0,2),np.int64),olda['skin_face_rows'],meta)
 keep=np.asarray(ident['retained_bone_mask'],bool)
 if len(changedfaces)!=0 or len(meta)!=0 or not keep.all():raise ValueError('historical guard source identity is unsafe on 404')
 bh=loadmod('bank_helper_314_406',ex.BANK_HELPER)
 T,ids,_g,_b,M,off,pos,bankkeys,pins_evidence,_unused=bh.read_bank_inputs(ex.BANK_DIR,ex.BANK_EVIDENCE)
 expected_keys=tuple((int(x[0]),int(x[1])) for x in np.asarray(bankkeys))
 if len(expected_keys)!=185 or len(set(expected_keys))!=185:raise ValueError('expected 185 unique banks')
 aud404=json.loads(P404.read_text()); current=ex.validate_audit_report(aud404,candidate_sha256=EXPECTED['c404'],point_count=len(points),face_count=len(faces),expected_bank_keys=expected_keys,expected_script_sha256=sha(ex.AUDIT_159),expected_predicate_sha256=sha(ex.EXACT_159))
 aud403=json.loads(R403.read_text()); base403=ex.validate_audit_report(aud403,candidate_sha256=EXPECTED['c403'],point_count=len(points),face_count=len(faces),expected_bank_keys=expected_keys,expected_script_sha256=sha(ex.AUDIT_159),expected_predicate_sha256=sha(ex.EXACT_159))
 audits=[]; pairsets=[]
 for cp,rp,kcand,kr in ((C405_3,R405_3,'c405_3','r405_3'),(C405_4,R405_4,'c405_4','r405_4')):
  a=json.loads(rp.read_text())
  ps=ex.validate_audit_report(a,candidate_sha256=EXPECTED[kcand],point_count=len(points),face_count=len(faces),expected_bank_keys=expected_keys,expected_script_sha256=sha(ex.AUDIT_159),expected_predicate_sha256=sha(ex.EXACT_159))
  if len(ps)!=sum(int((x.get('result') or {}).get('count',0)) for x in a['banks']):raise ValueError(f'{rp} report count does not match typed pairs')
  audits.append(a);pairsets.append(ps)
 if len(current)!=3332 or len(base403)!=3338 or len(pairsets[0])!=3343 or len(pairsets[1])!=3339:raise ValueError('unexpected complete 159 pair counts')
 new3=pairsets[0]-base403; new4=pairsets[1]-base403; new_union=new3|new4
 if len(new3)!=29 or len(new4)!=14 or len(new_union)!=29:raise ValueError(f'unexpected 405 introduced pair counts: {len(new3)}/{len(new4)}/{len(new_union)}')
 origins={k:['historical_394_guard'] for k in histset}
 for k in sorted(new3):origins.setdefault(k,[]).append('introduced_405_pass003_vs_403')
 for k in sorted(new4):origins.setdefault(k,[]).append('introduced_405_pass004_vs_403')
 if histset & new_union:raise ValueError('405 new pair duplicated historical guard unexpectedly')
 full_union=set(origins)
 omitted=full_union & current
 retained=full_union-current
 if len(histset & current)!=0 or len(new_union & current)!=7 or len(omitted)!=7 or len(retained)!=963:raise ValueError(f'404 subtraction counts changed: hist={len(histset&current)} new={len(new_union&current)} omitted={len(omitted)} retained={len(retained)}')
 lookup=ex.typed_triangle_lookup(T,ids)
 transforms={int(b):(M[int(b)],off[int(b)],pos[int(b)]) for b in M}
 arrays=ex.make_barrier_arrays(sorted(retained),lookup,transforms)
 order=sorted(range(len(arrays['skin_face_rows'])),key=lambda i:(int(arrays['skin_face_rows'][i]),int(arrays['bank_body'][i]),int(arrays['stable_bone_id'][i]),int(arrays['bank_triangle_stable_id'][i])))
 arrays={k:np.asarray(v)[order].copy() for k,v in arrays.items()}
 records=[]
 for i in range(len(order)):
  records.append({'skin_face_row':int(arrays['skin_face_rows'][i]),'bank_body':int(arrays['bank_body'][i]),'stable_bone_id':int(arrays['stable_bone_id'][i]),'bank_triangle_stable_id':int(arrays['bank_triangle_stable_id'][i]),'fixed_triangle_world_mm':arrays['fixed_triangles_world_mm'][i]})
 pointsmm=points.astype(np.float64)*1000.
 rows,typed=phase.build_fixed_boundary_barriers(pointsmm,faces,records,fit,fx,margin_fraction=.25)
 if len(typed)!=len(retained) or len(rows)!=len(retained)*6:raise ValueError('313 row build count mismatch')
 OUT.mkdir(parents=True,exist_ok=False)
 npz=OUT/'introduced-skin-bone-barriers.npz';np.savez_compressed(npz,**arrays)
 final_typed=[{'skin_face_row':f,'bank_body':b,'stable_bone_id':bo,'bank_triangle_stable_id':t} for b,bo,f,t in sorted(retained)]
 pair_prov=[{'skin_face_row':k[2],'bank_body':k[0],'stable_bone_id':k[1],'bank_triangle_stable_id':k[3],'origins':origins[k]} for k in sorted(retained)]
 omissions=[{'skin_face_row':k[2],'bank_body':k[0],'stable_bone_id':k[1],'bank_triangle_stable_id':k[3],'origins':origins[k],'reason':'PRESENT_IN_COMPLETE_404_159_AUDIT'} for k in sorted(omitted)]
 new_pairs=[{'skin_face_row':k[2],'bank_body':k[0],'stable_bone_id':k[1],'bank_triangle_stable_id':k[3],'in_pass003':k in new3,'in_pass004':k in new4,'present_in_404':k in current} for k in sorted(new_union)]
 report={
  'status':'COMPLETE_TYPED_INTRODUCED_SKIN_BONE_BARRIER_EXPORT','schema':'numi.fixed_skin_bone_barriers.v1',
  'filtered_builder_path':str(Path(__file__)),'filtered_builder_sha256':sha(__file__),
  'base_candidate_path':str(C404),'base_candidate_sha256':sha(C404),'candidate_points_world_m_array_sha256':arrsha(points),'skin_faces_array_sha256':arrsha(faces),
  'point_count':len(points),'face_count':len(faces),'candidate_points_world_m_shape':list(points.shape),'skin_faces_shape':list(faces.shape),
  'bank_count':185,'expected_bank_count':185,'audit_script_path':str(ex.AUDIT_159),'audit_script_sha256':sha(ex.AUDIT_159),
  'exact_predicate_path':str(ex.EXACT_159),'exact_predicate_sha256':sha(ex.EXACT_159),'bank_reader_path':str(ex.BANK_HELPER),'bank_reader_sha256':sha(ex.BANK_HELPER),
  'bank_source_pins':pins_evidence,'bank_source_paths':{n:(ex.BANK_DIR/n).as_posix() for n in pins_evidence},
  'introduced_pair_count':len(retained),'typed_pairs':final_typed,'fixed_triangles_units':'mm','fixed_triangles_frame':'world',
  'fixed_triangle_transform':'Pinned raw bank triangles transformed to world-frame millimetres in Float64 using owner 314; construction-only fixed geometry.',
  'inputs':[
    {'role':'historical_guard_base_394','report_path':str(OLD_REPORT),'report_sha256':sha(OLD_REPORT),'npz_path':str(OLD_NPZ),'npz_sha256':sha(OLD_NPZ),'candidate_path':str(C394),'candidate_sha256':sha(C394),'pair_count':histn},
    {'role':'introduced_pair_baseline_403','report_path':str(R403),'report_sha256':sha(R403),'candidate_path':str(C403),'candidate_sha256':sha(C403),'pair_count':len(base403)},
    {'role':'base','report_path':str(P404),'report_sha256':sha(P404),'candidate_path':str(C404),'candidate_sha256':sha(C404),'pair_count':len(current)},
    {'role':'405_pass003_complete_audit','report_path':str(R405_3),'report_sha256':sha(R405_3),'candidate_path':str(C405_3),'candidate_sha256':sha(C405_3),'pair_count':len(pairsets[0]),'introduced_vs_403':len(new3)},
    {'role':'405_pass004_complete_audit','report_path':str(R405_4),'report_sha256':sha(R405_4),'candidate_path':str(C405_4),'candidate_sha256':sha(C405_4),'pair_count':len(pairsets[1]),'introduced_vs_403':len(new4)},
  ],
  'new_405_pair_union_count_vs_403':len(new_union),'new_405_pairs':new_pairs,
  'removed_current_404_pairs':omissions,
  'pair_provenance':pair_prov,
  'output_npz':npz.name,'output_npz_sha256':sha(npz),'geometry_or_native_admission':False,
  'construction_scope':{
   'selection_scope':'UNION_394_HISTORICAL_GUARDS_AND_405_PASS003_PASS004_NEW_TYPED_PAIRS_VS_403_MINUS_COMPLETE_CURRENT_404_159_PAIRS',
   'historical_pair_count':histn,'historical_pairs_preserved_before_current_subtraction':len(histset),
   'historical_pairs_removed_because_current_404_159':len(histset & current),
   '405_pass003_pair_count':len(pairsets[0]),'405_pass003_introduced_vs_403':len(new3),
   '405_pass004_pair_count':len(pairsets[1]),'405_pass004_introduced_vs_403':len(new4),
   '405_introduced_union_vs_403':len(new_union),'405_union_pairs_present_in_current_404':len(new_union & current),
   'removed_current_404_pair_count':len(omitted),'filtered_guard_pair_count':len(retained),'rows_emitted_by_313':len(rows),
   'current_404_159_pair_count':len(current),'current_404_159_complete_typed_banks_validated':True,
   'current_404_159_audit_path':str(P404),'current_404_159_audit_sha256':sha(P404),
   'current_403_159_audit_path':str(R403),'current_403_159_audit_sha256':sha(R403),
   'identity_source_candidate_path':str(C394),'identity_source_candidate_sha256':sha(C394),
   'source_topology_parity':{'394_to_404_changed_arrays':['points_world_m'],'405_pass003_vs_404_changed_arrays':['points_world_m'],'405_pass004_vs_404_changed_arrays':['points_world_m'],'face_count':len(faces),'connectivity_and_all_noncoordinate_ancestry_byte_identical':True},
   'is_complete_current_159_pair_set':False,
   'interpretation':'Construction guard subset only. All 941 validated historical guards are retained unless their typed identity occurs in the complete current 404 audit. Added pairs are the union of exact 405 pass-003/pass-004 identities absent from complete 403; 404-current identities are omitted and listed individually. This is not a complete current 159 set; absence is not evidence of clearance.',
   'filter_owner_path':str(P364),'filter_owner_sha256':sha(P364),'filter_method':'Exact face-row connectivity and row-aligned ancestry identity; no nearest-row or geometric remapping.',
   'rebuild_owner_314_path':str(P314),'rebuild_owner_314_sha256':sha(P314),'fixed_row_owner_313_path':str(P313),'fixed_row_owner_313_sha256':sha(P313),
   'pair_owner_026_path':str(P026),'pair_owner_026_sha256':sha(P026),'barrier_margin_fraction':.25,
   'historical_payload_validated_against_394':True,'all_rows_built_at_candidate_404_coordinates':True},
  'limitations':['This pair set is an incremental construction guard subset, not a complete current 159 audit.','The complete 404 159 audit remains authoritative; missing guard pairs do not establish clearance.','All fixed-bone guard rows are construction-only; no native, physical, or anatomy qualification.']}
 report['source_array_parity']={'394_candidate_sha256':sha(C394),'404_candidate_sha256':sha(C404),'array_count':len(cur),'byte_identical_noncoordinate_arrays':len(cur)-1,'only_changed_array':'points_world_m','source_O_faces_bitwise_identical':True,'face_node_ancestry_bitwise_identical':True}
 rp=OUT/'report.json';rp.write_text(json.dumps(report,indent=2,sort_keys=True,default=json_default)+'\n')
 loaded=readnpz(npz)
 records2,receipt=phase.validate_fixed_boundary_payload(loaded,report,candidate_sha256=sha(C404),candidate_points=points,candidate_faces=faces,npz_path=npz)
 rebuilt,typed2=phase.build_fixed_boundary_barriers(pointsmm,faces,records2,fit,fx,margin_fraction=.25)
 zero=all(float(r['lower'])<=2e-8 for r in rebuilt)
 if not zero or len(rebuilt)!=len(rows) or len(typed2)!=len(typed):raise ValueError('401/313 validation or zero-feasible row roundtrip failed')
 validation={'status':'PASS_401_FIXED_BOUNDARY_PAYLOAD_AND_313_ROW_VALIDATION','candidate_sha256':sha(C404),'npz_sha256':sha(npz),'report_sha256':sha(rp),'filtered_guard_pairs':len(records2),'313_rows':len(rebuilt),'all_rows_zero_feasible':zero,'receipt':receipt}
 vp=OUT/'validation.json';vp.write_text(json.dumps(validation,indent=2,sort_keys=True,default=json_default)+'\n')
 print(json.dumps({'status':'PASS','candidate_sha256':sha(C404),'npz_path':str(npz),'npz_sha256':sha(npz),'report_path':str(rp),'report_sha256':sha(rp),'validation_path':str(vp),'validation_sha256':sha(vp),'historical':len(histset),'new405_union':len(new_union),'removed_current404':len(omitted),'final_pairs':len(records2),'rows':len(rebuilt),'current404_pairs':len(current),'pass003_new':len(new3),'pass004_new':len(new4)},indent=2))
if __name__=='__main__':main()

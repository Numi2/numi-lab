#!/usr/bin/env python3
"""Replay 405 exact edge operations on a candidate with the same face-row preconditions."""
from __future__ import annotations
import argparse,hashlib,json,sys
from pathlib import Path
import numpy as np
import cross_seam_search_405 as m

def sha_file(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return h.hexdigest()

def replay(candidate,manifest,outdir):
 cp=Path(candidate);mp=Path(manifest);od=Path(outdir)
 if od.exists():raise FileExistsError(od)
 od.mkdir(parents=True)
 with np.load(cp,allow_pickle=False) as z:base={k:z[k] for k in z.files}
 b=m.load_mod('two_parent_patch_flips_402',m.OWNER402); b.validate_candidate(base)
 cfg=json.loads(mp.read_text())
 if len(base['points_world_m'])!=int(cfg['expected_point_count']) or len(base['source_O_faces'])!=int(cfg['expected_face_count']):raise ValueError('candidate topology size mismatch')
 out={k:np.array(v,copy=True) for k,v in base.items()}
 locks,outer,between,_=m.boundary_locks(out,m.detail_csr(out,{9570,9577,10226}),{9570,9577,10226})
 ops=[]
 for item in cfg['operations']:
  edge=tuple(map(int,item['edge']));fr=list(map(int,item['face_rows']))
  if not np.array_equal(out['source_O_faces'][fr],np.asarray(item['expected_old_faces'],dtype=out['source_O_faces'].dtype)):raise ValueError(f'old face precondition failed for {edge}')
  em=b.edge_map(out['source_O_faces']);inc=em.get(edge,[])
  if sorted(int(x[0]) for x in inc)!=sorted(fr):raise ValueError(f'incident edge precondition failed for {edge}')
  locks,_,_,_=m.boundary_locks(out,m.detail_csr(out,{9570,9577,10226}),{9570,9577,10226})
  op,why=m.propose_one(out,edge,inc,locks)
  if op is None:raise ValueError(f'current/reference/material guard rejected {edge}: {why}')
  if op['face_rows']!=fr or op['new_faces']!=item['new_faces']:raise ValueError(f'operation topology changed for {edge}')
  out=m.apply_op(out,op)
  ops.append({**op,'expected_old_faces':item['expected_old_faces']})
 locks2,outer2,between2,_=m.boundary_locks(out,m.detail_csr(out,{9570,9577,10226}),{9570,9577,10226})
 if outer2!=outer or between2!=between:raise RuntimeError('replay changed fixed patch boundary')
 if not b.array_identical(base['points_world_m'],out['points_world_m']):raise RuntimeError('coordinates changed')
 if not np.array_equal(out['source_O_faces'],out['area_reference_037_source_O_faces']):raise RuntimeError('matched-037 faces mismatch')
 em=b.edge_map(out['source_O_faces'])
 if any(len(v)>2 for v in em.values()):raise RuntimeError('nonmanifold edge')
 if len({tuple(sorted(map(int,t))) for t in out['source_O_faces']})!=len(out['source_O_faces']):raise RuntimeError('duplicate face')
 # Positive changed faces in both frames, and orientational agreement with matched reference.
 rows=sorted({int(r) for op in ops for r in op['face_rows']})
 for r in rows:
  nc,ac=b.normal_area(out['points_world_m'],out['source_O_faces'][r]);nr,ar=b.normal_area(out['area_reference_037_points_world_m_f64'],out['source_O_faces'][r])
  if ac<=0 or ar<=0 or float(np.dot(nc,nr))<=0:raise RuntimeError(f'changed face {r} fails positive/current-037 orientation')
 sys.path.insert(0,str(m.HERE.parent/'local-two-parent-retriangulation-402'))
 search=m.load_mod('exact_local_flip_search_402',m.SEARCH402);search.PRED=m.PRED
 exact=search.exact_owner()
 per_group={}
 for g in (0,1):
  _,_,br,bp=m.audit_group(exact,base,g);_,scope,rr,rp=m.audit_group(exact,out,g)
  per_group[str(g)]={'baseline_pair_count':len(bp),'baseline_pairs':bp.tolist(),'candidate_pair_count':len(rp),'candidate_pairs':rp.tolist(),'scope_face_count':len(scope),'selected_face_count':int(rr.get('selected_face_count',-1)),'complete_surface_face_count':int(rr.get('complete_surface_face_count',-1))}
 dest=od/'candidate.npz';np.savez_compressed(dest,**out)
 all_zero=all(x['candidate_pair_count']==0 for x in per_group.values())
 report={'status':'CROSS_SEAM_REPLAY_LOCAL_EXACT_PASS' if all_zero else 'CROSS_SEAM_REPLAY_LOCAL_EXACT_NONZERO',
         'geometry_admitted':False,'accepted_physical_steps':0,'candidate_input_path':str(cp),'candidate_input_sha256':sha_file(cp),
         'candidate_output_path':str(dest),'candidate_output_sha256':sha_file(dest),'manifest_path':str(mp),'manifest_sha256':sha_file(mp),
         'replay_script_sha256':sha_file(Path(__file__)),'search_owner_sha256':sha_file(m.__file__),'patch_owner_sha256':sha_file(m.OWNER402),
         'predicate_owner_sha256':sha_file(m.PRED),'operations':ops,'local_exact_by_group':per_group,'local_exact_pass':all_zero,
         'points_bitwise_unchanged':b.array_identical(base['points_world_m'],out['points_world_m']),
         'matched_037_faces_synchronized':bool(np.array_equal(out['source_O_faces'],out['area_reference_037_source_O_faces'])),
         'fixed_outer_edges_preserved':outer==outer2,'fixed_between_group_boundaries_preserved':between==between2,
         'fixed_outer_edge_count':len(outer),'fixed_between_group_boundary_count':len(between),'changed_face_rows':rows,
         'changed_face_detail_union':{str(r):m.detail_csr(out,{9570,9577,10226})[r] for r in rows},
         'changed_face_parent_union':{str(r):m.csr_rows(out['refinement_face_parent_ancestry_indptr'],out['refinement_face_parent_ancestry_face_rows'],len(out['source_O_faces']))[r] for r in rows},
         'scope_limit':'Exact self predicate covers each selected source patch and vertex one-ring only; no whole-surface or bone audit.'}
 (od/'report.json').write_text(json.dumps(report,indent=2,sort_keys=True,allow_nan=False)+'\n')
 return report

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--candidate',required=True);ap.add_argument('--manifest',required=True);ap.add_argument('--output-dir',required=True)
 a=ap.parse_args();r=replay(a.candidate,a.manifest,a.output_dir);print(json.dumps({k:v for k,v in r.items() if k not in ('operations','changed_face_detail_union','changed_face_parent_union','local_exact_by_group')},indent=2))
if __name__=='__main__':main()

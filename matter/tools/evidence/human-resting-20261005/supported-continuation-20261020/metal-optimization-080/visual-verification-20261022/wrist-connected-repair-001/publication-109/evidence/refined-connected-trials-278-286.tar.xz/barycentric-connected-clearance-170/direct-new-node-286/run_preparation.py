from pathlib import Path
import numpy as np,json,hashlib
from scipy import sparse
D=Path('/Users/numi/Work/numi-human-connected-surface-069');H=D/'barycentric-connected-clearance-170';o=H/'direct-new-node-286'
c=H/'connected-refined-278/candidate.npz';target=H/'connected-refined-278/point-targets/nearest-union-exits.npz'
z=np.load(c);t=np.load(target);X=z['points_world_m'];F=z['source_O_faces'];rows=t['query_rows']
assert (rows>=18430).all()and t['pass_mask'].all()and len(rows)==len(np.unique(rows))
d=t['target_world_f32_m'].astype(float)-X[rows];lens=np.linalg.norm(d,axis=1);d*=np.minimum(1.,.001/lens)[:,None]
Y=X.copy();Y[rows]=(X[rows].astype(float)+d).astype(np.float32)
assert np.array_equal(X[:18430].view(np.uint32),Y[:18430].view(np.uint32))
cross=lambda p:np.cross(p[F[:,1]].astype(float)-p[F[:,0]],p[F[:,2]].astype(float)-p[F[:,0]])
cx=cross(X);cy=cross(Y);cr=cross(z['area_reference_037_points_world_m_f64'])
oriented=np.einsum('ij,ij->i',cy,cx)/np.einsum('ij,ij->i',cx,cx)
mag=np.linalg.norm(cy,axis=1)/np.linalg.norm(cr,axis=1)
P=sparse.eye(len(X),format='csr');b=np.load(D/'full-connected-clearance-150/run-009-certified-source-normal-union-rays/endpoint-candidate.npz')['points_before_joint_self_pair_repair_m'];prefixes=('','prior_input_006__','prior_run028__')
for i,pre in enumerate(prefixes):
 nc=len(z[prefixes[i+1]+'source_prolongation_indptr'])-1 if i<2 else len(b);P=P@sparse.csr_matrix((z[pre+'source_prolongation_weights'],z[pre+'source_prolongation_node_rows'],z[pre+'source_prolongation_indptr']),shape=(P.shape[1],nc))
R0=P@b;bad=np.flatnonzero((oriented<.1)|(mag<.1));cap=np.linalg.norm(Y.astype(float)-R0,axis=1)
np.savez_compressed(o/'trial.npz',**{**{k:z[k]for k in z.files},'points_world_m':Y})
j=dict(status='CHEAP_PREPARATION_PASS'if not len(bad)and cap.max()<=.012002 else'CHEAP_PREPARATION_FAILED',candidate_sha256=hashlib.sha256(c.read_bytes()).hexdigest(),targets_sha256=hashlib.sha256(target.read_bytes()).hexdigest(),bad_area_faces=len(bad),minimum_oriented_area_ratio=float(oriented.min()),minimum_fixed037_area_magnitude_ratio=float(mag.min()),maximum_source_displacement_mm=float(cap.max()*1000),fixed_prefix_unchanged=True,native_admission=False,accepted_physical_steps=0)
(o/'result.json').write_text(json.dumps(j,indent=2));print(json.dumps(j))

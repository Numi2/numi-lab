#ifndef METALROBO_MRNX_BRIDGE_V1_H
#define METALROBO_MRNX_BRIDGE_V1_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#if defined(_WIN32)
#  if defined(METALROBO_BUILDING_LIBRARY)
#    define MRNX_BRIDGE_EXPORT __declspec(dllexport)
#  else
#    define MRNX_BRIDGE_EXPORT __declspec(dllimport)
#  endif
#else
#  define MRNX_BRIDGE_EXPORT __attribute__((visibility("default")))
#endif

#if defined(_MSC_VER)
#  define MRNX_ALIGN16 __declspec(align(16))
#else
#  define MRNX_ALIGN16 __attribute__((aligned(16)))
#endif

#ifdef __cplusplus
extern "C" {
#endif

#define MRNX_BRIDGE_ABI_V1 1u
#define MRNX_OWNER_WIRE_ABI_V4 4u
#define MRNX_FULL_BODY_NQ 129u
#define MRNX_FULL_BODY_NV 128u
#define MRNX_FULL_BODY_MUSCLE_COUNT 416u
#define MRNX_BRAIN_MOTOR_CANDIDATE_VERSION_V1 7u
#define MRNX_BRAIN_MOTOR_CANDIDATE_VERSION_V2 8u
#define MRNX_BRAIN_MOTOR_CANDIDATE_VALID_V1 (1u << 0u)
#define MRNX_BRAIN_MOTOR_CANDIDATE_DECISION_SHADOW_V1 (1u << 1u)
#define MRNX_BRAIN_MOTOR_READY_ABI_VERSION_V1 1u
#define MRNX_BRAIN_MOTOR_READY_ABI_VERSION_V2 2u
#define MRNX_BRAIN_MOTOR_READY_GATE_SUCCESS_V2 1u
#define MRNX_BRAIN_MOTOR_READY_GATE_BYTES_V1 160u
#define MRNX_BRAIN_JOINT_TRANSACTION_VERSION_V2 2u
#define MRNX_BRAIN_MOTOR_OUTPUT_VERSION_V2 4u
#define MRNX_BRAIN_MOTOR_OUTPUT_VALID_V2 (1u << 0u)
#define MRNX_PHYSICAL_CLOCK_DOMAIN_EXACT_NANOSECONDS 2u
#define MRNX_EXACT_CLOCK_QUANTUM_NANOSECONDS 1u
#define MRNX_RUNTIME_CONFIG_ABI_V2 2u
#define MRNX_RUNTIME_CONFIG_ABI_V3 3u
#define MRNX_RUNTIME_CONFIG_ABI_V4 4u
#define MRNX_RUNTIME_CONFIG_ABI_V5 5u
#define MRNX_RUNTIME_CONFIG_ABI_V6 6u
#define MRNX_RUNTIME_CONFIG_ABI_V7 7u
#define MRNX_RUNTIME_CONFIG_ABI_V8 8u
#define MRNX_PHYSICAL_ROOT_REQUEST_ABI_V2 2u
#define MRNX_PHYSICAL_ROOT_REQUEST_ABI_V3 3u
// Retained for source compatibility with the former admission-only v3 lane.
// Executable request-v3 does not return this retired boundary stage.
#define MRNX_REQUEST_FAILURE_STAGE_EXACT_OUTBOUND_UNAVAILABLE 900u
#define MRNX_REQUEST_FAILURE_STAGE_LEGACY_EXACT_V2_UNROUTABLE 901u
#define MRNX_EXACT_CLOCK_INFO_ABI_V1 1u
#define MRNX_AGGREGATE_SNAPSHOT_ABI_V4 4u
#define MRNX_AGGREGATE_SNAPSHOT_ABI_V5 5u
#define MRNX_CANDIDATE_CHANNEL_ABI_V2 2u
#define MRNX_CANDIDATE_TIMING_ABI_V2 2u
#define MRNX_EXACT_INBOUND_AUTHORITY_ABI_V2 2u
#define MRNX_EXACT_SENSOR_PACKET_ABI_V2 2u
#define MRNX_PUBLICATION_ABI_V2 2u
#define MRNX_FINGERPRINT_DOMAIN_EXACT_INBOUND_AUTHORITY_V2 0x4e584941u
#define MRNX_FINGERPRINT_DOMAIN_EXACT_SENSOR_CHANNEL_V2 0x4e584348u
#define MRNX_FINGERPRINT_DOMAIN_EXACT_SENSOR_CHANNEL_SET_V2 0x4e584353u
#define MRNX_FINGERPRINT_DOMAIN_EXACT_SENSOR_TIMING_V2 0x4e58544du
#define MRNX_FINGERPRINT_DOMAIN_EXACT_SENSOR_PACKET_V2 0x4e585350u
#define MRNX_FINGERPRINT_DOMAIN_EXACT_PUBLICATION_V2 0x4e585050u
#define MRNX_CULTURE_ACCEPTED_VIEW_ABI_V1 1u
#define MRNX_CULTURE_PREPARED_VIEW_ABI_V1 1u
#define MRNX_CULTURE_ACCEPTED_BUFFER_COUNT_V1 11u

typedef struct mrnx_runtime_v1 mrnx_runtime_v1;
typedef struct mrnx_prepared_v1 mrnx_prepared_v1;
typedef struct mrnx_candidate_v1 mrnx_candidate_v1;

typedef enum mrnx_element_type_v1 {
    MRNX_ELEMENT_RAW_BYTES_V1 = 0u,
    MRNX_ELEMENT_FLOAT32_V1 = 1u,
    MRNX_ELEMENT_UINT32_V1 = 2u,
    // Typed declarations used by request-v3 admission and execution. They
    // prevent a legacy raw-byte motor header/gate lease from claiming the exact
    // family before the asynchronous GPU producer has made the contents
    // readable.
    MRNX_ELEMENT_BRAIN_MOTOR_OUTPUT_HEADER_V2 = 3u,
    MRNX_ELEMENT_BRAIN_MOTOR_READY_GATE_V2 = 4u,
} mrnx_element_type_v1;

typedef enum mrnx_completion_status_v1 {
    MRNX_COMPLETION_READY_V1 = 1u,
    MRNX_COMPLETION_ACCEPTED_PENDING_PUBLICATION_V1 = 2u,
    MRNX_COMPLETION_REJECTED_RELEASED_V1 = 3u,
    MRNX_COMPLETION_TERMINAL_NO_TOUCH_V1 = 4u,
    MRNX_COMPLETION_COMMAND_BUFFER_FAILURE_V1 = 5u,
    MRNX_COMPLETION_TIMEOUT_QUARANTINED_V1 = 6u,
} mrnx_completion_status_v1;

typedef enum mrnx_publication_disposition_v1 {
    MRNX_PUBLICATION_RELEASED_V1 = 1u,
    MRNX_PUBLICATION_REJECTED_V1 = 2u,
    MRNX_PUBLICATION_TERMINAL_NO_TOUCH_V1 = 3u,
} mrnx_publication_disposition_v1;

// Canonical disposition of the completed owner apply command. These values
// intentionally differ from mrnx_completion_status_v1 and match the Brain
// joint-resolution SPI exactly.
typedef enum mrnx_command_disposition_v1 {
    MRNX_COMMAND_ACCEPTED_PENDING_PUBLICATION_V1 = 1u,
    MRNX_COMMAND_REJECTED_RELEASED_V1 = 2u,
    MRNX_COMMAND_TERMINAL_NO_TOUCH_V1 = 3u,
} mrnx_command_disposition_v1;

typedef struct mrnx_root_v1 {
    uint32_t abi_version;
    uint32_t struct_size;
    uint32_t owner_wire_abi_version;
    uint32_t environment_count;
    uint32_t environment;
    uint32_t transaction_slot;
    uint32_t step_index;
    uint32_t control_step;
    uint32_t substep_index;
    uint32_t physics_substep_count;
    uint32_t q_coordinate_count;
    uint32_t dof_count;
    uint32_t dof_layout_version;
    uint32_t reserved0;
    uint64_t program_fingerprint;
    uint64_t transaction_fingerprint;
    uint64_t linearization_epoch;
    uint64_t slot_generation;
    uint64_t device_registry_id;
} mrnx_root_v1;

typedef struct mrnx_metal_range_v1 {
    uint32_t abi_version;
    uint32_t struct_size;
    void* metal_buffer;
    uint64_t gpu_address;
    uint64_t byte_offset;
    uint64_t byte_count;
    uint32_t element_type;
    uint32_t element_byte_count;
} mrnx_metal_range_v1;

// Every metal_buffer/shared_event descriptor is borrowed at +0. It remains
// valid only while the corresponding opaque candidate/prepared handle is
// retained AND its phase-specific copy API still succeeds. All descriptor
// authority expires on terminal or resolved state even if a scalar opaque
// reference remains alive. Callback descriptors expire when the callback
// returns unless the receiver retains that opaque handle and copies the
// fixed-width descriptor before terminal settlement.

typedef struct mrnx_event_point_v1 {
    uint32_t abi_version;
    uint32_t struct_size;
    void* shared_event;
    uint64_t value;
    uint64_t device_registry_id;
} mrnx_event_point_v1;

typedef struct mrnx_candidate_key_v1 {
    uint32_t abi_version;
    uint32_t struct_size;
    uint64_t transaction_fingerprint;
    uint64_t program_fingerprint;
    uint64_t sensor_fingerprint;
    uint64_t transaction_instance_fingerprint;
    uint64_t sensor_generation;
    uint64_t command_buffer_identity;
    uint64_t fingerprint;
} mrnx_candidate_key_v1;

typedef struct mrnx_candidate_view_v1 {
    uint32_t abi_version;
    uint32_t struct_size;
    mrnx_candidate_key_v1 key;
    uint64_t accepted_brain_generation;
    uint64_t candidate_publication_fingerprint;
    uint64_t candidate_identity_fingerprint;
    uint64_t device_registry_id;
    uint32_t channel_count;
    uint32_t reserved0;
} mrnx_candidate_view_v1;

#define MRNX_CANDIDATE_CHANNEL_HAS_VALIDITY_V1 (1u << 0u)
// Direct parity with NumiBrain SensoryModality raw values.
#define MRNX_CANDIDATE_MODALITY_VISION_V1 1u
#define MRNX_CANDIDATE_MODALITY_AUDITION_V1 2u
#define MRNX_CANDIDATE_MODALITY_TOUCH_V1 3u
// Direct parity with NumiBrain SensoryModality.proprioception.
#define MRNX_CANDIDATE_MODALITY_PROPRIOCEPTION_V1 4u
#define MRNX_CANDIDATE_MODALITY_VESTIBULAR_V1 5u
// Direct parity with NumiBrain SensoryModality.interoception.
#define MRNX_CANDIDATE_MODALITY_INTEROCEPTION_V1 8u
#define MRNX_CANDIDATE_MODALITY_KINESTHESIA_V1 9u
#define MRNX_AGGREGATE_SNAPSHOT_ABI_V2 2u
#define MRNX_AGGREGATE_SNAPSHOT_ABI_V3 3u
#define MRNX_MAX_SENSOR_CHANNELS_V2 8u

typedef struct mrnx_candidate_channel_v1 {
    uint32_t abi_version;
    uint32_t struct_size;
    uint32_t modality;
    uint32_t flags;
    uint64_t receptor_timestamp_microseconds;
    uint32_t receptor_count;
    uint32_t feature_dimension;
    mrnx_metal_range_v1 values;
    mrnx_metal_range_v1 validity;
} mrnx_candidate_channel_v1;

// Exact-clock successor to the public sensor-channel descriptor. It is
// additive: v1 keeps its immutable microsecond word and layout. The timestamp,
// domain, and quantum travel together so a nanosecond value can never be
// admitted through the legacy record by convention alone.
typedef struct mrnx_candidate_channel_v2 {
    uint32_t abi_version;
    uint32_t struct_size;
    uint32_t modality;
    uint32_t flags;
    uint64_t receptor_timestamp_nanoseconds;
    uint32_t clock_domain;
    uint32_t clock_quantum_nanoseconds;
    uint32_t receptor_count;
    uint32_t feature_dimension;
    mrnx_metal_range_v1 values;
    mrnx_metal_range_v1 validity;
    uint64_t channel_fingerprint;
} mrnx_candidate_channel_v2;

typedef struct mrnx_candidate_timing_v1 {
    uint32_t abi_version;
    uint32_t struct_size;
    uint64_t capture_timestamp_microseconds;
    uint64_t delivery_timestamp_microseconds;
    uint32_t latency_microseconds;
    uint32_t sample_interval_microseconds;
    uint64_t timing_fingerprint;
} mrnx_candidate_timing_v1;

// Exact sensor timing is never projected through a 32-bit microsecond latency.
// timing_fingerprint is the domain-separated FNV identity of every preceding
// field and therefore binds the explicit clock as well as the four durations.
typedef struct mrnx_candidate_timing_v2 {
    uint32_t abi_version;
    uint32_t struct_size;
    uint64_t capture_timestamp_nanoseconds;
    uint64_t delivery_timestamp_nanoseconds;
    uint64_t latency_nanoseconds;
    uint64_t sample_interval_nanoseconds;
    uint32_t clock_domain;
    uint32_t clock_quantum_nanoseconds;
    uint64_t timing_fingerprint;
} mrnx_candidate_timing_v2;

// Canonical, pointer-free receipt for the validated Brain authority that drove
// one physical candidate. Accepted Brain time/generation and the
// candidate/output/profile identify the motor payload; the ready gate plus all
// three Brain program identities close the asynchronous producer chain. Exact
// physical proof and sensor publication both bind this terminal fingerprint so
// stale motor authority cannot be republished or relabeled.
typedef struct mrnx_exact_inbound_authority_v2 {
    uint32_t abi_version;
    uint32_t struct_size;
    uint32_t clock_domain;
    uint32_t clock_quantum_nanoseconds;
    uint64_t accepted_brain_timestamp_nanoseconds;
    uint64_t brain_generation;
    uint64_t transaction_fingerprint;
    uint64_t substep_fingerprint;
    uint64_t motor_candidate_fingerprint;
    uint64_t motor_output_fingerprint;
    uint64_t motor_profile_fingerprint;
    uint64_t motor_ready_gate_fingerprint;
    uint64_t brain_program_fingerprint;
    uint64_t fast_program_fingerprint;
    uint64_t decision_gate_fingerprint;
    uint64_t inbound_authority_fingerprint;
} mrnx_exact_inbound_authority_v2;

// Canonical exact sensor-publication envelope. Channel fingerprints are folded
// in strictly increasing modality order into channel_set_fingerprint. The
// terminal candidate_publication_fingerprint thereby binds the v2 root and
// substep, accepted physics token, HumanIO identity, timing, and all channel
// descriptors, including the process-local borrowed Metal-buffer identities.
typedef struct mrnx_exact_sensor_packet_v2 {
    uint32_t abi_version;
    uint32_t struct_size;
    uint32_t clock_domain;
    uint32_t clock_quantum_nanoseconds;
    uint32_t channel_count;
    uint32_t channel_capacity;
    uint64_t transaction_fingerprint;
    uint64_t substep_fingerprint;
    uint64_t accepted_physics_token_fingerprint;
    uint64_t inbound_authority_fingerprint;
    uint64_t human_io_program_fingerprint;
    uint64_t sensor_fingerprint;
    uint64_t transaction_instance_fingerprint;
    uint64_t sensor_generation;
    uint64_t accepted_brain_generation;
    uint64_t device_registry_id;
    uint64_t timing_fingerprint;
    uint64_t channel_set_fingerprint;
    uint64_t candidate_publication_fingerprint;
} mrnx_exact_sensor_packet_v2;

typedef struct mrnx_wire_lease_v1 {
    uint32_t abi_version;
    uint32_t struct_size;
    mrnx_root_v1 root;
    mrnx_metal_range_v1 record;
    mrnx_event_point_v1 ready;
} mrnx_wire_lease_v1;

typedef struct mrnx_proposal_view_v1 {
    uint32_t abi_version;
    uint32_t struct_size;
    mrnx_root_v1 root;
    mrnx_metal_range_v1 proposal;
    mrnx_metal_range_v1 proposed_token;
    mrnx_metal_range_v1 publication_fence;
    mrnx_event_point_v1 ready;
} mrnx_proposal_view_v1;

typedef struct mrnx_applied_view_v1 {
    uint32_t abi_version;
    uint32_t struct_size;
    mrnx_root_v1 root;
    mrnx_metal_range_v1 applied;
    mrnx_metal_range_v1 final_token;
    mrnx_event_point_v1 ready;
    // One mrnx_command_disposition_v1 value.
    uint32_t command_disposition;
    uint32_t reserved0;
} mrnx_applied_view_v1;

typedef struct mrnx_completion_v1 {
    uint32_t abi_version;
    uint32_t struct_size;
    uint32_t status;
    uint32_t metal_status;
    uint64_t slot_generation;
} mrnx_completion_v1;

typedef struct mrnx_publication_v1 {
    uint32_t abi_version;
    uint32_t struct_size;
    uint64_t joint_commit_fingerprint;
    uint64_t brain_generation;
} mrnx_publication_v1;

// Exact joint-publication authority. The accepted physics token and HumanIO
// candidate remain private until this complete record is reserved and released
// under the sole public-reader writer gate. An executable request-v3 root must
// use this record; it may not reinterpret mrnx_publication_v1.
typedef struct mrnx_publication_v2 {
    uint32_t abi_version;
    uint32_t struct_size;
    uint32_t clock_domain;
    uint32_t clock_quantum_nanoseconds;
    uint64_t transaction_fingerprint;
    uint64_t accepted_physics_token_fingerprint;
    uint64_t candidate_publication_fingerprint;
    uint64_t joint_commit_fingerprint;
    uint64_t brain_generation;
    uint64_t committed_timestamp_nanoseconds;
    uint64_t publication_fingerprint;
} mrnx_publication_v2;

typedef enum mrnx_runtime_status_v1 {
    MRNX_RUNTIME_READY_V1 = 1u,
    MRNX_RUNTIME_INVALID_CONFIGURATION_V1 = 2u,
    MRNX_RUNTIME_ASSET_FAILURE_V1 = 3u,
    MRNX_RUNTIME_METAL_FAILURE_V1 = 4u,
    MRNX_RUNTIME_MATTER_FAILURE_V1 = 5u,
    MRNX_RUNTIME_BUSY_V1 = 6u,
    MRNX_RUNTIME_INVALID_REQUEST_V1 = 7u,
    MRNX_RUNTIME_SUBMISSION_FAILURE_V1 = 8u,
    MRNX_RUNTIME_TERMINAL_QUARANTINE_V1 = 9u,
    MRNX_RUNTIME_CONTINUATION_UNAVAILABLE_V1 = 10u,
} mrnx_runtime_status_v1;

// Trusted, process-local runtime construction. All strings are copied before
// create returns. The configured device and every subsequently imported Metal
// object must identify the same Apple GPU. The first production revision is
// deliberately exact: one 129-q/128-DoF floating Human, 416 MyoSim muscles,
// one environment, one physical substep, and one attached non-adaptive Matter
// world. Runtime-owned generations and transaction slots are never supplied
// by the caller.
typedef struct mrnx_runtime_config_v1 {
    uint32_t abi_version;
    uint32_t struct_size;
    void* metal_device;
    const char* rigid_payload_path;
    const char* muscle_payload_path;
    const char* support_contact_payload_path;
    const char* visual_pack_path;
    const char* vision_profile_path;
    const char* metalrobo_metallib_path;
    const char* matter_metallib_path;
    const char* matter_material_path;
    uint64_t timestep_microseconds;
    uint64_t maximum_retained_bytes;
    uint32_t transaction_slot_count;
    uint32_t reserved0;
} mrnx_runtime_config_v1;

// Additive runtime configuration. The v1 prefix is byte-for-byte unchanged;
// culture is enabled only when culture_pack_path is non-null and nonempty.
// checkpoint and protocol paths are optional, but may not be supplied without
// a culture pack. All strings are copied before create returns.
typedef struct mrnx_runtime_config_v2 {
    uint32_t abi_version;
    uint32_t struct_size;
    void* metal_device;
    const char* rigid_payload_path;
    const char* muscle_payload_path;
    const char* support_contact_payload_path;
    const char* visual_pack_path;
    const char* vision_profile_path;
    const char* metalrobo_metallib_path;
    const char* matter_metallib_path;
    const char* matter_material_path;
    uint64_t timestep_microseconds;
    uint64_t maximum_retained_bytes;
    uint32_t transaction_slot_count;
    uint32_t reserved0;
    const char* culture_pack_path;
    const char* culture_checkpoint_path;
    const char* culture_protocol_path;
    uint32_t culture_window_ticks;
    float culture_current_per_newton;
} mrnx_runtime_config_v2;

// Authored-world construction uses the existing cooked Matter package format.
// The nested v2 configuration retains its own v2 header; matter_material_path
// must be null. There is no fallback to the legacy attached-tet fixture.
// Both expected identities are mandatory trusted-process compatibility keys,
// not cryptographic provenance. Human identity covers NHRIGID/NHMYO/NHCNT;
// Matter identity covers the exact validated cooked world, including capacity.
// Initial attachment frames, timestep and gravity must agree with Human.
// This adds no joint-equality, adaptive-topology or active-muscle replacement
// authority; unsupported world modes fail before runtime allocation.
typedef struct mrnx_runtime_config_v3 {
    uint32_t abi_version;
    uint32_t struct_size;
    mrnx_runtime_config_v2 runtime;
    const char* matter_world_package_path;
    uint64_t expected_model_source_fingerprint;
    uint64_t expected_matter_world_fingerprint;
} mrnx_runtime_config_v3;

// Authored-world plus source joint compliance. Both nested headers remain
// explicit. The equality fingerprint is FNV-1a64 of the immutable NHEQ2 bytes.
// Nested v3 Human identity remains the base NHRIGID/NHMYO/NHCNT identity for
// world admission; returned runtime Human identity also binds NHEQ2.
typedef struct mrnx_runtime_config_v4 {
    uint32_t abi_version;
    uint32_t struct_size;
    mrnx_runtime_config_v3 runtime;
    const char* joint_equality_payload_path;
    uint64_t expected_joint_equality_fingerprint;
} mrnx_runtime_config_v4;

// Mass-conserving costal tissue on the same authored-world/equality runtime.
// The Matter package contains attachments in residual COM frames. NHTBIND1
// binds exact NHCART1/NHRIGID2 bytes and the common registration. Its FNV-1a64
// identity also binds the returned Human fingerprint. Construction rebases
// source sites, wraps, contacts and sensing before persistent allocation.
typedef struct mrnx_runtime_config_v5 {
    uint32_t abi_version;
    uint32_t struct_size;
    mrnx_runtime_config_v4 runtime;
    const char* costal_cartilage_payload_path;
    const char* costal_binding_payload_path;
    uint64_t expected_costal_binding_fingerprint;
} mrnx_runtime_config_v5;

// NHLIM1 scalar source limits on the same NHEQ2 authored-world solver.
// Limits are mandatory. Costal mass ownership is optional as one complete
// group; its three fields must all be absent or all be present. Construction
// admits the base world, then folds NHEQ2, NHLIM1 and optional NHTMASS1 into
// Human identity. No state projection or separate limit solver is installed.
typedef struct mrnx_runtime_config_v6 {
    uint32_t abi_version;
    uint32_t struct_size;
    mrnx_runtime_config_v4 runtime;
    const char* joint_limit_payload_path;
    uint64_t expected_joint_limit_fingerprint;
    const char* costal_cartilage_payload_path;
    const char* costal_binding_payload_path;
    uint64_t expected_costal_binding_fingerprint;
} mrnx_runtime_config_v6;

// Explicit construction-only NHINIT1/2/3 state. Requires the complete v6
// source physics and authored world. NHINIT3 is additionally bound to the
// already loaded exact NHCNT payload and seeds Matter's accepted support-
// history owner. Native admission binds the prepared state into Human identity;
// it never changes source rest coordinates or installs a runtime reset or
// recruitment path. No equilibrium claim is implied by admission.
typedef struct mrnx_runtime_config_v7 {
    uint32_t abi_version;
    uint32_t struct_size;
    mrnx_runtime_config_v6 runtime;
    const char* initial_state_payload_path;
    uint64_t expected_initial_state_fingerprint;
} mrnx_runtime_config_v7;

// Exact-clock construction extends the complete v7 prepared-state contract.
// The nested legacy microsecond word must be zero; timestep_nanoseconds is the
// sole clock authority and must be a positive value representable by the
// native transaction timeline. v1-v7 construction and request entry points
// remain unchanged and continue to use integer microseconds.
typedef struct mrnx_runtime_config_v8 {
    uint32_t abi_version;
    uint32_t struct_size;
    mrnx_runtime_config_v7 runtime;
    uint64_t timestep_nanoseconds;
} mrnx_runtime_config_v8;

typedef struct mrnx_exact_clock_info_v1 {
    uint32_t abi_version;
    uint32_t struct_size;
    uint64_t timestep_nanoseconds;
    uint64_t clock_quantum_nanoseconds;
    uint64_t published_timestamp_nanoseconds;
    uint64_t publication_epoch;
} mrnx_exact_clock_info_v1;

// Immutable construction metadata. Legacy v1/v2 worlds are explicitly marked
// as fixtures; successfully loading an authored package is not calibration.
typedef struct mrnx_runtime_world_info_v1 {
    uint32_t abi_version;
    uint32_t struct_size;
    uint32_t authored_package;
    uint32_t object_count;
    uint32_t fem_node_count;
    uint32_t fem_attachment_count;
    uint64_t world_fingerprint;
    uint64_t physics_fingerprint;
} mrnx_runtime_world_info_v1;

typedef struct mrnx_runtime_info_v1 {
    uint32_t abi_version;
    uint32_t struct_size;
    uint32_t status;
    uint32_t body_count;
    uint32_t q_coordinate_count;
    uint32_t dof_count;
    uint32_t muscle_count;
    uint32_t transaction_slot_count;
    uint32_t request_failure_stage;
    uint32_t resident_continuation_count;
    uint64_t device_registry_id;
    // Family-selected Matter proof producer: legacy runtimes report the v1
    // program and exact-clock v8 runtimes report the distinct V2 program.
    uint64_t accepted_state_proof_program_fingerprint;
    // Domain-separated identity of the exact immutable NHRIGID2, NHMYO, and
    // NHCNT byte streams parsed by this runtime. It is also transitively bound
    // into HumanIO program/publication authority.
    uint64_t model_source_fingerprint;
} mrnx_runtime_info_v1;

// Read-only source anatomy exported from the exact NHRIGID2/NHMYO payloads
// retained by one runtime. These records are scalar copies, not mutation or
// publication authority. Joint indices and muscle identifiers are canonical
// zero-based source order. A fixed joint has coordinate_count == 0.
typedef struct mrnx_runtime_anatomy_info_v1 {
    uint32_t abi_version;
    uint32_t struct_size;
    uint32_t body_count;
    uint32_t joint_count;
    uint32_t coordinate_count;
    uint32_t muscle_count;
    uint32_t head_body_identifier;
    uint32_t reserved0;
    uint64_t model_source_fingerprint;
} mrnx_runtime_anatomy_info_v1;

typedef struct mrnx_joint_anatomy_v1 {
    uint32_t abi_version;
    uint32_t struct_size;
    uint32_t joint_identifier;
    uint32_t parent_body_identifier;
    uint32_t child_body_identifier;
    uint32_t coordinate_offset;
    uint32_t coordinate_count;
    uint32_t reserved0;
    float parent_local_anchor[3];
    float reserved1;
    float child_local_anchor[3];
    float reserved2;
    float rest_relative_orientation[4];
} mrnx_joint_anatomy_v1;

typedef struct mrnx_joint_coordinate_anatomy_v1 {
    uint32_t abi_version;
    uint32_t struct_size;
    uint32_t joint_identifier;
    uint32_t coordinate_identifier;
    uint32_t kind;
    uint32_t q_index;
    uint32_t v_index;
    uint32_t flags;
    float parent_local_axis[3];
    float minimum_position;
    float maximum_position;
    float rest_position;
    float reserved0;
    float reserved1;
} mrnx_joint_coordinate_anatomy_v1;

typedef struct mrnx_muscle_attachment_anatomy_v1 {
    uint32_t abi_version;
    uint32_t struct_size;
    uint32_t muscle_identifier;
    uint32_t route_node_count;
    uint32_t first_body_identifier;
    uint32_t terminal_body_identifier;
    uint32_t reserved0;
    uint32_t reserved1;
    float first_local_point[3];
    float reserved2;
    float terminal_local_point[3];
    float reserved3;
} mrnx_muscle_attachment_anatomy_v1;

enum mrnx_joint_coordinate_kind_v1 {
    MRNX_JOINT_COORDINATE_ANGULAR_V1 = 1u,
    MRNX_JOINT_COORDINATE_LINEAR_V1 = 2u,
};

enum mrnx_joint_coordinate_flags_v1 {
    MRNX_JOINT_COORDINATE_POSITION_LIMIT_V1 = 1u << 0u,
    // NHLIM1 bounds are compliant; the source reset can lie outside them.
    MRNX_JOINT_COORDINATE_SOURCE_COMPLIANT_LIMIT_V1 = 1u << 1u,
};

// One aggregate public tuple copied while the bridge's shared reader gate is
// held. A poisoned or never-published runtime returns false and zeroes the
// caller-provided output. The two Metal ranges remain borrowed at +0 only
// while the runtime is retained and until the next successful publication.
typedef struct mrnx_aggregate_snapshot_v1 {
    uint32_t abi_version;
    uint32_t struct_size;
    uint64_t publication_epoch;
    uint64_t brain_generation;
    uint64_t physics_generation;
    uint64_t sensor_generation;
    mrnx_root_v1 root;
    mrnx_candidate_view_v1 sensor;
    mrnx_candidate_channel_v1 proprioception;
    mrnx_candidate_channel_v1 interoception;
} mrnx_aggregate_snapshot_v1;

// V2/V3 are extensible aggregate reader records. A runtime must report only
// channels backed by its authoritative HumanIO publication; unused entries
// remain zero. channel_capacity is always MRNX_MAX_SENSOR_CHANNELS_V2.
typedef struct mrnx_aggregate_snapshot_v2 {
    uint32_t abi_version;
    uint32_t struct_size;
    uint64_t publication_epoch;
    uint64_t brain_generation;
    uint64_t physics_generation;
    uint64_t sensor_generation;
    mrnx_root_v1 root;
    mrnx_candidate_view_v1 sensor;
    uint32_t channel_count;
    uint32_t channel_capacity;
    mrnx_candidate_channel_v1 channels[MRNX_MAX_SENSOR_CHANNELS_V2];
} mrnx_aggregate_snapshot_v2;

typedef struct mrnx_aggregate_snapshot_v3 {
    uint32_t abi_version;
    uint32_t struct_size;
    uint64_t publication_epoch;
    uint64_t brain_generation;
    uint64_t physics_generation;
    uint64_t sensor_generation;
    mrnx_root_v1 root;
    mrnx_candidate_view_v1 sensor;
    mrnx_candidate_timing_v1 timing;
    uint32_t channel_count;
    uint32_t channel_capacity;
    mrnx_candidate_channel_v1 channels[MRNX_MAX_SENSOR_CHANNELS_V2];
} mrnx_aggregate_snapshot_v3;

typedef struct mrnx_culture_accepted_view_v1 {
    uint32_t abi_version;
    uint32_t struct_size;
    uint64_t culture_fingerprint;
    uint64_t generation;
    uint64_t tick;
    uint64_t growth_generation;
    uint64_t source_root_fingerprint;
    uint64_t receipt_fingerprint;
    mrnx_event_point_v1 ready;
    uint32_t buffer_count;
    uint32_t reserved0;
    mrnx_metal_range_v1 buffers[MRNX_CULTURE_ACCEPTED_BUFFER_COUNT_V1];
} mrnx_culture_accepted_view_v1;

// Prepared culture authority exposes only identity/receipt/timeline metadata;
// all mutable prepared neural buffers remain bridge-private.
typedef struct mrnx_culture_prepared_view_v1 {
    uint32_t abi_version;
    uint32_t struct_size;
    mrnx_root_v1 root;
    uint64_t culture_fingerprint;
    uint64_t accepted_generation;
    uint64_t prepared_generation;
    uint64_t source_root_fingerprint;
    uint64_t receipt_fingerprint;
    mrnx_event_point_v1 ready;
    uint32_t status;
    uint32_t reserved0;
} mrnx_culture_prepared_view_v1;

typedef struct mrnx_aggregate_snapshot_v4 {
    uint32_t abi_version;
    uint32_t struct_size;
    uint64_t publication_epoch;
    uint64_t brain_generation;
    uint64_t physics_generation;
    uint64_t sensor_generation;
    mrnx_root_v1 root;
    mrnx_candidate_view_v1 sensor;
    mrnx_candidate_timing_v1 timing;
    uint32_t channel_count;
    uint32_t channel_capacity;
    mrnx_candidate_channel_v1 channels[MRNX_MAX_SENSOR_CHANNELS_V2];
    mrnx_culture_accepted_view_v1 culture;
} mrnx_aggregate_snapshot_v4;

// First all-exact public aggregate. It intentionally carries the accepted
// publication receipt alongside exact timing and channel records. The v1-v4
// readers remain legacy-only; an exact runtime must fail them closed rather
// than down-convert a sub-microsecond accepted root.
typedef struct mrnx_aggregate_snapshot_v5 {
    uint32_t abi_version;
    uint32_t struct_size;
    uint64_t publication_epoch;
    uint64_t brain_generation;
    uint64_t physics_generation;
    uint64_t sensor_generation;
    mrnx_root_v1 root;
    mrnx_candidate_view_v1 sensor;
    mrnx_candidate_timing_v2 timing;
    mrnx_exact_inbound_authority_v2 inbound_authority;
    mrnx_exact_sensor_packet_v2 sensor_packet;
    mrnx_publication_v2 publication;
    mrnx_candidate_channel_v2 channels[MRNX_MAX_SENSOR_CHANNELS_V2];
    mrnx_culture_accepted_view_v1 culture;
} mrnx_aggregate_snapshot_v5;

typedef struct mrnx_brain_joint_transaction_v1 {
    uint32_t format_version;
    uint32_t environment_identifier;
    uint64_t episode_identifier;
    uint64_t control_step_identifier;
    uint64_t parameter_version_fingerprint;
    uint64_t base_brain_generation;
    uint64_t base_physics_generation;
    uint64_t committed_timestamp_microseconds;
    uint64_t target_timestamp_microseconds;
    uint64_t shadow_generation;
    uint64_t random_counter_generation;
    uint32_t flags;
    uint32_t reserved;
    uint64_t transaction_fingerprint;
} mrnx_brain_joint_transaction_v1;

// Explicit exact-nanosecond successor. This mirrors
// NBJointTransactionTokenV2 without reinterpreting the immutable v1 record.
// Clock fields occupy the former v1 flags/reserved words so the ABI remains
// 96 bytes while the hash domain and time unit are unambiguous.
typedef struct mrnx_brain_joint_transaction_v2 {
    uint32_t format_version;
    uint32_t environment_identifier;
    uint64_t episode_identifier;
    uint64_t control_step_identifier;
    uint64_t parameter_version_fingerprint;
    uint64_t base_brain_generation;
    uint64_t base_physics_generation;
    uint64_t committed_timestamp_nanoseconds;
    uint64_t target_timestamp_nanoseconds;
    uint64_t shadow_generation;
    uint64_t random_counter_generation;
    uint32_t clock_domain;
    uint32_t clock_quantum_nanoseconds;
    uint64_t transaction_fingerprint;
} mrnx_brain_joint_transaction_v2;

typedef struct mrnx_brain_joint_substep_v1 {
    uint64_t transaction_fingerprint;
    uint32_t substep_index;
    uint32_t attempt_index;
    uint64_t start_timestamp_microseconds;
    uint64_t duration_microseconds;
    uint64_t candidate_timestamp_microseconds;
    uint64_t shadow_generation;
    uint64_t random_counter_generation;
    uint32_t flags;
    uint32_t reserved;
    uint64_t substep_fingerprint;
} mrnx_brain_joint_substep_v1;

typedef struct mrnx_brain_joint_substep_v2 {
    uint64_t transaction_fingerprint;
    uint32_t substep_index;
    uint32_t attempt_index;
    uint64_t start_timestamp_nanoseconds;
    uint64_t duration_nanoseconds;
    uint64_t candidate_timestamp_nanoseconds;
    uint64_t shadow_generation;
    uint64_t random_counter_generation;
    uint32_t clock_domain;
    uint32_t clock_quantum_nanoseconds;
    uint64_t substep_fingerprint;
} mrnx_brain_joint_substep_v2;

typedef struct mrnx_brain_motor_candidate_v1 {
    uint32_t format_version;
    uint32_t flags;
    uint64_t transaction_fingerprint;
    uint64_t substep_fingerprint;
    uint64_t accepted_brain_timestamp_microseconds;
    uint64_t brain_generation;
    uint64_t motor_profile_fingerprint;
    uint64_t motor_output_header_gpu_address;
    uint64_t muscle_excitation_gpu_address;
    uint64_t random_counter_generation;
    uint32_t motor_output_header_byte_count;
    uint32_t muscle_excitation_byte_count;
    uint32_t muscle_count;
    uint32_t environment_identifier;
    uint64_t autonomic_command_gpu_address;
    uint32_t autonomic_command_byte_count;
    uint32_t autonomic_command_count;
    uint64_t active_sensing_command_gpu_address;
    uint32_t active_sensing_command_byte_count;
    uint32_t active_sensing_command_count;
    uint32_t actuator_command_kind;
    uint32_t reserved;
    uint64_t species_template_fingerprint;
    uint64_t compiled_species_template_fingerprint;
    uint64_t candidate_fingerprint;
} mrnx_brain_motor_candidate_v1;

typedef struct mrnx_brain_motor_candidate_v2 {
    uint32_t format_version;
    uint32_t flags;
    uint64_t transaction_fingerprint;
    uint64_t substep_fingerprint;
    uint64_t accepted_brain_timestamp_nanoseconds;
    uint64_t brain_generation;
    uint64_t motor_profile_fingerprint;
    uint64_t motor_output_header_gpu_address;
    uint64_t muscle_excitation_gpu_address;
    uint64_t random_counter_generation;
    uint32_t motor_output_header_byte_count;
    uint32_t muscle_excitation_byte_count;
    uint32_t muscle_count;
    uint32_t environment_identifier;
    uint64_t autonomic_command_gpu_address;
    uint32_t autonomic_command_byte_count;
    uint32_t autonomic_command_count;
    uint64_t active_sensing_command_gpu_address;
    uint32_t active_sensing_command_byte_count;
    uint32_t active_sensing_command_count;
    uint32_t actuator_command_kind;
    uint32_t clock_domain;
    uint64_t species_template_fingerprint;
    uint64_t compiled_species_template_fingerprint;
    uint64_t candidate_fingerprint;
} mrnx_brain_motor_candidate_v2;

typedef struct MRNX_ALIGN16 mrnx_brain_motor_output_header_v2 {
    uint32_t format_version;
    uint32_t flags;
    uint64_t timestamp_nanoseconds;
    uint64_t brain_generation;
    uint64_t profile_fingerprint;
    uint64_t protective_command_fingerprint;
    uint32_t muscle_count;
    uint32_t environment_identifier;
    float motor_inhibition;
    float autonomic_arousal;
    uint32_t actuator_command_kind;
    uint32_t clock_domain;
    float output_minimum;
    float output_maximum;
    uint64_t output_fingerprint;
} mrnx_brain_motor_output_header_v2;

typedef struct mrnx_brain_motor_ready_gate_v1 {
    uint32_t abi_version;
    uint32_t struct_bytes;
    uint32_t status;
    uint32_t environment;
    uint32_t substep_index;
    uint32_t attempt_index;
    uint32_t muscle_count;
    uint32_t actuator_command_kind;
    uint64_t control_step;
    uint64_t transaction_fingerprint;
    uint64_t substep_fingerprint;
    uint64_t candidate_fingerprint;
    uint64_t motor_output_fingerprint;
    uint64_t motor_profile_fingerprint;
    uint64_t brain_generation;
    uint64_t accepted_brain_timestamp_microseconds;
    uint64_t random_counter_generation;
    uint64_t species_template_fingerprint;
    uint64_t compiled_species_template_fingerprint;
    uint64_t brain_program_fingerprint;
    uint64_t fast_program_fingerprint;
    uint64_t decision_gate_fingerprint;
    uint64_t reserved64_0;
    uint64_t gate_fingerprint;
} mrnx_brain_motor_ready_gate_v1;

typedef struct MRNX_ALIGN16 mrnx_brain_motor_ready_gate_v2 {
    uint32_t abi_version;
    uint32_t struct_bytes;
    uint32_t status;
    uint32_t environment;
    uint32_t substep_index;
    uint32_t attempt_index;
    uint32_t muscle_count;
    uint32_t actuator_command_kind;
    uint64_t control_step;
    uint64_t transaction_fingerprint;
    uint64_t substep_fingerprint;
    uint64_t candidate_fingerprint;
    uint64_t motor_output_fingerprint;
    uint64_t motor_profile_fingerprint;
    uint64_t brain_generation;
    uint64_t accepted_brain_timestamp_nanoseconds;
    uint64_t random_counter_generation;
    uint64_t species_template_fingerprint;
    uint64_t compiled_species_template_fingerprint;
    uint64_t brain_program_fingerprint;
    uint64_t fast_program_fingerprint;
    uint64_t decision_gate_fingerprint;
    uint32_t clock_domain;
    uint32_t clock_quantum_nanoseconds;
    uint64_t gate_fingerprint;
} mrnx_brain_motor_ready_gate_v2;

// Exact asynchronous Brain authority offered to the native full-body begin
// call. Every range is an exact checked slice of a retained same-device
// MTLBuffer; object identity, base+offset GPU address, count, type, and pairwise
// non-overlap are all authenticated before encoding. The event is liveness
// only; HumanIO validates motor_ready_gate on the GPU before reading any
// payload range. Model dimensions, sensor generation, slot, and physics
// identity are derived by the long-lived native runtime.
typedef struct mrnx_physical_root_request_v1 {
    uint32_t abi_version;
    uint32_t struct_size;
    mrnx_brain_joint_transaction_v1 root;
    mrnx_brain_joint_substep_v1 substep;
    mrnx_brain_motor_candidate_v1 candidate;
    mrnx_metal_range_v1 motor_header;
    mrnx_metal_range_v1 muscle_excitation;
    mrnx_metal_range_v1 autonomic_command;
    mrnx_metal_range_v1 active_sensing_command;
    mrnx_metal_range_v1 motor_ready_gate;
    mrnx_event_point_v1 motor_ready;
} mrnx_physical_root_request_v1;

// Published request-v2 shape. Its embedded records are the immutable v1
// family; the exact runtime now rejects this unit-ambiguous ABI before any
// borrowed resource is inspected. Keep this layout unchanged for binary
// compatibility with existing callers.
typedef struct mrnx_physical_root_request_v2 {
    uint32_t abi_version;
    uint32_t struct_size;
    mrnx_brain_joint_transaction_v1 root;
    mrnx_brain_joint_substep_v1 substep;
    mrnx_brain_motor_candidate_v1 candidate;
    mrnx_metal_range_v1 motor_header;
    mrnx_metal_range_v1 muscle_excitation;
    mrnx_metal_range_v1 autonomic_command;
    mrnx_metal_range_v1 active_sensing_command;
    mrnx_metal_range_v1 motor_ready_gate;
    mrnx_event_point_v1 motor_ready;
} mrnx_physical_root_request_v2;

// Executable exact-clock request. Every embedded time-bearing authority is a
// distinct v2 record with an explicit nanosecond clock domain. The resource
// descriptors for motor_header and motor_ready_gate use their typed v2 element
// kinds and full record element sizes. Admission imports retained same-device
// resources, then the native HumanMatter/HumanIO path produces an exact
// candidate for the existing proposal/apply and joint-publication protocol.
typedef struct mrnx_physical_root_request_v3 {
    uint32_t abi_version;
    uint32_t struct_size;
    mrnx_brain_joint_transaction_v2 root;
    mrnx_brain_joint_substep_v2 substep;
    mrnx_brain_motor_candidate_v2 candidate;
    mrnx_metal_range_v1 motor_header;
    mrnx_metal_range_v1 muscle_excitation;
    mrnx_metal_range_v1 autonomic_command;
    mrnx_metal_range_v1 active_sensing_command;
    mrnx_metal_range_v1 motor_ready_gate;
    mrnx_event_point_v1 motor_ready;
} mrnx_physical_root_request_v3;

// candidate_handle and every view passed here are borrowed for the callback
// invocation. On success candidate_handle is non-null and carries an internal
// lifecycle self-hold; call mrnx_bridge_v1_candidate_retain before returning
// only if the receiver needs an independent external reference. Failure
// completion supplies no candidate authority. Callbacks run outside native
// runtime locks and may synchronously re-enter the bridge.
typedef void (*mrnx_candidate_settled_callback_v1)(
    void* context,
    mrnx_candidate_v1* candidate_handle,
    const mrnx_completion_v1* completion,
    const mrnx_candidate_view_v1* candidate,
    const mrnx_candidate_channel_v1* channels,
    uint32_t channel_count);

typedef void (*mrnx_proposal_settled_callback_v1)(
    void* context,
    const mrnx_completion_v1* completion,
    const mrnx_proposal_view_v1* proposal);

typedef void (*mrnx_apply_settled_callback_v1)(
    void* context,
    const mrnx_completion_v1* completion,
    const mrnx_applied_view_v1* applied);

// Once begin is armed this callback is delivered exactly once, outside all
// runtime/owner/HumanIO mutexes, after both the original physical command and
// the HumanIO candidate have independently settled. It may run synchronously
// before begin returns. READY supplies borrowed prepared+candidate handles;
// retain them inside the callback to continue proposal/ACK/application.
// Failure supplies no usable authority. The runtime self-retains through the
// exact native terminal resolution even if the external runtime is dropped.
typedef void (*mrnx_physical_root_settled_callback_v1)(
    void* context,
    mrnx_prepared_v1* prepared,
    mrnx_candidate_v1* candidate,
    const mrnx_completion_v1* completion,
    const mrnx_root_v1* root);

// Borrowed synchronous callback. It must not be retained or invoked after the
// release function returns. The Brain runtime lock is already held; callback
// code may latch only the supplied generation and must not call a Brain getter.
typedef bool (*mrnx_brain_generation_latch_v1)(
    void* context,
    uint64_t publishing_brain_generation);

MRNX_BRIDGE_EXPORT uint32_t mrnx_bridge_v1_abi_version(void);

MRNX_BRIDGE_EXPORT mrnx_runtime_v1* mrnx_bridge_v1_runtime_create(
    const mrnx_runtime_config_v1* config,
    mrnx_runtime_info_v1* info);
MRNX_BRIDGE_EXPORT mrnx_runtime_v1* mrnx_bridge_v1_runtime_create_v2(
    const mrnx_runtime_config_v2* config,
    mrnx_runtime_info_v1* info);
MRNX_BRIDGE_EXPORT mrnx_runtime_v1* mrnx_bridge_v1_runtime_create_v3(
    const mrnx_runtime_config_v3* config,
    mrnx_runtime_info_v1* info);
MRNX_BRIDGE_EXPORT mrnx_runtime_v1* mrnx_bridge_v1_runtime_create_v4(
    const mrnx_runtime_config_v4* config,
    mrnx_runtime_info_v1* info);
MRNX_BRIDGE_EXPORT mrnx_runtime_v1* mrnx_bridge_v1_runtime_create_v5(
    const mrnx_runtime_config_v5* config,
    mrnx_runtime_info_v1* info);
MRNX_BRIDGE_EXPORT mrnx_runtime_v1* mrnx_bridge_v1_runtime_create_v6(
    const mrnx_runtime_config_v6* config,
    mrnx_runtime_info_v1* info);
MRNX_BRIDGE_EXPORT mrnx_runtime_v1* mrnx_bridge_v1_runtime_create_v7(
    const mrnx_runtime_config_v7* config,
    mrnx_runtime_info_v1* info
);
MRNX_BRIDGE_EXPORT mrnx_runtime_v1* mrnx_bridge_v1_runtime_create_v8(
    const mrnx_runtime_config_v8* config,
    mrnx_runtime_info_v1* info
);
MRNX_BRIDGE_EXPORT bool mrnx_bridge_v1_runtime_copy_world_info(
    const mrnx_runtime_v1* runtime,
    mrnx_runtime_world_info_v1* info);
MRNX_BRIDGE_EXPORT bool mrnx_bridge_v1_runtime_copy_exact_clock(
    const mrnx_runtime_v1* runtime,
    mrnx_exact_clock_info_v1* info);
MRNX_BRIDGE_EXPORT void mrnx_bridge_v1_runtime_retain(
    mrnx_runtime_v1* runtime);
MRNX_BRIDGE_EXPORT void mrnx_bridge_v1_runtime_drop(
    mrnx_runtime_v1* runtime);
MRNX_BRIDGE_EXPORT bool mrnx_bridge_v1_runtime_copy_info(
    const mrnx_runtime_v1* runtime,
    mrnx_runtime_info_v1* info);
MRNX_BRIDGE_EXPORT bool mrnx_bridge_v1_runtime_copy_anatomy_info(
    const mrnx_runtime_v1* runtime,
    mrnx_runtime_anatomy_info_v1* info);
MRNX_BRIDGE_EXPORT bool mrnx_bridge_v1_runtime_copy_joint_anatomy(
    const mrnx_runtime_v1* runtime,
    uint32_t joint_index,
    mrnx_joint_anatomy_v1* anatomy);
MRNX_BRIDGE_EXPORT bool mrnx_bridge_v1_runtime_copy_joint_coordinate_anatomy(
    const mrnx_runtime_v1* runtime,
    uint32_t coordinate_index,
    mrnx_joint_coordinate_anatomy_v1* anatomy);
MRNX_BRIDGE_EXPORT bool mrnx_bridge_v1_runtime_copy_muscle_attachment_anatomy(
    const mrnx_runtime_v1* runtime,
    uint32_t muscle_index,
    mrnx_muscle_attachment_anatomy_v1* anatomy);
MRNX_BRIDGE_EXPORT bool mrnx_bridge_v1_runtime_begin_physical_root(
    mrnx_runtime_v1* runtime,
    const mrnx_physical_root_request_v1* request,
    void* completion_context,
    mrnx_physical_root_settled_callback_v1 completion);
// Frozen compatibility entry point for the published all-v1 request-v2
// shape. Exact runtimes reject it as unit-ambiguous at the legacy-v2 failure
// stage before inspecting any borrowed Metal buffer or event.
MRNX_BRIDGE_EXPORT bool mrnx_bridge_v1_runtime_begin_physical_root_v2(
    mrnx_runtime_v1* runtime,
    const mrnx_physical_root_request_v2* request,
    void* completion_context,
    mrnx_physical_root_settled_callback_v1 completion);
// Executable entry point for the all-exact request-v3 family. It admits only a
// coherent nanosecond authority/resource set, preserves borrowed Metal
// resources through asynchronous settlement, and returns the same opaque
// prepared/candidate handles used by the proposal/apply protocol. Acceptance
// becomes public only through the exact publication-v2 reserve/release pair.
MRNX_BRIDGE_EXPORT bool mrnx_bridge_v1_runtime_begin_physical_root_v3(
    mrnx_runtime_v1* runtime,
    const mrnx_physical_root_request_v3* request,
    void* completion_context,
    mrnx_physical_root_settled_callback_v1 completion);
MRNX_BRIDGE_EXPORT bool mrnx_bridge_v1_runtime_copy_aggregate_snapshot(
    const mrnx_runtime_v1* runtime,
    mrnx_aggregate_snapshot_v1* snapshot);
MRNX_BRIDGE_EXPORT bool mrnx_bridge_v1_runtime_copy_aggregate_snapshot_v2(
    const mrnx_runtime_v1* runtime,
    mrnx_aggregate_snapshot_v2* snapshot);
MRNX_BRIDGE_EXPORT bool mrnx_bridge_v1_runtime_copy_aggregate_snapshot_v3(
    const mrnx_runtime_v1* runtime,
    mrnx_aggregate_snapshot_v3* snapshot);
MRNX_BRIDGE_EXPORT bool mrnx_bridge_v1_runtime_copy_aggregate_snapshot_v4(
    const mrnx_runtime_v1* runtime,
    mrnx_aggregate_snapshot_v4* snapshot);
MRNX_BRIDGE_EXPORT bool mrnx_bridge_v1_runtime_copy_aggregate_snapshot_v5(
    const mrnx_runtime_v1* runtime,
    mrnx_aggregate_snapshot_v5* snapshot);

MRNX_BRIDGE_EXPORT void mrnx_bridge_v1_prepared_retain(
    mrnx_prepared_v1* prepared);
MRNX_BRIDGE_EXPORT void mrnx_bridge_v1_prepared_drop(
    mrnx_prepared_v1* prepared);
MRNX_BRIDGE_EXPORT void mrnx_bridge_v1_candidate_retain(
    mrnx_candidate_v1* candidate);
MRNX_BRIDGE_EXPORT void mrnx_bridge_v1_candidate_drop(
    mrnx_candidate_v1* candidate);

MRNX_BRIDGE_EXPORT bool mrnx_bridge_v1_prepared_copy_root(
    const mrnx_prepared_v1* prepared,
    mrnx_root_v1* output);
// Exact GPU-read-only accepted-physics gate: 64-byte prepared token plus the
// owner physical-ready event. Descriptor authority expires on every terminal
// or resolved phase even if an external opaque reference remains alive.
MRNX_BRIDGE_EXPORT bool mrnx_bridge_v1_prepared_copy_physical_gate(
    const mrnx_prepared_v1* prepared,
    mrnx_wire_lease_v1* output);
MRNX_BRIDGE_EXPORT bool mrnx_bridge_v1_prepared_copy_culture_view(
    const mrnx_prepared_v1* prepared,
    mrnx_culture_prepared_view_v1* output);
MRNX_BRIDGE_EXPORT bool mrnx_bridge_v1_candidate_copy_view(
    const mrnx_candidate_v1* candidate,
    mrnx_candidate_view_v1* output);
MRNX_BRIDGE_EXPORT bool mrnx_bridge_v1_candidate_copy_channel(
    const mrnx_candidate_v1* candidate,
    uint32_t channel_index,
    mrnx_candidate_channel_v1* output);
MRNX_BRIDGE_EXPORT bool mrnx_bridge_v1_candidate_copy_timing(
    const mrnx_candidate_v1* candidate,
    mrnx_candidate_timing_v1* output);
// Exact candidates expose only the v2 clock/channel/receipt family below;
// legacy candidates fail every v2 copy and exact candidates fail the legacy
// timing/channel copies. The common candidate view remains available to both;
// for an exact callback its candidate publication fingerprint names the full
// canonical sensor packet, not HumanIO's private base-channel capability.
MRNX_BRIDGE_EXPORT bool mrnx_bridge_v1_candidate_copy_timing_v2(
    const mrnx_candidate_v1* candidate,
    mrnx_candidate_timing_v2* output);
MRNX_BRIDGE_EXPORT bool mrnx_bridge_v1_candidate_copy_channel_v2(
    const mrnx_candidate_v1* candidate,
    uint32_t channel_index,
    mrnx_candidate_channel_v2* output);
MRNX_BRIDGE_EXPORT bool mrnx_bridge_v1_candidate_copy_inbound_authority_v2(
    const mrnx_candidate_v1* candidate,
    mrnx_exact_inbound_authority_v2* output);
MRNX_BRIDGE_EXPORT bool mrnx_bridge_v1_candidate_copy_sensor_packet_v2(
    const mrnx_candidate_v1* candidate,
    mrnx_exact_sensor_packet_v2* output);
MRNX_BRIDGE_EXPORT bool mrnx_bridge_v1_bind_candidate(
    mrnx_prepared_v1* prepared,
    mrnx_candidate_v1* candidate);
// A successful bind makes the prepared handle retain the exact candidate and
// its move-only HumanIO publication lease through terminal root resolution.
// Dropping the caller's candidate reference cannot release that authority.

// All command buffers are borrowed at +0, must be same-device and
// NotEnqueued, and are retained by the opaque handle through settlement or an
// exact abort. The bridge encodes only: it never creates a queue, commits,
// waits, polls, reads payload bytes, or performs a readback/blit. Brain wire
// record/event objects are strongly retained after successful admission.
MRNX_BRIDGE_EXPORT bool mrnx_bridge_v1_submit_proposal(
    mrnx_prepared_v1* prepared,
    void* command_buffer,
    const mrnx_wire_lease_v1* brain_witness,
    void* completion_context,
    mrnx_proposal_settled_callback_v1 completion);
MRNX_BRIDGE_EXPORT bool mrnx_bridge_v1_abort_proposal(
    mrnx_prepared_v1* prepared,
    void* command_buffer);
MRNX_BRIDGE_EXPORT bool mrnx_bridge_v1_reserve_application(
    mrnx_prepared_v1* prepared,
    const mrnx_wire_lease_v1* brain_preflight);
MRNX_BRIDGE_EXPORT bool mrnx_bridge_v1_submit_apply(
    mrnx_prepared_v1* prepared,
    void* command_buffer,
    const mrnx_wire_lease_v1* brain_ack,
    void* completion_context,
    mrnx_apply_settled_callback_v1 completion);
MRNX_BRIDGE_EXPORT bool mrnx_bridge_v1_abort_apply(
    mrnx_prepared_v1* prepared,
    void* command_buffer);

// Timeout is sticky and blocks every ordinary witness/ACK transition above.
// These three explicitly named operations are the sole pre-apply teardown
// path after mrnx_bridge_v1_quarantine_timeout succeeds. They encode the
// owner's canonical forceReject proposal/apply modes and therefore never
// consume a Brain witness or ACK. The application reservation still requires
// an exact, GPU-produced Brain preflight lease; the bridge never fabricates a
// Brain record. A caller may use the forced reservation/apply after a late
// ordinary proposal completes, or use all three operations after timing out
// before proposal. A late native REJECT is released only by
// mrnx_bridge_v1_release_rejected. A normal ACCEPT apply already in flight
// when timeout wins is permanently quarantined and cannot be published. The
// generic abort functions reject a timed-out ordinary command; they may abort
// only an explicit timeout-reject command that is still NotEnqueued, preserving
// the same forced-reject phase for an exact retry.
MRNX_BRIDGE_EXPORT bool mrnx_bridge_v1_submit_timeout_reject_proposal(
    mrnx_prepared_v1* prepared,
    void* command_buffer,
    void* completion_context,
    mrnx_proposal_settled_callback_v1 completion);
MRNX_BRIDGE_EXPORT bool mrnx_bridge_v1_reserve_timeout_reject_application(
    mrnx_prepared_v1* prepared,
    const mrnx_wire_lease_v1* brain_preflight);
MRNX_BRIDGE_EXPORT bool mrnx_bridge_v1_submit_timeout_reject_apply(
    mrnx_prepared_v1* prepared,
    void* command_buffer,
    void* completion_context,
    mrnx_apply_settled_callback_v1 completion);

MRNX_BRIDGE_EXPORT bool mrnx_bridge_v1_reserve_publication(
    mrnx_prepared_v1* prepared,
    const mrnx_publication_v1* publication);
MRNX_BRIDGE_EXPORT bool mrnx_bridge_v1_reserve_publication_v2(
    mrnx_prepared_v1* prepared,
    const mrnx_publication_v2* publication);

// Called synchronously while the Brain runtime lock is already held. The
// bridge takes its sole public-reader writer gate, invokes generation_latch
// exactly once before any Matter/HumanIO visibility, and keeps the gate held
// through the native root release. A false latch invokes no native release and
// permanently quarantines the generation. No callback is retained. After a
// true latch the bridge performs no queue operation, GPU host wait, allocation,
// payload readback, or blit. The release is not lock-free: it acquires the
// predeclared owner -> adapter -> Matter -> HumanIO mutex chain while the
// writer gate remains held. Calling either release entry point with the other
// capability family returns MRNX_PUBLICATION_REJECTED_V1 before the writer
// gate, latch callback, or lifecycle state is touched.
MRNX_BRIDGE_EXPORT uint32_t mrnx_bridge_v1_release_accepted(
    mrnx_prepared_v1* prepared,
    const mrnx_publication_v1* publication,
    void* latch_context,
    mrnx_brain_generation_latch_v1 generation_latch);
MRNX_BRIDGE_EXPORT uint32_t mrnx_bridge_v1_release_accepted_v2(
    mrnx_prepared_v1* prepared,
    const mrnx_publication_v2* publication,
    void* latch_context,
    mrnx_brain_generation_latch_v1 generation_latch);
MRNX_BRIDGE_EXPORT uint32_t mrnx_bridge_v1_release_rejected(
    mrnx_prepared_v1* prepared);

// Host timeout is observation only: it never cancels, restores, reuses, or
// destroys the unresolved native capability. It atomically races accepted
// publication under the sole public-writer gate. Accepted release claims the
// terminal outcome before invoking the borrowed Brain latch, so timeout can
// deterministically lose without waiting on caller-controlled latch progress.
// A winning timeout immediately disables every ordinary ACCEPT-capable forward
// operation. Only the explicit timeout-reject operations above may continue a
// pre-apply root. The lifecycle self-hold remains until an exact later REJECT
// release, otherwise for runtime teardown.
MRNX_BRIDGE_EXPORT bool mrnx_bridge_v1_quarantine_timeout(
    mrnx_prepared_v1* prepared);

// Rejects an unbound HumanIO candidate via its exact native one-shot program.
// A bound candidate can be resolved only by its owning Prepared root.
MRNX_BRIDGE_EXPORT uint32_t mrnx_bridge_v1_reject_unbound_candidate(
    mrnx_candidate_v1* candidate);

// Opaque handles are created only by the bridge-owned runtime implementation;
// no C entrypoint adopts arbitrary C++ Prepared or HumanIO callback/program
// objects.

#ifdef __cplusplus
} // extern "C"

static_assert(sizeof(mrnx_runtime_config_v3) == 168u);
static_assert(sizeof(mrnx_runtime_config_v4) == 192u);
static_assert(sizeof(mrnx_runtime_config_v5) == 224u);
static_assert(sizeof(mrnx_runtime_config_v6) == 240u);
static_assert(offsetof(mrnx_runtime_config_v8, runtime) == 8u);
static_assert(offsetof(mrnx_runtime_config_v8, timestep_nanoseconds) == 8u + sizeof(mrnx_runtime_config_v7));
static_assert(sizeof(mrnx_physical_root_request_v2) == sizeof(mrnx_physical_root_request_v1));
static_assert(sizeof(mrnx_physical_root_request_v3) == sizeof(mrnx_physical_root_request_v1));
static_assert(sizeof(mrnx_exact_clock_info_v1) == 40u);
static_assert(offsetof(mrnx_runtime_config_v6, joint_limit_payload_path) == 200u);
static_assert(offsetof(mrnx_runtime_config_v6, costal_cartilage_payload_path) == 216u);
static_assert(offsetof(mrnx_runtime_config_v4, joint_equality_payload_path) == 176u);
static_assert(offsetof(mrnx_runtime_config_v4, expected_joint_equality_fingerprint) == 184u);
static_assert(offsetof(mrnx_runtime_config_v3, runtime) == 8u);
static_assert(offsetof(mrnx_runtime_config_v3, matter_world_package_path) == 144u);
static_assert(sizeof(mrnx_runtime_world_info_v1) == 40u);
static_assert(sizeof(mrnx_root_v1) == 96u);
static_assert(alignof(mrnx_root_v1) == 8u);
static_assert(offsetof(mrnx_root_v1, program_fingerprint) == 56u);
static_assert(offsetof(mrnx_root_v1, device_registry_id) == 88u);
static_assert(sizeof(mrnx_metal_range_v1) == 48u);
static_assert(offsetof(mrnx_metal_range_v1, metal_buffer) == 8u);
static_assert(offsetof(mrnx_metal_range_v1, gpu_address) == 16u);
static_assert(offsetof(mrnx_metal_range_v1, element_type) == 40u);
static_assert(sizeof(mrnx_event_point_v1) == 32u);
static_assert(offsetof(mrnx_event_point_v1, shared_event) == 8u);
static_assert(sizeof(mrnx_candidate_key_v1) == 64u);
static_assert(offsetof(mrnx_candidate_key_v1, fingerprint) == 56u);
static_assert(sizeof(mrnx_candidate_view_v1) == 112u);
static_assert(offsetof(mrnx_candidate_view_v1,
                       candidate_publication_fingerprint) == 80u);
static_assert(sizeof(mrnx_candidate_channel_v1) == 128u);
static_assert(offsetof(mrnx_candidate_channel_v1, values) == 32u);
static_assert(offsetof(mrnx_candidate_channel_v1, validity) == 80u);
static_assert(sizeof(mrnx_candidate_channel_v2) == 144u);
static_assert(alignof(mrnx_candidate_channel_v2) == 8u);
static_assert(offsetof(mrnx_candidate_channel_v2, values) == 40u);
static_assert(offsetof(mrnx_candidate_channel_v2, validity) == 88u);
static_assert(offsetof(mrnx_candidate_channel_v2,
                       channel_fingerprint) == 136u);
static_assert(sizeof(mrnx_candidate_timing_v1) == 40u);
static_assert(offsetof(mrnx_candidate_timing_v1,
                       timing_fingerprint) == 32u);
static_assert(sizeof(mrnx_candidate_timing_v2) == 56u);
static_assert(offsetof(mrnx_candidate_timing_v2,
                       timing_fingerprint) == 48u);
static_assert(sizeof(mrnx_exact_inbound_authority_v2) == 112u);
static_assert(offsetof(mrnx_exact_inbound_authority_v2,
                       inbound_authority_fingerprint) == 104u);
static_assert(sizeof(mrnx_exact_sensor_packet_v2) == 128u);
static_assert(offsetof(mrnx_exact_sensor_packet_v2,
                       candidate_publication_fingerprint) == 120u);
static_assert(sizeof(mrnx_wire_lease_v1) == 184u);
static_assert(offsetof(mrnx_wire_lease_v1, record) == 104u);
static_assert(offsetof(mrnx_wire_lease_v1, ready) == 152u);
static_assert(sizeof(mrnx_proposal_view_v1) == 280u);
static_assert(offsetof(mrnx_proposal_view_v1, proposal) == 104u);
static_assert(offsetof(mrnx_proposal_view_v1, ready) == 248u);
static_assert(sizeof(mrnx_applied_view_v1) == 240u);
static_assert(offsetof(mrnx_applied_view_v1, applied) == 104u);
static_assert(offsetof(mrnx_applied_view_v1, command_disposition) == 232u);
static_assert(sizeof(mrnx_completion_v1) == 24u);
static_assert(offsetof(mrnx_completion_v1, slot_generation) == 16u);
static_assert(sizeof(mrnx_publication_v1) == 24u);
static_assert(offsetof(mrnx_publication_v1,
                       joint_commit_fingerprint) == 8u);
static_assert(sizeof(mrnx_publication_v2) == 72u);
static_assert(offsetof(mrnx_publication_v2,
                       publication_fingerprint) == 64u);
static_assert(sizeof(mrnx_runtime_config_v1) == 104u);
static_assert(offsetof(mrnx_runtime_config_v1,
                       timestep_microseconds) == 80u);
static_assert(offsetof(mrnx_runtime_config_v1,
                       maximum_retained_bytes) == 88u);
static_assert(sizeof(mrnx_runtime_info_v1) == 64u);
static_assert(offsetof(mrnx_runtime_info_v1,
                       device_registry_id) == 40u);
static_assert(sizeof(mrnx_joint_anatomy_v1) == 80u);
static_assert(offsetof(mrnx_joint_anatomy_v1,
                       rest_relative_orientation) == 64u);
static_assert(sizeof(mrnx_joint_coordinate_anatomy_v1) == 64u);
static_assert(offsetof(mrnx_joint_coordinate_anatomy_v1,
                       parent_local_axis) == 32u);
static_assert(sizeof(mrnx_muscle_attachment_anatomy_v1) == 64u);
static_assert(offsetof(mrnx_muscle_attachment_anatomy_v1,
                       first_local_point) == 32u);
static_assert(sizeof(mrnx_runtime_anatomy_info_v1) == 40u);
static_assert(offsetof(mrnx_runtime_anatomy_info_v1,
                       model_source_fingerprint) == 32u);
static_assert(sizeof(mrnx_aggregate_snapshot_v1) == 504u);
static_assert(offsetof(mrnx_aggregate_snapshot_v1, root) == 40u);
static_assert(offsetof(mrnx_aggregate_snapshot_v1, sensor) == 136u);
static_assert(offsetof(mrnx_aggregate_snapshot_v1,
                       proprioception) == 248u);
static_assert(offsetof(mrnx_aggregate_snapshot_v1,
                       interoception) == 376u);
static_assert(sizeof(mrnx_aggregate_snapshot_v2) == 1280u);
static_assert(offsetof(mrnx_aggregate_snapshot_v2, root) == 40u);
static_assert(offsetof(mrnx_aggregate_snapshot_v2, sensor) == 136u);
static_assert(offsetof(mrnx_aggregate_snapshot_v2,
                       channel_count) == 248u);
static_assert(offsetof(mrnx_aggregate_snapshot_v2, channels) == 256u);
static_assert(sizeof(mrnx_aggregate_snapshot_v3) == 1320u);
static_assert(offsetof(mrnx_aggregate_snapshot_v3, timing) == 248u);
static_assert(offsetof(mrnx_aggregate_snapshot_v3,
                       channel_count) == 288u);
static_assert(offsetof(mrnx_aggregate_snapshot_v3, channels) == 296u);
static_assert(sizeof(mrnx_runtime_config_v2) == 136u);
static_assert(offsetof(mrnx_runtime_config_v2, culture_pack_path) == 104u);
static_assert(offsetof(mrnx_runtime_config_v2, culture_window_ticks) == 128u);
static_assert(sizeof(mrnx_culture_accepted_view_v1) == 624u);
static_assert(offsetof(mrnx_culture_accepted_view_v1,
                       receipt_fingerprint) == 48u);
static_assert(offsetof(mrnx_culture_accepted_view_v1, ready) == 56u);
static_assert(offsetof(mrnx_culture_accepted_view_v1, buffers) == 96u);
static_assert(sizeof(mrnx_culture_prepared_view_v1) == 184u);
static_assert(offsetof(mrnx_culture_prepared_view_v1, ready) == 144u);
static_assert(sizeof(mrnx_aggregate_snapshot_v4) == 1944u);
static_assert(offsetof(mrnx_aggregate_snapshot_v4, culture) == 1320u);
static_assert(sizeof(mrnx_aggregate_snapshot_v5) == 2392u);
static_assert(offsetof(mrnx_aggregate_snapshot_v5, timing) == 248u);
static_assert(offsetof(mrnx_aggregate_snapshot_v5,
                       inbound_authority) == 304u);
static_assert(offsetof(mrnx_aggregate_snapshot_v5, sensor_packet) == 416u);
static_assert(offsetof(mrnx_aggregate_snapshot_v5, publication) == 544u);
static_assert(offsetof(mrnx_aggregate_snapshot_v5, channels) == 616u);
static_assert(offsetof(mrnx_aggregate_snapshot_v5, culture) == 1768u);
static_assert(sizeof(mrnx_brain_joint_transaction_v1) == 96u);
static_assert(alignof(mrnx_brain_joint_transaction_v1) == 8u);
static_assert(offsetof(mrnx_brain_joint_transaction_v1,
                       transaction_fingerprint) == 88u);
static_assert(sizeof(mrnx_brain_joint_transaction_v2) == 96u);
static_assert(alignof(mrnx_brain_joint_transaction_v2) == 8u);
static_assert(offsetof(mrnx_brain_joint_transaction_v2,
                       clock_domain) == 80u);
static_assert(offsetof(mrnx_brain_joint_transaction_v2,
                       transaction_fingerprint) == 88u);
static_assert(sizeof(mrnx_brain_joint_substep_v1) == 72u);
static_assert(alignof(mrnx_brain_joint_substep_v1) == 8u);
static_assert(offsetof(mrnx_brain_joint_substep_v1,
                       substep_fingerprint) == 64u);
static_assert(sizeof(mrnx_brain_joint_substep_v2) == 72u);
static_assert(alignof(mrnx_brain_joint_substep_v2) == 8u);
static_assert(offsetof(mrnx_brain_joint_substep_v2,
                       clock_domain) == 56u);
static_assert(offsetof(mrnx_brain_joint_substep_v2,
                       substep_fingerprint) == 64u);
static_assert(sizeof(mrnx_brain_motor_candidate_v1) == 152u);
static_assert(alignof(mrnx_brain_motor_candidate_v1) == 8u);
static_assert(offsetof(mrnx_brain_motor_candidate_v1,
                       candidate_fingerprint) == 144u);
static_assert(sizeof(mrnx_brain_motor_candidate_v2) == 152u);
static_assert(alignof(mrnx_brain_motor_candidate_v2) == 8u);
static_assert(offsetof(mrnx_brain_motor_candidate_v2,
                       clock_domain) == 124u);
static_assert(offsetof(mrnx_brain_motor_candidate_v2,
                       candidate_fingerprint) == 144u);
static_assert(sizeof(mrnx_brain_motor_output_header_v2) == 80u);
static_assert(alignof(mrnx_brain_motor_output_header_v2) == 16u);
static_assert(offsetof(mrnx_brain_motor_output_header_v2,
                       clock_domain) == 60u);
static_assert(offsetof(mrnx_brain_motor_output_header_v2,
                       output_fingerprint) == 72u);
static_assert(sizeof(mrnx_brain_motor_ready_gate_v1) == 160u);
static_assert(alignof(mrnx_brain_motor_ready_gate_v1) == 8u);
static_assert(offsetof(mrnx_brain_motor_ready_gate_v1,
                       gate_fingerprint) == 152u);
static_assert(sizeof(mrnx_brain_motor_ready_gate_v2) == 160u);
static_assert(alignof(mrnx_brain_motor_ready_gate_v2) == 16u);
static_assert(offsetof(mrnx_brain_motor_ready_gate_v2,
                       clock_domain) == 144u);
static_assert(offsetof(mrnx_brain_motor_ready_gate_v2,
                       gate_fingerprint) == 152u);
static_assert(sizeof(mrnx_physical_root_request_v1) == 600u);
static_assert(alignof(mrnx_physical_root_request_v1) == 8u);
static_assert(offsetof(mrnx_physical_root_request_v1, root) == 8u);
static_assert(offsetof(mrnx_physical_root_request_v1,
                       motor_header) == 328u);
static_assert(offsetof(mrnx_physical_root_request_v1,
                       motor_ready_gate) == 520u);
static_assert(offsetof(mrnx_physical_root_request_v1,
                       motor_ready) == 568u);
static_assert(sizeof(mrnx_physical_root_request_v2) == 600u);
static_assert(alignof(mrnx_physical_root_request_v2) == 8u);
static_assert(offsetof(mrnx_physical_root_request_v2, root) == 8u);
static_assert(offsetof(mrnx_physical_root_request_v2,
                       motor_header) == 328u);
static_assert(offsetof(mrnx_physical_root_request_v2,
                       motor_ready_gate) == 520u);
static_assert(offsetof(mrnx_physical_root_request_v2,
                       motor_ready) == 568u);
static_assert(sizeof(mrnx_physical_root_request_v3) == 600u);
static_assert(alignof(mrnx_physical_root_request_v3) == 8u);
static_assert(offsetof(mrnx_physical_root_request_v3, root) == 8u);
static_assert(offsetof(mrnx_physical_root_request_v3,
                       candidate) == 176u);
static_assert(offsetof(mrnx_physical_root_request_v3,
                       motor_header) == 328u);
static_assert(offsetof(mrnx_physical_root_request_v3,
                       motor_ready_gate) == 520u);
static_assert(offsetof(mrnx_physical_root_request_v3,
                       motor_ready) == 568u);
#else
_Static_assert(sizeof(mrnx_root_v1) == 96u, "mrnx_root_v1 ABI");
_Static_assert(_Alignof(mrnx_root_v1) == 8u, "mrnx_root_v1 alignment");
_Static_assert(offsetof(mrnx_root_v1, program_fingerprint) == 56u,
               "mrnx_root_v1 program offset");
_Static_assert(offsetof(mrnx_root_v1, device_registry_id) == 88u,
               "mrnx_root_v1 device offset");
_Static_assert(sizeof(mrnx_metal_range_v1) == 48u,
               "mrnx_metal_range_v1 ABI");
_Static_assert(_Alignof(mrnx_metal_range_v1) == 8u,
               "mrnx_metal_range_v1 alignment");
_Static_assert(offsetof(mrnx_metal_range_v1, metal_buffer) == 8u,
               "mrnx_metal_range_v1 object offset");
_Static_assert(offsetof(mrnx_metal_range_v1, element_type) == 40u,
               "mrnx_metal_range_v1 type offset");
_Static_assert(sizeof(mrnx_event_point_v1) == 32u,
               "mrnx_event_point_v1 ABI");
_Static_assert(offsetof(mrnx_event_point_v1, shared_event) == 8u,
               "mrnx_event_point_v1 event offset");
_Static_assert(sizeof(mrnx_candidate_key_v1) == 64u,
               "mrnx_candidate_key_v1 ABI");
_Static_assert(offsetof(mrnx_candidate_key_v1, fingerprint) == 56u,
               "mrnx_candidate_key_v1 fingerprint offset");
_Static_assert(sizeof(mrnx_candidate_view_v1) == 112u,
               "mrnx_candidate_view_v1 ABI");
_Static_assert(offsetof(mrnx_candidate_view_v1,
                        candidate_publication_fingerprint) == 80u,
               "mrnx_candidate_view_v1 publication offset");
_Static_assert(sizeof(mrnx_candidate_channel_v1) == 128u,
               "mrnx_candidate_channel_v1 ABI");
_Static_assert(offsetof(mrnx_candidate_channel_v1, values) == 32u,
               "mrnx_candidate_channel_v1 values offset");
_Static_assert(sizeof(mrnx_candidate_channel_v2) == 144u,
               "mrnx_candidate_channel_v2 ABI");
_Static_assert(_Alignof(mrnx_candidate_channel_v2) == 8u,
               "mrnx_candidate_channel_v2 alignment");
_Static_assert(offsetof(mrnx_candidate_channel_v2, values) == 40u,
               "mrnx_candidate_channel_v2 values offset");
_Static_assert(offsetof(mrnx_candidate_channel_v2, validity) == 88u,
               "mrnx_candidate_channel_v2 validity offset");
_Static_assert(offsetof(mrnx_candidate_channel_v2,
                        channel_fingerprint) == 136u,
               "mrnx_candidate_channel_v2 fingerprint offset");
_Static_assert(sizeof(mrnx_candidate_timing_v1) == 40u,
               "mrnx_candidate_timing_v1 ABI");
_Static_assert(offsetof(mrnx_candidate_timing_v1,
                        timing_fingerprint) == 32u,
               "mrnx_candidate_timing_v1 fingerprint offset");
_Static_assert(sizeof(mrnx_candidate_timing_v2) == 56u,
               "mrnx_candidate_timing_v2 ABI");
_Static_assert(offsetof(mrnx_candidate_timing_v2,
                        timing_fingerprint) == 48u,
               "mrnx_candidate_timing_v2 fingerprint offset");
_Static_assert(sizeof(mrnx_exact_inbound_authority_v2) == 112u,
               "mrnx_exact_inbound_authority_v2 ABI");
_Static_assert(offsetof(mrnx_exact_inbound_authority_v2,
                        inbound_authority_fingerprint) == 104u,
               "mrnx_exact_inbound_authority_v2 fingerprint offset");
_Static_assert(sizeof(mrnx_exact_sensor_packet_v2) == 128u,
               "mrnx_exact_sensor_packet_v2 ABI");
_Static_assert(offsetof(mrnx_exact_sensor_packet_v2,
                        candidate_publication_fingerprint) == 120u,
               "mrnx_exact_sensor_packet_v2 fingerprint offset");
_Static_assert(sizeof(mrnx_wire_lease_v1) == 184u,
               "mrnx_wire_lease_v1 ABI");
_Static_assert(offsetof(mrnx_wire_lease_v1, ready) == 152u,
               "mrnx_wire_lease_v1 ready offset");
_Static_assert(sizeof(mrnx_proposal_view_v1) == 280u,
               "mrnx_proposal_view_v1 ABI");
_Static_assert(offsetof(mrnx_proposal_view_v1, ready) == 248u,
               "mrnx_proposal_view_v1 ready offset");
_Static_assert(sizeof(mrnx_applied_view_v1) == 240u,
               "mrnx_applied_view_v1 ABI");
_Static_assert(offsetof(mrnx_applied_view_v1, command_disposition) == 232u,
               "mrnx_applied_view_v1 disposition offset");
_Static_assert(sizeof(mrnx_completion_v1) == 24u,
               "mrnx_completion_v1 ABI");
_Static_assert(offsetof(mrnx_completion_v1, slot_generation) == 16u,
               "mrnx_completion_v1 generation offset");
_Static_assert(sizeof(mrnx_publication_v1) == 24u,
               "mrnx_publication_v1 ABI");
_Static_assert(sizeof(mrnx_publication_v2) == 72u,
               "mrnx_publication_v2 ABI");
_Static_assert(offsetof(mrnx_publication_v2,
                        publication_fingerprint) == 64u,
               "mrnx_publication_v2 fingerprint offset");
_Static_assert(sizeof(mrnx_runtime_config_v3) == 168u, "mrnx_runtime_config_v3 ABI");
_Static_assert(sizeof(mrnx_runtime_config_v4) == 192u, "mrnx_runtime_config_v4 ABI");
_Static_assert(sizeof(mrnx_runtime_config_v5) == 224u, "mrnx_runtime_config_v5 ABI");
_Static_assert(sizeof(mrnx_runtime_config_v6) == 240u, "mrnx_runtime_config_v6 ABI");
_Static_assert(offsetof(mrnx_runtime_config_v8, runtime) == 8u, "mrnx_runtime_config_v8 runtime offset");
_Static_assert(offsetof(mrnx_runtime_config_v8, timestep_nanoseconds) == 8u + sizeof(mrnx_runtime_config_v7), "mrnx_runtime_config_v8 clock offset");
_Static_assert(sizeof(mrnx_physical_root_request_v2) == sizeof(mrnx_physical_root_request_v1), "mrnx_physical_root_request_v2 ABI");
_Static_assert(sizeof(mrnx_physical_root_request_v3) == sizeof(mrnx_physical_root_request_v1), "mrnx_physical_root_request_v3 ABI");
_Static_assert(sizeof(mrnx_exact_clock_info_v1) == 40u, "mrnx_exact_clock_info_v1 ABI");
_Static_assert(offsetof(mrnx_runtime_config_v6, joint_limit_payload_path) == 200u, "mrnx limits offset");
_Static_assert(offsetof(mrnx_runtime_config_v6, costal_cartilage_payload_path) == 216u, "mrnx costal offset");
_Static_assert(offsetof(mrnx_runtime_config_v3, matter_world_package_path) == 144u,
               "mrnx_runtime_config_v3 world offset");
_Static_assert(sizeof(mrnx_runtime_world_info_v1) == 40u, "mrnx world info ABI");
_Static_assert(sizeof(mrnx_runtime_config_v1) == 104u,
               "mrnx_runtime_config_v1 ABI");
_Static_assert(offsetof(mrnx_runtime_config_v1,
                        timestep_microseconds) == 80u,
               "mrnx_runtime_config_v1 timestep offset");
_Static_assert(offsetof(mrnx_runtime_config_v1,
                        maximum_retained_bytes) == 88u,
               "mrnx_runtime_config_v1 retained offset");
_Static_assert(sizeof(mrnx_runtime_info_v1) == 64u,
               "mrnx_runtime_info_v1 ABI");
_Static_assert(sizeof(mrnx_joint_anatomy_v1) == 80u,
               "mrnx_joint_anatomy_v1 ABI");
_Static_assert(sizeof(mrnx_joint_coordinate_anatomy_v1) == 64u,
               "mrnx_joint_coordinate_anatomy_v1 ABI");
_Static_assert(sizeof(mrnx_muscle_attachment_anatomy_v1) == 64u,
               "mrnx_muscle_attachment_anatomy_v1 ABI");
_Static_assert(sizeof(mrnx_runtime_anatomy_info_v1) == 40u,
               "mrnx_runtime_anatomy_info_v1 ABI");
_Static_assert(sizeof(mrnx_aggregate_snapshot_v1) == 504u,
               "mrnx_aggregate_snapshot_v1 ABI");
_Static_assert(offsetof(mrnx_aggregate_snapshot_v1, root) == 40u,
               "mrnx_aggregate_snapshot_v1 root offset");
_Static_assert(offsetof(mrnx_aggregate_snapshot_v1,
                        proprioception) == 248u,
               "mrnx_aggregate_snapshot_v1 channel offset");
_Static_assert(offsetof(mrnx_aggregate_snapshot_v1,
                        interoception) == 376u,
               "mrnx_aggregate_snapshot_v1 interoception offset");
_Static_assert(sizeof(mrnx_aggregate_snapshot_v2) == 1280u,
               "mrnx_aggregate_snapshot_v2 ABI");
_Static_assert(offsetof(mrnx_aggregate_snapshot_v2, channels) == 256u,
               "mrnx_aggregate_snapshot_v2 channels offset");
_Static_assert(sizeof(mrnx_aggregate_snapshot_v3) == 1320u,
               "mrnx_aggregate_snapshot_v3 ABI");
_Static_assert(offsetof(mrnx_aggregate_snapshot_v3, timing) == 248u,
               "mrnx_aggregate_snapshot_v3 timing offset");
_Static_assert(offsetof(mrnx_aggregate_snapshot_v3, channels) == 296u,
               "mrnx_aggregate_snapshot_v3 channels offset");
_Static_assert(sizeof(mrnx_runtime_config_v2) == 136u,
               "mrnx_runtime_config_v2 ABI");
_Static_assert(offsetof(mrnx_runtime_config_v2, culture_pack_path) == 104u,
               "mrnx_runtime_config_v2 culture offset");
_Static_assert(sizeof(mrnx_culture_accepted_view_v1) == 624u,
               "mrnx_culture_accepted_view_v1 ABI");
_Static_assert(offsetof(mrnx_culture_accepted_view_v1,
                        receipt_fingerprint) == 48u,
               "mrnx_culture_accepted_view_v1 receipt offset");
_Static_assert(offsetof(mrnx_culture_accepted_view_v1, buffers) == 96u,
               "mrnx_culture_accepted_view_v1 buffers offset");
_Static_assert(sizeof(mrnx_culture_prepared_view_v1) == 184u,
               "mrnx_culture_prepared_view_v1 ABI");
_Static_assert(sizeof(mrnx_aggregate_snapshot_v4) == 1944u,
               "mrnx_aggregate_snapshot_v4 ABI");
_Static_assert(offsetof(mrnx_aggregate_snapshot_v4, culture) == 1320u,
               "mrnx_aggregate_snapshot_v4 culture offset");
_Static_assert(sizeof(mrnx_aggregate_snapshot_v5) == 2392u,
               "mrnx_aggregate_snapshot_v5 ABI");
_Static_assert(offsetof(mrnx_aggregate_snapshot_v5, timing) == 248u,
               "mrnx_aggregate_snapshot_v5 timing offset");
_Static_assert(offsetof(mrnx_aggregate_snapshot_v5,
                        inbound_authority) == 304u,
               "mrnx_aggregate_snapshot_v5 inbound authority offset");
_Static_assert(offsetof(mrnx_aggregate_snapshot_v5, sensor_packet) == 416u,
               "mrnx_aggregate_snapshot_v5 sensor packet offset");
_Static_assert(offsetof(mrnx_aggregate_snapshot_v5, publication) == 544u,
               "mrnx_aggregate_snapshot_v5 publication offset");
_Static_assert(offsetof(mrnx_aggregate_snapshot_v5, channels) == 616u,
               "mrnx_aggregate_snapshot_v5 channels offset");
_Static_assert(offsetof(mrnx_aggregate_snapshot_v5, culture) == 1768u,
               "mrnx_aggregate_snapshot_v5 culture offset");
_Static_assert(sizeof(mrnx_brain_joint_transaction_v1) == 96u,
               "mrnx_brain_joint_transaction_v1 ABI");
_Static_assert(_Alignof(mrnx_brain_joint_transaction_v1) == 8u,
               "mrnx_brain_joint_transaction_v1 alignment");
_Static_assert(offsetof(mrnx_brain_joint_transaction_v1,
                        transaction_fingerprint) == 88u,
               "mrnx_brain_joint_transaction_v1 fingerprint offset");
_Static_assert(sizeof(mrnx_brain_joint_transaction_v2) == 96u,
               "mrnx_brain_joint_transaction_v2 ABI");
_Static_assert(_Alignof(mrnx_brain_joint_transaction_v2) == 8u,
               "mrnx_brain_joint_transaction_v2 alignment");
_Static_assert(offsetof(mrnx_brain_joint_transaction_v2,
                        clock_domain) == 80u,
               "mrnx_brain_joint_transaction_v2 clock offset");
_Static_assert(offsetof(mrnx_brain_joint_transaction_v2,
                        transaction_fingerprint) == 88u,
               "mrnx_brain_joint_transaction_v2 fingerprint offset");
_Static_assert(sizeof(mrnx_brain_joint_substep_v1) == 72u,
               "mrnx_brain_joint_substep_v1 ABI");
_Static_assert(_Alignof(mrnx_brain_joint_substep_v1) == 8u,
               "mrnx_brain_joint_substep_v1 alignment");
_Static_assert(offsetof(mrnx_brain_joint_substep_v1,
                        substep_fingerprint) == 64u,
               "mrnx_brain_joint_substep_v1 fingerprint offset");
_Static_assert(sizeof(mrnx_brain_joint_substep_v2) == 72u,
               "mrnx_brain_joint_substep_v2 ABI");
_Static_assert(_Alignof(mrnx_brain_joint_substep_v2) == 8u,
               "mrnx_brain_joint_substep_v2 alignment");
_Static_assert(offsetof(mrnx_brain_joint_substep_v2,
                        clock_domain) == 56u,
               "mrnx_brain_joint_substep_v2 clock offset");
_Static_assert(offsetof(mrnx_brain_joint_substep_v2,
                        substep_fingerprint) == 64u,
               "mrnx_brain_joint_substep_v2 fingerprint offset");
_Static_assert(sizeof(mrnx_brain_motor_candidate_v1) == 152u,
               "mrnx_brain_motor_candidate_v1 ABI");
_Static_assert(_Alignof(mrnx_brain_motor_candidate_v1) == 8u,
               "mrnx_brain_motor_candidate_v1 alignment");
_Static_assert(offsetof(mrnx_brain_motor_candidate_v1,
                        candidate_fingerprint) == 144u,
               "mrnx_brain_motor_candidate_v1 fingerprint offset");
_Static_assert(sizeof(mrnx_brain_motor_candidate_v2) == 152u,
               "mrnx_brain_motor_candidate_v2 ABI");
_Static_assert(_Alignof(mrnx_brain_motor_candidate_v2) == 8u,
               "mrnx_brain_motor_candidate_v2 alignment");
_Static_assert(offsetof(mrnx_brain_motor_candidate_v2,
                        clock_domain) == 124u,
               "mrnx_brain_motor_candidate_v2 clock offset");
_Static_assert(offsetof(mrnx_brain_motor_candidate_v2,
                        candidate_fingerprint) == 144u,
               "mrnx_brain_motor_candidate_v2 fingerprint offset");
_Static_assert(sizeof(mrnx_brain_motor_output_header_v2) == 80u,
               "mrnx_brain_motor_output_header_v2 ABI");
_Static_assert(_Alignof(mrnx_brain_motor_output_header_v2) == 16u,
               "mrnx_brain_motor_output_header_v2 alignment");
_Static_assert(offsetof(mrnx_brain_motor_output_header_v2,
                        clock_domain) == 60u,
               "mrnx_brain_motor_output_header_v2 clock offset");
_Static_assert(offsetof(mrnx_brain_motor_output_header_v2,
                        output_fingerprint) == 72u,
               "mrnx_brain_motor_output_header_v2 fingerprint offset");
_Static_assert(sizeof(mrnx_brain_motor_ready_gate_v1) == 160u,
               "mrnx_brain_motor_ready_gate_v1 ABI");
_Static_assert(offsetof(mrnx_brain_motor_ready_gate_v1,
                        gate_fingerprint) == 152u,
               "mrnx_brain_motor_ready_gate_v1 fingerprint offset");
_Static_assert(sizeof(mrnx_brain_motor_ready_gate_v2) == 160u,
               "mrnx_brain_motor_ready_gate_v2 ABI");
_Static_assert(_Alignof(mrnx_brain_motor_ready_gate_v2) == 16u,
               "mrnx_brain_motor_ready_gate_v2 alignment");
_Static_assert(offsetof(mrnx_brain_motor_ready_gate_v2,
                        clock_domain) == 144u,
               "mrnx_brain_motor_ready_gate_v2 clock offset");
_Static_assert(offsetof(mrnx_brain_motor_ready_gate_v2,
                        gate_fingerprint) == 152u,
               "mrnx_brain_motor_ready_gate_v2 fingerprint offset");
_Static_assert(sizeof(mrnx_physical_root_request_v1) == 600u,
               "mrnx_physical_root_request_v1 ABI");
_Static_assert(offsetof(mrnx_physical_root_request_v1,
                        motor_header) == 328u,
               "mrnx_physical_root_request_v1 motor header offset");
_Static_assert(offsetof(mrnx_physical_root_request_v1,
                        motor_ready_gate) == 520u,
               "mrnx_physical_root_request_v1 gate offset");
_Static_assert(offsetof(mrnx_physical_root_request_v1,
                        motor_ready) == 568u,
               "mrnx_physical_root_request_v1 event offset");
_Static_assert(sizeof(mrnx_physical_root_request_v2) == 600u,
               "mrnx_physical_root_request_v2 ABI");
_Static_assert(offsetof(mrnx_physical_root_request_v2,
                        motor_header) == 328u,
               "mrnx_physical_root_request_v2 motor header offset");
_Static_assert(offsetof(mrnx_physical_root_request_v2,
                        motor_ready_gate) == 520u,
               "mrnx_physical_root_request_v2 gate offset");
_Static_assert(offsetof(mrnx_physical_root_request_v2,
                        motor_ready) == 568u,
               "mrnx_physical_root_request_v2 event offset");
_Static_assert(sizeof(mrnx_physical_root_request_v3) == 600u,
               "mrnx_physical_root_request_v3 ABI");
_Static_assert(offsetof(mrnx_physical_root_request_v3,
                        candidate) == 176u,
               "mrnx_physical_root_request_v3 candidate offset");
_Static_assert(offsetof(mrnx_physical_root_request_v3,
                        motor_header) == 328u,
               "mrnx_physical_root_request_v3 motor header offset");
_Static_assert(offsetof(mrnx_physical_root_request_v3,
                        motor_ready_gate) == 520u,
               "mrnx_physical_root_request_v3 gate offset");
_Static_assert(offsetof(mrnx_physical_root_request_v3,
                        motor_ready) == 568u,
               "mrnx_physical_root_request_v3 event offset");
#endif

#undef MRNX_ALIGN16

#endif // METALROBO_MRNX_BRIDGE_V1_H

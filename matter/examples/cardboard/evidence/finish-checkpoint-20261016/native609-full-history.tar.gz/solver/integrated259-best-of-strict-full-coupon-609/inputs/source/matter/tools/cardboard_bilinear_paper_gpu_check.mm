#import <Foundation/Foundation.h>
#import <Metal/Metal.h>
#include <CommonCrypto/CommonDigest.h>

#include "numi/matter/matter.hpp"
#include "numi/matter/detail.hpp"
#include "cardboard_bilinear_material_oracle.hpp"

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <map>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

namespace {
using namespace numi::matter;
namespace oracle = numi_cardboard_bilinear_oracle;
using Matrix = oracle::Matrix;
using State = oracle::State;

constexpr Matrix kIdentity{1,0,0, 0,1,0, 0,0,1};
constexpr double kRelativeGate = 1.0e-3;
constexpr char kLinerHash[] = "a2720b90f2004f2eccf180063e7ecc4e0acdda93f700c4fd357914fc24d2255a";
constexpr char kMediumHash[] = "76f2bef552822708c36b5acc9f92bd44e7bb92c578e5e46adb64a1a2e82e47f9";
constexpr char kSourceCsvHash[] = "83f5778db797f0fb9996416848abb91c18f9102f4c3707aea9ea267b1eeb0d82";

void require(bool condition, const std::string& message) {
    if (!condition) throw std::runtime_error(message);
}

std::string sha256(const std::filesystem::path& path) {
    std::ifstream input(path, std::ios::binary);
    require(input.good(), "cannot read hash-bound input: " + path.string());
    std::vector<unsigned char> bytes((std::istreambuf_iterator<char>(input)), {});
    require(bytes.size() <= static_cast<std::size_t>(UINT32_MAX), "hash input exceeds CommonCrypto limit");
    unsigned char digest[CC_SHA256_DIGEST_LENGTH]{};
    require(CC_SHA256(bytes.data(), static_cast<CC_LONG>(bytes.size()), digest)!=nullptr,
            "CommonCrypto SHA256 failed");
    static constexpr char hex[]="0123456789abcdef";
    std::string result;
    result.reserve(2u*CC_SHA256_DIGEST_LENGTH);
    for (const unsigned char value : digest) {
        result.push_back(hex[value>>4]);
        result.push_back(hex[value&0xf]);
    }
    return result;
}

std::vector<std::string> parseCsvRow(const std::string& line) {
    std::vector<std::string> fields;
    std::string field;
    bool quoted=false;
    for (std::size_t i=0;i<line.size();++i) {
        const char c=line[i];
        if (c=='"') {
            if (quoted && i+1u<line.size() && line[i+1u]=='"') { field.push_back('"'); ++i; }
            else quoted=!quoted;
        } else if (c==',' && !quoted) {
            fields.push_back(field); field.clear();
        } else field.push_back(c);
    }
    require(!quoted,"unterminated quoted field in source CSV");
    fields.push_back(field);
    return fields;
}

struct Curve {
    double yieldStrain=0.0;
    double endpointStrain=0.0;
    double tangentMPa=0.0;
    double tangentLowMPa=0.0;
    double tangentHighMPa=0.0;
    bool hasYield=false;
    bool hasEndpoint=false;
};

using Curves = std::map<std::pair<std::string,std::string>,Curve>;

Curves readSourceCurves(const std::filesystem::path& path) {
    std::ifstream input(path);
    require(input.good(),"cannot read registered source CSV");
    std::string line;
    require(bool(std::getline(input,line)),"empty registered source CSV");
    const auto names=parseCsvRow(line);
    std::map<std::string,std::size_t> columns;
    for (std::size_t i=0;i<names.size();++i) columns.emplace(names[i],i);
    for (const char* name : {"component","axis","point_role","strain_mm_per_mm",
                             "postyield_tangent_MPa","postyield_tangent_low_MPa",
                             "postyield_tangent_high_MPa"})
        require(columns.contains(name),std::string("source CSV missing column ")+name);
    Curves curves;
    while (std::getline(input,line)) {
        if (line.empty()) continue;
        const auto row=parseCsvRow(line);
        require(row.size()==names.size(),"registered source CSV row width changed");
        const std::string& component=row[columns.at("component")];
        const std::string& axis=row[columns.at("axis")];
        const std::string& role=row[columns.at("point_role")];
        if (role!="published_Table_1_tensile_yield_anchor" &&
            role!="digitized_bilinear_fit_endpoint") continue;
        const double strain=std::stod(row[columns.at("strain_mm_per_mm")]);
        auto& curve=curves[{component,axis}];
        curve.tangentMPa=std::stod(row[columns.at("postyield_tangent_MPa")]);
        curve.tangentLowMPa=std::stod(row[columns.at("postyield_tangent_low_MPa")]);
        curve.tangentHighMPa=std::stod(row[columns.at("postyield_tangent_high_MPa")]);
        if (role=="published_Table_1_tensile_yield_anchor") {
            require(!curve.hasYield,"duplicate Table 1 source anchor");
            curve.yieldStrain=strain; curve.hasYield=true;
        } else {
            require(!curve.hasEndpoint,"duplicate digitized endpoint");
            curve.endpointStrain=strain; curve.hasEndpoint=true;
        }
    }
    for (const auto& key : {std::pair<std::string,std::string>{"liner","MD"},
                            {"liner","CD"},{"medium_NSSC","MD"},{"medium_NSSC","CD"}}) {
        const auto it=curves.find(key);
        require(it!=curves.end() && it->second.hasYield && it->second.hasEndpoint &&
                it->second.endpointStrain>it->second.yieldStrain,
                "registered CSV lacks a valid yield/endpoint pair");
    }
    return curves;
}

double cpuStressFreeAxialMPa(const ConstitutiveProgram& program,const unsigned axis,
                             const double axialStrain) {
    Matrix f=kIdentity;
    const unsigned axialComponent=axis==0u?0u:4u;
    f[axialComponent]=1.0+axialStrain;
    const std::array<unsigned,2> lateralComponents=axis==0u
        ?std::array<unsigned,2>{4u,8u}:std::array<unsigned,2>{0u,8u};
    const std::array<unsigned,2> lateralF=axis==0u
        ?std::array<unsigned,2>{4u,8u}:std::array<unsigned,2>{0u,8u};
    f[lateralF[0]]=1.0-0.18*axialStrain;
    f[lateralF[1]]=1.0-0.01*axialStrain;
    const State accepted{};
    oracle::Point point;
    for (unsigned iteration=0;iteration<12u;++iteration) {
        point=oracle::project(program,f,accepted);
        const std::array<double,2> residual{
            point.firstPiolaPa[lateralComponents[0]],
            point.firstPiolaPa[lateralComponents[1]]};
        const double norm=std::max(std::abs(residual[0]),std::abs(residual[1]));
        if (norm<2.0e-2) break;
        std::array<double,4> jac{};
        for (unsigned column=0;column<2u;++column) {
            Matrix direction{}; direction[lateralF[column]]=1.0;
            const Matrix tangent=oracle::tangent(program,f,direction,accepted,point.state);
            for (unsigned row=0;row<2u;++row)
                jac[2u*row+column]=tangent[lateralComponents[row]];
        }
        const double det=jac[0]*jac[3]-jac[1]*jac[2];
        require(std::isfinite(det)&&std::abs(det)>1.0e-10,
                "CPU bilinear stress-free lateral tangent is singular");
        const std::array<double,2> correction{
            (-jac[3]*residual[0]+jac[1]*residual[1])/det,
            (jac[2]*residual[0]-jac[0]*residual[1])/det};
        bool acceptedStep=false;
        double step=1.0;
        for (unsigned backtrack=0;backtrack<16u;++backtrack) {
            Matrix trialF=f;
            for (unsigned c=0;c<2u;++c) trialF[lateralF[c]]+=step*correction[c];
            const auto trial=oracle::project(program,trialF,accepted);
            const double trialNorm=std::max(
                std::abs(trial.firstPiolaPa[lateralComponents[0]]),
                std::abs(trial.firstPiolaPa[lateralComponents[1]]));
            if (trialNorm<norm) { f=trialF; acceptedStep=true; break; }
            step*=0.5;
        }
        require(acceptedStep,"CPU bilinear stress-free lateral solve stalled");
    }
    point=oracle::project(program,f,accepted);
    return point.firstPiolaPa[axialComponent]*1.0e-6;
}

std::string diagnostics(const std::vector<Diagnostic>& values) {
    std::string result;
    for (const auto& value : values) result+=value.message+"; ";
    return result;
}

CompiledWorld cook(const MaterialProgram& material) {
    WorldSource source;
    source.materials={material};
    source.gravity={0,0,0};
    source.environmentCount=1;
    source.frameTimestep=1.0e-4;
    ObjectSource object;
    object.name="bilinear_material_point_only";
    object.representation=Representation::fem;
    object.deformableContact=false;
    object.deformableSelfContact=false;
    object.mixedFEM=false;
    object.femNodes={{{0,0,0}},{{.01,0,0}},{{0,.01,0}},{{0,0,.01}}};
    object.tetrahedra={{{0,1,2,3}}};
    object.characteristicLength=.01;
    source.objects={object};
    const auto result=compileWorld(source,{.maximumRateExponent=0u,.emitSpecializedMetal=false,
                                           .localMaterialNewtonIterations=16u});
    require(result.succeeded(),"bilinear material compile failed: "+diagnostics(result.diagnostics));
    require(result.world.materials.size()==1u && result.world.constitutive.size()==1u,
            "material-point fixture did not compile one constitutive program");
    const auto& compiled=result.world.constitutive[0];
    require(compiled.material.internalState.size()==15u &&
            compiled.implicitResiduals.size()==15u &&
            compiled.implicitJacobians.size()==225u &&
            compiled.implicitDeformationDirections.size()==15u &&
            compiled.stressStateDerivatives.size()==135u,
            "expected full generic 15-state residual/Jacobian/tangent chain");
    require(!compiled.material.paperHillScalarInitializer &&
            !compiled.material.paperCompensatedArithmetic &&
            !compiled.material.paperHillAccurateProjection,
            "bilinear check must exercise the ordinary generic production policy");
    require(result.world.materials[0].stateCount==15u,
            "compiled Metal material does not expose all 15 persistent states");
    require(result.world.stateInitials.size()==15u,
            "one-tet fixture has unexpected state-initial arena layout");
    return result.world;
}

template<class T>
id<MTLBuffer> makeBuffer(id<MTLDevice> device,const std::vector<T>& values) {
    T zero{};
    const void* bytes=values.empty()?static_cast<const void*>(&zero):static_cast<const void*>(values.data());
    return [device newBufferWithBytes:bytes
                               length:sizeof(T)*std::max<std::size_t>(1u,values.size())
                              options:MTLResourceStorageModeShared];
}

struct Response {
    bool valid=false;
    bool projectionValid=false;
    Matrix p{};
    Matrix tangent{};
    State state{};
    float residual=0.0f;
    unsigned iterations=0u;
    unsigned flags=0u;
    unsigned failure=0u;
};

struct MetalInstrument {
    id<MTLDevice> device=nil;
    id<MTLCommandQueue> queue=nil;
    id<MTLComputePipelineState> pipeline=nil;

    MetalInstrument() {
        device=MTLCreateSystemDefaultDevice();
        require(device!=nil,"Metal device unavailable");
        const std::string name=[[device name] UTF8String];
        require(name.find("Apple")!=std::string::npos &&
                name.find("Paravirtual")==std::string::npos,
                "physical Apple GPU required for this native material check");
        queue=[device newCommandQueue];
        NSError* error=nil;
        id<MTLLibrary> library=[device newLibraryWithURL:
            [NSURL fileURLWithPath:@NUMI_CARDBOARD_PAPER_METALLIB] error:&error];
        require(library!=nil,"cardboard_paper_check.metallib is missing");
        id<MTLFunction> function=[library newFunctionWithName:@"cardboard_paper_check"];
        require(function!=nil,"existing production material-point kernel is missing");
        pipeline=[device newComputePipelineStateWithFunction:function error:&error];
        require(pipeline!=nil,"could not build existing production material-point pipeline");
        std::cout<<"device=\""<<name<<"\" kernel=cardboard_paper_check"
            <<" scope=native_metal_generic_material_point_only physical_steps=0\n";
    }

    Response evaluate(const CompiledWorld& world,const Matrix& inputF,const Matrix& inputH,
                      const State& accepted) {
        std::vector<float> inputs;
        inputs.reserve(28u);
        Matrix realizedF{},realizedH{};
        for (unsigned i=0;i<9u;++i) { realizedF[i]=static_cast<float>(inputF[i]); inputs.push_back(static_cast<float>(inputF[i])); }
        for (unsigned i=0;i<9u;++i) { realizedH[i]=static_cast<float>(inputH[i]); inputs.push_back(static_cast<float>(inputH[i])); }
        for (unsigned i=0;i<9u;++i) inputs.push_back(0.0f);
        inputs.push_back(0.0f); // ordinary generic projection, no 13-state-only accurate policy
        std::vector<float> acceptedFloat(accepted.begin(),accepted.end());
        std::vector<float> parameterValues;
        parameterValues.reserve(world.parameters.size());
        for (const auto& value : world.parameters) parameterValues.push_back(value.valueAndBounds.x);
        const std::vector<float> outputZero(25u+2u*NM_MAX_MATERIAL_STATE,0.0f);
        std::array<id<MTLBuffer>,7> buffers{
            makeBuffer(device,std::vector<NMMaterialGPU>{world.materials.at(0)}),
            makeBuffer(device,world.scalarPrograms),
            makeBuffer(device,world.instructions),
            makeBuffer(device,parameterValues),
            makeBuffer(device,acceptedFloat),
            makeBuffer(device,inputs),
            makeBuffer(device,outputZero)};
        require(std::all_of(buffers.begin(),buffers.end(),[](id<MTLBuffer> x){return x!=nil;}),
                "failed allocating material-point Metal buffers");
        id<MTLCommandBuffer> command=[queue commandBuffer];
        id<MTLComputeCommandEncoder> encoder=[command computeCommandEncoder];
        [encoder setComputePipelineState:pipeline];
        for (NSUInteger i=0;i<buffers.size();++i) [encoder setBuffer:buffers[i] offset:0 atIndex:i];
        [encoder dispatchThreads:MTLSizeMake(1,1,1) threadsPerThreadgroup:MTLSizeMake(1,1,1)];
        [encoder endEncoding]; [command commit]; [command waitUntilCompleted];
        require(command.status==MTLCommandBufferStatusCompleted,
                command.error?std::string([[command.error description] UTF8String]):
                    "Metal material-point command did not complete");
        const auto* out=static_cast<const float*>(buffers[6].contents);
        Response result;
        result.valid=out[0]==1.0f;
        for (unsigned i=0;i<9u;++i) { result.p[i]=out[1u+i]; result.tangent[i]=out[10u+i]; }
        for (unsigned i=0;i<oracle::kStateCount;++i) result.state[i]=out[19u+i];
        result.projectionValid=out[19u+NM_MAX_MATERIAL_STATE]==1.0f;
        result.residual=out[20u+NM_MAX_MATERIAL_STATE];
        result.iterations=static_cast<unsigned>(out[22u+NM_MAX_MATERIAL_STATE]);
        result.flags=static_cast<unsigned>(out[23u+NM_MAX_MATERIAL_STATE]);
        result.failure=static_cast<unsigned>(out[24u+NM_MAX_MATERIAL_STATE]);
        // Keep exact input roundoff visible to the finite-difference check.
        for (unsigned i=0;i<9u;++i) {
            require(std::isfinite(realizedF[i]) && std::isfinite(realizedH[i]),
                    "nonfinite Metal input conversion");
        }
        return result;
    }
};

double norm(const Matrix& values) {
    double sum=0.0;
    for (double value : values) sum+=value*value;
    return std::sqrt(sum);
}

double stateNorm(const State& values) {
    double sum=0.0;
    for (double value : values) sum+=value*value;
    return std::sqrt(sum);
}

double relativeError(const Matrix& actual,const Matrix& expected) {
    Matrix difference{};
    for (unsigned i=0;i<9u;++i) difference[i]=actual[i]-expected[i];
    return norm(difference)/norm(expected);
}

double relativeStateError(const State& actual,const State& expected) {
    State difference{};
    for (unsigned i=0;i<oracle::kStateCount;++i) difference[i]=actual[i]-expected[i];
    return stateNorm(difference)/stateNorm(expected);
}

State asDouble(const Response& value) { return value.state; }

void validateStateAndStress(const std::string& label,const Response& metal,
                            const oracle::Point& exact,const State& accepted) {
    if (!metal.valid || !metal.projectionValid) {
        std::ostringstream message;
        message<<label<<" Metal projection/stress validity failed"
            <<" valid="<<metal.valid<<" projection_valid="<<metal.projectionValid
            <<" residual="<<metal.residual<<" iterations="<<metal.iterations
            <<" flags=0x"<<std::hex<<metal.flags<<std::dec
            <<" failure="<<metal.failure;
        throw std::runtime_error(message.str());
    }
    Matrix actualP=metal.p;
    const double exactPNorm=norm(exact.firstPiolaPa);
    if (exactPNorm<=1.0e-2) {
        std::cout<<"{\"case\":\""<<label<<"\",\"quantity\":\"first_piola\","
            <<"\"status\":\"inconclusive_zero_response\",\"oracle_norm_Pa\":"<<exactPNorm
            <<",\"noise_floor\":null}\n";
    } else {
        const double error=relativeError(actualP,exact.firstPiolaPa);
        std::cout<<"{\"case\":\""<<label<<"\",\"quantity\":\"first_piola\","
            <<"\"relative_error\":"<<error<<",\"status\":\""
            <<(error<=kRelativeGate?"pass":"fail")<<"\"}\n";
        require(error<=kRelativeGate,label+" Metal first Piola differs from FP64 bytecode oracle by more than 1e-3");
    }
    const double exactStateNorm=stateNorm(exact.state);
    if (exactStateNorm<=1.0e-10) {
        std::cout<<"{\"case\":\""<<label<<"\",\"quantity\":\"state\","
            <<"\"status\":\"inconclusive_zero_response\",\"oracle_norm\":"<<exactStateNorm
            <<",\"noise_floor\":null}\n";
    } else {
        const double error=relativeStateError(asDouble(metal),exact.state);
        std::cout<<"{\"case\":\""<<label<<"\",\"quantity\":\"all_15_states\","
            <<"\"relative_error\":"<<error<<",\"history13\":"<<metal.state[13]
            <<",\"history14\":"<<metal.state[14]<<",\"status\":\""
            <<(error<=kRelativeGate?"pass":"fail")<<"\"}\n";
        require(error<=kRelativeGate,label+" complete projected state differs from FP64 bytecode oracle by more than 1e-3");
    }
    for (unsigned state=12u;state<15u;++state)
        require(metal.state[state]+2.0e-7>=accepted[state],
                label+" irreversible multiplier/history regressed at state "+std::to_string(state));
}

void validateFullTangent(const std::string& label,MetalInstrument& metal,
                         const CompiledWorld& world,const Matrix& f,
                         const State& accepted,const oracle::Point& exact) {
    unsigned resolved=0u;
    double worst=0.0;
    for (unsigned column=0;column<9u;++column) {
        Matrix direction{}; direction[column]=1.0;
        const Response actual=metal.evaluate(world,f,direction,accepted);
        require(actual.valid && actual.projectionValid,label+" tangent column projection failed");
        const Matrix expected=oracle::tangent(world.constitutive.at(0),f,direction,
                                              accepted,exact.state);
        const double expectedNorm=norm(expected);
        if (expectedNorm<=1.0e-2) {
            std::cout<<"{\"case\":\""<<label<<"\",\"tangent_column\":"<<column
                     <<",\"status\":\"inconclusive_zero_response\",\"oracle_norm_Pa_per_F\":"
                     <<expectedNorm<<"}\n";
            continue;
        }
        const double error=relativeError(actual.tangent,expected);
        worst=std::max(worst,error); ++resolved;
        std::cout<<"{\"case\":\""<<label<<"\",\"tangent_column\":"<<column
                 <<",\"relative_error\":"<<error<<",\"gate\":"<<kRelativeGate
                 <<",\"status\":\""<<(error<=kRelativeGate?"pass":"fail")<<"\"}\n";
        require(error<=kRelativeGate,label+" full algorithmic tangent column exceeds 1e-3 gate");
    }
    require(resolved>0u,label+" produced no resolved tangent columns");
    std::cout<<"{\"case\":\""<<label<<"\",\"quantity\":\"complete_9x9_algorithmic_tangent\","
        <<"\"resolved_columns\":"<<resolved<<",\"worst_relative_error\":"<<worst
        <<",\"includes_implicit_states\":15,\"status\":\"pass\"}\n";
}

void validateBranchAwareFD(const std::string& label,MetalInstrument& metal,
                           const CompiledWorld& world,const Matrix& centerF,
                           const unsigned axis,const State& accepted,
                           const Response& center) {
    Matrix direction{};
    const unsigned component=axis==0u?0u:4u;
    direction[component]=1.0;
    constexpr std::array<double,2> epsilons{5.0e-4,2.5e-4};
    std::array<Matrix,2> estimates{};
    for (unsigned level=0;level<epsilons.size();++level) {
        Matrix plusF=centerF,minusF=centerF;
        plusF[component]+=epsilons[level];
        minusF[component]-=epsilons[level];
        const float centerInput=static_cast<float>(centerF[component]);
        const float plusInput=static_cast<float>(plusF[component]);
        const float minusInput=static_cast<float>(minusF[component]);
        const double realizedPlus=double(plusInput)-double(centerInput);
        const double realizedMinus=double(centerInput)-double(minusInput);
        require(realizedPlus>0.0 && realizedMinus>0.0,
                label+" finite-difference perturbation is not representable in FP32");
        const Response plus=metal.evaluate(world,plusF,direction,accepted);
        const Response minus=metal.evaluate(world,minusF,direction,accepted);
        require(plus.valid&&plus.projectionValid&&minus.valid&&minus.projectionValid,
                label+" branch-aware finite-difference projection failed");
        const bool plusPlastic=plus.state[12]-accepted[12]>1.0e-8;
        const bool minusPlastic=minus.state[12]-accepted[12]>1.0e-8;
        const bool centerPlastic=center.state[12]-accepted[12]>1.0e-8;
        require(centerPlastic&&plusPlastic&&minusPlastic,
                label+" FD perturbations did not remain on the loaded plastic branch");
        for (unsigned row=0;row<9u;++row)
            estimates[level][row]=(plus.p[row]-minus.p[row])/(realizedPlus+realizedMinus);
        std::cout<<"{\"case\":\""<<label<<"\",\"fd_level\":"<<level
            <<",\"requested_epsilon\":"<<epsilons[level]
            <<",\"realized_plus\":"<<realizedPlus<<",\"realized_minus\":"<<realizedMinus
            <<",\"branch\":\"plastic\",\"projection_residual_plus\":"<<plus.residual
            <<",\"projection_residual_minus\":"<<minus.residual<<"}\n";
    }
    Matrix richardson{};
    for (unsigned i=0;i<9u;++i)
        richardson[i]=(4.0*estimates[1][i]-estimates[0][i])/3.0;
    const double noise=relativeError(estimates[0],estimates[1]);
    const double tangentError=relativeError(center.tangent,richardson);
    std::cout<<"{\"case\":\""<<label<<"\",\"quantity\":\"branch_aware_centered_fd\","
        <<"\"step_halving_noise_relative\":"<<noise<<",\"metal_tangent_relative_error\":"
        <<tangentError<<",\"gate\":"<<kRelativeGate<<",\"status\":\""
        <<(noise<=kRelativeGate?(tangentError<=kRelativeGate?"pass":"fail_resolved_tangent_mismatch"):
                                  "inconclusive_fd_noise")
        <<"\"}\n";
    // The exact FP64 compiled tangent is also checked for every column. This
    // FD gate is enforced only when step-halving measured its own noise below
    // 1e-3; noisier comparisons remain explicitly inconclusive.
    if (noise<=kRelativeGate)
        require(tangentError<=kRelativeGate,
                label+" branch-preserving resolved Metal FD disagrees with tangent by more than 1e-3");
}

struct MaterialFixture {
    std::string role;
    std::string assetName;
    std::string assetHash;
    std::string csvComponent;
    std::filesystem::path path;
};

void runMaterial(MetalInstrument& metal,const MaterialFixture& fixture,
                 const Curves& curves) {
    const std::string digest=sha256(fixture.path);
    require(digest==fixture.assetHash,fixture.role+" bilinear asset SHA256 does not match registered source identity");
    const auto parsed=parseMatterFile(fixture.path.string());
    require(parsed.succeeded(),fixture.role+" parse failed: "+diagnostics(parsed.diagnostics));
    const MaterialProgram& material=parsed.material;
    require(material.name==fixture.assetName,fixture.role+" parsed material name is not the registered asset");
    const CompiledWorld world=cook(material);
    const auto& program=world.constitutive.at(0);
    std::cout<<"{\"material\":\""<<material.name<<"\",\"asset_sha256\":\""<<digest
        <<"\",\"state_count\":15,\"source_csv_sha256\":\""<<kSourceCsvHash
        <<"\",\"cpu_digitized_slope_check\":\"separately_recorded_in_compiler_test\"}\n";

    State accepted{};
    for (unsigned i=0;i<oracle::kStateCount;++i) accepted[i]=world.stateInitials[i];
    const Matrix zeroDirection{};
    const Response rest=metal.evaluate(world,kIdentity,zeroDirection,accepted);
    const oracle::Point restExact=oracle::project(program,kIdentity,accepted);
    validateStateAndStress(material.name+"_rest",rest,restExact,accepted);
    validateFullTangent(material.name+"_rest",metal,world,kIdentity,accepted,restExact);
    accepted=asDouble(rest);

    for (unsigned axis=0;axis<2u;++axis) {
        const std::string axisName=axis==0u?"MD":"CD";
        const auto& curve=curves.at({fixture.csvComponent,axisName});
        const double strain=0.5*(curve.yieldStrain+curve.endpointStrain);
        Matrix loadedF=kIdentity;
        const unsigned component=axis==0u?0u:4u;
        loadedF[component]=1.0+strain;
        const Response loaded=metal.evaluate(world,loadedF,zeroDirection,accepted);
        const oracle::Point loadedExact=oracle::project(program,loadedF,accepted);
        validateStateAndStress(material.name+"_"+axisName+"_load",loaded,loadedExact,accepted);
        require(loaded.state[12]-accepted[12]>1.0e-8,
                material.name+" "+axisName+" load did not activate plastic flow");
        const unsigned channel=axis==0u?13u:14u;
        require(loaded.state[channel]>accepted[channel]+1.0e-8,
                material.name+" "+axisName+" tensile load did not update its directional hardening history");
        validateFullTangent(material.name+"_"+axisName+"_load",metal,world,
                            loadedF,accepted,loadedExact);
        Matrix axisDirection{}; axisDirection[component]=1.0;
        const Response tangentCenter=metal.evaluate(world,loadedF,axisDirection,accepted);
        validateBranchAwareFD(material.name+"_"+axisName+"_load",metal,world,
                              loadedF,axis,accepted,tangentCenter);

        const State loadedState=asDouble(loaded);
        const Response unload=metal.evaluate(world,kIdentity,zeroDirection,loadedState);
        const oracle::Point unloadExact=oracle::project(program,kIdentity,loadedState);
        validateStateAndStress(material.name+"_"+axisName+"_unload",unload,unloadExact,loadedState);
        const State unloadedState=asDouble(unload);
        const Response reload=metal.evaluate(world,loadedF,zeroDirection,unloadedState);
        const oracle::Point reloadExact=oracle::project(program,loadedF,unloadedState);
        validateStateAndStress(material.name+"_"+axisName+"_reload",reload,reloadExact,unloadedState);
        for (unsigned state=12u;state<15u;++state) {
            require(unload.state[state]+2.0e-7>=loaded.state[state],
                    material.name+" unloading lost irreversible state "+std::to_string(state));
            require(reload.state[state]+2.0e-7>=unload.state[state],
                    material.name+" reloading lost irreversible state "+std::to_string(state));
        }
        std::cout<<"{\"material\":\""<<material.name<<"\",\"axis\":\""<<axisName
            <<"\",\"source_yield_strain\":"<<curve.yieldStrain
            <<",\"source_digitized_endpoint_strain\":"<<curve.endpointStrain
            <<",\"instrument_strain\":"<<strain
            <<",\"history13_load_unload_reload\":["<<loaded.state[13]<<','<<unload.state[13]<<','<<reload.state[13]
            <<"],\"history14_load_unload_reload\":["<<loaded.state[14]<<','<<unload.state[14]<<','<<reload.state[14]
            <<"],\"multiplier_load_unload_reload\":["<<loaded.state[12]<<','<<unload.state[12]<<','<<reload.state[12]
            <<"],\"physical_steps\":0}\n";
    }
}

} // namespace

int main(int argc,char** argv) {
    @autoreleasepool {
        try {
            if (argc==5 && std::string(argv[1])=="--cpu-source-fit-diagnose") {
                const std::filesystem::path linerPath=argv[2],mediumPath=argv[3],csvPath=argv[4];
                require(sha256(csvPath)==kSourceCsvHash,
                        "CPU fit diagnostic registered CSV SHA256 changed");
                const Curves curves=readSourceCurves(csvPath);
                for (const auto& entry : {
                    std::pair<std::filesystem::path,std::string>{linerPath,"liner"},
                    {mediumPath,"medium_NSSC"}}) {
                    const auto parsed=parseMatterFile(entry.first.string());
                    require(parsed.succeeded(),"CPU fit diagnostic parse failed: "+
                            diagnostics(parsed.diagnostics));
                    const auto compiled=detail::compileConstitutive(parsed.material,
                                                                     NM_EXPRESSION_STACK_CAPACITY);
                    require(compiled.succeeded(),"CPU fit diagnostic compile failed: "+
                            diagnostics(compiled.diagnostics));
                    for (const auto& axis : {std::string("MD"),std::string("CD")}) {
                        const auto& curve=curves.at({entry.second,axis});
                        const double span=curve.endpointStrain-curve.yieldStrain;
                        const double aStrain=curve.yieldStrain+0.30*span;
                        const double bStrain=curve.yieldStrain+0.70*span;
                        const unsigned axisIndex=axis=="MD"?0u:1u;
                        const double a=cpuStressFreeAxialMPa(compiled.program,axisIndex,aStrain);
                        const double b=cpuStressFreeAxialMPa(compiled.program,axisIndex,bStrain);
                        const double observed=(b-a)/(bStrain-aStrain);
                        std::cout<<std::setprecision(10)
                            <<"{\"material\":\""<<parsed.material.name
                            <<"\",\"axis\":\""<<axis<<"\",\"observed_slope_MPa\":"<<observed
                            <<",\"digitized_slope_MPa\":"<<curve.tangentMPa
                            <<",\"digitized_interval_MPa\":["<<curve.tangentLowMPa<<','
                            <<curve.tangentHighMPa<<"],\"inside_interval\":"
                            <<(observed>=curve.tangentLowMPa&&observed<=curve.tangentHighMPa?"true":"false")
                            <<",\"diagnostic_only\":true}\n";
                    }
                }
                return 0;
            }
            if (argc==3 && std::string(argv[1])=="--cpu-rest-diagnose") {
                const auto parsed=parseMatterFile(argv[2]);
                require(parsed.succeeded(),"CPU diagnostic parse failed: "+diagnostics(parsed.diagnostics));
                const auto compiled=detail::compileConstitutive(parsed.material,
                                                                 NM_EXPRESSION_STACK_CAPACITY);
                require(compiled.succeeded(),"CPU diagnostic constitutive compile failed: "+
                        diagnostics(compiled.diagnostics));
                const auto report=oracle::diagnoseFloat32Rest(compiled.program);
                std::cout<<std::setprecision(9)
                    <<"{\"schema\":\"numi.cardboard.bilinear-fp32-rest-diagnostic.v1\","
                    <<"\"material\":\""<<parsed.material.name<<"\","
                    <<"\"state_count\":"<<oracle::kStateCount<<','
                    <<"\"production_pivot_threshold\":1e-8,"
                    <<"\"division_domain_valid\":"<<(report.divisionDomainValid?"true":"false")<<','
                    <<"\"minimum_bytecode_divisor\":"<<report.minimumDivision<<','
                    <<"\"minimum_update_divisor\":"<<report.minimumUpdateDivision<<','
                    <<"\"minimum_residual_divisor\":"<<report.minimumResidualDivision<<','
                    <<"\"minimum_jacobian_divisor\":"<<report.minimumJacobianDivision<<','
                    <<"\"minimum_jacobian_divisor_row\":"<<report.minimumJacobianDivisionRow<<','
                    <<"\"minimum_jacobian_divisor_column\":"<<report.minimumJacobianDivisionColumn<<','
                    <<"\"initial_residual_infinity\":"<<report.residualInfinity<<','
                    <<"\"minimum_gaussian_pivot\":"<<report.minimumPivot<<','
                    <<"\"first_rejected_pivot_column\":"<<report.firstRejectedPivot<<','
                    <<"\"pivot_magnitudes\":[";
                for (unsigned i=0;i<oracle::kStateCount;++i)
                    std::cout<<(i?",":"")<<report.pivotMagnitudes[i];
                std::cout<<"],\"candidate\":[";
                for (unsigned i=0;i<oracle::kStateCount;++i)
                    std::cout<<(i?",":"")<<report.candidate[i];
                std::cout<<"],\"residual\":[";
                for (unsigned i=0;i<oracle::kStateCount;++i)
                    std::cout<<(i?",":"")<<report.residual[i];
                std::cout<<"],\"diagnostic_only\":true}\n";
                const float stateNorm=*std::max_element(report.candidate.begin(),
                    report.candidate.end(),[](const float a,const float b){return std::abs(a)<std::abs(b);});
                require(report.divisionDomainValid && report.firstRejectedPivot<0 &&
                        report.residualInfinity<=2.0e-5f*(1.0f+std::abs(stateNorm)),
                        "FP32 rest system violates the production material projection/tangent gates");
                return 0;
            }
            require(argc==4,"usage: bilinear-paper-gpu-check LINER_ASSET MEDIUM_ASSET REGISTERED_SOURCE_CSV");
            const std::filesystem::path linerPath=argv[1],mediumPath=argv[2],csvPath=argv[3];
            const std::string csvDigest=sha256(csvPath);
            require(csvDigest==kSourceCsvHash,"registered Haj-Ali digitized source CSV SHA256 changed");
            const Curves curves=readSourceCurves(csvPath);
            std::cout<<std::setprecision(10)
                <<"{\"schema\":\"numi.cardboard.bilinear-native-material-point.v1\","
                <<"\"source_csv_sha256\":\""<<csvDigest
                <<"\",\"evidence_scope\":\"production_Metal_generic_projection_stress_tangent_only\","
                <<"\"physical_steps\":0,\"physical_validation\":false,"
                <<"\"native_nonzero_gate\":"<<kRelativeGate
                <<",\"zero_response_policy\":\"inconclusive_unless_measured_noise_floor_is_recorded\"}\n";
            MetalInstrument metal;
            runMaterial(metal,{"liner","hajali2009_liner_hill_bilinear_fit",kLinerHash,
                               "liner",linerPath},curves);
            runMaterial(metal,{"medium","hajali2009_medium_hill_bilinear_fit",kMediumHash,
                               "medium_NSSC",mediumPath},curves);
            std::cout<<"PASS native 15-state generic material-point checks; physical_validation=false\n";
            return 0;
        } catch (const std::exception& error) {
            std::cerr<<"FAIL bilinear native material-point check: "<<error.what()<<'\n';
            return 1;
        }
    }
}

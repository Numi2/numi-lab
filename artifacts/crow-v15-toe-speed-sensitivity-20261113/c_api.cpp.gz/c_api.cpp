#include "box_distance.hpp"
#include "metalrobo/RetinalObserver.hpp"
#include "metalrobo/CrowForaging.hpp"
#include "metalrobo/CrowManipulation.hpp"
#include "metalrobo/detail/Checkpoint.hpp"
#include "metalrobo/c_api.h"

#include "metalrobo/EpisodeTwinCompiler.hpp"
#include "metalrobo/Franka.hpp"
#include "metalrobo/FiniteResource.hpp"
#include "metalrobo/FrankaWorld.hpp"
#include "metalrobo/G1.hpp"
#include "metalrobo/LearningPacks.hpp"
#include "metalrobo/LocomotionWorld.hpp"
#include "metalrobo/MetalHybridRenderer.hpp"
#include "metalrobo/MetalRunInspector.hpp"
#include "metalrobo/MetalTactile.hpp"
#include "metalrobo/MetalWorld.hpp"
#include "metalrobo/MetalWorldFamily.hpp"
#include "metalrobo/RuntimeAbi.hpp"
#include "metalrobo/RobotDescriptionCooker.hpp"
#include "metalrobo/RunProgram.hpp"
#include "wing_model.hpp"
#include "metalrobo/VisualPlatform.hpp"
#include "metalrobo/WorldPack.hpp"

#include <cstring>
#include <algorithm>
#include <atomic>
#include <array>
#include <cmath>
#include <exception>
#include <filesystem>
#include <iomanip>
#include <initializer_list>
#include <iterator>
#include <limits>
#include <memory>
#include <numbers>
#include <numeric>
#include <ranges>
#include <span>
#include <sstream>
#include <stdexcept>
#include <string>
#include <string_view>
#include <tuple>
#include <unordered_map>
#include <unordered_set>
#include <utility>
#include <vector>

struct MRWorldFamilyHandle {
    std::atomic_uint32_t references{1u};
    metalrobo::MetalWorldFamilyContext context;
    metalrobo::WorldFamily family;
    metalrobo::ScenarioSchema scenarioSchema;
    std::uint64_t authoredPackHash = 0u;
    metalrobo::WorldInstanceBatch readback;
    std::string deviceName;
    double lastSampleMilliseconds = 0.0;
};

struct MRHybridRendererHandle {
    std::atomic_uint32_t references{1u};
    metalrobo::MetalHybridRenderer renderer;
    metalrobo::HybridObservationBatch readback;
    std::string deviceName;
    std::uint32_t activeEnvironmentCount = 0u;
    double lastRenderMilliseconds = 0.0;
};

struct MRTactileHandle {
    metalrobo::MetalTactileContext context;
    metalrobo::TactileObservationBatch readback;
    std::string deviceName;
    std::string observationMetadataJSON;
    std::uint32_t activeEnvironmentCount = 0u;
    double lastObserveMilliseconds = 0.0;
};

struct MRTaskVisualRuntime {
    metalrobo::WorldTemplate worldTemplate;
    metalrobo::WorldFamily family;
    metalrobo::MetalWorldFamilyContext worlds;
    metalrobo::MetalHybridRenderer renderer;
    metalrobo::MetalHybridRenderer captureRenderer;
    metalrobo::MetalHybridObjectTracker tracker;
    std::unique_ptr<metalrobo::RetinalObserverContext> retinal;
    std::unique_ptr<metalrobo::MetalRunInspector> inspector;
    std::vector<MRBodyStateGPU> previousCaptureBodies;
    std::uint64_t captureFrameIndex = 0u;
    bool captureEnabled = false;
    bool capturePolicyCamera = false;
    bool deviceObservationEnabled = false;
    std::uint64_t sceneFingerprint = 0u;
};

struct MRTaskOutcomeDescriptor {
    std::string id;
    std::string unit;
    std::uint32_t source = MR_TASK_OUTCOME_REWARD;
    std::uint32_t direction = MR_TASK_OUTCOME_NEUTRAL;
};

struct CrowClearanceRecord {
    double distance = std::numeric_limits<double>::infinity();
    unsigned long long step = 0;
    std::size_t birdShape = 0, obstacleShape = 0;
    bool closed = false;
};
struct MRTaskRolloutHandle {
    std::vector<CrowClearanceRecord> crowClearance;
    explicit MRTaskRolloutHandle(
        metalrobo::MetalWorldConfig config,
        metalrobo::CompiledRun compiled
    ) : run(std::move(compiled)),
        model(run.model()),
        world(run.world()),
        taskProgram(run.task()),
        context(std::move(config)) {}

    metalrobo::CompiledRun run;
    const metalrobo::EngineModel& model;
    const metalrobo::CompiledWorld& world;
    const metalrobo::CompiledTaskProgram& taskProgram;
    // Exact guided task accepted only as the source of an explicitly
    // compiled autonomous/reset-only policy variant.
    metalrobo::CompiledTaskProgram compatiblePolicySourceTask;
    metalrobo::MetalWorldContext context;
    std::unique_ptr<metalrobo::FiniteResourceContext> resourceRuntime;
    metalrobo::MetalWorldResidentState residentState;
    metalrobo::MetalWorldStepConfig stepConfig;
    std::vector<MRBodyStateGPU> defaultSceneBodies;
    std::vector<float> resetQ;
    std::vector<float> resetV;
    std::vector<MRBodyStateGPU> resetSceneBodies;
    std::vector<std::uint32_t> resetMasks;
    metalrobo::MetalWorldResult result;
    std::vector<std::uint32_t> statusCodes;
    std::vector<std::uint32_t> activeContacts;
    std::vector<MRTaskOutcomeDescriptor> outcomes;
    std::vector<float> outcomeValues;
    std::unique_ptr<MRTaskVisualRuntime> visualRuntime;
    std::unique_ptr<MRTaskVisualRuntime> inspectionVisualRuntime;
    std::string deviceName;
    std::string metallibPath;
    std::string taskId;
    std::uint32_t environmentCount = 0u;
    bool rejectedRetinalBatch=false;
    std::vector<std::byte> pendingLifeWorld;
    std::uint64_t submittedControlSteps = 0u;
    std::uint64_t completedEnvironmentSteps = 0u;
    std::uint64_t submissionCount = 0u;
    double totalGPUMilliseconds = 0.0;
    double totalSubmissionMilliseconds = 0.0;
};

namespace {
void installTaskVisualRuntime(
    MRTaskRolloutHandle& handle,
    const metalrobo::VisualSensorProgram& program
);
void installTaskInspectionRuntime(
    MRTaskRolloutHandle& handle,
    const metalrobo::VisualSensorProgram& program
);
}

static_assert(sizeof(MRHybridGaussianC) == 80u);
static_assert(sizeof(MRHybridGaussianGPU) == 80u);
static_assert(
    sizeof(MRVisualFrameMetadataC) ==
    sizeof(MRVisualFrameMetadataGPU)
);
static_assert(
    sizeof(MRTactileSummaryC) ==
    sizeof(MRTactileSummaryGPU)
);
static_assert(
    sizeof(MRTaskTransitionC) ==
    sizeof(MRTaskTransitionGPU)
);
static_assert(
    offsetof(MRTaskTransitionC, policy_revision) ==
    offsetof(MRTaskTransitionGPU, policyRevision)
);
static_assert(
    offsetof(MRTaskTransitionC, timeout_bootstrap_value) ==
    offsetof(MRTaskTransitionGPU, timeoutBootstrapValue)
);
static_assert(
    offsetof(MRTaskTransitionC, episode_tracking_score) ==
    offsetof(MRTaskTransitionGPU, episodeTrackingScore)
);
static_assert(
    offsetof(MRTaskTransitionC, difficulty_band) ==
    offsetof(MRTaskTransitionGPU, taskProgress)
);
static_assert(sizeof(MRTaskEvidenceTelemetryC) == 48u);

namespace {

thread_local std::string gLastError;

std::string unitreeG1DeploymentContractJSON() {
    const metalrobo::G1ModelMetadata& metadata =
        metalrobo::unitreeG1Metadata();
    const metalrobo::EngineModel model =
        metalrobo::makeUnitreeG1EngineModel();
    const MRArticulationGPU& articulation =
        model.articulations.front();
    std::ostringstream output;
    output << std::setprecision(9);
    output
        << "{\"format\":\"metalrobo.unitree-g1-deployment\","
        << "\"schema\":1,"
        << "\"model_name\":" << std::quoted(
            std::string{metadata.modelName}
        ) << ","
        << "\"source_repository\":" << std::quoted(
            std::string{metadata.sourceRepository}
        ) << ","
        << "\"source_commit\":" << std::quoted(
            std::string{metadata.sourceCommit}
        ) << ","
        << "\"source_model_path\":" << std::quoted(
            std::string{metadata.sourceModelPath}
        ) << ","
        << "\"simulator_repository\":" << std::quoted(
            std::string{metadata.simulatorRepository}
        ) << ","
        << "\"simulator_commit\":" << std::quoted(
            std::string{metadata.simulatorCommit}
        ) << ","
        << "\"simulator_model_path\":" << std::quoted(
            std::string{metadata.simulatorModelPath}
        ) << ","
        << "\"rl_preset_repository\":" << std::quoted(
            std::string{metadata.rlPresetRepository}
        ) << ","
        << "\"rl_preset_commit\":" << std::quoted(
            std::string{metadata.rlPresetCommit}
        ) << ","
        << "\"physics_timestep_seconds\":0.005,"
        << "\"policy_timestep_seconds\":0.02,"
        << "\"drive_prediction_seconds\":0.005,"
        << "\"solver_root_frame\":\"center_of_mass\","
        << "\"interaction_root_frame\":\"root_link_origin\","
        << "\"root_center_of_mass_local_xyz\":["
        << model.bodies[articulation.rootBody].centerOfMass.x << ','
        << model.bodies[articulation.rootBody].centerOfMass.y << ','
        << model.bodies[articulation.rootBody].centerOfMass.z << "],"
        << "\"action_scale_radians\":0.25,"
        << "\"actor_frame_size\":96,"
        << "\"actor_history_length\":5,";

    const auto writeScalarArray =
        [&output](const char* key, const auto& values) {
            output << std::quoted(key) << ":[";
            for (std::size_t index = 0u;
                 index < values.size();
                 ++index) {
                if (index != 0u) {
                    output << ',';
                }
                output << values[index];
            }
            output << ']';
        };
    output << "\"joint_order\":[";
    for (std::size_t index = 0u;
         index < metadata.jointLimits.size();
         ++index) {
        if (index != 0u) {
            output << ',';
        }
        output << std::quoted(
            std::string{metadata.jointLimits[index].name}
        );
    }
    output << "],";

    std::array<float, metalrobo::kUnitreeG1JointCount>
        defaultPose{};
    std::array<float, metalrobo::kUnitreeG1JointCount>
        stiffness{};
    std::array<float, metalrobo::kUnitreeG1JointCount>
        damping{};
    std::array<float, metalrobo::kUnitreeG1JointCount>
        velocityLimits{};
    std::array<float, metalrobo::kUnitreeG1JointCount>
        effortLimits{};
    const std::span<const float> actionScales =
        metalrobo::unitreeG1LocomotionActionScales();
    for (std::size_t index = 0u;
         index < metadata.jointLimits.size();
         ++index) {
        defaultPose[index] =
            model.defaultQ[
                articulation.qOffset + 7u + index
            ];
        stiffness[index] =
            metadata.rlLabDrives[index].stiffness;
        damping[index] =
            metadata.rlLabDrives[index].damping;
        velocityLimits[index] =
            metadata.jointLimits[index].maximumVelocity;
        effortLimits[index] =
            metadata.jointLimits[index].maximumEffort;
    }
    writeScalarArray("default_pose", defaultPose);
    output << ',';
    writeScalarArray("task_action_scale", actionScales);
    output << ',';
    writeScalarArray("stiffness", stiffness);
    output << ',';
    writeScalarArray("damping", damping);
    output << ',';
    writeScalarArray("velocity_limits", velocityLimits);
    output << ',';
    writeScalarArray("effort_limits", effortLimits);
    output << ",\"position_limits\":[";
    for (std::size_t index = 0u;
         index < metadata.jointLimits.size();
         ++index) {
        if (index != 0u) {
            output << ',';
        }
        output
            << '['
            << metadata.jointLimits[index].lowerPosition
            << ','
            << metadata.jointLimits[index].upperPosition
            << ']';
    }
    output << "]}";
    return output.str();
}

template <typename Function>
int translateErrors(Function&& function) noexcept {
    try {
        function();
        gLastError.clear();
        return 0;
    } catch (const std::exception& error) {
        gLastError = error.what();
    } catch (...) {
        gLastError = "MetalRobo failed with an unknown native exception.";
    }
    return -1;
}

bool requireWorldFamilyHandle(const MRWorldFamilyHandle* handle) {
    if (handle != nullptr) {
        return true;
    }
    gLastError = "MetalRobo world-family handle is null.";
    return false;
}

bool requireHybridRendererHandle(
    const MRHybridRendererHandle* handle
) {
    if (handle != nullptr) {
        return true;
    }
    gLastError = "MetalRobo hybrid renderer handle is null.";
    return false;
}

bool requireTactileHandle(const MRTactileHandle* handle) {
    if (handle != nullptr) {
        return true;
    }
    gLastError = "MetalRobo tactile handle is null.";
    return false;
}

bool requireTaskRolloutHandle(
    const MRTaskRolloutHandle* handle
) {
    if (handle != nullptr) {
        return true;
    }
    gLastError = "MetalRobo task-rollout handle is null.";
    return false;
}

void accumulateTaskStageHighWater(
    MRTaskRolloutStageHighWaterC& target,
    const metalrobo::MetalWorldStageCounts& source
) {
    const auto maximum = [](uint32_t& value, const uint32_t sample) {
        value = std::max(value, sample);
    };
    maximum(target.candidate_pairs, source.candidatePairs);
    maximum(target.raw_contacts, source.rawContacts);
    maximum(target.manifolds, source.manifolds);
    maximum(target.constraint_blocks, source.constraintBlocks);
    maximum(target.constraint_rows, source.constraintRows);
    maximum(target.islands, source.islands);
    maximum(target.hard_convex_pairs, source.hardConvexPairs);
    maximum(
        target.mesh_triangle_candidates,
        source.meshTriangleCandidates
    );
    maximum(target.solver_tiles, source.solverTiles);
    maximum(target.spill_rows, source.spillRows);
    maximum(target.ccd_candidates, source.ccdCandidates);
    maximum(target.ccd_events, source.ccdEvents);
    maximum(
        target.endpoint_runtime_records,
        source.endpointRuntimeRecords
    );
    maximum(
        target.articulation_point_queries,
        source.articulationPointQueries
    );
    maximum(target.rod_candidate_pairs, source.rodCandidatePairs);
    maximum(target.rod_raw_contacts, source.rodRawContacts);
    maximum(target.rod_manifolds, source.rodManifolds);
    maximum(target.rod_ccd_events, source.rodCCDEvents);
    maximum(
        target.quality_generalized_velocities,
        source.qualityGeneralizedVelocities
    );
    maximum(target.quality_rows, source.qualityRows);
    maximum(
        target.quality_krylov_vectors,
        source.qualityKrylovVectors
    );
    maximum(
        target.quality_direct_tiles,
        source.qualityDirectTiles
    );
    maximum(target.dynamic_nodes, source.dynamicNodes);
    maximum(
        target.island_node_references,
        source.islandNodeReferences
    );
    maximum(
        target.island_constraint_references,
        source.islandConstraintReferences
    );
    maximum(target.rod_factor_blocks, source.rodFactorBlocks);
    maximum(
        target.operator_velocity_elements,
        source.operatorVelocityElements
    );
}

std::size_t checkedProduct(
    const std::initializer_list<std::size_t> values,
    const char* label
) {
    std::size_t product = 1u;
    for (const std::size_t value : values) {
        if (value != 0u &&
            product >
                std::numeric_limits<std::size_t>::max() / value) {
            throw std::overflow_error(
                std::string{label} + " size overflows size_t"
            );
        }
        product *= value;
    }
    return product;
}

void resetTaskRolloutState(
    MRTaskRolloutHandle& handle,
    const std::uint64_t seed
) {
    const std::size_t environmentCount =
        handle.environmentCount;
    const std::size_t nq = handle.world.nq();
    const std::size_t nv = handle.world.nv();
    const MRArticulationGPU& articulation =
        handle.model.articulations[
            handle.world.articulationIndex()
        ];
    handle.resetQ.resize(environmentCount * nq);
    handle.resetV.resize(environmentCount * nv);
    for (std::size_t environment = 0u;
         environment < environmentCount;
         ++environment) {
        const std::size_t qBase = environment * nq;
        const std::size_t vBase = environment * nv;
        std::copy_n(
            handle.model.defaultQ.begin() +
                articulation.qOffset,
            nq,
            handle.resetQ.begin() +
                static_cast<std::ptrdiff_t>(qBase)
        );
        std::copy_n(
            handle.model.defaultV.begin() +
                articulation.vOffset,
            nv,
            handle.resetV.begin() +
                static_cast<std::ptrdiff_t>(vBase)
        );
    }

    const std::size_t sceneBodyCount =
        handle.defaultSceneBodies.size();
    handle.resetSceneBodies.resize(
        environmentCount * sceneBodyCount
    );
    for (std::size_t environment = 0u;
         environment < environmentCount;
         ++environment) {
        std::copy(
            handle.defaultSceneBodies.begin(),
            handle.defaultSceneBodies.end(),
            handle.resetSceneBodies.begin() +
                static_cast<std::ptrdiff_t>(
                    environment * sceneBodyCount
                )
        );
    }

    handle.stepConfig.taskSeed = seed;
    handle.residentState =
        metalrobo::MetalWorldResidentState{};
    if (handle.visualRuntime != nullptr) {
        if (handle.visualRuntime->retinal) {
            handle.visualRuntime->retinal->reset(seed);
            handle.rejectedRetinalBatch=false;
        } else {
        const auto sampled = handle.visualRuntime->worlds.sample(
            handle.environmentCount,
            seed
        );
        if (!sampled.succeeded()) {
            throw std::runtime_error(
                std::string{"visual WorldFamily reset failed ["} +
                metalrobo::metalWorldFamilyStatusName(sampled.status) +
                "]: " + sampled.message
            );
        }
        if (handle.visualRuntime->deviceObservationEnabled) {
            const auto tracker = handle.visualRuntime->tracker.reset();
            if (!tracker.succeeded()) {
                throw std::runtime_error(
                    std::string{"visual tracker reset failed ["} +
                    metalrobo::metalHybridRendererStatusName(tracker.status) +
                    "]: " + tracker.message
                );
            }
        }
    }
        }
    handle.pendingLifeWorld.clear();
    handle.resetMasks.clear();
    handle.result = {};
    handle.statusCodes.clear();
    handle.activeContacts.clear();
}

void applyCrowNavigationCourseSplit(
    MRTaskRolloutHandle& handle,
    const std::uint32_t split
) {
    if (split == MR_BIRDFLOW_NAVIGATION_COURSE_TRAINING) {
        return;
    }
    constexpr std::array<const char*, 5u> names{{
        "crow_course_gate_left",
        "crow_course_gate_right",
        "crow_course_slalom_a",
        "crow_course_slalom_b",
        "crow_course_perch",
    }};
    constexpr std::array<std::array<mr_float4, 5u>, 11u> positions{{
        {{{1.55f, 0.58f, 0.80f, 1.0f},
          {1.55f, -0.76f, 0.80f, 1.0f},
          {2.75f, -0.28f, 0.65f, 1.0f},
          {3.95f, 0.42f, 0.65f, 1.0f},
          {5.20f, -0.18f, 0.86f, 1.0f}}},
        {{{1.25f, 0.78f, 0.80f, 1.0f},
          {1.25f, -0.56f, 0.80f, 1.0f},
          {2.45f, 0.46f, 0.65f, 1.0f},
          {3.55f, -0.46f, 0.65f, 1.0f},
          {4.85f, 0.22f, 0.70f, 1.0f}}},
        // Accepted scene-body poses from environment 4, episode-local band 5,
        // seed 2650817001. The inherited V33-r11 actor reached waypoint one
        // on this exact course before the turn-preview experiment.
        {{{1.4494589567f, 0.6012506485f, 0.7421792746f, 1.0f},
          {1.2955527306f, -0.7601146698f, 0.7944179177f, 1.0f},
          {2.4459667206f, 0.4744514823f, 0.6441041827f, 1.0f},
          {3.6380522251f, -0.2306721509f, 0.5702749491f, 1.0f},
          {4.9732704163f, -0.0928055048f, 0.8553680778f, 1.0f}}},
        // Former final-c: assessed, now development only.
        {{{1.48f, 0.72f, 0.80f, 1.0f},
          {1.48f, -0.62f, 0.80f, 1.0f},
          {2.69f, -0.40f, 0.65f, 1.0f},
          {3.88f, 0.35f, 0.65f, 1.0f},
          {5.11f, 0.08f, 0.79f, 1.0f}}},
        // Former final-d: assessed, now development only.
        {{{1.42f, 0.75f, 0.80f, 1.0f},
          {1.42f, -0.65f, 0.80f, 1.0f},
          {2.62f, 0.40f, 0.65f, 1.0f},
          {3.83f, -0.39f, 0.65f, 1.0f},
          {5.04f, -0.10f, 0.77f, 1.0f}}},
        // Former assessment layouts, now development only.
        {{{1.36f, 0.68f, 0.80f, 1.0f},
          {1.36f, -0.70f, 0.80f, 1.0f},
          {2.56f, -0.34f, 0.65f, 1.0f},
          {3.72f, 0.43f, 0.65f, 1.0f},
          {4.97f, 0.14f, 0.82f, 1.0f}}},
        {{{1.52f, 0.76f, 0.80f, 1.0f},
          {1.52f, -0.60f, 0.80f, 1.0f},
          {2.78f, 0.37f, 0.65f, 1.0f},
          {3.91f, -0.35f, 0.65f, 1.0f},
          {5.16f, -0.13f, 0.75f, 1.0f}}},
        // Former assessment layouts, now development only.
        {{{1.45f, 0.71f, 0.80f, 1.0f},
          {1.45f, -0.67f, 0.80f, 1.0f},
          {2.67f, 0.32f, 0.65f, 1.0f},
          {3.78f, -0.38f, 0.65f, 1.0f},
          {5.03f, 0.03f, 0.84f, 1.0f}}},
        {{{1.31f, 0.70f, 0.80f, 1.0f},
          {1.31f, -0.64f, 0.80f, 1.0f},
          {2.57f, -0.42f, 0.65f, 1.0f},
          {3.82f, 0.39f, 0.65f, 1.0f},
          {5.08f, -0.17f, 0.78f, 1.0f}}},
        // Untouched assessment layouts; never use for fitting or selection.
        {{{1.42f, 0.66f, 0.80f, 1.0f},
          {1.42f, -0.72f, 0.80f, 1.0f},
          {2.70f, -0.38f, 0.65f, 1.0f},
          {3.86f, 0.35f, 0.65f, 1.0f},
          {5.12f, 0.10f, 0.81f, 1.0f}}},
        {{{1.35f, 0.73f, 0.80f, 1.0f},
          {1.35f, -0.65f, 0.80f, 1.0f},
          {2.61f, 0.36f, 0.65f, 1.0f},
          {3.88f, -0.40f, 0.65f, 1.0f},
          {5.00f, -0.06f, 0.79f, 1.0f}}},
    }};
    const auto sceneBodies = handle.world.sceneBodyIndices();
    for (std::size_t index = 0u; index < names.size(); ++index) {
        const auto body = std::ranges::find(handle.model.bodyNames, names[index]);
        if (body == handle.model.bodyNames.end()) {
            throw std::logic_error(
                "compiled Crow navigation course body is missing"
            );
        }
        const std::uint32_t bodyIndex = static_cast<std::uint32_t>(
            body - handle.model.bodyNames.begin()
        );
        const auto scene = std::ranges::find(sceneBodies, bodyIndex);
        if (scene == sceneBodies.end()) {
            throw std::logic_error(
                "compiled Crow navigation course body is not a scene body"
            );
        }
        const std::size_t local = static_cast<std::size_t>(
            scene - sceneBodies.begin()
        );
        handle.defaultSceneBodies.at(local).position =
            positions[split - 1u][index];
    }
}

void validateTaskRolloutConfiguration(
    const MRTaskRolloutConfigC& config
) {
    if (config.environment_count == 0u ||
        config.physics_substeps == 0u ||
        config.velocity_iterations == 0u ||
        !std::isfinite(config.control_timestep_seconds) ||
        !(config.control_timestep_seconds > 0.0f)) {
        throw std::invalid_argument(
            "task-rollout counts and timing must be finite and positive"
        );
    }
    if (config.dynamic_sphere_count > 0u &&
        config.dynamic_spheres == nullptr) {
        throw std::invalid_argument(
            "task-rollout dynamic sphere storage is null"
        );
    }
    if (config.dynamic_sphere_count > 64u) {
        throw std::invalid_argument(
            "task-rollout dynamic sphere count exceeds 64"
        );
    }
    if (config.interaction_reference_mode >
        MR_INTERACTION_REFERENCE_RESET_ONLY) {
        throw std::invalid_argument(
            "task-rollout interaction reference mode is invalid"
        );
    }
    if (config.override_interaction_student_authority > 1u ||
        (config.override_interaction_student_authority != 0u &&
         (!std::isfinite(config.interaction_student_authority) ||
          config.interaction_student_authority < 0.0f ||
          config.interaction_student_authority > 1.0f))) {
        throw std::invalid_argument(
            "task-rollout interaction student authority must be in [0, 1]"
        );
    }
    if (config.materialize_articulated_contact_responses > 1u) {
        throw std::invalid_argument(
            "materialized articulated-contact response flag is invalid"
        );
    }
    if (!std::isfinite(config.birdflow_journey_student_authority) ||
        config.birdflow_journey_student_authority < 0.0f ||
        config.birdflow_journey_student_authority > 1.0f) {
        throw std::invalid_argument(
            "task-rollout journey student authority must be in [0, 1]"
        );
    }
    if (config.birdflow_navigation_curriculum > 6u) {
        throw std::invalid_argument(
            "task-rollout BirdFlow navigation curriculum mode is invalid"
        );
    }
    if (!std::isfinite(config.difficulty_sampling_exponent_override) ||
        config.difficulty_sampling_exponent_override < 0.0f) {
        throw std::invalid_argument(
            "task-rollout difficulty sampling exponent must be non-negative"
        );
    }
    if (config.birdflow_journey_variant >
        MR_BIRDFLOW_JOURNEY_V15_CONDITIONAL_LANDING_NAVIGATION) {
        throw std::invalid_argument(
            "task-rollout BirdFlow journey variant is invalid"
        );
    }
    if (config.birdflow_navigation_course >
        MR_BIRDFLOW_NAVIGATION_COURSE_RESERVED_FINAL_J) {
        throw std::invalid_argument(
            "task-rollout BirdFlow navigation course split is invalid"
        );
    }
    if (config.override_difficulty_band_range > 1u ||
        (config.override_difficulty_band_range != 0u &&
         config.minimum_difficulty_band >
             config.maximum_difficulty_band)) {
        throw std::invalid_argument(
            "task-rollout difficulty-band range is invalid"
        );
    }
}

metalrobo::LocomotionSurface locomotionSurface(
    const std::uint32_t value
) {
    switch (value) {
    case MR_LOCOMOTION_SURFACE_GROUND:
        return metalrobo::LocomotionSurface::ground;
    case MR_LOCOMOTION_SURFACE_TERRAIN:
        return metalrobo::LocomotionSurface::terrain;
    default:
        throw std::invalid_argument(
            "locomotion surface is invalid"
        );
    }
}

metalrobo::UnitreeG1Task unitreeG1Task(const std::uint32_t value) {
    switch (value) {
    case MR_UNITREE_G1_TASK_VELOCITY:
        return metalrobo::UnitreeG1Task::velocity;
    case MR_UNITREE_G1_TASK_DISTURBANCE_RECOVERY:
        return metalrobo::UnitreeG1Task::disturbanceRecovery;
    case MR_UNITREE_G1_TASK_SUPINE_GET_UP_DISCOVERY:
        return metalrobo::UnitreeG1Task::supineGetUpDiscovery;
    case MR_UNITREE_G1_TASK_BALL_DISTURBANCE_RECOVERY:
        return metalrobo::UnitreeG1Task::ballDisturbanceRecovery;
    case MR_UNITREE_G1_TASK_BALL_DODGE:
        return metalrobo::UnitreeG1Task::ballDodge;
    case MR_UNITREE_G1_TASK_DEVELOPMENTAL_RECOVERY:
        return metalrobo::UnitreeG1Task::developmentalRecovery;
    case MR_UNITREE_G1_TASK_ADULT_LOCOMOTION:
        return metalrobo::UnitreeG1Task::adultLocomotion;
    case MR_UNITREE_G1_TASK_G1_LEGS_LOCOMOTION:
        return metalrobo::UnitreeG1Task::g1LegsLocomotion;
    default:
        throw std::invalid_argument("Unitree G1 task is invalid");
    }
}

const metalrobo::InteractionClip& selectedInteractionClip(
    const metalrobo::InteractionPack& pack,
    const std::string_view clipId
) {
    const auto found = std::find_if(
        pack.clips.begin(),
        pack.clips.end(),
        [clipId](const metalrobo::InteractionClip& clip) {
            return clip.id == clipId;
        }
    );
    if (found == pack.clips.end()) {
        throw std::invalid_argument(
            "InteractionPack clip does not exist: " +
            std::string{clipId}
        );
    }
    return *found;
}

void authorG1InteractionTrackingTask(
    metalrobo::TaskPack& task,
    metalrobo::TaskObservationProgram& observations,
    metalrobo::TaskResetProgram& reset,
    const metalrobo::InteractionPack& interactions,
    const metalrobo::InteractionClip& clip,
    const MRTaskRolloutConfigC& config
) {
    task.id = "unitree_g1_interaction_tracking/" +
        interactions.id + "/" + clip.id;
    task.outcomes = {
        {"tracking", "ratio",
            metalrobo::TaskOutcomeSource::trackingScore,
            metalrobo::TaskOutcomeDirection::higherIsBetter},
        {"contact_reward", "reward",
            metalrobo::TaskOutcomeSource::contactReward,
            metalrobo::TaskOutcomeDirection::higherIsBetter},
    };
    task.difficultyBandCount = 1u;
    task.commands = {};
    task.commands.standingProbability = 1.0f;
    task.pushes.maximumVelocity = 0.0f;
    task.pushes.minimumIntervalSeconds = 5.0f;
    task.pushes.maximumIntervalSeconds = 5.0f;
    reset.operators.clear();
    // The standing profile's 32-manifold envelope is too small for generated
    // whole-body motions. The first physically coherent ARDY residual batch
    // measured 33 simultaneous manifolds (37 raw contacts) at control step
    // zero. Reuse the qualified two-Wave32 get-up envelope without changing
    // contact generation, solver acceptance, or transactional rollback.
    task.capacities.manifolds = std::max(
        task.capacities.manifolds,
        64u
    );
    // A generic generated motion may deliberately leave the standing height
    // and orientation envelope (acrobatics, get-up, crawling, manipulation).
    // The InteractionPack root target is the task-relative posture authority;
    // inherited locomotion tilt/height terminations would reject the desired
    // motion before physics can evaluate it. Numerical failures remain owned
    // by the transactional solver and non-looping clips retain their horizon.
    const bool physicsGated =
        config.interaction_reference_mode !=
        MR_INTERACTION_REFERENCE_RESET_ONLY;
    task.interactionPhysicsGated = physicsGated;
    if (physicsGated) {
        task.id += "/physics-gated-v4";
    }
    task.terminations.clear();
    if (physicsGated && config.disable_task_terminations == 0u) {
        // ARDY_PHYSICS_GATED_REFERENCE_V4: stop before ground contact
        // can become a second, uncontrolled phase of the motion.
        task.terminations = {
            {
                .operation = metalrobo::TaskTerminationOperator::
                    minimumRootHeight,
                .reason = MR_TASK_TERMINATION_HEIGHT,
                .priority = 10u,
                .threshold = 0.55f,
                .failurePenalty = -5.0f,
            },
            {
                .operation = metalrobo::TaskTerminationOperator::
                    maximumTilt,
                .reason = MR_TASK_TERMINATION_TILT,
                .priority = 11u,
                .threshold = 0.50f,
                .failurePenalty = -5.0f,
            },
            {
                .operation = metalrobo::TaskTerminationOperator::
                    contactGroup,
                .sourceGroup = "undesired_contact",
                .reason = MR_TASK_TERMINATION_CONTACT,
                .priority = 12u,
                .threshold = 0.5f,
                .failurePenalty = -5.0f,
            },
        };
    }
    reset.maximumActionDelaySteps = 0u;
    reset.maximumObservationDelaySteps = 0u;
    if (!clip.loop) {
        const double durationSeconds =
            static_cast<double>(clip.frameCount - 1u) /
            static_cast<double>(clip.framesPerSecond);
        const double nominalSteps = std::ceil(
            durationSeconds /
            static_cast<double>(config.control_timestep_seconds)
        ) + 1.0;
        // A physics-gated clock may legitimately hold a frame while a
        // foot releases or lands. Give it four nominal clip durations.
        const double steps = physicsGated
            ? 4.0 * nominalSteps
            : nominalSteps;
        if (!std::isfinite(steps) || steps < 2.0 ||
            steps > static_cast<double>(
                std::numeric_limits<std::uint32_t>::max()
            )) {
            throw std::invalid_argument(
                "InteractionPack duration does not fit the task horizon"
            );
        }
        task.maximumEpisodeSteps =
            static_cast<std::uint32_t>(steps);
    }

    // Generated-motion tracking has no locomotion command, and the selected
    // interaction publishes its own phase below. Reuse those five otherwise
    // dead/redundant actor slots for solver-resolved support state without
    // changing the policy shape: total load, left/right load balance, maximum
    // support slip, and each foot's actual support load. ARDY remains intent;
    // these values come only from accepted NumiSolver contacts.
    const auto installSupportState = [](
        std::vector<metalrobo::TaskObservationOperatorSpec>& observations
    ) {
        for (metalrobo::TaskObservationOperatorSpec& observation :
             observations) {
            if (observation.source ==
                    metalrobo::TaskObservationSource::command) {
                observation.source =
                    metalrobo::TaskObservationSource::supportSense;
                observation.target.clear();
                observation.scale = observation.component == 0u
                    ? 0.002f
                    : 1.0f;
                observation.offset = 0.0f;
                observation.noiseAmplitude = 0.0f;
                observation.biasLower = 0.0f;
                observation.biasUpper = 0.0f;
                observation.normalizeVector3 = false;
                continue;
            }
            if (observation.source !=
                    metalrobo::TaskObservationSource::gaitPhase) {
                continue;
            }
            observation.source =
                metalrobo::TaskObservationSource::contactMetric;
            observation.target = observation.component == 0u
                ? "left_foot_contact"
                : "right_foot_contact";
            observation.component = 0u;
            observation.scale = 0.002f;
            observation.offset = 0.0f;
            observation.noiseAmplitude = 0.0f;
            observation.biasLower = 0.0f;
            observation.biasUpper = 0.0f;
            observation.normalizeVector3 = false;
        }
    };
    installSupportState(observations.actorFrame);
    installSupportState(observations.critic);

    const auto appendObservation =
        [&observations](const metalrobo::TaskObservationOperatorSpec& operation) {
            observations.actorCurrent.push_back(operation);
            observations.critic.push_back(operation);
        };
    for (std::uint32_t component = 0u; component < 3u; ++component) {
        appendObservation({
            .source = metalrobo::TaskObservationSource::interactionPhase,
            .component = component,
        });
    }
    for (std::uint32_t component = 0u; component < 12u; ++component) {
        appendObservation({
            .source = metalrobo::TaskObservationSource::
                interactionRootTrackingError,
            .component = component,
        });
    }
    for (const metalrobo::TaskActionBinding& action : task.actions) {
        appendObservation({
            .source = metalrobo::TaskObservationSource::
                interactionJointPositionError,
            .target = action.actuator,
        });
    }
    for (const metalrobo::InteractionContactTrack& track :
         interactions.contactTracks) {
        for (std::uint32_t component = 0u; component < 2u; ++component) {
            appendObservation({
                .source = metalrobo::TaskObservationSource::
                    interactionContactMode,
                .target = track.id,
                .component = component,
            });
        }
        for (std::uint32_t component = 0u;
             component < metalrobo::kInteractionContactFeatureCount;
             ++component) {
            appendObservation({
                .source = metalrobo::TaskObservationSource::
                    interactionContactTarget,
                .target = track.id,
                .component = component,
            });
            appendObservation({
                .source = metalrobo::TaskObservationSource::
                    interactionContactValidity,
                .target = track.id,
                .component = component,
            });
        }
    }

    task.rewards = {
        {
            .operation = metalrobo::TaskRewardOperator::
                interactionJointTracking,
            .weight = 0.5f,
            .parameters = {0.25f, 1.0f, 0.0f, 0.0f},
        },
        {
            .operation = metalrobo::TaskRewardOperator::
                interactionRootTracking,
            .weight = 3.0f,
            // Broad widths retain a useful gradient after a dynamic tracking
            // error instead of saturating the exponential while the robot is
            // still recoverable.
            .parameters = {1.0f, 0.20f, 1.0f, 1.0f},
        },
        {
            .operation = metalrobo::TaskRewardOperator::
                interactionRootLinearVelocityError,
            .weight = -0.75f,
            .parameters = {1.0f, 0.0f, 0.0f, 0.0f},
        },
        // Do not add standing-relative height, uprightness, tilt, or root
        // velocity costs here.  Generated motion may intentionally crouch,
        // get up, turn, jump, or rotate.  interactionRootTracking already
        // scores position, orientation, linear velocity, and angular velocity
        // against the selected trajectory, so the same compiled objective is
        // meaningful for every motion without classifying it on the host.
        {
            .operation = metalrobo::TaskRewardOperator::
                jointVelocitySquared,
            .weight = -0.001f,
        },
        {
            .operation = metalrobo::TaskRewardOperator::
                jointAccelerationSquared,
            .weight = -2.5e-7f,
        },
        {
            .operation = metalrobo::TaskRewardOperator::
                actionRateSquared,
            .weight = -0.02f,
        },
        {
            .operation = metalrobo::TaskRewardOperator::
                jointLimitViolationAbsolute,
            .weight = -5.0f,
            .parameters = {0.9f, 0.0f, 0.0f, 0.0f},
        },
        {
            .operation = metalrobo::TaskRewardOperator::mechanicalPower,
            .weight = -2.0e-5f,
        },
        {
            .operation = metalrobo::TaskRewardOperator::supportSlip,
            .weight = -0.25f,
        },
        {
            .operation = metalrobo::TaskRewardOperator::forbiddenContact,
            .sourceGroup = "undesired_contact",
            .weight = -3.0f,
        },
    };
    for (const metalrobo::InteractionContactTrack& track :
         interactions.contactTracks) {
        task.rewards.push_back({
            .operation = metalrobo::TaskRewardOperator::
                interactionContactTracking,
            .sourceGroup = track.taskContactGroup,
            .target = track.id,
            .weight = 1.0f,
            .parameters = {0.65f, 1.0f, 0.0f, 0.0f},
        });
    }
}

void authorG1ImaginedTask(
    metalrobo::TaskPack& task,
    metalrobo::TaskObservationProgram& observations,
    const metalrobo::InteractionPack& interactions,
    const metalrobo::InteractionClip& clip,
    const MRTaskRolloutConfigC& config,
    const bool includeInteractionContacts
) {
    task.id += "/imagined_interaction";
    if (std::ranges::none_of(
            task.outcomes,
            [](const metalrobo::TaskOutcomeSpec& outcome) {
                return outcome.source ==
                    metalrobo::TaskOutcomeSource::trackingScore;
            }
        )) {
        task.outcomes.push_back({
            "tracking", "ratio",
            metalrobo::TaskOutcomeSource::trackingScore,
            metalrobo::TaskOutcomeDirection::higherIsBetter,
        });
    }
    if (!clip.loop) {
        const double durationSeconds =
            static_cast<double>(clip.frameCount - 1u) /
            static_cast<double>(clip.framesPerSecond);
        const double steps = std::ceil(
            durationSeconds /
            static_cast<double>(config.control_timestep_seconds)
        ) + 1.0;
        if (!std::isfinite(steps) || steps < 2.0 ||
            steps > static_cast<double>(
                std::numeric_limits<std::uint32_t>::max()
            )) {
            throw std::invalid_argument(
                "InteractionPack duration does not fit the imagined-task horizon"
            );
        }
        task.maximumEpisodeSteps = static_cast<std::uint32_t>(steps);
    }
    const auto appendObservation =
        [&observations](const metalrobo::TaskObservationOperatorSpec& operation) {
            observations.critic.push_back(operation);
        };
    for (std::uint32_t component = 0u; component < 3u; ++component) {
        const metalrobo::TaskObservationOperatorSpec phase{
            .source = metalrobo::TaskObservationSource::interactionPhase,
            .component = component,
        };
        // Elapsed recovery phase is a deployable mode-clock signal. It lets
        // the actor distinguish rising from settling without exposing the
        // imagined joint/contact targets, which remain critic-only intent.
        observations.actorCurrent.push_back(phase);
        observations.critic.push_back(phase);
    }
    for (const metalrobo::TaskActionBinding& action : task.actions) {
        appendObservation({
            .source = metalrobo::TaskObservationSource::
                interactionJointPositionError,
            .target = action.actuator,
        });
    }
    if (includeInteractionContacts) for (
        const metalrobo::InteractionContactTrack& track :
        interactions.contactTracks
    ) {
        for (std::uint32_t component = 0u; component < 2u; ++component) {
            appendObservation({
                .source = metalrobo::TaskObservationSource::
                    interactionContactMode,
                .target = track.id,
                .component = component,
            });
        }
        for (std::uint32_t component = 0u; component < 3u; ++component) {
            appendObservation({
                .source = metalrobo::TaskObservationSource::
                    contactWrenchLocal,
                .target = track.taskContactGroup,
                .component = component,
                .scale = 0.01f,
            });
        }
    }
    task.rewards.push_back({
        .operation = metalrobo::TaskRewardOperator::
            interactionJointTracking,
        .weight = 0.5f,
        .parameters = {0.25f, 1.0f, 0.0f, 0.0f},
    });
    task.rewards.push_back({
        .operation = metalrobo::TaskRewardOperator::
            interactionRootTracking,
        .weight = 2.0f,
        .parameters = {0.04f, 0.08f, 0.25f, 0.5f},
    });
    if (includeInteractionContacts) for (
        const metalrobo::InteractionContactTrack& track :
        interactions.contactTracks
    ) {
        task.rewards.push_back({
            .operation = metalrobo::TaskRewardOperator::
                interactionContactTracking,
            .sourceGroup = track.taskContactGroup,
            .target = track.id,
            .weight = 1.0f,
            .parameters = {1.0f, 1.0f, 1.0f, 0.0f},
        });
    }
}

std::unique_ptr<MRTaskRolloutHandle>
createTaskRolloutHandle(
    metalrobo::CompiledRun run,
    const char* metallibPath,
    std::string taskId,
    const std::string_view source,
    std::optional<metalrobo::FiniteResourceConfig> resources=std::nullopt
) {
    metalrobo::MetalWorldConfig worldConfig;
    worldConfig.preferParallelABA = false;
    if (metallibPath != nullptr && metallibPath[0] != '\0') {
        worldConfig.metallibPath = metallibPath;
    }
    worldConfig.maximumInFlightSubmissions = 1u;
    worldConfig.enableResidentCheckpoints = MR_TASK_PROGRAM_HAS_RETINAL(run.task().header().articulation.z);
    auto handle = std::make_unique<MRTaskRolloutHandle>(
        std::move(worldConfig),
        std::move(run)
    );
    if (metallibPath != nullptr && metallibPath[0] != '\0') {
        handle->metallibPath = metallibPath;
    }
    const metalrobo::CompiledTaskProgram& taskProgram =
        handle->run.task();
    const auto appendOutcome = [&handle](
        std::string id,
        std::string unit,
        const std::uint32_t source,
        const std::uint32_t direction
    ) {
        handle->outcomes.push_back({
            std::move(id), std::move(unit), source, direction
        });
    };
    appendOutcome("reward", "reward", MR_TASK_OUTCOME_REWARD,
        MR_TASK_OUTCOME_HIGHER_IS_BETTER);
    appendOutcome("task_reward", "reward", MR_TASK_OUTCOME_TASK_REWARD,
        MR_TASK_OUTCOME_HIGHER_IS_BETTER);
    appendOutcome("done", "bool", MR_TASK_OUTCOME_DONE,
        MR_TASK_OUTCOME_LOWER_IS_BETTER);
    appendOutcome("timeout", "bool", MR_TASK_OUTCOME_TIMEOUT,
        MR_TASK_OUTCOME_NEUTRAL);
    appendOutcome("physics_error", "bool", MR_TASK_OUTCOME_PHYSICS_ERROR,
        MR_TASK_OUTCOME_LOWER_IS_BETTER);
    for (const metalrobo::CompiledTaskOutcomeSpec& outcome :
         taskProgram.outcomes()) {
        appendOutcome(
            outcome.id,
            outcome.unit,
            outcome.source,
            static_cast<std::uint32_t>(outcome.direction)
        );
    }
    handle->defaultSceneBodies.assign(
        handle->run.defaultSceneBodies().begin(),
        handle->run.defaultSceneBodies().end()
    );
    handle->taskId = std::move(taskId);
    if (handle->run.world().sceneBodyCount() !=
            handle->defaultSceneBodies.size()) {
        throw std::runtime_error(
            std::string{source} +
            " scene-state count does not match compiled topology"
        );
    }
    const metalrobo::RunProfile& profile = handle->run.profile();
    handle->environmentCount = profile.environmentCount;
    handle->stepConfig.timestepSeconds = profile.controlTimestepSeconds;
    handle->stepConfig.physicsSubsteps = profile.physicsSubsteps;
    handle->stepConfig.solverMode =
        metalrobo::MetalWorldSolverMode::temporalCone;
    handle->stepConfig.actuationMode =
        metalrobo::MetalWorldActuationMode::implicitPositionDrive;
    handle->stepConfig.velocityIterations = profile.velocityIterations;
    handle->stepConfig.finalVelocityIterations =
        profile.finalVelocityIterations;
    handle->stepConfig.ccdMode = std::any_of(
        handle->model.shapes.begin(),
        handle->model.shapes.end(),
        [](const MRShapeGPU& shape) {
            return (shape.flags & MR_SHAPE_FLAG_ENABLE_CCD) != 0u;
        }
    )
        ? metalrobo::MetalWorldCCDMode::hybrid
        : metalrobo::MetalWorldCCDMode::disabled;
    handle->stepConfig.applyBodyDamping = true;
    handle->stepConfig.deterministic = true;
    handle->stepConfig.warmStart = true;
    handle->stepConfig.streamedArticulatedContactResponses = false;
    handle->stepConfig.matrixFreeArticulatedContact = false;
    handle->stepConfig.minimumDifficultyBand =
        profile.minimumDifficultyBand;
    handle->stepConfig.maximumDifficultyBand =
        profile.maximumDifficultyBand;
    handle->stepConfig.difficultySamplingExponentOverride =
        profile.difficultySamplingExponentOverride;
    handle->stepConfig.captureContactEvidence = std::getenv("CROW_CONTACT_TRACE") != nullptr;
    handle->stepConfig.publishFinalState = false;
    handle->stepConfig.publishStateTrajectory = false;
    handle->stepConfig.taskProgram = taskProgram;
    if (const metalrobo::MetalWorldMulticopterProgram* multicopter =
            handle->run.multicopterProgram()) {
        handle->stepConfig.multicopterProgram = *multicopter;
    }
    if (const metalrobo::MetalWorldFlappingWingProgram* flappingWings =
            handle->run.flappingWingProgram()) {
        handle->stepConfig.flappingWingProgram = *flappingWings;
    }
    if(resources) {
        const auto& r=*resources;
        if(r.worldFingerprint!=handle->world.fingerprint() || r.environmentCount!=handle->environmentCount ||
            r.bodyCount!=handle->model.bodies.size() || r.nq!=handle->model.defaultQ.size() ||
            metalrobo::finiteResourceProgramFingerprint(r.program,r.patches,r.publishTaskState,r.allocation)!=taskProgram.header().deviceStateProgramFingerprint)
            throw std::invalid_argument("Authored native resources differ from the compiled world/task");
        handle->resourceRuntime=std::make_unique<metalrobo::FiniteResourceContext>(std::move(*resources));
        handle->stepConfig.devicePhysicsProgram=handle->resourceRuntime->deviceProgram();
    }
    if (const metalrobo::VisualSensorProgram* visual =
            handle->run.visualSensorProgram()) {
        installTaskVisualRuntime(*handle, *visual);
    }
    resetTaskRolloutState(*handle, profile.seed);
    return handle;
}

float taskOutcomeValue(
    const MRTaskTransitionC& transition,
    const std::uint32_t source
) {
    switch (source) {
    case MR_TASK_OUTCOME_REWARD: return transition.reward;
    case MR_TASK_OUTCOME_TASK_REWARD: return transition.task_reward;
    case MR_TASK_OUTCOME_TRACKING_SCORE: return transition.tracking_score;
    case MR_TASK_OUTCOME_ROOT_HEIGHT: return transition.root_height;
    case MR_TASK_OUTCOME_TILT: return transition.tilt;
    case MR_TASK_OUTCOME_DONE: return static_cast<float>(transition.done);
    case MR_TASK_OUTCOME_TIMEOUT: return static_cast<float>(transition.timeout);
    case MR_TASK_OUTCOME_PHYSICS_ERROR:
        return static_cast<float>(transition.physics_error);
    case MR_TASK_OUTCOME_CONTACT_REWARD: return transition.contact_reward;
    case MR_TASK_OUTCOME_CHANNEL_0:
        return transition.task_outcome_channel_0;
    case MR_TASK_OUTCOME_CHANNEL_1:
        return transition.task_outcome_channel_1;
    case MR_TASK_OUTCOME_CHANNEL_2:
        return transition.task_outcome_channel_2;
    case MR_TASK_OUTCOME_CHANNEL_3:
        return transition.task_outcome_channel_3;
    case MR_TASK_OUTCOME_CHANNEL_4:
        return transition.task_outcome_channel_4;
    case MR_TASK_OUTCOME_CHANNEL_5:
        return transition.task_outcome_channel_5;
    case MR_TASK_OUTCOME_CHANNEL_6:
        return transition.task_outcome_channel_6;
    case MR_TASK_OUTCOME_CHANNEL_7:
        return transition.task_outcome_channel_7;
    case MR_TASK_OUTCOME_NAVIGATION_PROGRESS:
        return transition.navigation_cumulative_progress;
    case MR_TASK_OUTCOME_NAVIGATION_WAYPOINTS_REACHED:
        return transition.navigation_waypoints_reached;
    case MR_TASK_OUTCOME_NAVIGATION_COMPLETION:
        return transition.navigation_completion;
    default: return 0.0f;
    }
}

std::vector<metalrobo::LocomotionDynamicSphere>
locomotionDynamicSpheres(const MRTaskRolloutConfigC& config) {
    std::vector<metalrobo::LocomotionDynamicSphere> spheres;
    spheres.reserve(config.dynamic_sphere_count);
    for (std::uint32_t index = 0u;
         index < config.dynamic_sphere_count;
         ++index) {
        const MRTaskRolloutDynamicSphereC& source =
            config.dynamic_spheres[index];
        spheres.push_back({
            .position = {
                source.position[0], source.position[1],
                source.position[2], 1.0f,
            },
            .linearVelocity = {
                source.linear_velocity[0],
                source.linear_velocity[1],
                source.linear_velocity[2], 0.0f,
            },
            .radius = source.radius,
            .mass = source.mass,
            .launchStep = source.launch_step,
        });
    }
    return spheres;
}

void applyRunProfile(
    metalrobo::RunManifest& manifest,
    const MRTaskRolloutConfigC& config
) {
    manifest.profile.id = "native_task_rollout";
    manifest.profile.environmentCount = config.environment_count;
    manifest.profile.controlSteps = 1u;
    manifest.profile.physicsSubsteps = config.physics_substeps;
    manifest.profile.velocityIterations = config.velocity_iterations;
    manifest.profile.finalVelocityIterations =
        config.final_velocity_iterations;
    manifest.profile.controlTimestepSeconds =
        config.control_timestep_seconds;
    manifest.profile.seed = config.seed;
    manifest.profile.streamedArticulatedContactResponses =
        config.materialize_articulated_contact_responses == 0u;
    if (config.override_difficulty_band_range != 0u) {
        manifest.profile.minimumDifficultyBand =
            config.minimum_difficulty_band;
        manifest.profile.maximumDifficultyBand =
            config.maximum_difficulty_band;
    }
    manifest.profile.difficultySamplingExponentOverride =
        config.difficulty_sampling_exponent_override;
}

metalrobo::RunManifest makeUnitreeG1RunManifest(
    const metalrobo::LocomotionSurface surface,
    const metalrobo::UnitreeG1Task taskKind,
    const MRTaskRolloutConfigC& config
) {
    auto robot = metalrobo::builtinRobotPack("unitree_g1");
    if (!robot) {
        throw std::logic_error("bundled G1 RobotPack is unavailable");
    }
    metalrobo::RunManifest manifest;
    manifest.id = "unitree_g1_run";
    manifest.robot = std::move(*robot);
    manifest.scene.id = surface == metalrobo::LocomotionSurface::ground
        ? "ground_scene"
        : "terrain_scene";
    manifest.sensors.id = "unitree_g1_default_sensors";
    manifest.reality.id = "nominal_reality";
    applyRunProfile(manifest, config);

    switch (taskKind) {
    case metalrobo::UnitreeG1Task::velocity:
        manifest.task = metalrobo::makeUnitreeG1LocomotionTaskPack(
            surface,
            manifest.sensors.observation,
            manifest.reality.reset
        );
        break;
    case metalrobo::UnitreeG1Task::disturbanceRecovery:
        manifest.task =
            metalrobo::makeUnitreeG1DisturbanceRecoveryTaskPack(
                surface,
                manifest.sensors.observation,
                manifest.reality.reset
            );
        break;
    case metalrobo::UnitreeG1Task::supineGetUpDiscovery:
        manifest.task =
            metalrobo::makeUnitreeG1SupineGetUpDiscoveryTaskPack(
                surface,
                manifest.sensors.observation,
                manifest.reality.reset
            );
        break;
    case metalrobo::UnitreeG1Task::ballDisturbanceRecovery:
        manifest.task = metalrobo::
            makeUnitreeG1BallDisturbanceRecoveryTaskPack(
                surface,
                manifest.sensors.observation,
                manifest.reality.reset
            );
        break;
    case metalrobo::UnitreeG1Task::ballDodge:
        manifest.task = metalrobo::makeUnitreeG1BallDodgeTaskPack(
            surface,
            manifest.sensors.observation,
            manifest.reality.reset
        );
        break;
    case metalrobo::UnitreeG1Task::developmentalRecovery:
        manifest.task = metalrobo::
            makeUnitreeG1DevelopmentalRecoveryTaskPack(
                surface,
                manifest.sensors.observation,
                manifest.reality.reset
            );
        break;
    case metalrobo::UnitreeG1Task::adultLocomotion:
        manifest.task = metalrobo::
            makeUnitreeG1AdultLocomotionTaskPack(
                surface,
                manifest.sensors.observation,
                manifest.reality.reset
        );
        break;
    case metalrobo::UnitreeG1Task::g1LegsLocomotion:
        manifest.task = metalrobo::makeUnitreeG1LegsLocomotionTaskPack(
            surface,
            manifest.sensors.observation,
            manifest.reality.reset
        );
        break;
    }
    if (taskKind == metalrobo::UnitreeG1Task::g1LegsLocomotion) {
        // The imported actor owns only the twelve leg motors.  Preserve its
        // position-drive/reset contract for the rest of the G1 rather than
        // allowing the generic whole-body action profile to move the arms.
        constexpr std::array<float, 29u> targets{{
            -0.125f, 0.0f, 0.0f, 0.3f, -0.2f, 0.0f,
            -0.125f, 0.0f, 0.0f, 0.3f, -0.2f, 0.0f,
            0.0f, 0.0f, 0.0f,
            0.0f, 0.2f, 0.0f, 0.9f, 0.0f, 0.0f, 0.0f,
            0.0f, -0.2f, 0.0f, 0.9f, 0.0f, 0.0f, 0.0f,
        }};
        constexpr std::array<float, 29u> stiffness{{
            110.0f, 110.0f, 110.0f, 100.0f, 40.0f, 40.0f,
            110.0f, 110.0f, 110.0f, 100.0f, 40.0f, 40.0f,
            250.0f, 250.0f, 250.0f,
            90.0f, 60.0f, 20.0f, 60.0f, 4.0f, 4.0f, 4.0f,
            90.0f, 60.0f, 20.0f, 60.0f, 4.0f, 4.0f, 4.0f,
        }};
        constexpr std::array<float, 29u> damping{{
            1.5f, 1.5f, 1.5f, 4.0f, 2.5f, 2.5f,
            1.5f, 1.5f, 1.5f, 4.0f, 2.5f, 2.5f,
            5.0f, 5.0f, 5.0f,
            2.0f, 1.0f, 0.4f, 1.0f, 0.2f, 0.2f, 0.2f,
            2.0f, 1.0f, 0.4f, 1.0f, 0.2f, 0.2f, 0.2f,
        }};
        constexpr std::uint32_t rootQCount = 7u;
        // The imported policy was trained around a 0.83 m pelvis-link height. G1's
        // generic task reset is 0.80 m, so preserve the source standing
        // geometry before its PD controller takes the first policy action.
        if (manifest.robot.mechanics.defaultQ.size() > 2u) {
            manifest.robot.mechanics.defaultQ[2u] += 0.03f;
        }
        if (!manifest.robot.mechanics.materials.empty()) {
            // The source validation scene uses MuJoCo's unit-friction
            // flat floor.  Keep the imported policy on that authored contact
            // contract instead of the bundled RL-Lab 0.6 preset.
            manifest.robot.mechanics.materials.front().friction =
                {1.0f, 1.0f, 0.0f, 0.0f};
        }
        for (std::size_t motor = 0u; motor < targets.size(); ++motor) {
            const std::uint32_t qIndex = rootQCount +
                static_cast<std::uint32_t>(motor);
            if (qIndex < manifest.robot.mechanics.defaultQ.size()) {
                manifest.robot.mechanics.defaultQ[qIndex] = targets[motor];
            }
            for (MRDofPropertiesGPU& dof : manifest.robot.mechanics.dofs) {
                if (dof.jointIndex == motor) {
                    dof.drive.x = stiffness[motor];
                    dof.drive.y = damping[motor];
                    if (motor < 12u) {
                        // The source AGILE leg spec uses a 0.02 kg m^2
                        // reflected actuator armature.  The bundled G1
                        // locomotion preset has a lower hardware-specific
                        // value, which makes this imported gait overreact.
                        dof.drive.z = 0.02f;
                    }
                    break;
                }
            }
            if (motor < 12u && motor < manifest.robot.actuators.size()) {
                manifest.robot.actuators[motor].scale = 0.5f;
            }
        }
    }
    if (taskKind == metalrobo::UnitreeG1Task::supineGetUpDiscovery ||
        taskKind == metalrobo::UnitreeG1Task::developmentalRecovery) {
        if (!manifest.robot.mechanics.materials.empty()) {
            manifest.robot.mechanics.materials.front().response.z =
                1.25e-7f;
        }
        for (metalrobo::RobotActuatorSpec& actuator :
             manifest.robot.actuators) {
            const auto joint = std::ranges::find(
                manifest.robot.mechanics.jointNames,
                actuator.target
            );
            if (joint == manifest.robot.mechanics.jointNames.end()) {
                continue;
            }
            const std::uint32_t jointIndex =
                static_cast<std::uint32_t>(
                    joint - manifest.robot.mechanics.jointNames.begin()
                );
            const auto dof = std::ranges::find_if(
                manifest.robot.mechanics.dofs,
                [jointIndex](const MRDofPropertiesGPU& candidate) {
                    return candidate.jointIndex == jointIndex;
                }
            );
            if (dof == manifest.robot.mechanics.dofs.end() ||
                dof->qIndex >= manifest.robot.mechanics.defaultQ.size()) {
                continue;
            }
            // Keep G1 recovery actuators at unit scale too.  Joint travel
            // remains represented by the authored limits, not an implicit
            // per-joint action multiplier.
            actuator.scale = 1.0f;
            actuator.responseTimeSeconds = 0.0f;
        }
    }
    if (config.disable_task_terminations != 0u) {
        manifest.task.terminations.clear();
    }
    manifest.profile.capacities = manifest.task.capacities;
    const metalrobo::LocomotionSceneComponent surfaceComponent =
        metalrobo::makeLocomotionSurfaceComponent(
            manifest.robot.mechanics,
            surface
        );
    manifest.scene.objects.push_back({
        .id = surface == metalrobo::LocomotionSurface::ground
            ? "locomotion_ground"
            : "locomotion_terrain",
        .semanticClass = "support_surface",
        .role = MR_WORLD_ASSET_FIXTURE,
        .render = MR_WORLD_RENDER_NONE,
        .collision = surface == metalrobo::LocomotionSurface::ground
            ? MR_WORLD_COLLISION_PRIMITIVES
            : MR_WORLD_COLLISION_TRIANGLE_MESH,
        .dynamics = MR_WORLD_DYNAMICS_STATIC,
        .mechanics = surfaceComponent.mechanics,
        .defaultBodyStates = surfaceComponent.defaultBodyStates,
    });
    const auto spheres = locomotionDynamicSpheres(config);
    if (!spheres.empty()) {
        metalrobo::LocomotionSceneComponent sphereComponent =
            metalrobo::makeLocomotionDynamicSphereComponent(
                manifest.robot.mechanics,
                spheres
            );
        manifest.scene.objects.push_back({
            .id = "locomotion_dynamic_spheres",
            .semanticClass = "dynamic_projectile",
            .role = MR_WORLD_ASSET_MANIPULATED,
            .render = MR_WORLD_RENDER_NONE,
            .collision = MR_WORLD_COLLISION_PRIMITIVES,
            .dynamics = MR_WORLD_DYNAMICS_RIGID,
            .mechanics = std::move(sphereComponent.mechanics),
            .defaultBodyStates =
                std::move(sphereComponent.defaultBodyStates),
        });
    }
    return manifest;
}

metalrobo::RunManifest makeFrankaPickPlaceRunManifest(
    const MRTaskRolloutConfigC& config
) {
    auto robot = metalrobo::builtinRobotPack("franka_panda");
    if (!robot) {
        throw std::logic_error("bundled Franka RobotPack is unavailable");
    }
    metalrobo::RunManifest manifest;
    manifest.id = "franka_pick_place_run";
    manifest.robot = std::move(*robot);
    manifest.scene = metalrobo::makeFrankaPickPlaceScenePack();
    manifest.sensors.id = "franka_default_sensors";
    manifest.task = metalrobo::makeFrankaPickPlaceTaskPack(
        manifest.sensors.observation,
        manifest.reality.reset
    );
    if (config.disable_task_terminations != 0u) {
        manifest.task.terminations.clear();
    }
    manifest.reality.id = "franka_nominal_reality";
    manifest.reality.program =
        metalrobo::makeFrankaPickPlaceWorldProgram();
    // This run has no visual sensor executor yet. Retain only variations with
    // a direct native physics/controller/reset effect; camera, appearance and
    // topology alternatives must never survive as passive metadata.
    std::erase_if(
        manifest.reality.program.variations,
        [](const metalrobo::VariationParameter& variation) {
            return variation.target >=
                    MR_WORLD_TARGET_ASSET_RENDER_ALTERNATIVE ||
                variation.target == MR_WORLD_TARGET_ASSET_SCALE ||
                variation.target ==
                    MR_WORLD_TARGET_ASSET_ORIENTATION_ROLL ||
                variation.target ==
                    MR_WORLD_TARGET_ASSET_ORIENTATION_PITCH ||
                variation.target ==
                    MR_WORLD_TARGET_ASSET_ORIENTATION_YAW;
        }
    );
    for (metalrobo::VariationParameter& variation :
         manifest.reality.program.variations) {
        if (variation.targetId == "franka") {
            variation.targetId = manifest.robot.id;
        }
    }
    applyRunProfile(manifest, config);
    manifest.profile.capacities = manifest.task.capacities;
    return manifest;
}

metalrobo::RunManifest makeImportedRunManifest(
    metalrobo::EngineModel mechanics,
    std::vector<MRBodyStateGPU> defaultSceneBodies,
    const std::uint32_t articulationIndex,
    metalrobo::TaskPack task,
    metalrobo::RobotActuatorPack actuatorPack,
    metalrobo::SensorProgramPack sensorPack,
    metalrobo::RealityProgramPack realityPack,
    const MRTaskRolloutConfigC& config,
    std::string id
) {
    // A RobotActuatorPack is executable controller truth, not descriptive
    // metadata. Position-controller overrides must reach the cooked model's
    // implicit drives before WorldPack compilation; otherwise the task can
    // publish valid targets that exert no physical authority.
    for (const metalrobo::RobotActuatorSpec& actuator :
         actuatorPack.actuators) {
        if (actuator.kind !=
                metalrobo::RobotActuatorKind::jointPosition ||
            (actuator.parameters.x == 0.0f &&
             actuator.parameters.y == 0.0f)) {
            continue;
        }
        const auto first = std::find(
            mechanics.dofNames.begin(), mechanics.dofNames.end(),
            actuator.target
        );
        if (first == mechanics.dofNames.end() ||
            std::find(
                std::next(first), mechanics.dofNames.end(),
                actuator.target
            ) != mechanics.dofNames.end()) {
            throw std::invalid_argument(
                "joint-position actuator controller target is unresolved or ambiguous: " +
                actuator.target
            );
        }
        const std::size_t dofIndex = static_cast<std::size_t>(
            first - mechanics.dofNames.begin()
        );
        if (dofIndex >= mechanics.dofs.size() ||
            !(actuator.parameters.x > 0.0f) ||
            actuator.parameters.y < 0.0f) {
            throw std::invalid_argument(
                "joint-position actuator controller parameters are invalid: " +
                actuator.id
            );
        }
        MRDofPropertiesGPU& dof = mechanics.dofs[dofIndex];
        dof.flags |= MR_DOF_FLAG_DRIVE;
        dof.drive.x = actuator.parameters.x;
        dof.drive.y = actuator.parameters.y;
    }
    metalrobo::RunManifest manifest;
    manifest.id = std::move(id);
    manifest.robot.id = manifest.id + ".robot";
    manifest.robot.mechanics = std::move(mechanics);
    manifest.robot.defaultSceneBodies =
        std::move(defaultSceneBodies);
    manifest.robot.primaryArticulationIndex =
        articulationIndex;
    manifest.robot.actuators = std::move(actuatorPack.actuators);
    manifest.robot.capabilities = {"authored_task_execution"};
    manifest.robot.roles.push_back({
        .id = "whole_body",
        .kind = metalrobo::RobotSemanticKind::body,
        .members = manifest.robot.mechanics.bodyNames,
    });
    if (!manifest.robot.mechanics.jointNames.empty()) {
        manifest.robot.roles.push_back({
            .id = "all_joints",
            .kind = metalrobo::RobotSemanticKind::joint,
            .members = manifest.robot.mechanics.jointNames,
        });
    }
    if (!manifest.robot.mechanics.dofNames.empty()) {
        manifest.robot.roles.push_back({
            .id = "all_dofs",
            .kind = metalrobo::RobotSemanticKind::dof,
            .members = manifest.robot.mechanics.dofNames,
        });
    }
    manifest.scene.id = manifest.id + ".scene";
    manifest.sensors.id = std::move(sensorPack.id);
    manifest.sensors.observation = std::move(sensorPack.observation);
    manifest.task = std::move(task);
    manifest.reality.id = std::move(realityPack.id);
    manifest.reality.program = std::move(realityPack.program);
    manifest.reality.sourceProgramFingerprint =
        realityPack.sourceProgramFingerprint;
    manifest.reality.reset = std::move(realityPack.reset);
    manifest.teacher.id = "no_teacher";
    applyRunProfile(manifest, config);
    manifest.profile.capacities = manifest.task.capacities;
    return manifest;
}

metalrobo::VisualSensorProgram visualSensorProgram(
    const MRTaskVisualObservationConfigC& config
) {
    if (config.capture_policy_camera > 1u) {
        throw std::invalid_argument(
            "visual capture policy-camera flag is invalid"
        );
    }
    if (config.pack_count != 0u && config.packs == nullptr) {
        throw std::invalid_argument(
            "visual SensorPack asset bindings are missing"
        );
    }
    metalrobo::VisualSensorProgram program;
    program.assets.reserve(config.pack_count);
    for (std::uint32_t index = 0u; index < config.pack_count; ++index) {
        const MRTaskVisualPackC& reference = config.packs[index];
        if (reference.path == nullptr || reference.path[0] == '\0' ||
            reference.asset_id == nullptr || reference.asset_id[0] == '\0') {
            throw std::invalid_argument(
                "visual SensorPack contains an incomplete asset binding"
            );
        }
        metalrobo::VisualAssetPackV2 pack;
        std::string reason;
        if (!metalrobo::readVisualAssetPackIndex(
                reference.path,
                pack,
                &reason
            )) {
            throw std::invalid_argument(
                "visual SensorPack asset load failed: " + reason
            );
        }
        program.assets.push_back({
            reference.path,
            reference.asset_id,
            pack.contentHash,
            reference.semantic_id,
            reference.instance_id,
        });
    }
    if (config.environment_pack_path != nullptr &&
        config.environment_pack_path[0] != '\0') {
        metalrobo::VisualEnvironmentPackV2 environment;
        std::string reason;
        if (!metalrobo::readVisualEnvironmentPackIndex(
                config.environment_pack_path,
                environment,
                &reason
            )) {
            throw std::invalid_argument(
                "visual SensorPack environment load failed: " + reason
            );
        }
        program.environmentPath = config.environment_pack_path;
        program.environmentContentHash = environment.contentHash;
    }
    program.rendererProfile =
        config.renderer_profile == nullptr
        ? std::string{}
        : config.renderer_profile;
    program.cameraParentBody =
        config.camera_parent_body == nullptr
        ? std::string{}
        : config.camera_parent_body;
    program.cameraPosition = {
        config.camera_position[0],
        config.camera_position[1],
        config.camera_position[2],
        0.0f,
    };
    program.cameraOrientation = {
        config.camera_orientation[0],
        config.camera_orientation[1],
        config.camera_orientation[2],
        config.camera_orientation[3],
    };
    program.width = config.width;
    program.height = config.height;
    program.minimumVisiblePixels = config.minimum_visible_pixels;
    program.verticalFieldOfViewDegrees =
        config.vertical_field_of_view_degrees;
    program.nominalRateHz = config.nominal_rate_hz;
    program.maximumRetainedBytes = config.maximum_retained_bytes;
    program.captureWidth = config.capture_width;
    program.captureHeight = config.capture_height;
    program.capturePolicyCamera = config.capture_policy_camera != 0u;
    program.fingerprint =
        metalrobo::visualSensorProgramFingerprint(program);
    return program;
}

std::unique_ptr<MRTaskRolloutHandle> createCompiledRunTaskRollout(
    metalrobo::RunManifest manifest,
    const char* metallibPath,
    const std::string_view source,
    const MRTaskVisualObservationConfigC* visualSensor,
    const metalrobo::RunManifest* compatiblePolicySource = nullptr,
    std::optional<metalrobo::FiniteResourceConfig> resources=std::nullopt
) {
    const auto prepareManifest = [visualSensor](
        metalrobo::RunManifest& value
    ) {
        if (value.teacher.id.empty()) {
            value.teacher.id = "no_teacher";
        }
        if (visualSensor != nullptr) {
            value.sensors.deviceVisual =
                visualSensorProgram(*visualSensor);
        }
        // Task composition (notably an InteractionPack) may refine the
        // measured contact profile after the base manifest is authored.
        value.profile.capacities = value.task.capacities;
    };
    prepareManifest(manifest);
    metalrobo::CompiledRun compiled;
    const metalrobo::RunCompileDiagnostics status =
        metalrobo::compileRun(manifest, compiled);
    if (!status.succeeded()) {
        throw std::runtime_error(
            std::string{source} + " CompiledRun failed [" +
            metalrobo::runCompileStatusName(status.status) + "]: " +
            status.element + ": " + status.message
        );
    }
    auto handle = createTaskRolloutHandle(
        std::move(compiled),
        metallibPath,
        manifest.task.id,
        source,std::move(resources)
    );
    if (compatiblePolicySource != nullptr) {
        metalrobo::RunManifest sourceManifest =
            *compatiblePolicySource;
        prepareManifest(sourceManifest);
        metalrobo::CompiledRun sourceRun;
        const metalrobo::RunCompileDiagnostics sourceStatus =
            metalrobo::compileRun(sourceManifest, sourceRun);
        if (sourceStatus.succeeded() &&
            sourceRun.task().worldFingerprint() ==
                handle->taskProgram.worldFingerprint() &&
            sourceRun.task().observationFingerprint() ==
                handle->taskProgram.observationFingerprint() &&
            sourceRun.task().actionFingerprint() ==
                handle->taskProgram.actionFingerprint()) {
            handle->compatiblePolicySourceTask = sourceRun.task();
        }
    }
    return handle;
}

std::vector<float> copyPolicyFloats(
    const float* values,
    const std::size_t count,
    const char* label
) {
    if (count != 0u && values == nullptr) {
        throw std::invalid_argument(
            std::string{label} + " pointer is null"
        );
    }
    return count == 0u
        ? std::vector<float>{}
        : std::vector<float>{values, values + count};
}

metalrobo::PolicyPack policyPackFromC(
    const MRPolicyPackC& policy
) {
    if (policy.id == nullptr ||
        policy.id[0] == '\0' ||
        policy.layers == nullptr ||
        policy.layer_count == 0u ||
        policy.layer_count >
            std::numeric_limits<std::uint32_t>::max() ||
        policy.critic_layer_count >
            std::numeric_limits<std::uint32_t>::max() ||
        (policy.critic_layer_count != 0u &&
         policy.critic_layers == nullptr)) {
        throw std::invalid_argument(
            "policy identity and dense layers are required"
        );
    }

    metalrobo::PolicyPack authored;
    authored.id = policy.id;
    authored.revision = policy.revision;
    authored.contract = {
        .version = policy.contract_version,
        .worldFingerprint = policy.world_fingerprint,
        .taskFingerprint = policy.task_fingerprint,
        .observationFingerprint = policy.observation_fingerprint,
        .actionFingerprint = policy.action_fingerprint,
    };
    authored.observationMean = copyPolicyFloats(
        policy.observation_mean,
        policy.observation_mean_count,
        "policy observation mean"
    );
    authored.observationInverseStandardDeviation =
        copyPolicyFloats(
            policy.observation_inverse_standard_deviation,
            policy.observation_inverse_standard_deviation_count,
            "policy observation inverse standard deviation"
        );
    authored.criticObservationMean = copyPolicyFloats(
        policy.critic_observation_mean,
        policy.critic_observation_mean_count,
        "policy critic observation mean"
    );
    authored.criticObservationInverseStandardDeviation =
        copyPolicyFloats(
            policy.critic_observation_inverse_standard_deviation,
            policy.critic_observation_inverse_standard_deviation_count,
            "policy critic observation inverse standard deviation"
        );
    authored.actionLogStandardDeviation =
        copyPolicyFloats(
            policy.action_log_standard_deviation,
            policy.action_log_standard_deviation_count,
            "policy action log standard deviation"
        );
    authored.actionBias = copyPolicyFloats(
        policy.action_bias,
        policy.action_bias_count,
        "policy action bias"
    );
    authored.actionScale = copyPolicyFloats(
        policy.action_scale,
        policy.action_scale_count,
        "policy action scale"
    );
    authored.observationClip = policy.observation_clip;
    authored.actionClip = policy.action_clip;
    const auto appendLayers = [](
        const MRPolicyDenseLayerC* sources,
        const std::size_t count,
        std::vector<metalrobo::PolicyDenseLayer>& destination,
        const char* label
    ) {
        destination.reserve(count);
        for (std::size_t index = 0u;
             index < count;
             ++index) {
            const MRPolicyDenseLayerC& source =
                sources[index];
            const std::uint64_t expectedWeights =
                static_cast<std::uint64_t>(
                    source.input_count
                ) * source.output_count;
            if (source.activation >
                    MR_POLICY_ACTIVATION_C_SILU ||
                expectedWeights != source.weight_count ||
                source.bias_count != source.output_count) {
                throw std::invalid_argument(
                    std::string{label} +
                    " dense layer shape or activation is invalid"
                );
            }
            destination.push_back({
                .inputCount = source.input_count,
                .outputCount = source.output_count,
                .activation =
                    static_cast<
                        metalrobo::PolicyActivation
                    >(source.activation),
                .weights = copyPolicyFloats(
                    source.weights,
                    source.weight_count,
                    "policy dense weights"
                ),
                .bias = copyPolicyFloats(
                    source.bias,
                    source.bias_count,
                    "policy dense bias"
                ),
            });
        }
    };
    appendLayers(
        policy.layers,
        policy.layer_count,
        authored.layers,
        "actor"
    );
    appendLayers(
        policy.critic_layers,
        policy.critic_layer_count,
        authored.criticLayers,
        "critic"
    );
    return authored;
}

void installPolicyPack(
    MRTaskRolloutHandle& handle,
    const metalrobo::PolicyPack& authored
) {
    metalrobo::CompiledPolicyProgram compiled;
    metalrobo::PolicyCompileDiagnostics status =
        metalrobo::compilePolicyProgram(
            authored,
            handle.taskProgram,
            compiled
        );
    if (!status.succeeded() &&
        handle.compatiblePolicySourceTask.valid()) {
        status = metalrobo::compilePolicyProgramForTaskVariant(
            authored,
            handle.compatiblePolicySourceTask,
            handle.taskProgram,
            compiled
        );
    }
    if (!status.succeeded()) {
        throw std::invalid_argument(
            std::string{"PolicyPack compile failed ["} +
            metalrobo::policyCompileStatusName(
                status.status
            ) + "]: " + status.element + ": " +
            status.message
        );
    }
    if (handle.residentState.valid()) {
        const auto* previous=handle.stepConfig.policyProgram.actorMemory();const auto* next=compiled.actorMemory();
        if (bool(previous)!=bool(next) || (previous && (previous->afterLayer!=next->afterLayer ||
            previous->cell.inputs!=next->cell.inputs || previous->cell.hidden!=next->cell.hidden)))
            throw std::invalid_argument("Policy publication cannot change recurrent architecture inside a resident life");
        if (previous && compiled.fingerprint()!=handle.stepConfig.policyProgram.fingerprint() &&
            compiled.revision()<=handle.stepConfig.policyProgram.revision())
            throw std::invalid_argument("Resident recurrent policy changes require a strictly increasing revision");
    }
    handle.stepConfig.policyProgram = std::move(compiled);
}

void installBasePolicyPack(
    MRTaskRolloutHandle& handle,
    const metalrobo::PolicyPack& authored
) {
    // A base actor is an immutable deterministic action source. Keeping its
    // stochastic head or critic would make protected-band behavior depend on
    // a second random stream and break the exact non-forgetting control.
    if (!authored.criticLayers.empty() ||
        !authored.actionLogStandardDeviation.empty()) {
        throw std::invalid_argument(
            "residual base PolicyPack must be deterministic and actor-only"
        );
    }
    metalrobo::CompiledPolicyProgram compiled;
    const metalrobo::PolicyCompileDiagnostics status =
        metalrobo::compilePolicyProgram(
            authored,
            handle.taskProgram,
            compiled
        );
    if (!status.succeeded()) {
        throw std::invalid_argument(
            std::string{"base PolicyPack compile failed ["} +
            metalrobo::policyCompileStatusName(status.status) +
            "]: " + status.element + ": " + status.message
        );
    }
    handle.stepConfig.basePolicyProgram = std::move(compiled);
}

std::runtime_error worldFamilyError(
    const char* operation,
    const metalrobo::MetalWorldFamilyDiagnostics& diagnostics
);

metalrobo::WorldAsset makeRolloutVisualAsset(
    const MRTaskRolloutHandle& handle,
    const std::string& id,
    const std::vector<std::uint32_t>& bodies,
    const std::uint32_t role,
    const std::uint32_t render,
    const std::uint32_t dynamics,
    const std::uint32_t articulationIndex = MR_INVALID_INDEX
) {
    metalrobo::WorldAsset asset;
    asset.id = id;
    asset.semanticClass = id;
    asset.role = static_cast<MRWorldAssetRole>(role);
    asset.render = static_cast<MRWorldRenderRepresentation>(render);
    asset.collision = MR_WORLD_COLLISION_PRIMITIVES;
    asset.dynamics =
        static_cast<MRWorldDynamicsRepresentation>(dynamics);
    asset.articulationIndex = articulationIndex;
    asset.bodyIndices = bodies;
    std::unordered_set<std::uint32_t> materials;
    for (std::uint32_t shape = 0u;
         shape < handle.model.shapes.size();
         ++shape) {
        if (std::ranges::find(
                bodies,
                handle.model.shapes[shape].bodyIndex
            ) == bodies.end()) {
            continue;
        }
        asset.shapeIndices.push_back(shape);
        materials.insert(handle.model.shapes[shape].materialIndex);
    }
    asset.materialIndices.assign(materials.begin(), materials.end());
    std::ranges::sort(asset.materialIndices);
    return asset;
}

std::unique_ptr<MRTaskVisualRuntime> compileTaskVisualRuntime(
    MRTaskRolloutHandle& handle,
    const metalrobo::VisualSensorProgram& program,
    const bool deviceObservation,
    const metalrobo::FiniteResourceContext* cueResources=nullptr
) {
    if (program.assets.empty() || program.cameraParentBody.empty() ||
        program.width == 0u || program.height == 0u ||
        program.minimumVisiblePixels == 0u ||
        !std::isfinite(program.verticalFieldOfViewDegrees) ||
        program.verticalFieldOfViewDegrees < 0.0f ||
        program.verticalFieldOfViewDegrees >= 180.0f ||
        !std::isfinite(program.nominalRateHz) ||
        !(program.nominalRateHz > 0.0f)) {
        throw std::invalid_argument(
            "visual observation packs, articulated camera, and dimensions are required"
        );
    }
    const std::string selectedProfile =
        program.rendererProfile.empty()
        ? "sensor_fast"
        : program.rendererProfile;
    if (selectedProfile != "sensor_fast") {
        throw std::invalid_argument(
            "closed-loop visual observation currently requires sensor_fast"
        );
    }

    const auto parentBody = std::ranges::find(
        handle.model.bodyNames,
        program.cameraParentBody
    );
    if (parentBody == handle.model.bodyNames.end()) {
        throw std::invalid_argument(
            "head-camera parent body is not present in the compiled world"
        );
    }
    const std::uint32_t parentBodyIndex =
        static_cast<std::uint32_t>(
            parentBody - handle.model.bodyNames.begin()
        );
    if (handle.model.bodies[parentBodyIndex].articulationIndex ==
        MR_INVALID_INDEX) {
        throw std::invalid_argument(
            "visual camera must be attached to an articulated link"
        );
    }

    const auto sceneIndices = handle.world.sceneBodyIndices();
    std::map<std::uint32_t, std::uint32_t> trackedOffsets;
    std::map<std::uint32_t, float> positionScales;
    std::map<std::uint32_t, float> velocityScales;
    std::unordered_set<std::uint32_t> trackedSceneBodies;
    std::unordered_set<std::uint32_t> maskedDepthSceneBodies;
    std::uint32_t maskedDepthOffset = MR_INVALID_INDEX;
    std::uint32_t maskedDepthCount = 0u;
    if (deviceObservation) {
        const auto actorOperators = handle.taskProgram.actorOperators();
        for (std::uint32_t offset = 0u;
             offset < actorOperators.size();
             ++offset) {
            const MRTaskObservationOperatorGPU& operation =
                actorOperators[offset];
            if (operation.source.x == MR_TASK_OBSERVE_MASKED_DEPTH) {
                if (maskedDepthOffset == MR_INVALID_INDEX) {
                    maskedDepthOffset = offset;
                }
                if (offset != maskedDepthOffset + operation.source.z) {
                    throw std::logic_error(
                        "compiled masked-depth actor slots are not contiguous"
                    );
                }
                ++maskedDepthCount;
                continue;
            }
            if (operation.source.x != MR_TASK_OBSERVE_OBJECT_TRACK) {
                continue;
            }
            if (operation.source.y >= sceneIndices.size()) {
                throw std::logic_error(
                    "compiled object-track scene index is invalid"
                );
            }
            if (operation.source.z == 0u) {
                trackedOffsets.emplace(operation.source.y, offset);
                trackedSceneBodies.insert(operation.source.y);
            } else if (operation.source.z == 1u) {
                positionScales.emplace(
                    operation.source.y,
                    operation.transform.x
                );
            } else if (operation.source.z == 4u) {
                velocityScales.emplace(
                    operation.source.y,
                    operation.transform.x
                );
            }
        }
        for (const MRTaskObservationOperatorGPU& operation :
             handle.taskProgram.criticOperators()) {
            if (operation.source.x == MR_TASK_OBSERVE_OBJECT_TRACK) {
                if (operation.source.y >= sceneIndices.size()) {
                    throw std::logic_error(
                        "compiled critic object-track scene index is invalid"
                    );
                }
                trackedSceneBodies.insert(operation.source.y);
            }
        }
    }
    const MRTaskProgramHeaderGPU& taskHeader =
        handle.taskProgram.header();
    const std::uint64_t expectedMaskedDepthPixels =
        static_cast<std::uint64_t>(taskHeader.visualLayout.x) *
        taskHeader.visualLayout.y * taskHeader.visualLayout.z;
    const std::uint32_t maskedDepthFeatureCount =
        (taskHeader.schedule.w &
         MR_TASK_PROGRAM_MASKED_DEPTH_FEATURES) != 0u
        ? MR_TASK_MASKED_DEPTH_FEATURE_COUNT
        : 0u;
    const std::uint64_t expectedMaskedDepth =
        expectedMaskedDepthPixels + maskedDepthFeatureCount;
    if (deviceObservation &&
        (maskedDepthCount != 0u || expectedMaskedDepth != 0u) &&
        (maskedDepthCount != expectedMaskedDepth ||
         maskedDepthOffset == MR_INVALID_INDEX)) {
        throw std::invalid_argument(
            "SensorPack masked-depth actor layout is incomplete"
        );
    }
    const bool retinal = deviceObservation && program.retinal.has_value();
    if (program.retinal && (!deviceObservation || program.captureWidth || program.captureHeight))
        throw std::invalid_argument("Retinal streams require native device observations; presentation uses a separate inspection program");
    const bool deviceObservationEnabled =
        deviceObservation &&
        (retinal || !trackedOffsets.empty() || maskedDepthCount != 0u);
    if (deviceObservation && !deviceObservationEnabled &&
        (program.captureWidth == 0u || program.captureHeight == 0u)) {
        throw std::invalid_argument(
            "visual runtime requires device observations or presentation capture"
        );
    }
    if (maskedDepthCount != 0u) {
        maskedDepthSceneBodies = trackedSceneBodies;
        if (maskedDepthSceneBodies.empty()) {
            // Navigation/perching actors may consume the visible authored
            // environment without a privileged object-track channel. Keep
            // every scene body eligible for the instance-masked depth plane;
            // ordinary object-tracking tasks retain their narrow target set.
            for (std::uint32_t local = 0u;
                 local < sceneIndices.size(); ++local) {
                maskedDepthSceneBodies.insert(local);
            }
        }
    }

    metalrobo::EpisodeTwin episode;
    episode.id = handle.model.name + ".visual_rollout";
    std::vector<std::uint32_t> articulatedBodies;
    for (std::uint32_t body = 0u;
         body < handle.model.bodies.size();
         ++body) {
        if (handle.model.bodies[body].articulationIndex !=
            MR_INVALID_INDEX) {
            articulatedBodies.push_back(body);
        }
    }
    episode.assets.push_back(makeRolloutVisualAsset(
        handle,
        "robot",
        articulatedBodies,
        MR_WORLD_ASSET_ROBOT,
        MR_WORLD_RENDER_MESH_PBR,
        MR_WORLD_DYNAMICS_ARTICULATED,
        handle.model.bodies[parentBodyIndex].articulationIndex
    ));

    std::string manipulatedAsset;
    std::string targetAsset;
    for (std::uint32_t local = 0u;
         local < sceneIndices.size();
         ++local) {
        const std::uint32_t body = sceneIndices[local];
        const std::string& id = handle.model.bodyNames[body];
        const std::uint32_t motion = handle.model.bodies[body].motionType;
        const bool tracked = trackedSceneBodies.contains(local);
        const bool maskedDepthVisible =
            maskedDepthSceneBodies.contains(local);
        const std::uint32_t role = tracked && manipulatedAsset.empty()
            ? MR_WORLD_ASSET_MANIPULATED
            : motion == MR_MOTION_STATIC
                ? MR_WORLD_ASSET_FIXTURE
                : MR_WORLD_ASSET_CLUTTER;
        const std::uint32_t dynamics = motion == MR_MOTION_STATIC
            ? MR_WORLD_DYNAMICS_STATIC
            : motion == MR_MOTION_KINEMATIC
                ? MR_WORLD_DYNAMICS_KINEMATIC
                : MR_WORLD_DYNAMICS_RIGID;
        metalrobo::WorldAsset asset = makeRolloutVisualAsset(
            handle,
            id,
            {body},
            role,
            (retinal || tracked || maskedDepthVisible || !deviceObservation)
                ? MR_WORLD_RENDER_MESH_PBR
                : MR_WORLD_RENDER_NONE,
            dynamics
        );
        // Retinal packs already contain metric geometry bound to the actual
        // collider. The legacy nonretinal tracker uses a unit-radius mesh.
        if (tracked && !retinal) {
            const auto sphereShape = std::ranges::find_if(
                asset.shapeIndices,
                [&](const std::uint32_t shape) {
                    return handle.model.shapes[shape].shapeType ==
                        MR_SHAPE_SPHERE;
                }
            );
            if (sphereShape != asset.shapeIndices.end()) {
                // The bundled visual sphere is unit radius; imported tracked
                // assets retain their authored presentation scale.
                asset.uniformScale =
                    handle.model.shapes[*sphereShape].dimensions.x;
            }
        }
        if (local < handle.defaultSceneBodies.size()) {
            const MRBodyStateGPU& state =
                handle.defaultSceneBodies[local];
            asset.initialPose.position = {
                state.position.x,
                state.position.y,
                state.position.z,
                0.0f,
            };
            asset.initialPose.orientation = state.orientation;
        }
        if (role == MR_WORLD_ASSET_MANIPULATED) {
            manipulatedAsset = id;
        }
        if (motion == MR_MOTION_STATIC && targetAsset.empty()) {
            targetAsset = id;
            asset.anchors.push_back({
                "visual_rollout_target",
                {},
                0.0f,
                0u,
            });
        }
        episode.assets.push_back(std::move(asset));
    }
    if (deviceObservationEnabled &&
        (targetAsset.empty() ||
         (!trackedOffsets.empty() && manipulatedAsset.empty()))) {
        throw std::invalid_argument(
            "visual sensing requires a static scene asset and object tracking additionally requires a tracked rigid object"
        );
    }

    metalrobo::SensorSpec camera;
    camera.id = "head_rgbd";
    camera.parentAssetId = deviceObservation ? "robot" : targetAsset;
    camera.parentKind = deviceObservation
        ? MR_WORLD_SENSOR_PARENT_ARTICULATED_LINK
        : MR_WORLD_SENSOR_PARENT_WORLD;
    camera.parentBodyIndex = deviceObservation
        ? parentBodyIndex
        : MR_INVALID_INDEX;
    camera.kind = MR_WORLD_SENSOR_RGBD;
    camera.localPose.position = {
        program.cameraPosition.x,
        program.cameraPosition.y,
        program.cameraPosition.z,
        0.0f,
    };
    camera.localPose.orientation = program.cameraOrientation;
    camera.width = program.width;
    camera.height = program.height;
    const float focalLengthPixels =
        program.verticalFieldOfViewDegrees > 0.0f
        ? 0.5f * static_cast<float>(program.height) /
            std::tan(
                0.5f * program.verticalFieldOfViewDegrees *
                std::numbers::pi_v<float> / 180.0f
            )
        : 0.875f * static_cast<float>(program.width);
    if (!std::isfinite(focalLengthPixels) ||
        !(focalLengthPixels > 0.0f)) {
        throw std::invalid_argument(
            "visual observation field of view produces invalid intrinsics"
        );
    }
    camera.intrinsics = {
        focalLengthPixels,
        focalLengthPixels,
        0.5f * static_cast<float>(program.width),
        0.5f * static_cast<float>(program.height),
    };
    camera.nominalRateHz = program.nominalRateHz;
    camera.exposureSeconds = 1.0f / 240.0f;
    camera.minimumDepthMeters = 0.05f;
    camera.maximumDepthMeters = deviceObservation ? 8.0f : 100.0f;
    if (retinal) {
        camera.minimumDepthMeters=program.retinal->minimumDepthMeters;
        camera.maximumDepthMeters=program.retinal->maximumDepthMeters;camera.depthQuantumMeters=.0001f;
        auto right=camera;right.id="right_head_rgbd";right.localPose.position=program.retinal->rightCameraPosition;
        right.localPose.orientation=program.retinal->rightCameraOrientation;
        episode.sensors.push_back(camera);episode.sensors.push_back(std::move(right));
    } else episode.sensors.push_back(std::move(camera));
    if (program.capturePolicyCamera &&
        !(program.verticalFieldOfViewDegrees > 0.0f)) {
        throw std::invalid_argument(
            "policy-camera capture requires an authored vertical field of view"
        );
    }
    if (program.captureWidth != 0u && program.captureHeight != 0u) {
        metalrobo::SensorSpec presentation;
        presentation.id = program.capturePolicyCamera
            ? "foundation_policy_camera"
            : "presentation_camera";
        presentation.parentAssetId = "robot";
        presentation.parentKind = program.capturePolicyCamera
            ? MR_WORLD_SENSOR_PARENT_ARTICULATED_LINK
            : MR_WORLD_SENSOR_PARENT_WORLD;
        presentation.parentBodyIndex = program.capturePolicyCamera
            ? parentBodyIndex
            : MR_INVALID_INDEX;
        presentation.kind = MR_WORLD_SENSOR_RGBD;
        presentation.localPose.position = program.capturePolicyCamera
            ? program.cameraPosition
            : mr_float4{1.05f, -1.30f, 1.05f, 0.0f};
        // External media keeps the qualified Studio Small 03 view. Teacher
        // capture instead inherits the deployable policy sensor pose.
        presentation.localPose.orientation = program.capturePolicyCamera
            ? program.cameraOrientation
            : mr_float4{
                  -0.73858354f,
                  -0.26102070f,
                  0.20711737f,
                  0.58605883f,
              };
        presentation.width = program.captureWidth;
        presentation.height = program.captureHeight;
        const float captureFocalLengthPixels =
            program.capturePolicyCamera
            ? 0.5f * static_cast<float>(program.captureHeight) /
                std::tan(
                    0.5f * program.verticalFieldOfViewDegrees *
                    std::numbers::pi_v<float> / 180.0f
                )
            : 0.90f * static_cast<float>(program.captureHeight);
        presentation.intrinsics = {
            captureFocalLengthPixels,
            captureFocalLengthPixels,
            0.5f * static_cast<float>(program.captureWidth),
            0.5f * static_cast<float>(program.captureHeight),
        };
        presentation.nominalRateHz = 50.0f;
        presentation.exposureSeconds = 1.0f / 240.0f;
        presentation.minimumDepthMeters = 0.05f;
        presentation.maximumDepthMeters = 12.0f;
        episode.sensors.push_back(std::move(presentation));
    }
    episode.task = !trackedOffsets.empty()
        ? metalrobo::TaskSpec{
              "compiled_task_visual_observation",
              "robot",
              manipulatedAsset,
              targetAsset,
              "visual_rollout_target",
              handle.stepConfig.timestepSeconds,
              20.0,
          }
        : metalrobo::TaskSpec{
              deviceObservationEnabled
                  ? "compiled_task_masked_depth_observation"
                  : deviceObservation
                  ? "compiled_task_presentation_capture"
                  : "inspection_presentation",
              "robot",
              {},
              {},
              {},
              handle.stepConfig.timestepSeconds,
              20.0,
          };

    auto runtime = std::make_unique<MRTaskVisualRuntime>();
    const metalrobo::WorldCompileResult worldStatus =
        metalrobo::compileEpisodeTwin(
            episode,
            handle.model,
            runtime->worldTemplate
        );
    if (!worldStatus.succeeded()) {
        throw std::runtime_error(
            "visual WorldTemplate compile failed: " +
            worldStatus.message
        );
    }
    metalrobo::WorldProgram worldProgram;
    worldProgram.id = episode.id + ".program";
    const metalrobo::WorldCompileResult familyStatus =
        metalrobo::compileWorldFamily(
            runtime->worldTemplate,
            worldProgram,
            runtime->family
        );
    if (!familyStatus.succeeded()) {
        throw std::runtime_error(
            "visual WorldFamily compile failed: " +
            familyStatus.message
        );
    }

    std::vector<metalrobo::VisualAssetReferenceV3> references;
    references.reserve(program.assets.size());
    std::unordered_map<std::string, std::uint32_t> trackedInstances;
    for (std::size_t index = 0u;
         index < program.assets.size();
         ++index) {
        const metalrobo::VisualSensorAssetProgram& source =
            program.assets[index];
        const std::uint32_t assetIndex =
            runtime->worldTemplate.assetIndex(source.assetId);
        if (assetIndex == MR_INVALID_INDEX) {
            throw std::invalid_argument(
                std::string{"visual pack references unknown asset: "} +
                source.assetId
            );
        }
        metalrobo::VisualAssetPackV2 pack;
        std::string reason;
        if (!metalrobo::readVisualAssetPackIndex(
                source.path,
                pack,
                &reason
            )) {
            throw std::runtime_error(
                "visual pack load failed: " + reason
            );
        }
        if (pack.contentHash != source.contentHash) {
            throw std::runtime_error(
                "visual pack content changed after run compilation: " +
                source.path
            );
        }
        if (source.assetId.starts_with("crow_course_")) {
            const auto body = std::ranges::find(handle.model.bodyNames, source.assetId);
            if (body == handle.model.bodyNames.end())
                throw std::invalid_argument("unknown active-head navigation course body: " + source.assetId);
            const auto expected = static_cast<std::uint32_t>(body - handle.model.bodyNames.begin());
            if (pack.instances.empty() ||
                std::ranges::any_of(pack.instances, [expected](const auto& instance) {
                    return instance.binding.y != expected;
                }) ||
                std::ranges::any_of(pack.symbolicBindings, [expected](const auto& binding) {
                    return binding.bodyIndex != expected;
                }))
                throw std::invalid_argument("navigation visual pack is bound to the wrong physics body: " + source.assetId);
        }
        const bool robotPresentationPack =
            program.captureWidth != 0u &&
            source.instanceId == 1u &&
            source.assetId == "robot";
        const std::uint32_t instanceId =
            robotPresentationPack && index != 0u
            ? 1'000u + static_cast<std::uint32_t>(index)
            : source.instanceId;
        references.push_back({
            source.path,
            pack.contentHash,
            assetIndex,
            source.semanticId,
            instanceId,
        });
        const auto sceneName = std::ranges::find(
            handle.model.bodyNames,
            source.assetId
        );
        if (sceneName != handle.model.bodyNames.end()) {
            const std::uint32_t body =
                static_cast<std::uint32_t>(
                    sceneName - handle.model.bodyNames.begin()
                );
            const auto local = std::ranges::find(sceneIndices, body);
            const std::uint32_t localIndex = local == sceneIndices.end()
                ? MR_INVALID_INDEX
                : static_cast<std::uint32_t>(
                      local - sceneIndices.begin()
                  );
            if (local != sceneIndices.end() &&
                (trackedSceneBodies.contains(localIndex) ||
                 maskedDepthSceneBodies.contains(localIndex))) {
                const bool rigidBound = std::ranges::any_of(
                    pack.symbolicBindings,
                    [&](const metalrobo::VisualSymbolicBindingV2& binding) {
                        return binding.bodyIndex == body &&
                            binding.binding ==
                                MR_VISUAL_BINDING_RIGID_BODY;
                    }
                );
                const bool objectTracked =
                    trackedSceneBodies.contains(localIndex);
                const bool staticMaskedDepth =
                    maskedDepthSceneBodies.contains(localIndex) &&
                    handle.model.bodies[body].motionType ==
                        MR_MOTION_STATIC;
                if (!rigidBound && (objectTracked || !staticMaskedDepth)) {
                    throw std::invalid_argument(
                        std::string{
                            "sensor-visible visual pack is not bound to physics body: "
                        } + source.assetId
                    );
                }
                trackedInstances[source.assetId] = source.instanceId;
            }
        }
    }

    metalrobo::VisualEnvironmentReferenceV2 environment =
        metalrobo::makeNeutralStudioEnvironmentV2();
    if (!program.environmentPath.empty()) {
        metalrobo::VisualEnvironmentPackV2 pack;
        std::string reason;
        if (!metalrobo::readVisualEnvironmentPackIndex(
                program.environmentPath,
                pack,
                &reason
            )) {
            throw std::runtime_error(
                "visual environment pack load failed: " + reason
            );
        }
        if (pack.contentHash != program.environmentContentHash) {
            throw std::runtime_error(
                "visual environment content changed after run compilation"
            );
        }
        environment.id = pack.id;
        environment.packPath = program.environmentPath;
        environment.contentHash = pack.contentHash;
        environment.intensity = 0.12f;
    }
    metalrobo::VisualSceneManifestV3 manifest;
    std::string reason;
    if (!metalrobo::compileVisualSceneManifestV3(
            runtime->worldTemplate,
            references,
            environment,
            metalrobo::makeIndoorAreaLightRigV1(),
            manifest,
            &reason
        )) {
        throw std::runtime_error(
            "visual scene compile failed: " + reason
        );
    }
    if (retinal) {
        runtime->retinal=std::make_unique<metalrobo::RetinalObserverContext>(handle.run,runtime->family,manifest,
            handle.environmentCount,handle.run.profile().seed,cueResources);
        runtime->deviceObservationEnabled=true;runtime->sceneFingerprint=manifest.fingerprint;
        return runtime;
    }
    auto captureScene = manifest.renderScene;

    metalrobo::MetalWorldFamilyConfig familyConfig;
    familyConfig.metallibPath = handle.metallibPath;
    runtime->worlds = metalrobo::MetalWorldFamilyContext{
        std::move(familyConfig)
    };
    const auto metalFamily = runtime->worlds.compile(
        runtime->family,
        handle.environmentCount
    );
    if (!metalFamily.succeeded()) {
        throw worldFamilyError("visual WorldFamily Metal compile", metalFamily);
    }
    const auto sampled = runtime->worlds.sample(
        handle.environmentCount,
        handle.stepConfig.taskSeed
    );
    if (!sampled.succeeded()) {
        throw worldFamilyError("visual WorldFamily sample", sampled);
    }

    if (!deviceObservation) {
        metalrobo::MetalRunInspectorConfig inspectionConfig;
        inspectionConfig.metallibPath = handle.metallibPath;
        inspectionConfig.width = program.width;
        inspectionConfig.height = program.height;
        inspectionConfig.environmentIndex = 0u;
        inspectionConfig.maximumFramesInFlight = 3u;
        if (program.maximumRetainedBytes != 0u) {
            if (program.maximumRetainedBytes >
                std::numeric_limits<std::size_t>::max()) {
                throw std::invalid_argument(
                    "inspection retained-memory budget exceeds size_t"
                );
            }
            inspectionConfig.maximumRetainedBytes =
                static_cast<std::size_t>(program.maximumRetainedBytes);
        }
        runtime->inspector = std::make_unique<
            metalrobo::MetalRunInspector
        >(std::move(inspectionConfig));
        const auto inspectionCompiled = runtime->inspector->compile(
            std::move(manifest.renderScene),
            metalrobo::VisualRendererProfileV1::sensorFast(),
            runtime->worlds
        );
        if (!inspectionCompiled.succeeded()) {
            throw std::runtime_error(
                std::string{"inspection renderer compile failed ["} +
                metalrobo::metalHybridRendererStatusName(
                    inspectionCompiled.status
                ) + "]: " + inspectionCompiled.message
            );
        }
        runtime->sceneFingerprint = manifest.fingerprint;
        return runtime;
    }

    metalrobo::MetalHybridRendererConfig rendererConfig;
    rendererConfig.metallibPath = handle.metallibPath;
    rendererConfig.width = program.width;
    rendererConfig.height = program.height;
    // Closed-loop masked depth consumes exact geometric winners directly.
    // Media capture has its own retained renderer below.
    rendererConfig.retainObservationBuffers = false;
    rendererConfig.geometricObservationsOnly = true;
    if (program.maximumRetainedBytes != 0u) {
        if (program.maximumRetainedBytes >
            std::numeric_limits<std::size_t>::max()) {
            throw std::invalid_argument(
                "visual retained-memory budget exceeds size_t"
            );
        }
        rendererConfig.maximumRetainedBytes =
            static_cast<std::size_t>(
                program.maximumRetainedBytes
            );
    }
    runtime->renderer = metalrobo::MetalHybridRenderer{
        std::move(rendererConfig)
    };
    const auto rendered = runtime->renderer.compile(
        std::move(manifest.renderScene),
        metalrobo::VisualRendererProfileV1::sensorFast(),
        handle.environmentCount
    );
    if (!rendered.succeeded()) {
        throw std::runtime_error(
            std::string{"visual renderer compile failed ["} +
            metalrobo::metalHybridRendererStatusName(rendered.status) +
            "]: " + rendered.message
        );
    }
    if (program.captureWidth != 0u) {
        metalrobo::MetalHybridRendererConfig captureConfig;
        captureConfig.metallibPath = handle.metallibPath;
        captureConfig.width = program.captureWidth;
        captureConfig.height = program.captureHeight;
        captureConfig.retainObservationBuffers = true;
        runtime->captureRenderer = metalrobo::MetalHybridRenderer{
            std::move(captureConfig)
        };
        const auto captureCompiled = runtime->captureRenderer.compile(
            std::move(captureScene),
            metalrobo::VisualRendererProfileV1::sensorReference(),
            handle.environmentCount
        );
        if (!captureCompiled.succeeded()) {
            throw std::runtime_error(
                std::string{"visual capture renderer compile failed ["} +
                metalrobo::metalHybridRendererStatusName(
                    captureCompiled.status
                ) + "]: " + captureCompiled.message
            );
        }
        runtime->captureEnabled = true;
        runtime->capturePolicyCamera = program.capturePolicyCamera;
    }

    metalrobo::MetalHybridObjectTrackerConfig trackerConfig;
    trackerConfig.capacity = handle.environmentCount;
    trackerConfig.cameraIndex = 0u;
    trackerConfig.rootBodyIndex =
        handle.model.articulations[handle.world.articulationIndex()].rootBody;
    trackerConfig.maximumActorHistoryLength =
        handle.taskProgram.layout().actorHistoryLength;
    trackerConfig.timestepSeconds = handle.stepConfig.timestepSeconds;
    trackerConfig.nominalSensorRateHz = program.nominalRateHz;
    trackerConfig.maximumTrackSpeedMetersPerSecond = 10.0f;
    for (const auto& [sceneIndex, offset] : trackedOffsets) {
        const std::string& assetId =
            handle.model.bodyNames[sceneIndices[sceneIndex]];
        const auto instance = trackedInstances.find(assetId);
        if (instance == trackedInstances.end() ||
            !positionScales.contains(sceneIndex) ||
            !velocityScales.contains(sceneIndex)) {
            throw std::invalid_argument(
                "every SensorPack object track requires one authored visual pack binding"
            );
        }
        trackerConfig.bindings.push_back({
            .instanceId = instance->second,
            .actorFrameOffset = offset,
            .positionScale = positionScales[sceneIndex],
            .velocityScale = velocityScales[sceneIndex],
            .minimumVisiblePixels = program.minimumVisiblePixels,
        });
    }
    if (maskedDepthCount != 0u) {
        trackerConfig.maskedDepthWidth = taskHeader.visualLayout.x;
        trackerConfig.maskedDepthHeight = taskHeader.visualLayout.y;
        trackerConfig.maskedDepthActorFrameOffset =
            handle.taskProgram.layout().actorFrameSize *
            handle.taskProgram.layout().actorHistoryLength +
            taskHeader.counts3.w;
        trackerConfig.maskedDepthNearMeters = taskHeader.visualRange.x;
        trackerConfig.maskedDepthFarMeters = taskHeader.visualRange.y;
        trackerConfig.maskedDepthEdgeFlickerProbability =
            taskHeader.visualRange.z;
        trackerConfig.maskedDepthCurriculumCorruptionGain =
            taskHeader.visualRange.w;
        trackerConfig.maskedDepthFullDropoutProbability =
            taskHeader.visualCorruption.x;
        trackerConfig.maskedDepthPixelDropoutProbability =
            taskHeader.visualCorruption.y;
        trackerConfig.maskedDepthJitterMeters =
            taskHeader.visualCorruption.z;
        trackerConfig.maskedDepthNoiseSigmaMeters =
            taskHeader.visualCorruption.w;
        const std::array offsets{
            taskHeader.visualHistory.x,
            taskHeader.visualHistory.y,
            taskHeader.visualHistory.z,
            taskHeader.visualHistory.w,
        };
        trackerConfig.maskedDepthFrameOffsets.assign(
            offsets.begin(),
            offsets.begin() + taskHeader.visualLayout.z
        );
        trackerConfig.maskedDepthCurriculumLevelCount =
            taskHeader.schedule.z;
        trackerConfig.maskedDepthFeatureCount =
            maskedDepthFeatureCount;
        for (const std::uint32_t sceneIndex : maskedDepthSceneBodies) {
            const std::uint32_t bodyIndex = sceneIndices[sceneIndex];
            const std::string& bodyId = handle.model.bodyNames[bodyIndex];
            auto instance = trackedInstances.find(bodyId);
            if (instance == trackedInstances.end()) {
                // A multi-body static course is authored as one SceneObject
                // and one visual pack. Resolve each body back to that owning
                // asset so the complete course shares a stable instance mask.
                const auto owner = std::ranges::find_if(
                    runtime->worldTemplate.assets,
                    [&](const metalrobo::WorldAsset& asset) {
                        return std::ranges::find(
                            asset.bodyIndices, bodyIndex
                        ) != asset.bodyIndices.end();
                    }
                );
                if (owner != runtime->worldTemplate.assets.end()) {
                    instance = trackedInstances.find(owner->id);
                }
            }
            if (instance == trackedInstances.end()) {
                throw std::invalid_argument(
                    "every masked-depth object requires an authored visual binding"
                );
            }
            if (std::ranges::find(
                    trackerConfig.maskedDepthInstanceIds,
                    instance->second
                ) == trackerConfig.maskedDepthInstanceIds.end()) {
                trackerConfig.maskedDepthInstanceIds.push_back(
                    instance->second
                );
            }
        }
    }
    if (deviceObservationEnabled) {
        const auto trackerStatus = runtime->tracker.compile(
            runtime->renderer,
            runtime->worlds,
            std::move(trackerConfig)
        );
        if (!trackerStatus.succeeded()) {
            throw std::runtime_error(
                std::string{"visual tracker compile failed ["} +
                metalrobo::metalHybridRendererStatusName(trackerStatus.status) +
                "]: " + trackerStatus.message
            );
        }
    }
    runtime->deviceObservationEnabled = deviceObservationEnabled;
    runtime->sceneFingerprint = manifest.fingerprint;
    return runtime;
}

void installTaskVisualRuntime(
    MRTaskRolloutHandle& handle,
    const metalrobo::VisualSensorProgram& program
) {
    if (handle.residentState.valid()) {
        throw std::logic_error(
            "SensorPack must compile before resident initialization"
        );
    }
    std::unique_ptr<MRTaskVisualRuntime> candidate =
        compileTaskVisualRuntime(handle, program, true,
            program.retinal && !program.retinal->resourceCues.empty() ? handle.resourceRuntime.get() : nullptr);
    if (candidate->deviceObservationEnabled) {
        const metalrobo::MetalWorldDeviceObservationProgram observationProgram =
            candidate->retinal ? candidate->retinal->deviceProgram() : candidate->tracker.observationProgram();
        if (!observationProgram.valid()) {
            throw std::runtime_error(
                "compiled SensorPack visual program is invalid"
            );
        }
        handle.stepConfig.deviceObservationProgram = observationProgram;
    }
    handle.visualRuntime = std::move(candidate);
}

void installTaskInspectionRuntime(
    MRTaskRolloutHandle& handle,
    const metalrobo::VisualSensorProgram& program
) {
    if (handle.residentState.valid()) {
        throw std::logic_error(
            "inspection scene must compile before resident initialization"
        );
    }
    std::unique_ptr<MRTaskVisualRuntime> candidate =
        compileTaskVisualRuntime(handle, program, false);
    if (candidate->inspector == nullptr) {
        throw std::logic_error("inspection renderer did not compile");
    }
    const metalrobo::MetalWorldInspectionProgram inspectionProgram =
        candidate->inspector->inspectionProgram();
    if (!inspectionProgram.valid()) {
        throw std::logic_error("inspection program is invalid");
    }
    handle.inspectionVisualRuntime = std::move(candidate);
    handle.stepConfig.inspectionProgram = inspectionProgram;
}

std::runtime_error worldFamilyError(
    const char* operation,
    const metalrobo::MetalWorldFamilyDiagnostics& diagnostics
) {
    return std::runtime_error(
        std::string{operation} + " failed [" +
        metalrobo::metalWorldFamilyStatusName(diagnostics.status) +
        "]: " + diagnostics.message
    );
}

} // namespace

extern "C" {

const char* mr_version(void) {
    return "0.4.0";
}

uint64_t mr_runtime_abi_fingerprint(void) {
    return metalrobo::runtimeAbiFingerprint();
}

const char* mr_last_error(void) {
    return gLastError.c_str();
}

const char* mr_unitree_g1_deployment_contract_json(void) {
    try {
        static const std::string contract =
            unitreeG1DeploymentContractJSON();
        gLastError.clear();
        return contract.c_str();
    } catch (const std::exception& error) {
        gLastError = error.what();
    } catch (...) {
        gLastError =
            "failed to construct the Unitree G1 deployment contract";
    }
    return nullptr;
}

int mr_write_policy_pack(
    const MRPolicyPackC* policy,
    const char* policy_pack_path
) {
    if (policy == nullptr ||
        policy_pack_path == nullptr ||
        policy_pack_path[0] == '\0') {
        gLastError = "PolicyPack and output path are required.";
        return -1;
    }
    return translateErrors([&] {
        const metalrobo::PolicyPack authored =
            policyPackFromC(*policy);
        const metalrobo::LearningPackResult written =
            metalrobo::writePolicyPack(
                authored,
                policy_pack_path
            );
        if (!written.succeeded()) {
            throw std::invalid_argument(
                std::string{"PolicyPack write failed ["} +
                metalrobo::learningPackStatusName(
                    written.status
                ) + "]: " + written.message
            );
        }
    });
}

int mr_write_recurrent_policy_pack(const MRPolicyPackC* policy,
    const MRPolicyGRUMemoryC* memory,const char* policy_pack_path) {
    if (!policy || !memory || !policy_pack_path || !policy_pack_path[0]) {
        gLastError="Recurrent PolicyPack, memory descriptor and output path are required";return -1;
    }
    return translateErrors([&] {
        if (memory->abi_version!=1 || memory->struct_size!=sizeof(MRPolicyGRUMemoryC))
            throw std::invalid_argument("Unsupported recurrent policy memory descriptor ABI/size");
        const std::uint64_t I=memory->input_count,H=memory->hidden_count,rows=3*H;
        if (!I || I>65536 || !H || H>4096 || memory->input_weight_count!=rows*I ||
            memory->recurrent_weight_count!=rows*H || memory->input_bias_count!=rows || memory->recurrent_bias_count!=rows)
            throw std::invalid_argument("Recurrent policy memory dimensions/tensor counts are invalid");
        auto authored=policyPackFromC(*policy);metalrobo::PolicyGRUMemory m;
        m.afterLayer=memory->after_layer;auto& p=m.cell;p.inputs=I;p.hidden=H;p.maximumAbsoluteInput=memory->maximum_absolute_input;
        p.inputWeights=copyPolicyFloats(memory->input_weights,memory->input_weight_count,"GRU input weights");
        p.recurrentWeights=copyPolicyFloats(memory->recurrent_weights,memory->recurrent_weight_count,"GRU recurrent weights");
        p.inputBias=copyPolicyFloats(memory->input_bias,memory->input_bias_count,"GRU input bias");
        p.recurrentBias=copyPolicyFloats(memory->recurrent_bias,memory->recurrent_bias_count,"GRU recurrent bias");
        authored.actorMemory=std::move(m);const auto written=metalrobo::writePolicyPack(authored,policy_pack_path);
        if (!written.succeeded()) throw std::invalid_argument("Recurrent PolicyPack write failed: "+written.message);
    });
}

uint64_t mr_learning_pack_content_hash(
    const void* payload,
    const size_t byte_count
) {
    if (payload == nullptr && byte_count != 0u) {
        return 0u;
    }
    return metalrobo::learningPackContentHash(
        {
            static_cast<const std::byte*>(payload),
            byte_count,
        }
    );
}

int mr_compile_episode_manifest(
    const char* manifest_path,
    const char* output_pack_path,
    const char* artifact_store_path
) {
    if (manifest_path == nullptr || manifest_path[0] == '\0' ||
        output_pack_path == nullptr || output_pack_path[0] == '\0') {
        gLastError =
            "manifest_path and output_pack_path must be nonempty.";
        return -1;
    }
    return translateErrors([&] {
        metalrobo::CaptureManifest manifest;
        const metalrobo::EpisodeTwinCompilerResult loaded =
            metalrobo::loadCaptureManifestJSON(
                manifest_path,
                manifest
            );
        if (!loaded.succeeded()) {
            throw std::runtime_error(
                std::string{"capture manifest load failed ["} +
                metalrobo::episodeTwinCompilerStatusName(loaded.status) +
                "]: " + loaded.message
            );
        }
        if (manifest.engineModelId != "franka_pick_place" ||
            manifest.worldProgramId != "franka_pick_place") {
            throw std::runtime_error(
                "capture manifest references an unregistered engine "
                "model or world program"
            );
        }

        const std::filesystem::path outputPath{output_pack_path};
        metalrobo::EpisodeTwinCompilerConfig config;
        config.artifactStore =
            artifact_store_path != nullptr &&
                artifact_store_path[0] != '\0'
            ? std::filesystem::path{artifact_store_path}
            : outputPath.parent_path() /
                (outputPath.stem().string() + ".artifacts");
        metalrobo::EpisodeTwinCompiler compiler{std::move(config)};
        metalrobo::CompiledEpisodeTwin compiled;
        const metalrobo::EpisodeTwinCompilerResult result =
            compiler.compile(
                manifest,
                metalrobo::makeFrankaPickPlaceEngineModel(),
                metalrobo::makeFrankaPickPlaceWorldProgram(),
                compiled
            );
        if (!result.succeeded()) {
            throw std::runtime_error(
                std::string{"episode twin compilation failed ["} +
                metalrobo::episodeTwinCompilerStatusName(result.status) +
                "]: " + result.message
            );
        }
        const metalrobo::WorldPackResult written =
            metalrobo::writeWorldPack(
                compiled.worldPack,
                outputPath
            );
        if (!written.succeeded()) {
            throw std::runtime_error(
                std::string{"world-pack write failed ["} +
                metalrobo::worldPackStatusName(written.status) +
                "]: " + written.message
            );
        }
    });
}

static MRTaskRolloutHandle* createUnitreeG1Run(
    const MRTaskRolloutConfigC* config,
    const uint32_t surface_value,
    const uint32_t task_value,
    const MRTaskVisualObservationConfigC* visual_sensor,
    const char* metallib_path
) {
    if (config == nullptr) {
        gLastError = "task-rollout config is null.";
        return nullptr;
    }

    MRTaskRolloutHandle* result = nullptr;
    const int status = translateErrors([&] {
        validateTaskRolloutConfiguration(*config);
        const metalrobo::LocomotionSurface surface =
            locomotionSurface(surface_value);
        auto handle = createCompiledRunTaskRollout(
            makeUnitreeG1RunManifest(
                surface,
                unitreeG1Task(task_value),
                *config
            ),
            metallib_path,
            "bundled G1",
            visual_sensor
        );
        result = handle.release();
    });
    return status == 0 ? result : nullptr;
}

static MRTaskRolloutHandle* createFrankaRun(
    const MRTaskRolloutConfigC* config,
    const MRTaskVisualObservationConfigC* visual_sensor,
    const char* metallib_path
) {
    if (config == nullptr) {
        gLastError = "task-rollout config is null.";
        return nullptr;
    }
    MRTaskRolloutHandle* result = nullptr;
    const int status = translateErrors([&] {
        validateTaskRolloutConfiguration(*config);
        auto handle = createCompiledRunTaskRollout(
            makeFrankaPickPlaceRunManifest(*config),
            metallib_path,
            "bundled Franka pick/place",
            visual_sensor
        );
        result = handle.release();
    });
    return status == 0 ? result : nullptr;
}

static MRTaskRolloutHandle* createPX4X500Run(
    const MRTaskRolloutConfigC* config,
    const char* metallib_path
) {
    if (config == nullptr) {
        gLastError = "task-rollout config is null.";
        return nullptr;
    }
    MRTaskRolloutHandle* result = nullptr;
    const int status = translateErrors([&] {
        validateTaskRolloutConfiguration(*config);
        auto robot = metalrobo::builtinRobotPack("px4_x500");
        if (!robot) {
            throw std::logic_error(
                "bundled PX4 X500 RobotPack is unavailable"
            );
        }
        metalrobo::RunManifest manifest;
        manifest.id = "px4_x500_hover_run";
        manifest.robot = std::move(*robot);
        manifest.scene = metalrobo::makePX4X500HoverScenePack();
        manifest.sensors.id = "px4_x500_state_sensors";
        manifest.task = metalrobo::makePX4X500HoverTaskPack(
            manifest.sensors.observation,
            manifest.reality.reset
        );
        manifest.reality.id = "px4_x500_nominal_reality";
        manifest.teacher.id = "no_teacher";
        applyRunProfile(manifest, *config);
        manifest.profile.capacities = manifest.task.capacities;
        auto handle = createCompiledRunTaskRollout(
            std::move(manifest),
            metallib_path,
            "PX4 X500",
            nullptr
        );
        result = handle.release();
    });
    return status == 0 ? result : nullptr;
}

static MRTaskRolloutHandle* createBirdFlowDoveRun(
    const MRTaskRolloutConfigC* config,
    const MRTaskVisualObservationConfigC* visual_sensor,
    const char* metallib_path
) {
    if (config == nullptr) {
        gLastError = "BirdFlow dove rollout configuration is required.";
        return nullptr;
    }
    MRTaskRolloutHandle* result = nullptr;
    const int status = translateErrors([&] {
        validateTaskRolloutConfiguration(*config);
        auto robot = metalrobo::builtinRobotPack("birdflow_deetjen_dove_hybrid");
        if (!robot) {
            throw std::logic_error("bundled BirdFlow dove RobotPack is unavailable");
        }
        metalrobo::RunManifest manifest;
        manifest.id = "birdflow_deetjen_dove_hybrid_run";
        manifest.robot = std::move(*robot);
        manifest.scene = metalrobo::makeBirdFlowDoveFlightScenePack();
        manifest.sensors.id = "birdflow_deetjen_dove_hybrid_state_sensors";
        manifest.task = metalrobo::makeBirdFlowDoveFlightTaskPack(
            manifest.sensors.observation, manifest.reality.reset);
        manifest.reality.id = "birdflow_deetjen_dove_hybrid_nominal_reality";
        manifest.teacher.id = "no_teacher";
        applyRunProfile(manifest, *config);
        manifest.profile.capacities = manifest.task.capacities;
        auto handle = createCompiledRunTaskRollout(
            std::move(manifest), metallib_path,
            "BirdFlow Deetjen dove hybrid", visual_sensor);
        result = handle.release();
    });
    return status == 0 ? result : nullptr;
}

namespace { using namespace metalrobo;
static void crowToeNeed(bool ok, const std::string& why) { if (!ok) throw std::runtime_error(why); }
static void close(double a, double b, const char* why) { crowToeNeed(std::abs(a-b)<=2e-7*(1+std::abs(a)),why); }
static void crowToeDiagonal(MRBodyPropertiesGPU& b,float x,float y,float z) {
  crowToeNeed(x>0 && y>0 && z>0,"nonpositive residual inertia");
  b.inertiaRow0={x,0,0,0}; b.inertiaRow1={0,y,0,0}; b.inertiaRow2={0,0,z,0};
  b.inverseInertiaRow0={1/x,0,0,0}; b.inverseInertiaRow1={0,1/y,0,0}; b.inverseInertiaRow2={0,0,1/z,0};
}
static RobotPack crowToeModel() {
  auto p=makeAmericanCrowActiveHeadRobotPack(); auto& m=p.mechanics;
  p.id="american_crow_toe_two_segment_prototype_v0"; m.name=p.id; p.sourceRevision+="+exploratory-toes-two-segment-v0";
  constexpr float mass=0.00005f, hx=0.009f, hy=0.0025f, hz=0.0092f;
  constexpr float ix=mass*(hy*hy+hz*hz)/3, iy=mass*(hx*hx+hz*hz)/3, iz=mass*(hx*hx+hy*hy)/3;
  for (int side=0;side<2;side++) {
    const std::string footName=side==0?"crow_left_foot":"crow_right_foot";
    auto it=std::find(m.bodyNames.begin(),m.bodyNames.end(),footName); crowToeNeed(it!=m.bodyNames.end(),"foot missing"); const unsigned foot=static_cast<unsigned>(it-m.bodyNames.begin()); auto& parent=m.bodies.at(foot);
    const float dx[4]={.020666667f,.020666667f,.020666667f,-.062f},dy[4]={-.012f,0,.012f,0};
    float sx=0,sy=0,sz=0;
    for(int t=0;t<4;t++) for(int seg=0;seg<2;seg++) { const float sign=t==3?-1.f:1.f; const float x=dx[t]+sign*(seg==0?-hx:hx); sx+=ix+mass*dy[t]*dy[t]; sy+=iy+mass*x*x; sz+=iz+mass*(x*x+dy[t]*dy[t]); }
    const float pm=parent.massAndInverseMass.x-8*mass;crowToeNeed(pm>0,"negative foot mass");parent.massAndInverseMass={pm,1/pm,0,0};crowToeDiagonal(parent,parent.inertiaRow0.x-sx,parent.inertiaRow1.y-sy,parent.inertiaRow2.z-sz);
    for(unsigned si=0;si<m.shapeNames.size();si++)if(m.shapeNames[si]==(side==0?"crow_left_foot/sole":"crow_right_foot/sole"))m.shapes[si].dimensions.x=.010f;
    for(int t=0;t<4;t++) {
      const float sign=t==3?-1.f:1.f;
      const std::string digit=std::string("crow_")+(side==0?"left_":"right_")+(t==3?"rear_toe":("front_toe_"+std::to_string(t+1)));
      unsigned previous=foot;
      for(int seg=0;seg<2;seg++) {
        const unsigned bi=m.bodies.size(),ji=m.joints.size(),qi=m.defaultQ.size(),vi=m.defaultV.size();const std::string name=digit+(seg==0?"_proximal":"_distal");
        MRBodyPropertiesGPU b{};b.articulationIndex=0;b.parentBody=previous;b.inboundJoint=ji;b.motionType=MR_MOTION_DYNAMIC;b.massAndInverseMass={mass,1/mass,0,0};crowToeDiagonal(b,ix,iy,iz);b.dampingAndSpeedLimits={0,0,30,35};m.bodies.push_back(b);m.bodyNames.push_back(name);
        MRJointDescriptorGPU j{};j.parentBody=previous;j.childBody=bi;j.jointType=MR_JOINT_REVOLUTE;j.qOffset=qi;j.nq=1;j.vOffset=vi;j.nv=1;j.axis0={0,sign,0,0};if(seg==0)j.parentAnchor={dx[t]-sign*2*hx,dy[t],0,0};else j.parentAnchor={sign*hx,0,0,0};j.childAnchor={-sign*hx,0,0,0};j.parentRotation=j.childRotation={0,0,0,1};m.joints.push_back(j);m.jointNames.push_back(name+"_flex");
        MRDofPropertiesGPU d{};d.articulationIndex=0;d.jointIndex=ji;d.qIndex=qi;d.vIndex=vi;d.flags=MR_DOF_FLAG_ACTUATED|MR_DOF_FLAG_POSITION_LIMIT|MR_DOF_FLAG_VELOCITY_LIMIT|MR_DOF_FLAG_EFFORT_LIMIT|MR_DOF_FLAG_DRIVE;d.limits={-.3f,1.2f,24.f,.02f};d.drive={.1f,.003f,.00005f,0};m.dofs.push_back(d);m.dofNames.push_back(name+"_flex");m.defaultQ.push_back(0);m.defaultV.push_back(0);if(!m.actuatorProfiles.empty())m.actuatorProfiles.emplace_back();
        MRShapeGPU shape=m.shapes.front();shape.bodyIndex=bi;shape.localPosition={0,0,0,1};shape.localRotation={0,0,0,1};shape.dimensions={hx,hy,hz,0};shape.slotGeneration=m.shapes.size()+1;shape.contactRestAndBoundingRadius.z=std::sqrt(hx*hx+hy*hy+hz*hz);m.shapes.push_back(shape);m.shapeNames.push_back(name+"/collision");previous=bi;
      }
    }
  }
  auto& a=m.articulations.at(0);a.bodyCount=m.world.bodyCount=m.bodies.size();a.jointCount=m.world.jointCount=m.joints.size();a.nq=m.world.nq=m.defaultQ.size();a.nv=m.world.nv=m.defaultV.size();m.world.shapeCount=m.shapes.size();
  for(auto& role:p.roles){if(role.id=="whole_body")role.members=m.bodyNames;if(role.id=="all_joints")role.members=m.jointNames;if(role.id=="all_dofs")role.members=m.dofNames;}
  std::string reason;crowToeNeed(m.valid(&reason),"invalid model: "+reason);return p;
}
static RobotPack crowHipRollModel(){
 auto p=crowToeModel();crowResearchWingInertia(p);auto &m=p.mechanics;p.id="crow_v15_experimental_hip_roll";p.sourceRevision+="+hip_roll_experiment";
 auto oldBodies=m.bodies;auto oldNames=m.bodyNames;auto oldJoints=m.joints;
 auto map=[](unsigned i){return i+(i>=8u)+(i>=11u);};
 m.bodies.clear();m.bodyNames.clear();
 const unsigned newJointBase=m.joints.size(),newQ=m.defaultQ.size(),newV=m.defaultV.size();
 for(unsigned i=0;i<oldBodies.size();++i){
  if(i==8u||i==11u){unsigned side=i==8u?0u:1u;auto proxy=oldBodies[side==0?1:2];proxy.parentBody=0;proxy.inboundJoint=newJointBase+side;proxy.centerOfMass={0,0,0,0};m.bodies.push_back(proxy);m.bodyNames.push_back(side==0?"crow_left_hip_roll_link":"crow_right_hip_roll_link");}
  auto b=oldBodies[i];if(b.parentBody!=MR_INVALID_INDEX)b.parentBody=map(b.parentBody);if(i==8u||i==11u)b.parentBody=map(i)-1u;m.bodies.push_back(b);m.bodyNames.push_back(oldNames[i]);
 }
 for(unsigned i=0;i<m.joints.size();++i){auto &j=m.joints[i];j.parentBody=map(j.parentBody);j.childBody=map(j.childBody);if(i==7u||i==10u){j.parentBody=j.childBody-1u;j.parentAnchor={0,0,0,0};}}
 for(auto& s:m.shapes)s.bodyIndex=map(s.bodyIndex);
 // Preserve precisely the torso/thigh shape exclusions that came from direct
 // adjacency before the added hip-roll proxy links changed that topology.
 for(unsigned i=0;i<m.shapes.size();++i)for(unsigned j=i+1;j<m.shapes.size();++j){const auto a=m.shapes[i].bodyIndex,b=m.shapes[j].bodyIndex;if((a==0u && (b==map(8u)||b==map(11u))) || (b==0u && (a==map(8u)||a==map(11u))))m.collisionExclusions.push_back({i,j});}
 std::sort(m.collisionExclusions.begin(),m.collisionExclusions.end(),[](const auto&a,const auto&b){return a.colliderA<b.colliderA || (a.colliderA==b.colliderA && a.colliderB<b.colliderB);});m.collisionExclusions.erase(std::unique(m.collisionExclusions.begin(),m.collisionExclusions.end(),[](const auto&a,const auto&b){return a.colliderA==b.colliderA && a.colliderB==b.colliderB;}),m.collisionExclusions.end());
 for(unsigned side=0;side<2;++side){unsigned oldJ=side==0?7u:10u;auto j=oldJoints[oldJ];j.childBody=map(j.childBody)-1u;j.parentBody=0;j.qOffset=newQ+side;j.vOffset=newV+side;j.axis0={1,0,0,0};j.childAnchor={0,0,0,0};m.joints.push_back(j);m.jointNames.push_back(side==0?"crow_left_hip_roll":"crow_right_hip_roll");auto d=m.dofs.at(oldJoints[oldJ].vOffset);d.jointIndex=newJointBase+side;d.qIndex=newQ+side;d.vIndex=newV+side;d.limits={-.35f,.35f,8.f,.22f};d.drive={8.f,.15f,.00005f,0};m.dofs.push_back(d);m.dofNames.push_back(side==0?"crow_left_hip_roll":"crow_right_hip_roll");m.defaultQ.push_back(0);m.defaultV.push_back(0);if(!m.actuatorProfiles.empty())m.actuatorProfiles.emplace_back();}
 auto&a=m.articulations.at(0);a.bodyCount=m.world.bodyCount=m.bodies.size();a.jointCount=m.world.jointCount=m.joints.size();a.nq=m.world.nq=m.defaultQ.size();a.nv=m.world.nv=m.defaultV.size();
 for(auto& r:p.roles){if(r.id=="whole_body")r.members=m.bodyNames;if(r.id=="all_joints")r.members=m.jointNames;if(r.id=="all_dofs")r.members=m.dofNames;}
 std::string why;crowToeNeed(m.valid(&why),"model invalid: "+why);return p;
}
}

static MRTaskRolloutHandle* createBirdFlowAmericanCrowRun(
    const MRTaskRolloutConfigC* config,
    const MRTaskVisualObservationConfigC* visual_sensor,
    const char* metallib_path,
    const bool journey,
    const MRRetinalSensorConfigC* retinalConfig=nullptr,
    const MRCrowCuedForagingConfigC* cueConfig=nullptr,
    const std::uint32_t memoryChoiceDecisionStep=0u,
    const std::uint32_t headHold=0u,const std::uint32_t beakHold=0u,
    const MRCrowObjectPushCurriculumC* objectCurriculum=nullptr
) {
    if (config == nullptr) {
        gLastError = "BirdFlow American-crow rollout configuration is required.";
        return nullptr;
    }
    MRTaskRolloutHandle* result = nullptr;
    const int status = translateErrors([&] {
        validateTaskRolloutConfiguration(*config);
        const bool manipulation=journey && config->birdflow_journey_variant==MR_BIRDFLOW_JOURNEY_V14_OBJECT_PUSH;
        const bool retinal=journey && (config->birdflow_journey_variant==MR_BIRDFLOW_JOURNEY_V13_RETINAL_FEEDING || manipulation);
        static_assert(sizeof(MRCrowCuedForagingConfigC)==64);
        static_assert(sizeof(MRCrowObjectPushCurriculumC)==32);
        if(objectCurriculum && (!manipulation || objectCurriculum->struct_size!=sizeof(*objectCurriculum) ||
            objectCurriculum->abi_version!=1 || objectCurriculum->reserved))
            throw std::invalid_argument("Unsupported native object curriculum configuration");
        if(cueConfig && (!retinal || cueConfig->struct_size!=sizeof(*cueConfig) || cueConfig->abi_version!=1 || cueConfig->reserved || cueConfig->occluded>1))
            throw std::invalid_argument("Unsupported native cue-foraging configuration");
        if (retinal != (retinalConfig!=nullptr) || (retinal && visual_sensor==nullptr))
            throw std::invalid_argument("Retinal crow variants require the additive entry and explicit visual and retinal programs");
        metalrobo::RetinalSensorProgram retina;
        if (retinal) {
            static_assert(sizeof(MRRetinalSensorConfigC)==64);
            if (retinalConfig->struct_size!=sizeof(MRRetinalSensorConfigC) || retinalConfig->abi_version!=1)
                throw std::invalid_argument("Unsupported retinal C configuration size/version");
            const auto& c=*retinalConfig;
            retina.rightCameraPosition={c.right_camera_position[0],c.right_camera_position[1],c.right_camera_position[2],0};
            retina.rightCameraOrientation={c.right_camera_orientation[0],c.right_camera_orientation[1],c.right_camera_orientation[2],c.right_camera_orientation[3]};
            retina.width=c.width;retina.height=c.height;retina.sampleNumerator=c.sample_numerator;
            retina.sampleDenominator=c.sample_denominator;retina.latencyTicks=c.latency_ticks;
            retina.minimumDepthMeters=c.minimum_depth_meters;retina.maximumDepthMeters=c.maximum_depth_meters;
            if(cueConfig)for(unsigned side=0;side<2;++side)
                retina.resourceCues.push_back({{cueConfig->cue_mesh_instances[side],side,metalrobo::crowForagingCueEndTick,0}});
        }
        if(manipulation) {
            if(config->physics_substeps!=32)
                throw std::invalid_argument("Object push requires its admitted32-substep contact quality profile");
            if(cueConfig || config->birdflow_journey_teacher)
                throw std::invalid_argument("Object push requires exclusive policy authority and no resource cues");
            auto manifest=metalrobo::makeAmericanCrowObjectPushFixtureManifest();
            manifest.sensors.observation={};
            manifest.task=metalrobo::makeAmericanCrowObjectPushTaskPack(
                manifest.sensors.observation,manifest.reality.reset,&retina);
            auto p=visualSensorProgram(*visual_sensor);p.retinal=retina;
            p.fingerprint=metalrobo::visualSensorProgramFingerprint(p);
            manifest.sensors.deviceVisual=std::move(p);
            if(config->disable_task_terminations)manifest.task.terminations.clear();
            applyRunProfile(manifest,*config);metalrobo::applyAmericanCrowForagingFixtureLimits(manifest);
            if(objectCurriculum) {
                const auto& c=*objectCurriculum;
                metalrobo::applyAmericanCrowObjectPushCurriculum(manifest,
                    {c.episode_steps,c.minimum_x,c.maximum_x,c.minimum_y,c.maximum_y});
            }
            result=createCompiledRunTaskRollout(std::move(manifest),metallib_path,
                "American-crow native object push",nullptr).release();
            return;
        }
        const bool conditionalLandingNavigation = journey &&
            config->birdflow_journey_variant == MR_BIRDFLOW_JOURNEY_V15_CONDITIONAL_LANDING_NAVIGATION;
        const bool tripleWaypointExpertNavigation = conditionalLandingNavigation || (journey &&
            config->birdflow_journey_variant == MR_BIRDFLOW_JOURNEY_V15_TRIPLE_WAYPOINT_EXPERT_NAVIGATION);
        const bool dualWaypointExpertNavigation = tripleWaypointExpertNavigation || (journey &&
            config->birdflow_journey_variant == MR_BIRDFLOW_JOURNEY_V15_DUAL_WAYPOINT_EXPERT_NAVIGATION);
        const bool waypointExpertNavigation = dualWaypointExpertNavigation || (journey &&
            config->birdflow_journey_variant == MR_BIRDFLOW_JOURNEY_V15_WAYPOINT_EXPERT_NAVIGATION);
        const bool hierarchicalNavigation = journey &&
            (waypointExpertNavigation ||
             config->birdflow_journey_variant == MR_BIRDFLOW_JOURNEY_V15_HIERARCHICAL_NAVIGATION);
        const bool activeNavigation = hierarchicalNavigation || (journey &&
            config->birdflow_journey_variant == MR_BIRDFLOW_JOURNEY_V15_ACTIVE_HEAD_NAVIGATION);
        const bool feeding=retinal || (journey && config->birdflow_journey_variant==MR_BIRDFLOW_JOURNEY_V12_FEEDING_STATION);
        const bool embodied = journey && (config->birdflow_journey_variant ==
            MR_BIRDFLOW_JOURNEY_V11_EMBODIED || feeding || activeNavigation);
        if (embodied && !activeNavigation && config->birdflow_journey_teacher != 0u) {
            throw std::invalid_argument("Active-head variants have no admitted teacher action contract");
        }
        if (embodied && !retinal && !activeNavigation && visual_sensor!=nullptr)
            throw std::invalid_argument("Active-head variants have no admitted eye-image or presentation contract");
        auto robot = metalrobo::builtinRobotPack(embodied
            ? "american_crow_active_head_estimated_v1"
            : "birdflow_american_crow_estimated_hybrid");
        if (!robot) {
            throw std::logic_error(
                "bundled BirdFlow American-crow RobotPack is unavailable"
            );
        }
        metalrobo::RunManifest manifest;
        const bool worldModelNavigation = activeNavigation || (journey &&
            config->birdflow_journey_variant ==
                MR_BIRDFLOW_JOURNEY_V10_WORLD_MODEL_NAVIGATION);
        const bool visualNeuralJourney = journey &&
            (config->birdflow_journey_variant ==
                 MR_BIRDFLOW_JOURNEY_V9_VISUAL_NEURAL ||
             worldModelNavigation);
        const bool neuralJourney = journey &&
            config->birdflow_journey_variant ==
                MR_BIRDFLOW_JOURNEY_V8_NEURAL;
        if (visualNeuralJourney && visual_sensor == nullptr) {
            throw std::invalid_argument(
                "BirdFlow journey V9/V10 requires an explicit visual "
                "observation SensorPack; masked-depth policy inputs cannot "
                "fall back to zero-filled observations"
            );
        }
        if (activeNavigation && visual_sensor != nullptr &&
            (visual_sensor->camera_parent_body == nullptr ||
             std::string_view(visual_sensor->camera_parent_body) != "crow_head")) {
            throw std::invalid_argument("Active-head navigation requires a head-mounted visual sensor");
        }
        manifest.id = cueConfig ? "crow_head_camera_geometry_admission" : journey
            ? activeNavigation ? "american_crow_active_head_navigation_development_v1_run"
            : retinal ? "american_crow_retinal_feeding_v13_run"
            : feeding ? "american_crow_feeding_station_v12_run"
            : embodied ? "american_crow_embodied_development_v11_run"
            : worldModelNavigation
                ? "birdflow_american_crow_navigation_v10_world_model_run"
                : visualNeuralJourney
                ? "birdflow_american_crow_journey_v9_visual_neural_run"
                : neuralJourney
                ? "birdflow_american_crow_journey_v8_neural_run"
                : "birdflow_american_crow_journey_v7_run"
            : "birdflow_american_crow_estimated_hybrid_run";
        manifest.robot = activeNavigation ? crowHipRollModel() : std::move(*robot);
        // Wing inertia was applied before adding hip-roll links.
        manifest.scene = cueConfig ? metalrobo::makeAmericanCrowForagingFixtureManifest(cueConfig->occluded!=0).scene : worldModelNavigation
            ? metalrobo::makeBirdFlowAmericanCrowNavigationScenePack()
            : metalrobo::makeBirdFlowAmericanCrowFlightScenePack();
        if (activeNavigation) {
            bool foundPerch=false;
            for (auto& object : manifest.scene.objects) {
                for (std::size_t i=0;i<object.mechanics.shapeNames.size();++i) {
                    if (object.mechanics.shapeNames[i]!="crow_course_perch/collision") continue;
                    auto& shape=object.mechanics.shapes.at(i);
                    if (std::abs(shape.dimensions.x-0.10f)>1e-6f) throw std::logic_error("unexpected original perch width");
                    shape.dimensions.x=0.025f;
                    shape.contactRestAndBoundingRadius.z=std::sqrt(shape.dimensions.x*shape.dimensions.x+shape.dimensions.y*shape.dimensions.y+shape.dimensions.z*shape.dimensions.z);
                    foundPerch=true;
                }
            }
            if (!foundPerch) throw std::logic_error("navigation perch shape not found");
        }
        manifest.sensors.id = cueConfig ? "camera_admission_proprioception" : journey
            ? activeNavigation ? "american_crow_active_head_navigation_rgbd_sensors"
            : retinal ? "american_crow_retinal_v13_rgb_proprioception_nutrition"
            : feeding ? "american_crow_feeding_v12_proprioception_and_nutrition"
            : embodied ? "american_crow_embodied_v11_proprioception"
            : worldModelNavigation
                ? "birdflow_american_crow_navigation_v10_rgbd_sensors"
                : visualNeuralJourney
                ? "birdflow_american_crow_journey_v9_visual_neural_sensors"
                : neuralJourney
                ? "birdflow_american_crow_journey_v8_neural_state_sensors"
                : "birdflow_american_crow_journey_v7_state_sensors"
            : "birdflow_american_crow_estimated_hybrid_state_sensors";
        manifest.task = journey
            ? activeNavigation ? metalrobo::makeAmericanCrowActiveHeadNavigationTaskPack(
                manifest.sensors.observation, manifest.reality.reset)
            : retinal ? metalrobo::makeAmericanCrowRetinalFeedingTaskPack(manifest.sensors.observation,manifest.reality.reset,retina)
            : feeding ? metalrobo::makeAmericanCrowFeedingStationTaskPack(
                manifest.sensors.observation,manifest.reality.reset)
            : embodied ? metalrobo::makeAmericanCrowEmbodiedTaskPack(
                manifest.sensors.observation, manifest.reality.reset)
            : worldModelNavigation
                ? metalrobo::makeBirdFlowAmericanCrowWorldModelNavigationTaskPack(
                      manifest.sensors.observation, manifest.reality.reset
                  )
                : visualNeuralJourney
                ? metalrobo::makeBirdFlowAmericanCrowVisualJourneyTaskPack(
                      manifest.sensors.observation, manifest.reality.reset
                  )
                : neuralJourney
                ? metalrobo::makeBirdFlowAmericanCrowNeuralJourneyTaskPack(
                      manifest.sensors.observation, manifest.reality.reset
                  )
                : metalrobo::makeBirdFlowAmericanCrowJourneyTaskPack(
                      manifest.sensors.observation, manifest.reality.reset
                  )
            : metalrobo::makeBirdFlowAmericanCrowFlightTaskPack(
                  manifest.sensors.observation, manifest.reality.reset
              );
        if (activeNavigation) {
            for (auto& group : manifest.task.contactGroups) {
                const std::string side=group.id=="left_foot_contact" ? "left" : group.id=="right_foot_contact" ? "right" : "";
                if (side.empty()) continue;
                for (unsigned digit=1u;digit<=3u;++digit) for(const char* segment : {"_proximal", "_distal"}) group.bodies.push_back("crow_"+side+"_front_toe_"+std::to_string(digit)+segment);
                for(const char* segment : {"_proximal", "_distal"}) group.bodies.push_back("crow_"+side+"_rear_toe"+segment);
            }
            manifest.task.contactGroups.push_back({.id="left_rear_toe_wrench",.bodies={"crow_left_rear_toe_proximal", "crow_left_rear_toe_distal"},.referenceBody="crow_left_rear_toe_proximal"});
            manifest.task.contactGroups.push_back({.id="right_rear_toe_wrench",.bodies={"crow_right_rear_toe_proximal", "crow_right_rear_toe_distal"},.referenceBody="crow_right_rear_toe_proximal"});
        }
        if (retinal) {
            auto p=visualSensorProgram(*visual_sensor);p.retinal=retina;
            p.fingerprint=metalrobo::visualSensorProgramFingerprint(p);manifest.sensors.deviceVisual=std::move(p);
        }
        manifest.reality.id = cueConfig ? "canonical_camera_reality" :
            "birdflow_american_crow_estimated_hybrid_nominal_reality";
        manifest.teacher.id = "no_teacher";
        if (config->disable_task_terminations != 0u) {
            manifest.task.terminations.clear();
        }
        applyRunProfile(manifest, *config);
        if (hierarchicalNavigation) {
            manifest.task.maximumEpisodeSteps = 5000u;
            manifest.task.id = conditionalLandingNavigation
                ? "american_crow_v15_conditional_landing_navigation_development_v1"
                : tripleWaypointExpertNavigation
                ? "american_crow_v15_triple_waypoint_expert_navigation_development_v1"
                : dualWaypointExpertNavigation
                ? "american_crow_v15_dual_waypoint_expert_navigation_development_v1"
                : waypointExpertNavigation
                ? "american_crow_v15_waypoint_expert_navigation_development_v1"
                : "american_crow_v15_goal_memory_navigation_development_v1";
        }
        manifest.profile.capacities = manifest.task.capacities;
        std::optional<metalrobo::FiniteResourceConfig> resources;
        if(cueConfig) {
            metalrobo::applyAmericanCrowForagingFixtureLimits(manifest);
            metalrobo::CompiledRun physical;
            const auto compiled=metalrobo::compileRun(manifest,physical);
            if(!compiled.succeeded())throw std::invalid_argument("Cue fixture physical compilation failed: "+compiled.message);
            const auto* a=cueConfig->left_port;const auto* b=cueConfig->right_port;
            const std::array<mr_float4,2> ports{{{a[0],a[1],a[2],a[3]},{b[0],b[1],b[2],b[3]}}};
            resources=metalrobo::authorAmericanCrowCuedForagingResources(physical,ports,config->environment_count,cueConfig->allocation_seed);
            manifest.task.deviceStateProgramFingerprint=metalrobo::finiteResourceProgramFingerprint(resources->program,resources->patches,true,resources->allocation);
            if(memoryChoiceDecisionStep)metalrobo::applyAmericanCrowMemoryChoiceCurriculum(manifest.task,memoryChoiceDecisionStep,headHold,beakHold);
        }
        auto handle = createCompiledRunTaskRollout(
            std::move(manifest), metallib_path,
            "BirdFlow American-crow estimated hybrid", retinal ? nullptr : visual_sensor,nullptr,std::move(resources)
        );
        if (feeding && !cueConfig) {
            handle->resourceRuntime=std::make_unique<metalrobo::FiniteResourceContext>(
                metalrobo::makeAmericanCrowFeedingResourceConfig(handle->run,config->environment_count));
            handle->stepConfig.devicePhysicsProgram=handle->resourceRuntime->deviceProgram();
            resetTaskRolloutState(*handle,config->seed);
        }
        if (worldModelNavigation) {
            applyCrowNavigationCourseSplit(
                *handle,
                config->birdflow_navigation_course
            );
            resetTaskRolloutState(*handle, config->seed);
        }
        handle->stepConfig.birdFlowJourneyTeacher =
            journey && config->birdflow_journey_teacher != 0u;
        handle->stepConfig.birdFlowJourneyStudentAuthority =
            journey
            ? config->birdflow_journey_student_authority
            : 0.0f;
        handle->stepConfig.birdFlowNavigationCurriculumMode =
            worldModelNavigation
            ? config->birdflow_navigation_curriculum
            : 0u;
        handle->stepConfig.birdFlowNavigationDevelopmentReference =
            worldModelNavigation &&
            config->birdflow_navigation_course ==
                MR_BIRDFLOW_NAVIGATION_COURSE_DEVELOPMENT_REFERENCE;
        if (handle->stepConfig.birdFlowJourneyTeacher) {
            // createTaskRolloutHandle establishes the resident allocation
            // before source-specific invocation flags are known. Recreate the
            // initial resident state once so its rollout layout includes the
            // journey teacher-action stream from control step zero.
            resetTaskRolloutState(*handle, config->seed);
        }
        result = handle.release();
    });
    return status == 0 ? result : nullptr;
}

static MRTaskRolloutHandle* createUnitreeG1TeacherRun(
    const MRTaskRolloutConfigC* config,
    const uint32_t surface_value,
    const uint32_t task_value,
    const char* interaction_pack_path,
    const char* interaction_clip_id,
    const MRTaskVisualObservationConfigC* visual_sensor,
    const char* metallib_path
) {
    if (config == nullptr || interaction_pack_path == nullptr ||
        interaction_pack_path[0] == '\0' ||
        interaction_clip_id == nullptr ||
        interaction_clip_id[0] == '\0') {
        gLastError =
            "InteractionPack path, clip identity, and task-rollout config are required.";
        return nullptr;
    }

    MRTaskRolloutHandle* result = nullptr;
    const int status = translateErrors([&] {
        validateTaskRolloutConfiguration(*config);
        metalrobo::InteractionPack interactions;
        const metalrobo::LearningPackResult loaded =
            metalrobo::readInteractionPack(
                interaction_pack_path,
                interactions
            );
        if (!loaded.succeeded()) {
            throw std::invalid_argument(
                std::string{"InteractionPack load failed ["} +
                metalrobo::learningPackStatusName(loaded.status) +
                "]: " + loaded.message
            );
        }
        const metalrobo::InteractionClip& clip =
            selectedInteractionClip(
                interactions,
                interaction_clip_id
            );
        const metalrobo::UnitreeG1Task task =
            unitreeG1Task(task_value);
        if (task != metalrobo::UnitreeG1Task::velocity &&
            task != metalrobo::UnitreeG1Task::ballDodge &&
            task != metalrobo::UnitreeG1Task::supineGetUpDiscovery) {
            throw std::invalid_argument(
                "InteractionPack task composition supports velocity, ball-dodge, or supine-get-up."
            );
        }
        metalrobo::RunManifest manifest = makeUnitreeG1RunManifest(
            locomotionSurface(surface_value),
            task,
            *config
        );
        if (task == metalrobo::UnitreeG1Task::velocity) {
            authorG1InteractionTrackingTask(
                manifest.task,
                manifest.sensors.observation,
                manifest.reality.reset,
                interactions,
                clip,
                *config
            );
        } else {
            authorG1ImaginedTask(
                manifest.task,
                manifest.sensors.observation,
                interactions,
                clip,
                *config,
                task != metalrobo::UnitreeG1Task::ballDodge
            );
        }
        metalrobo::RunManifest compatiblePolicySource;
        const metalrobo::RunManifest* compatiblePolicySourcePointer =
            nullptr;
        if (config->interaction_reference_mode ==
            MR_INTERACTION_REFERENCE_GUIDE) {
            manifest.task.interactionControlReference = true;
        } else if (config->interaction_reference_mode ==
                   MR_INTERACTION_REFERENCE_RESET_ONLY) {
            compatiblePolicySource = manifest;
            compatiblePolicySource.task.interactionControlReference = true;
            compatiblePolicySourcePointer = &compatiblePolicySource;
            manifest.task.interactionControlReference = false;
        }
        if (config->override_interaction_student_authority != 0u) {
            manifest.task.interactionStudentAuthority =
                config->interaction_student_authority;
        }
        if (config->override_interaction_reset_phase_fraction != 0u) {
            manifest.task.interactionResetPhaseFraction =
                config->interaction_reset_phase_fraction;
        }
        if (config->override_interaction_reset_phase_probability != 0u) {
            manifest.task.interactionResetPhaseProbability =
                config->interaction_reset_phase_probability;
        }
        if (config->override_interaction_reset_maximum_phase != 0u) {
            manifest.task.interactionResetMaximumPhase =
                config->interaction_reset_maximum_phase;
        }
        manifest.teacher = {
            .id = interactions.id,
            .kind = metalrobo::TeacherKind::motionImagination,
            .provider = "interaction_pack",
            .model = clip.id,
            .artifact = interaction_pack_path,
            .artifactFingerprint = loaded.contentHash,
            .interactions = interactions,
            .interactionClip = clip.id,
        };
        auto handle = createCompiledRunTaskRollout(
            std::move(manifest),
            metallib_path,
            "bundled G1 interaction",
            visual_sensor,
            compatiblePolicySourcePointer
        );
        result = handle.release();
    });
    return status == 0 ? result : nullptr;
}

static MRTaskRolloutHandle* createImportedURDFRun(
    const char* urdf_path,
    const char* srdf_path,
    const char* task_pack_path,
    const char* robot_actuator_pack_path,
    const char* sensor_program_pack_path,
    const char* reality_program_pack_path,
    const MRTaskRolloutConfigC* config,
    const uint32_t surface_value,
    const char* interaction_pack_path,
    const char* interaction_clip_id,
    const MRTaskVisualObservationConfigC* visual_sensor,
    const char* metallib_path
) {
    if (config == nullptr ||
        urdf_path == nullptr || urdf_path[0] == '\0' ||
        task_pack_path == nullptr ||
        task_pack_path[0] == '\0' ||
        robot_actuator_pack_path == nullptr ||
        robot_actuator_pack_path[0] == '\0' ||
        sensor_program_pack_path == nullptr ||
        sensor_program_pack_path[0] == '\0' ||
        reality_program_pack_path == nullptr ||
        reality_program_pack_path[0] == '\0') {
        gLastError =
            "URDF, TaskPack, RobotActuatorPack, SensorProgramPack, "
            "RealityProgramPack, and task-rollout config are required.";
        return nullptr;
    }

    MRTaskRolloutHandle* result = nullptr;
    const int status = translateErrors([&] {
        const metalrobo::LocomotionSurface surface =
            locomotionSurface(surface_value);
        metalrobo::TaskPack task;
        metalrobo::RobotActuatorPack actuators;
        metalrobo::SensorProgramPack sensors;
        metalrobo::RealityProgramPack reality;
        const metalrobo::LearningPackResult taskLoaded =
            metalrobo::readTaskPack(task_pack_path, task);
        const metalrobo::LearningPackResult actuatorLoaded =
            metalrobo::readRobotActuatorPack(
                robot_actuator_pack_path, actuators);
        const metalrobo::LearningPackResult sensorLoaded =
            metalrobo::readSensorProgramPack(
                sensor_program_pack_path, sensors);
        const metalrobo::LearningPackResult realityLoaded =
            metalrobo::readRealityProgramPack(
                reality_program_pack_path, reality);
        if (!taskLoaded.succeeded() || !actuatorLoaded.succeeded() ||
            !sensorLoaded.succeeded() || !realityLoaded.succeeded()) {
            throw std::invalid_argument(
                "one or more imported run owner artifacts failed to load"
            );
        }
        const bool hasInteraction = interaction_pack_path != nullptr &&
            interaction_pack_path[0] != '\0';
        if (hasInteraction != (interaction_clip_id != nullptr &&
                               interaction_clip_id[0] != '\0')) {
            throw std::invalid_argument(
                "imported InteractionPack requires both a path and clip identity"
            );
        }
        metalrobo::InteractionPack interactions;
        metalrobo::LearningPackResult interactionLoaded;
        const metalrobo::InteractionClip* interactionClip = nullptr;
        std::string interactionClipId;
        if (hasInteraction) {
            interactionLoaded = metalrobo::readInteractionPack(
                interaction_pack_path,
                interactions
            );
            if (!interactionLoaded.succeeded()) {
                throw std::invalid_argument(
                    std::string{"InteractionPack load failed ["} +
                    metalrobo::learningPackStatusName(
                        interactionLoaded.status) + "]: " +
                    interactionLoaded.message
                );
            }
            interactionClip = &selectedInteractionClip(
                interactions,
                interaction_clip_id
            );
            interactionClipId = interactionClip->id;
            // AI Sapiens mimic actors already emit the source's absolute
            // joint-position commands.  The InteractionPack is their
            // motion-conditioned observation/reset authority, not a second
            // residual controller layered onto those commands.
            task.interactionControlReference = false;
        }

        metalrobo::RobotDescriptionCookOptions options;
        options.rootMode =
            metalrobo::RobotDescriptionRootMode::floating;
        options.meshMode =
            metalrobo::RobotDescriptionMeshMode::convexHull;
        const bool aiSapiensK1 =
            task.id == "robotis_ai_sapiens_k1_velocity_v1" ||
            task.id == "robotis_ai_sapiens_k1_mimic_v1";
        if (aiSapiensK1) {
            // The pinned K1 MuJoCo floor is condim=3 with sliding friction
            // 0.8.  It has no torsional or rolling constraint rows, so map
            // that Coulomb coefficient to both MetalWorld sliding modes and
            // leave the unsupported rows at zero.
            options.friction = {0.8F, 0.8F, 0.0F, 0.0F};
        }
        metalrobo::LocomotionWorld authored;
        const metalrobo::RobotDescriptionDiagnostics cooked =
            metalrobo::cookRobotDescriptionFiles(
                urdf_path,
                srdf_path != nullptr && srdf_path[0] != '\0'
                    ? std::filesystem::path{srdf_path}
                    : std::filesystem::path{},
                authored.model,
                options
            );
        if (!cooked.succeeded()) {
            throw std::invalid_argument(
                std::string{"URDF/SRDF cook failed ["} +
                metalrobo::robotDescriptionStatusName(
                    cooked.status
                ) + "]: " + cooked.element + ": " +
                cooked.message
            );
        }
        metalrobo::LocomotionSceneComponent surfaceComponent =
            metalrobo::makeLocomotionSurfaceComponent(
                authored.model,
                surface
            );
        metalrobo::RunManifest manifest = makeImportedRunManifest(
            std::move(authored.model),
            std::move(authored.sceneBodies),
            authored.articulationIndex,
            std::move(task),
            std::move(actuators),
            std::move(sensors),
            std::move(reality),
            *config,
            "imported_urdf_run"
        );
        manifest.scene.objects.push_back({
            .id = "imported_locomotion_surface",
            .semanticClass = "support_surface",
            .role = MR_WORLD_ASSET_FIXTURE,
            .render = MR_WORLD_RENDER_NONE,
            .collision = MR_WORLD_COLLISION_PRIMITIVES,
            .dynamics = MR_WORLD_DYNAMICS_STATIC,
            .mechanics = std::move(surfaceComponent.mechanics),
            .defaultBodyStates = std::move(surfaceComponent.defaultBodyStates),
        });
        const auto spheres = locomotionDynamicSpheres(*config);
        if (!spheres.empty()) {
            metalrobo::LocomotionSceneComponent sphereComponent =
                metalrobo::makeLocomotionDynamicSphereComponent(
                    manifest.robot.mechanics,
                    spheres
                );
            manifest.scene.objects.push_back({
                .id = "locomotion_dynamic_spheres",
                .semanticClass = "dynamic_projectile",
                .role = MR_WORLD_ASSET_MANIPULATED,
                .render = MR_WORLD_RENDER_NONE,
                .collision = MR_WORLD_COLLISION_PRIMITIVES,
                .dynamics = MR_WORLD_DYNAMICS_RIGID,
                .mechanics = std::move(sphereComponent.mechanics),
                .defaultBodyStates =
                    std::move(sphereComponent.defaultBodyStates),
            });
        }
        if (interactionClip != nullptr) {
            manifest.teacher = {
                .id = interactions.id,
                .kind = metalrobo::TeacherKind::motionImagination,
                .provider = "interaction_pack",
                .model = interactionClipId,
                .artifact = interaction_pack_path,
                .artifactFingerprint = interactionLoaded.contentHash,
                .interactions = std::move(interactions),
                .interactionClip = interactionClipId,
            };
        }
        auto handle = createCompiledRunTaskRollout(
            std::move(manifest),
            metallib_path,
            "imported URDF",
            visual_sensor
        );
        result = handle.release();
    });
    return status == 0 ? result : nullptr;
}

static MRTaskRolloutHandle* createWorldPackRun(
    const char* world_pack_path,
    const char* task_pack_path,
    const char* robot_actuator_pack_path,
    const char* sensor_program_pack_path,
    const char* reality_program_pack_path,
    const MRTaskRolloutConfigC* config,
    const MRTaskVisualObservationConfigC* visual_sensor,
    const char* metallib_path
) {
    if (config == nullptr ||
        world_pack_path == nullptr ||
        world_pack_path[0] == '\0' ||
        task_pack_path == nullptr ||
        task_pack_path[0] == '\0' ||
        robot_actuator_pack_path == nullptr ||
        robot_actuator_pack_path[0] == '\0' ||
        sensor_program_pack_path == nullptr ||
        sensor_program_pack_path[0] == '\0' ||
        reality_program_pack_path == nullptr ||
        reality_program_pack_path[0] == '\0') {
        gLastError =
            "MRWorldPack and all four executable owner artifacts are required.";
        return nullptr;
    }

    MRTaskRolloutHandle* result = nullptr;
    const int status = translateErrors([&] {
        metalrobo::TaskPack task;
        metalrobo::RobotActuatorPack actuators;
        metalrobo::SensorProgramPack sensors;
        metalrobo::RealityProgramPack reality;
        const metalrobo::LearningPackResult taskLoaded =
            metalrobo::readTaskPack(task_pack_path, task);
        const metalrobo::LearningPackResult actuatorLoaded =
            metalrobo::readRobotActuatorPack(
                robot_actuator_pack_path, actuators);
        const metalrobo::LearningPackResult sensorLoaded =
            metalrobo::readSensorProgramPack(
                sensor_program_pack_path, sensors);
        const metalrobo::LearningPackResult realityLoaded =
            metalrobo::readRealityProgramPack(
                reality_program_pack_path, reality);
        if (!taskLoaded.succeeded() || !actuatorLoaded.succeeded() ||
            !sensorLoaded.succeeded() || !realityLoaded.succeeded()) {
            throw std::invalid_argument(
                "one or more WorldPack run owner artifacts failed to load"
            );
        }
        metalrobo::MRWorldPack worldPack;
        const metalrobo::WorldPackResult worldLoaded =
            metalrobo::readWorldPack(
                world_pack_path,
                worldPack
            );
        if (!worldLoaded.succeeded()) {
            throw std::invalid_argument(
                std::string{"MRWorldPack load failed ["} +
                metalrobo::worldPackStatusName(
                    worldLoaded.status
                ) + "]: " + worldLoaded.message
            );
        }
        metalrobo::LocomotionWorld materialized =
            metalrobo::makeWorldPackLocomotionWorld(worldPack);
        const auto spheres = locomotionDynamicSpheres(*config);
        if (!spheres.empty()) {
            metalrobo::appendLocomotionDynamicSpheres(materialized, spheres);
        }
        metalrobo::RunManifest run = makeImportedRunManifest(
            std::move(materialized.model),
            std::move(materialized.sceneBodies),
            materialized.articulationIndex,
            std::move(task),
            std::move(actuators),
            std::move(sensors),
            std::move(reality),
            *config,
            "world_pack_run"
        );
        run.robot.id = worldPack.family.worldTemplate.task.robotAssetId;
        run.scene.authoredAssets =
            worldPack.family.worldTemplate.assets;
        run.sensors.worldSensors =
            worldPack.family.worldTemplate.sensors;
        auto handle = createCompiledRunTaskRollout(
            std::move(run),
            metallib_path,
            "MRWorldPack",
            visual_sensor
        );
        result = handle.release();
    });
    return status == 0 ? result : nullptr;
}

MRTaskRolloutHandle* mr_create_task_rollout(
    const MRRunManifestC* manifest
) {
    if (manifest == nullptr) {
        gLastError = "run manifest is null.";
        return nullptr;
    }
    MRTaskRolloutHandle* result = nullptr;
    switch (manifest->source) {
    case MR_RUN_SOURCE_UNITREE_G1:
        if (manifest->teacher_pack_path != nullptr &&
            manifest->teacher_pack_path[0] != '\0') {
            result = createUnitreeG1TeacherRun(
                &manifest->profile,
                manifest->surface,
                manifest->task,
                manifest->teacher_pack_path,
                manifest->teacher_clip_id,
                manifest->visual_sensor_program,
                manifest->metallib_path
            );
            break;
        }
        result = createUnitreeG1Run(
            &manifest->profile,
            manifest->surface,
            manifest->task,
            manifest->visual_sensor_program,
            manifest->metallib_path
        );
        break;
    case MR_RUN_SOURCE_FRANKA_PICK_PLACE:
        result = createFrankaRun(
            &manifest->profile,
            manifest->visual_sensor_program,
            manifest->metallib_path
        );
        break;
    case MR_RUN_SOURCE_IMPORTED_URDF:
        result = createImportedURDFRun(
            manifest->urdf_path,
            manifest->srdf_path,
            manifest->task_pack_path,
            manifest->robot_actuator_pack_path,
            manifest->sensor_program_pack_path,
            manifest->reality_program_pack_path,
            &manifest->profile,
            manifest->surface,
            manifest->teacher_pack_path,
            manifest->teacher_clip_id,
            manifest->visual_sensor_program,
            manifest->metallib_path
        );
        break;
    case MR_RUN_SOURCE_WORLD_PACK:
        result = createWorldPackRun(
            manifest->world_pack_path,
            manifest->task_pack_path,
            manifest->robot_actuator_pack_path,
            manifest->sensor_program_pack_path,
            manifest->reality_program_pack_path,
            &manifest->profile,
            manifest->visual_sensor_program,
            manifest->metallib_path
        );
        break;
    case MR_RUN_SOURCE_PX4_X500:
        result = createPX4X500Run(
            &manifest->profile,
            manifest->metallib_path
        );
        break;
    case MR_RUN_SOURCE_BIRDFLOW_DOVE:
        result = createBirdFlowDoveRun(
            &manifest->profile,
            manifest->visual_sensor_program,
            manifest->metallib_path
        );
        break;
    case MR_RUN_SOURCE_BIRDFLOW_AMERICAN_CROW:
        result = createBirdFlowAmericanCrowRun(
            &manifest->profile,
            manifest->visual_sensor_program,
            manifest->metallib_path,
            false
        );
        break;
    case MR_RUN_SOURCE_BIRDFLOW_AMERICAN_CROW_JOURNEY:
        result = createBirdFlowAmericanCrowRun(
            &manifest->profile,
            manifest->visual_sensor_program,
            manifest->metallib_path,
            true
        );
        break;
    default:
        gLastError = "run manifest source is invalid.";
        return nullptr;
    }
    if (result != nullptr && manifest->inspection_visual_program != nullptr) {
        const int inspectionStatus = translateErrors([&] {
            installTaskInspectionRuntime(
                *result,
                visualSensorProgram(*manifest->inspection_visual_program)
            );
        });
        if (inspectionStatus != 0) {
            delete result;
            return nullptr;
        }
    }
    return result;
}

MRTaskRolloutHandle* mr_create_task_rollout_retinal(const MRRunManifestC* manifest,const MRRetinalSensorConfigC* retinal) {
    if (!manifest || !retinal || manifest->source!=MR_RUN_SOURCE_BIRDFLOW_AMERICAN_CROW_JOURNEY ||
        (manifest->profile.birdflow_journey_variant!=MR_BIRDFLOW_JOURNEY_V13_RETINAL_FEEDING &&
         manifest->profile.birdflow_journey_variant!=MR_BIRDFLOW_JOURNEY_V14_OBJECT_PUSH)) {
        gLastError="Retinal entry requires an explicit v13/v14 American-crow manifest and retinal configuration";return nullptr;
    }
    auto* result=createBirdFlowAmericanCrowRun(&manifest->profile,manifest->visual_sensor_program,manifest->metallib_path,true,retinal);
    if (result && manifest->inspection_visual_program) {
        if (translateErrors([&] {installTaskInspectionRuntime(*result,visualSensorProgram(*manifest->inspection_visual_program));})!=0) {
            delete result;return nullptr;
        }
    }
    return result;
}

MRTaskRolloutHandle* mr_create_task_rollout_object_push_curriculum(const MRRunManifestC* manifest,
    const MRRetinalSensorConfigC* retinal,const MRCrowObjectPushCurriculumC* curriculum) {
    if(!manifest || !retinal || !curriculum ||
       manifest->source!=MR_RUN_SOURCE_BIRDFLOW_AMERICAN_CROW_JOURNEY ||
       manifest->profile.birdflow_journey_variant!=MR_BIRDFLOW_JOURNEY_V14_OBJECT_PUSH ||
       manifest->inspection_visual_program || manifest->profile.birdflow_journey_teacher) {
        gLastError="Object curriculum requires explicit v14 retinal crow, exclusive policy authority and no separate inspection program";
        return nullptr;
    }
    return createBirdFlowAmericanCrowRun(&manifest->profile,manifest->visual_sensor_program,
        manifest->metallib_path,true,retinal,nullptr,0,0,0,curriculum);
}

MRTaskRolloutHandle* mr_create_task_rollout_cued_foraging(const MRRunManifestC* manifest,
    const MRRetinalSensorConfigC* retinal,const MRCrowCuedForagingConfigC* foraging) {
    if(!manifest || !retinal || !foraging || manifest->source!=MR_RUN_SOURCE_BIRDFLOW_AMERICAN_CROW_JOURNEY ||
        manifest->profile.birdflow_journey_variant!=MR_BIRDFLOW_JOURNEY_V13_RETINAL_FEEDING || manifest->inspection_visual_program) {
        gLastError="Cued foraging requires explicit v13 crow, retinal/resource programs, and no separate inspection program";return nullptr;
    }
    return createBirdFlowAmericanCrowRun(&manifest->profile,manifest->visual_sensor_program,manifest->metallib_path,true,retinal,foraging);
}

MRTaskRolloutHandle* mr_create_task_rollout_cued_memory_foraging(const MRRunManifestC* manifest,
    const MRRetinalSensorConfigC* retinal,const MRCrowCuedForagingConfigC* foraging,uint32_t decision_step) {
    if(!manifest || !retinal || !foraging || decision_step<48u || decision_step>192u ||
        manifest->source!=MR_RUN_SOURCE_BIRDFLOW_AMERICAN_CROW_JOURNEY ||
        manifest->profile.birdflow_journey_variant!=MR_BIRDFLOW_JOURNEY_V13_RETINAL_FEEDING ||
        manifest->inspection_visual_program || manifest->profile.birdflow_journey_teacher) {
        gLastError="Memory-choice requires cued v13, decision tick48..192 and exclusive policy authority";return nullptr;
    }
    return createBirdFlowAmericanCrowRun(&manifest->profile,manifest->visual_sensor_program,manifest->metallib_path,true,retinal,foraging,decision_step);
}

MRTaskRolloutHandle* mr_create_task_rollout_cued_memory_foraging_holds(const MRRunManifestC* manifest,
    const MRRetinalSensorConfigC* retinal,const MRCrowCuedForagingConfigC* foraging,uint32_t decision,uint32_t head_hold,uint32_t beak_hold) {
    if(!manifest || !retinal || !foraging || decision<48u || decision>192u || !head_hold || !beak_hold || head_hold>512u || beak_hold>512u ||
        manifest->source!=MR_RUN_SOURCE_BIRDFLOW_AMERICAN_CROW_JOURNEY ||
        manifest->profile.birdflow_journey_variant!=MR_BIRDFLOW_JOURNEY_V13_RETINAL_FEEDING ||
        manifest->inspection_visual_program || manifest->profile.birdflow_journey_teacher) {
        gLastError="Native holds require cued v13, decision48..192, periods1..512 and exclusive policy authority";return nullptr;
    }
    return createBirdFlowAmericanCrowRun(&manifest->profile,manifest->visual_sensor_program,manifest->metallib_path,true,retinal,foraging,decision,head_hold,beak_hold);
}

namespace {
std::uint64_t lifeCheckpointIdentity(const MRTaskRolloutHandle& h) {
    using namespace metalrobo;
    const bool resourceFreeObject = !h.resourceRuntime && h.taskId=="american_crow_object_push_v14";
    checkpoint::require(h.visualRuntime && h.visualRuntime->retinal && (h.resourceRuntime || resourceFreeObject) &&
        MR_TASK_PROGRAM_HAS_RETINAL(h.taskProgram.header().articulation.z) && h.stepConfig.policyProgram.valid(),
        "Life checkpoint requires native retinal feeding or object push and an exact policy");
    checkpoint::Bytes identity;
    for (const auto value : {h.world.fingerprint(),h.taskProgram.fingerprint(),h.taskProgram.observationFingerprint(),
        h.taskProgram.actionFingerprint(),h.stepConfig.policyProgram.fingerprint(),h.stepConfig.basePolicyProgram.fingerprint(),h.resourceRuntime ? h.resourceRuntime->fingerprint() : std::uint64_t{0},h.stepConfig.taskSeed,
        std::uint64_t(h.environmentCount)}) checkpoint::append(identity,value);
    const auto digest=checkpoint::digest(identity);std::uint64_t result=0;std::memcpy(&result,digest.data(),sizeof(result));return result;
}
}
int mr_task_rollout_save_life_checkpoint(const MRTaskRolloutHandle* handle,const char* path) {
    return translateErrors([&] {
        using namespace metalrobo;checkpoint::require(handle && path && path[0],"Life checkpoint requires handle and path");
        const auto identity=lifeCheckpointIdentity(*handle);
        checkpoint::require(!handle->rejectedRetinalBatch && handle->pendingLifeWorld.empty() && handle->residentState.valid(),"Life checkpoint requires admitted successful resident state");
        const auto world=handle->context.checkpointResident(handle->residentState,handle->stepConfig);
        const auto retina=handle->visualRuntime->retinal->checkpointState();
        const auto resource=handle->resourceRuntime ? handle->resourceRuntime->checkpointState() : checkpoint::Bytes{};
        checkpoint::Bytes bytes;checkpoint::append(bytes,handle->submittedControlSteps);checkpoint::append(bytes,handle->completedEnvironmentSteps);
        checkpoint::append(bytes,handle->submissionCount);checkpoint::append(bytes,handle->totalGPUMilliseconds);checkpoint::append(bytes,handle->totalSubmissionMilliseconds);
        checkpoint::appendBlob(bytes,world);checkpoint::appendBlob(bytes,retina);checkpoint::appendBlob(bytes,resource);
        checkpoint::writeExclusive(path,checkpoint::seal({'N','U','M','I','L','F','0','1'},identity,bytes));
    });
}
int mr_task_rollout_restore_life_checkpoint(MRTaskRolloutHandle* handle,const char* path) {
    return translateErrors([&] {
        using namespace metalrobo;checkpoint::require(handle && path && path[0],"Life restore requires handle and path");
        const auto identity=lifeCheckpointIdentity(*handle);
        checkpoint::require(!handle->residentState.valid() && !handle->submittedControlSteps && !handle->submissionCount &&
            handle->pendingLifeWorld.empty() && !handle->rejectedRetinalBatch,"Life restore requires a fresh unadvanced handle");
        const auto bytes=checkpoint::readBounded(path,1024ull*1024*1024);
        checkpoint::Reader reader{checkpoint::open(bytes,{'N','U','M','I','L','F','0','1'},identity)};
        const auto steps=reader.get<std::uint64_t>(),completed=reader.get<std::uint64_t>(),submissions=reader.get<std::uint64_t>();
        const auto gpu=reader.get<double>(),submission=reader.get<double>();
        checkpoint::require(steps && submissions && steps<=std::numeric_limits<std::uint64_t>::max()/handle->environmentCount &&
            completed==steps*handle->environmentCount && std::isfinite(gpu) && gpu>=0 &&
            std::isfinite(submission) && submission>=0,"Invalid life checkpoint host accounting");
        const auto world=reader.blob(),retina=reader.blob(),resource=reader.blob();reader.end();
        checkpoint::require(bool(handle->resourceRuntime)==!resource.empty(),"Life checkpoint resource component contract mismatch");
        const std::vector<unsigned> masks(handle->environmentCount,0);
        const MetalWorldBatch validation{.environmentCount=handle->environmentCount,.controlStepCount=1,
            .initialQ=handle->resetQ,.initialV=handle->resetV,.resetMasks=masks,.initialSceneBodies=handle->resetSceneBodies};
        handle->context.validateResidentCheckpoint(handle->world,validation,handle->stepConfig,world);
        // Build and restore candidates. An invalid later component cannot mutate
        // the published handle or allow a partially restored life to advance.
        // Preserve the exact authored resource layout/allocation/life seed.
        // A candidate cue observer must retain the candidate food owner,
        // rather than the live handle's soon-to-be-replaced resource state.
        std::unique_ptr<FiniteResourceContext> food;
        if(handle->resourceRuntime) food=std::make_unique<FiniteResourceContext>(handle->resourceRuntime->deviceView().config);
        const auto& sensor=*handle->run.visualSensorProgram();
        auto visual=compileTaskVisualRuntime(*handle,sensor,true,
            sensor.retinal && !sensor.retinal->resourceCues.empty() ? food.get() : nullptr);
        visual->retinal->restoreState(retina);
        if(food) food->restoreState(resource);
        std::vector<std::byte> pending(world.begin(),world.end());
        handle->visualRuntime=std::move(visual);handle->resourceRuntime=std::move(food);handle->pendingLifeWorld=std::move(pending);
        handle->stepConfig.deviceObservationProgram=handle->visualRuntime->retinal->deviceProgram();
        handle->stepConfig.devicePhysicsProgram=handle->resourceRuntime ? handle->resourceRuntime->deviceProgram() : MetalWorldDevicePhysicsProgram{};
        handle->submittedControlSteps=steps;handle->completedEnvironmentSteps=completed;handle->submissionCount=submissions;
        handle->totalGPUMilliseconds=gpu;handle->totalSubmissionMilliseconds=submission;
    });
}

void mr_task_rollout_destroy(MRTaskRolloutHandle* handle) {
    delete handle;
}

int mr_task_rollout_reset(
    MRTaskRolloutHandle* handle,
    const uint64_t seed
) {
    if (!requireTaskRolloutHandle(handle)) {
        return -1;
    }
    return translateErrors(
        [&] { resetTaskRolloutState(*handle, seed); }
    );
}

int mr_task_rollout_evidence_telemetry(
    const MRTaskRolloutHandle* handle,
    MRTaskEvidenceTelemetryC* telemetry
) {
    if (!requireTaskRolloutHandle(handle)) {
        return -1;
    }
    if (telemetry == nullptr) {
        gLastError = "task evidence telemetry output is null.";
        return -1;
    }
    return translateErrors([&] {
        if (!handle->residentState.valid()) {
            throw std::logic_error(
                "task evidence telemetry requires a completed resident submission"
            );
        }
        const MRTaskEvidenceStateGPU& state =
            handle->result.evidenceState;
        telemetry->control_steps = state.controlSteps;
        telemetry->evidence_windows = state.evidenceWindows;
        telemetry->pending_completed_episode_count =
            state.completedEpisodeCount;
        telemetry->pending_timeout_episode_count =
            state.timeoutEpisodeCount;
        telemetry->last_completed_episode_count =
            state.lastCompletedEpisodeCount;
        telemetry->last_contact_rate = state.lastWindow.x;
        telemetry->last_clean_miss_rate = state.lastWindow.y;
        telemetry->last_balance_failure_rate = state.lastWindow.z;
        telemetry->last_mean_tracking_per_million =
            state.lastWindow.w;
    });
}

int mr_task_rollout_copy_lifetime_ticks(
    const MRTaskRolloutHandle* handle, uint64_t* output, const size_t output_count
) {
    if (!requireTaskRolloutHandle(handle)) return -1;
    return translateErrors([&] {
        using namespace metalrobo;
        checkpoint::require(output && output_count==handle->environmentCount,
            "Lifetime tick output has the wrong size");
        checkpoint::require(!handle->rejectedRetinalBatch &&
            (handle->residentState.valid() || !handle->pendingLifeWorld.empty()) &&
            handle->submittedControlSteps &&
            handle->submittedControlSteps<=std::numeric_limits<std::uint64_t>::max()/handle->environmentCount &&
            handle->completedEnvironmentSteps==handle->submittedControlSteps*handle->environmentCount,
            "Lifetime ticks require a successful accepted or restored native life");
        std::vector<std::uint64_t> ticks(output_count);
        if(handle->resourceRuntime) {
            const auto states=handle->resourceRuntime->snapshot();
            checkpoint::require(states.size()==output_count,"Resource lifetime lane count mismatch");
            for(std::size_t lane=0;lane<states.size();++lane)
                ticks[lane]=(std::uint64_t(states[lane].clock.y)<<32u)|states[lane].clock.x;
        } else {
            // Retinal batches fail closed: any rejected lane invalidates the
            // handle before these counters publish. The resource-free object
            // task therefore has one successful stream clock shared by all
            // lanes, preserved across episode resets and exact life restore.
            checkpoint::require(handle->taskId=="american_crow_object_push_v14" &&
                handle->visualRuntime && handle->visualRuntime->retinal,
                "Resource-free lifetime clock is not admitted for this task");
            std::fill(ticks.begin(),ticks.end(),handle->submittedControlSteps);
        }
        checkpoint::require(std::all_of(ticks.begin(),ticks.end(),[&](auto tick){
            return tick==handle->submittedControlSteps;
        }),"Native lifetime clocks disagree with accepted host accounting");
        std::copy(ticks.begin(),ticks.end(),output);
    });
}

int mr_task_rollout_copy_resource_accounting(
    const MRTaskRolloutHandle* handle,
    MRTaskResourceAccountingC* output,
    const size_t output_count
) {
    if (!requireTaskRolloutHandle(handle)) return -1;
    if (output == nullptr || output_count != handle->environmentCount) {
        gLastError = "resource accounting output has the wrong size";
        return -1;
    }
    return translateErrors([&] {
        if (!handle->resourceRuntime || !handle->residentState.valid()) {
            throw std::logic_error("resource accounting requires a completed finite-resource submission");
        }
        const auto states = handle->resourceRuntime->snapshot();
        if (states.size() != output_count) {
            throw std::logic_error("resource accounting environment count mismatch");
        }
        for (std::size_t lane=0u; lane<states.size(); ++lane) {
            const auto& state=states[lane];
            std::uint64_t remaining=0u;
            for (const auto& patch : state.remaining) {
                remaining += static_cast<std::uint64_t>(patch.x)+patch.y+patch.z+patch.w;
            }
            output[lane] = {remaining, state.accounting.x, state.accounting.y,
                state.accounting.z, state.accounting.w,
                (static_cast<std::uint64_t>(state.clock.y)<<32u)|state.clock.x};
        }
    });
}

int mr_task_rollout_set_policy(
    MRTaskRolloutHandle* handle,
    const MRPolicyPackC* policy
) {
    if (!requireTaskRolloutHandle(handle)) {
        return -1;
    }
    if (policy == nullptr) {
        gLastError = "task-rollout policy is null.";
        return -1;
    }
    return translateErrors([&] {
        metalrobo::PolicyPack authored =
            policyPackFromC(*policy);
        installPolicyPack(*handle, authored);
    });
}

int mr_task_rollout_load_policy_pack(
    MRTaskRolloutHandle* handle,
    const char* policy_pack_path
) {
    if (!requireTaskRolloutHandle(handle)) {
        return -1;
    }
    if (policy_pack_path == nullptr ||
        policy_pack_path[0] == '\0') {
        gLastError = "PolicyPack path is empty.";
        return -1;
    }
    return translateErrors([&] {
        metalrobo::PolicyPack authored;
        const metalrobo::LearningPackResult loaded =
            metalrobo::readPolicyPack(
                policy_pack_path,
                authored
            );
        if (!loaded.succeeded()) {
            throw std::invalid_argument(
                std::string{"PolicyPack load failed ["} +
                metalrobo::learningPackStatusName(
                    loaded.status
                ) + "]: " + loaded.message
            );
        }
        installPolicyPack(*handle, authored);
    });
}

int mr_task_rollout_load_base_policy_pack(
    MRTaskRolloutHandle* handle,
    const char* policy_pack_path
) {
    if (!requireTaskRolloutHandle(handle)) {
        return -1;
    }
    if (policy_pack_path == nullptr ||
        policy_pack_path[0] == '\0') {
        gLastError = "base PolicyPack path is empty.";
        return -1;
    }
    return translateErrors([&] {
        metalrobo::PolicyPack authored;
        const metalrobo::LearningPackResult loaded =
            metalrobo::readPolicyPack(policy_pack_path, authored);
        if (!loaded.succeeded()) {
            throw std::invalid_argument(
                std::string{"base PolicyPack load failed ["} +
                metalrobo::learningPackStatusName(loaded.status) +
                "]: " + loaded.message
            );
        }
        installBasePolicyPack(*handle, authored);
    });
}

uint64_t mr_task_rollout_policy_revision(
    const MRTaskRolloutHandle* handle
) {
    if (!requireTaskRolloutHandle(handle) ||
        !handle->stepConfig.policyProgram.valid()) {
        return 0u;
    }
    return handle->stepConfig.policyProgram.revision();
}

int mr_task_rollout_clear_policy(
    MRTaskRolloutHandle* handle
) {
    if (!requireTaskRolloutHandle(handle)) {
        return -1;
    }
    if (handle->residentState.valid() && handle->stepConfig.policyProgram.actorMemory()) {
        gLastError="Cannot clear a resident recurrent policy and discard its working-memory contract";
        return -1;
    }
    handle->stepConfig.policyProgram = {};
    handle->stepConfig.basePolicyProgram = {};
    gLastError.clear();
    return 0;
}

size_t mr_task_rollout_copy_visual_rgba(
    MRTaskRolloutHandle* handle,
    float* destination,
    const size_t destination_count,
    uint32_t* width,
    uint32_t* height
) {
    if (!requireTaskRolloutHandle(handle) ||
        handle->visualRuntime == nullptr ||
        !handle->visualRuntime->captureEnabled) {
        gLastError = "task rollout has no native presentation capture.";
        return 0u;
    }
    const std::uint32_t environments = handle->environmentCount;
    const std::size_t bodyCount = handle->model.bodies.size();
    const std::size_t nq = handle->world.nq();
    const std::size_t nv = handle->world.nv();
    if (handle->result.finalQ.size() != environments * nq ||
        handle->result.finalV.size() != environments * nv) {
        gLastError = "task visual capture requires final-state readback.";
        return 0u;
    }
    std::vector<MRBodyStateGPU> bodies;
    std::string compositionReason;
    if (!metalrobo::composeVisualBodyStates(
            handle->model,
            environments,
            handle->result.finalQ,
            handle->result.finalV,
            handle->result.finalSceneBodies,
            bodies,
            &compositionReason
        )) {
        gLastError =
            "task visual body composition failed: " +
            compositionReason;
        return 0u;
    }
    for (std::uint32_t environment = 0u;
         environment < environments;
         ++environment) {
        for (std::size_t body = 0u; body < bodyCount; ++body) {
            if (!std::string_view{handle->model.bodyNames[body]}
                    .starts_with("locomotion_dynamic_sphere_")) {
                continue;
            }
            MRBodyStateGPU& projectile =
                bodies[environment * bodyCount + body];
            const float speedSquared =
                projectile.linearVelocityAndInverseMass.x *
                    projectile.linearVelocityAndInverseMass.x +
                projectile.linearVelocityAndInverseMass.y *
                    projectile.linearVelocityAndInverseMass.y +
                projectile.linearVelocityAndInverseMass.z *
                    projectile.linearVelocityAndInverseMass.z;
            if (!handle->visualRuntime->capturePolicyCamera &&
                speedSquared <= 0.25f) {
                // Staged and expired projectiles remain real simulator state,
                // but are not active presentation subjects. The onboard
                // sensor path above continues to consume untouched states.
                projectile.position.z = -100.0f;
            }
        }
    }
    auto& runtime = *handle->visualRuntime;
    metalrobo::VisualMotionSampleBatchV1 motion;
    motion.environmentCount = environments;
    motion.bodyCount = static_cast<std::uint32_t>(bodyCount);
    motion.sampleCount = 2u;
    motion.exposureOpenSeconds = 0.0;
    motion.exposureCloseSeconds = 1.0 / 120.0;
    motion.timestampsSeconds = {
        motion.exposureOpenSeconds,
        motion.exposureCloseSeconds,
    };
    const auto& previous = runtime.previousCaptureBodies.empty()
        ? bodies
        : runtime.previousCaptureBodies;
    motion.bodyStates.reserve(2u * bodies.size());
    motion.bodyStates.insert(
        motion.bodyStates.end(),
        previous.begin(),
        previous.end()
    );
    motion.bodyStates.insert(
        motion.bodyStates.end(),
        bodies.begin(),
        bodies.end()
    );
    motion.frameIndex = ++runtime.captureFrameIndex;
    motion.sensorSequence =
        static_cast<std::uint32_t>(runtime.captureFrameIndex);
    motion.source = MR_VISUAL_SOURCE_SIMULATION;
    const auto render = runtime.captureRenderer.renderFrame(
        runtime.worlds,
        motion,
        1u
    );
    if (!render.succeeded()) {
        gLastError = std::string{"task visual capture render failed: "} +
            render.message;
        return 0u;
    }
    runtime.previousCaptureBodies = bodies;
    metalrobo::HybridObservationBatch frame;
    const auto diagnostics =
        runtime.captureRenderer.readback(frame);
    if (!diagnostics.succeeded()) {
        gLastError =
            std::string{"task visual readback failed ["} +
            metalrobo::metalHybridRendererStatusName(
                diagnostics.status
            ) + "]: " + diagnostics.message;
        return 0u;
    }
    if (width != nullptr) {
        *width = frame.width;
    }
    if (height != nullptr) {
        *height = frame.height;
    }
    const size_t required = frame.rgb.size() * 4u;
    const bool anyColor = std::ranges::any_of(
        frame.rgb,
        [](const mr_float4 value) {
            return value.x != 0.0f || value.y != 0.0f || value.z != 0.0f;
        }
    );
    if (!anyColor) {
        const std::size_t visible = std::ranges::count_if(
            frame.segmentation,
            [](const std::uint32_t value) { return value != 0u; }
        );
        gLastError = "native presentation capture is empty; visible pixels=" +
            std::to_string(visible) + ", root=" +
            std::to_string(bodies.front().position.x) + "," +
            std::to_string(bodies.front().position.y) + "," +
            std::to_string(bodies.front().position.z);
        return 0u;
    }
    if (destination == nullptr) {
        gLastError.clear();
        return required;
    }
    if (destination_count < required) {
        gLastError = "task visual RGBA destination is too small.";
        return 0u;
    }
    static_assert(sizeof(mr_float4) == 4u * sizeof(float));
    std::memcpy(destination, frame.rgb.data(), required * sizeof(float));
    gLastError.clear();
    return required;
}

int mr_task_rollout_set_state_readback(
    MRTaskRolloutHandle* handle,
    const uint32_t enabled
) {
    if (!requireTaskRolloutHandle(handle) || enabled > 1u) {
        if (enabled > 1u) {
            gLastError = "task-rollout state-readback flag is invalid.";
        }
        return -1;
    }
    handle->stepConfig.publishFinalState = enabled != 0u;
    gLastError.clear();
    return 0;
}

int mr_task_rollout_advance(
    MRTaskRolloutHandle* handle,
    const float* normalized_actions,
    const size_t normalized_action_count,
    const uint32_t* reset_masks,
    const size_t reset_mask_count,
    const uint32_t control_step_count,
    const uint64_t policy_revision,
    const uint32_t evaluate_final_policy,
    MRTaskRolloutAdvanceC* advance
) {
    if (!requireTaskRolloutHandle(handle)) {
        return -1;
    }
    if (advance == nullptr) {
        gLastError = "task-rollout advance result is null.";
        return -1;
    }
    *advance = {};
    advance->first_failing_environment = UINT32_MAX;
    advance->first_failing_control_step = UINT32_MAX;
    if (control_step_count == 0u) {
        gLastError =
            "task-rollout control_step_count must be positive.";
        return -1;
    }

    return translateErrors([&] {
        if (handle->rejectedRetinalBatch) throw std::runtime_error("Retinal batch invalidated; an explicit world reset is required before reuse");
        handle->stepConfig.evaluateFinalPolicy =
            evaluate_final_policy != 0u;
        const std::size_t actionCount =
            handle->taskProgram.layout().actionCount;
        const std::size_t environmentCount =
            handle->environmentCount;
        const bool nativePolicy =
            handle->stepConfig.policyProgram.valid();
        const std::size_t requiredActions =
            nativePolicy
            ? 0u
            : checkedProduct(
                  {
                      control_step_count,
                      environmentCount,
                      actionCount,
                  },
                  "task-rollout action"
              );
        const std::size_t requiredMasks = checkedProduct(
            {control_step_count, environmentCount},
            "task-rollout reset mask"
        );
        if ((!nativePolicy &&
             normalized_actions == nullptr) ||
            normalized_action_count != requiredActions ||
            (nativePolicy &&
             normalized_actions != nullptr)) {
            throw std::invalid_argument(
                nativePolicy
                ? "native-policy rollout does not accept a host action stream"
                : "normalized task action count must equal step_count * environment_count * compiled action_count"
            );
        }
        if ((reset_masks == nullptr && reset_mask_count != 0u) ||
            (reset_masks != nullptr &&
             reset_mask_count != requiredMasks)) {
            throw std::invalid_argument(
                "task reset mask count must be zero or "
                "step_count * environment_count"
            );
        }

        handle->resetMasks.assign(requiredMasks, 0u);
        if (reset_masks != nullptr) {
            std::copy(
                reset_masks,
                reset_masks + reset_mask_count,
                handle->resetMasks.begin()
            );
        }
        advance->host_requested_resets =
            static_cast<std::uint32_t>(
                std::count_if(
                    handle->resetMasks.begin(),
                    handle->resetMasks.end(),
                    [](const std::uint32_t value) {
                        return value != 0u;
                    }
                )
            );

        const bool initializeResidentState =
            !handle->residentState.valid();
        const metalrobo::MetalWorldBatch batch{
            .environmentCount = environmentCount,
            .controlStepCount = control_step_count,
            .initialQ =
                initializeResidentState
                ? std::span<const float>{handle->resetQ}
                : std::span<const float>{},
            .initialV =
                initializeResidentState
                ? std::span<const float>{handle->resetV}
                : std::span<const float>{},
            .actions =
                nativePolicy
                ? std::span<const float>{}
                : std::span<const float>{
                      normalized_actions,
                      normalized_action_count
                  },
            .policyRevision = policy_revision,
            .resetMasks = handle->resetMasks,
            .initialSceneBodies =
                initializeResidentState
                ? std::span<const MRBodyStateGPU>{
                      handle->resetSceneBodies
                  }
                : std::span<const MRBodyStateGPU>{},
        };
        metalrobo::MetalWorldSubmission submission;
        metalrobo::MetalWorldResult published;
        metalrobo::MetalWorldDiagnostics diagnostics =
            initializeResidentState
            ? !handle->pendingLifeWorld.empty()
                ? handle->context.resumeResident(handle->world,batch,handle->stepConfig,handle->pendingLifeWorld,handle->residentState,submission)
                : handle->context.initializeResidentState(
                handle->world,
                batch,
                handle->stepConfig,
                handle->residentState,
                submission
            )
            : handle->context.submitResident(
                handle->world,
                batch,
                handle->stepConfig,
                handle->residentState,
                submission
            );
        if (diagnostics.succeeded()) {
            diagnostics = submission.wait(published);
        }
        if (handle->visualRuntime && handle->visualRuntime->retinal)
            handle->rejectedRetinalBatch=true; // Clear only after complete native and sensor admission.
        advance->control_step_count = control_step_count;
        advance->successful_environment_steps =
            diagnostics.successfulStepCount;
        advance->failed_environment_steps =
            diagnostics.failedStepCount;
        advance->first_failing_environment =
            diagnostics.firstFailingEnvironment;
        advance->first_failing_control_step =
            diagnostics.firstFailingControlStep;
        advance->first_gpu_status_code =
            diagnostics.firstGPUStatusCode;
        advance->gpu_milliseconds =
            diagnostics.gpuElapsedMilliseconds;
        advance->submission_milliseconds =
            diagnostics.submissionElapsedMilliseconds;

        handle->statusCodes.assign(
            requiredMasks,
            MR_STEP_SUCCESS
        );
        handle->activeContacts.assign(requiredMasks, 0u);
        for (std::size_t index = 0u;
             index < requiredMasks;
             ++index) {
            if (index < published.statuses.size()) {
                handle->statusCodes[index] =
                    published.statuses[index].code;
            }
            if (index < published.contactStatuses.size()) {
                const auto& contact =
                    published.contactStatuses[index];
                if (handle->statusCodes[index] ==
                    MR_STEP_SUCCESS) {
                    handle->statusCodes[index] = contact.code;
                }
                handle->activeContacts[index] =
                    contact.activeContacts;
                advance->maximum_active_contacts = std::max(
                    advance->maximum_active_contacts,
                    contact.activeContacts
                );
                advance->maximum_manifolds = std::max(
                    advance->maximum_manifolds,
                    contact.requiredManifolds
                );
            }
        }
        for (const metalrobo::MetalWorldStatus& status :
             published.environmentStatuses) {
            accumulateTaskStageHighWater(
                advance->high_water,
                status.highWater
            );
        }

        if (!diagnostics.published ||
            published.statuses.size() != requiredMasks ||
            published.contactStatuses.size() !=
                requiredMasks) {
            throw std::runtime_error(
                std::string{"task-rollout publication failed ["} +
                metalrobo::metalWorldHostStatusName(
                    diagnostics.status
                ) + "]: " + diagnostics.message
            );
        }
        if (std::getenv("CROW_CLEARANCE_TRACE") != nullptr &&
            control_step_count == 1u) {
            if (handle->crowClearance.empty())
                handle->crowClearance.resize(environmentCount);
            if (handle->crowClearance.size()!=environmentCount)
                throw std::runtime_error("clearance observer lane count changed");
            std::vector<MRBodyStateGPU> composed;
            std::string reason;
            if (!metalrobo::composeVisualBodyStates(handle->model,environmentCount,
                    published.finalQ,published.finalV,published.finalSceneBodies,
                    composed,&reason))
                throw std::runtime_error("clearance body composition failed: "+reason);
            const auto& model=handle->model;
            const std::size_t bodyCount=model.bodies.size();
            std::vector<std::size_t> birds,obstacles;
            for (std::size_t i=0;i<model.shapes.size();++i) {
                const auto& shape=model.shapes[i];
                const auto& name=model.bodyNames.at(shape.bodyIndex);
                if (name.starts_with("crow_course_gate_") ||
                    name.starts_with("crow_course_slalom_")) obstacles.push_back(i);
                else if (name.starts_with("crow_") &&
                         !name.starts_with("crow_course_")) birds.push_back(i);
            }
            if (birds.empty() || obstacles.size()!=4u)
                throw std::runtime_error("clearance observer collider contract mismatch");
            const auto makeBox=[&](std::size_t lane,std::size_t index) {
                const auto& shape=model.shapes[index];
                if (shape.shapeType!=MR_SHAPE_BOX)
                    throw std::runtime_error("clearance observer requires box colliders");
                const auto& body=composed[lane*bodyCount+shape.bodyIndex];
                const auto &p=body.position,&q=body.orientation,
                           &lp=shape.localPosition,&lq=shape.localRotation,&d=shape.dimensions;
                return crowclear::box({p.x,p.y,p.z},{q.x,q.y,q.z,q.w},
                    {lp.x,lp.y,lp.z},{lq.x,lq.y,lq.z,lq.w},{d.x,d.y,d.z});
            };
            const auto step=static_cast<unsigned long long>(handle->submittedControlSteps+1u);
            for (std::size_t lane=0;lane<environmentCount;++lane) {
                auto& record=handle->crowClearance[lane];
                if(record.closed)continue;
                for (const auto j:obstacles) {
                    const auto obstacle=makeBox(lane,j);
                    for (const auto i:birds) {
                        const auto bird=makeBox(lane,i);
                        const double bound=std::sqrt(crowclear::norm2(bird.c-obstacle.c))-
                            std::sqrt(bird.h[0]*bird.h[0]+bird.h[1]*bird.h[1]+bird.h[2]*bird.h[2])-
                            std::sqrt(obstacle.h[0]*obstacle.h[0]+obstacle.h[1]*obstacle.h[1]+obstacle.h[2]*obstacle.h[2]);
                        if (bound>=record.distance)continue;
                        const auto distance=crowclear::distance(bird,obstacle);
                        if (distance<record.distance) {
                            record.distance=distance;record.step=step;
                            record.birdShape=i;record.obstacleShape=j;
                        }
                    }
                }
                const bool terminated=lane<published.transitions.size() &&
                   published.transitions[lane].termination.w!=MR_TASK_TERMINATION_CONTINUING;
                if(terminated || step%1u==0u) {
                    record.closed=terminated;
                    const auto& bs=model.shapes[record.birdShape];
                    const auto& os=model.shapes[record.obstacleShape];
                    std::fprintf(stderr,
                        "CROW_CLEARANCE_SAMPLE {\"lane\":%zu,\"end_step\":%llu,\"minimum_step\":%llu,\"minimum_m\":%.12g,\"bird_shape\":\"%s\",\"obstacle_shape\":\"%s\",\"bird_body\":\"%s\",\"obstacle_body\":\"%s\",\"sampling\":\"accepted_control_steps\"}\n",
                        lane,step,record.step,record.distance,
                        model.shapeNames[record.birdShape].c_str(),model.shapeNames[record.obstacleShape].c_str(),
                        model.bodyNames[bs.bodyIndex].c_str(),model.bodyNames[os.bodyIndex].c_str());
                }
            }
        }
        if (handle->visualRuntime && handle->visualRuntime->retinal) {
            handle->rejectedRetinalBatch=true;
            if (!diagnostics.succeeded()) throw std::runtime_error("Retinal native rollout failed: "+diagnostics.message);
            const auto sensor=handle->visualRuntime->retinal->snapshot();
            for (unsigned lane=0;lane<sensor.errors.size();++lane) if (sensor.errors[lane])
                throw std::runtime_error("Retinal GPU rejected learner batch: lane="+std::to_string(lane)+" error="+std::to_string(sensor.errors[lane]));
            handle->rejectedRetinalBatch=false;
        }
        if (std::getenv("CROW_CONTACT_TRACE") != nullptr &&
            control_step_count == 1u) {
            const auto array = [](const char* name, const std::vector<float>& v, size_t start, size_t n) {
                std::fprintf(stderr, ",\"%s\":[", name);
                for (size_t i=0; i<n && start+i<v.size(); ++i)
                    std::fprintf(stderr, "%s%.9g", i ? "," : "", v[start+i]);
                std::fprintf(stderr, "]");
            };
            if ((handle->submittedControlSteps + 1u) % 100u == 0u || (std::getenv("CROW_EARLY_FLIGHT_TRACE") != nullptr && handle->submittedControlSteps < 4u)) {
                for (size_t lane=0; lane<environmentCount; ++lane) {
                    std::fprintf(stderr, "CROW_FLIGHT_SAMPLE {\"step\":%llu,\"lane\":%zu",
                        static_cast<unsigned long long>(handle->submittedControlSteps+1u), lane);
                    array("q", published.finalQ, lane*handle->world.nq(), handle->world.nq());
                    array("v", published.finalV, lane*handle->world.nv(), handle->world.nv());
                    array("policy_action", published.policyActions,
                        lane*handle->taskProgram.layout().actionCount, handle->taskProgram.layout().actionCount);
                    std::fprintf(stderr, "}\n");
                }
            }

            if (std::getenv("CROW_SUPPORT_TRACE") != nullptr) {
                for (size_t lane=0; lane<environmentCount && lane<published.contactStatuses.size(); ++lane) {
                    const auto stride = published.layout.contactDispatch.constraintStride;
                    const auto count = published.contactStatuses[lane].activeContacts;
                    const auto name=[&](uint32_t b) { return b<handle->model.bodyNames.size()
                        ? handle->model.bodyNames[b].c_str() : "invalid"; };
                    // Bound repetitive stable-support evidence, while keeping
                    // all contact interruptions and the final 25 steps.
                    static std::vector<unsigned> consecutive;
                    static std::vector<unsigned long long> lastStep;
                    if (consecutive.size()!=environmentCount) {
                        consecutive.assign(environmentCount,0u);
                        lastStep.assign(environmentCount,0ull);
                    }
                    bool hasFoot=false, hasOther=false;
                    double upward=0.0;
                    for (size_t i=0;i<count && lane*stride+i<published.contactEvidence.contacts.size();++i) {
                        const auto& c=published.contactEvidence.contacts[lane*stride+i];
                        const std::string a=name(c.bodyA), b=name(c.bodyB);
                        if (a.find("crow_course_perch")==std::string::npos &&
                            b.find("crow_course_perch")==std::string::npos &&
                            a.find("locomotion_ground")==std::string::npos &&
                            b.find("locomotion_ground")==std::string::npos) continue;
                        const bool footA=a.find("foot")!=std::string::npos;
                        const bool footB=b.find("foot")!=std::string::npos;
                        if (footA || footB) {
                            hasFoot=true;
                            upward+=(footA ? -1.0 : 1.0)*c.normal.z*c.impulses.x;
                        } else hasOther=true;
                    }
                    const auto step=static_cast<unsigned long long>(handle->submittedControlSteps+1u);
                    const auto vb=lane*handle->world.nv();
                    const bool velocityOK=vb+2u<published.finalV.size() &&
                        std::hypot(published.finalV[vb],published.finalV[vb+1u])<=0.12f &&
                        std::abs(published.finalV[vb+2u])<=0.12f;
                    if (hasFoot && !hasOther && upward>0.0 && velocityOK)
                        consecutive[lane]=(lastStep[lane]+1ull==step) ? consecutive[lane]+1u : 1u;
                    else consecutive[lane]=0u;
                    lastStep[lane]=step;
                    if (step>350u && consecutive[lane]>50u && step<2976u && step%100u!=0u) continue;
                    bool opened=false, first=true;
                    for (size_t i=0; i<count && lane*stride+i<published.contactEvidence.contacts.size(); ++i) {
                        const auto& c=published.contactEvidence.contacts[lane*stride+i];
                        const std::string a=name(c.bodyA), b=name(c.bodyB);
                        if (!opened) {
                            std::fprintf(stderr, "CROW_SUPPORT_SAMPLE {\"step\":%llu,\"lane\":%zu",
                                static_cast<unsigned long long>(handle->submittedControlSteps+1u), lane);
                            array("q",published.finalQ,lane*handle->world.nq(),handle->world.nq());
                            array("v",published.finalV,lane*handle->world.nv(),handle->world.nv());
                            array("policy_action",published.policyActions,lane*handle->taskProgram.layout().actionCount,handle->taskProgram.layout().actionCount);
                            std::fprintf(stderr,",\"contacts\":[");
                            opened=true;
                        }
                        std::fprintf(stderr,"%s{\"a\":%u,\"a_name\":\"%s\",\"b\":%u,\"b_name\":\"%s\",\"point\":[%.9g,%.9g,%.9g],\"normal\":[%.9g,%.9g,%.9g],\"tangent_u\":[%.9g,%.9g,%.9g],\"tangent_v\":[%.9g,%.9g,%.9g],\"impulses\":[%.9g,%.9g,%.9g],\"separation\":%.9g}",
                            first?"":",",c.bodyA,a.c_str(),c.bodyB,b.c_str(),c.pointAndSeparation.x,c.pointAndSeparation.y,c.pointAndSeparation.z,
                            c.normal.x,c.normal.y,c.normal.z,c.tangent.x,c.tangent.y,c.tangent.z,
                            c.normal.y*c.tangent.z-c.normal.z*c.tangent.y,c.normal.z*c.tangent.x-c.normal.x*c.tangent.z,c.normal.x*c.tangent.y-c.normal.y*c.tangent.x,c.impulses.x,c.impulses.y,c.impulses.z,c.pointAndSeparation.w);
                        first=false;
                    }
                    if (opened) std::fprintf(stderr,"]}\n");
                    else {
                        std::fprintf(stderr, "CROW_SUPPORT_SAMPLE {\"step\":%llu,\"lane\":%zu",
                            static_cast<unsigned long long>(handle->submittedControlSteps+1u), lane);
                        array("q",published.finalQ,lane*handle->world.nq(),handle->world.nq());
                        array("v",published.finalV,lane*handle->world.nv(),handle->world.nv());
                        array("policy_action",published.policyActions,lane*handle->taskProgram.layout().actionCount,handle->taskProgram.layout().actionCount);
                        std::fprintf(stderr, ",\"contacts\":[]}\n");
                    }
                }
            }
            for (size_t lane=0; lane<environmentCount && lane<published.transitions.size(); ++lane) {
                if (published.transitions[lane].termination.w != MR_TASK_TERMINATION_CONTACT) continue;
                const auto& prev = handle->result;
                std::fprintf(stderr, "CROW_CONTACT_TRACE {\"step\":%llu,\"lane\":%zu",
                    static_cast<unsigned long long>(handle->submittedControlSteps+1u), lane);
                array("pre_q", prev.finalQ, lane*handle->world.nq(), handle->world.nq());
                array("pre_v", prev.finalV, lane*handle->world.nv(), handle->world.nv());
                array("policy_action", published.policyActions,
                    lane*handle->taskProgram.layout().actionCount, handle->taskProgram.layout().actionCount);
                std::fprintf(stderr, ",\"contacts\":[");
                const auto stride = published.layout.contactDispatch.constraintStride;
                const auto count = published.contactStatuses[lane].activeContacts;
                bool first=true;
                for (size_t i=0; i<count && lane*stride+i<published.contactEvidence.contacts.size(); ++i) {
                    const auto& c=published.contactEvidence.contacts[lane*stride+i];
                    const auto name=[&](uint32_t b) { return b<handle->model.bodyNames.size()
                        ? handle->model.bodyNames[b].c_str() : "invalid"; };
                    std::fprintf(stderr, "%s{\"a\":%u,\"a_name\":\"%s\",\"b\":%u,\"b_name\":\"%s\",\"normal_impulse\":%.9g,\"separation\":%.9g}",
                        first?"":",",c.bodyA,name(c.bodyA),c.bodyB,name(c.bodyB),c.impulses.x,c.pointAndSeparation.w);
                    first=false;
                }
                std::fprintf(stderr, "]}\n");
            }
        }
        handle->pendingLifeWorld.clear();
        handle->result = std::move(published);
        handle->outcomeValues.clear();
        handle->outcomeValues.reserve(
            handle->result.transitions.size() *
            handle->outcomes.size()
        );
        for (const MRTaskTransitionGPU& native :
             handle->result.transitions) {
            const auto& transition =
                reinterpret_cast<const MRTaskTransitionC&>(native);
            for (const MRTaskOutcomeDescriptor& outcome :
                 handle->outcomes) {
                handle->outcomeValues.push_back(
                    taskOutcomeValue(transition, outcome.source)
                );
            }
        }
        handle->deviceName = diagnostics.deviceName;
        handle->submittedControlSteps += control_step_count;
        handle->completedEnvironmentSteps +=
            diagnostics.successfulStepCount;
        ++handle->submissionCount;
        handle->totalGPUMilliseconds +=
            diagnostics.gpuElapsedMilliseconds;
        handle->totalSubmissionMilliseconds +=
            diagnostics.submissionElapsedMilliseconds;
        if (!diagnostics.succeeded()) {
            throw std::runtime_error(
                std::string{"task-rollout GPU step failed ["} +
                metalrobo::metalWorldHostStatusName(
                    diagnostics.status
                ) + "]: " + diagnostics.message
            );
        }
    });
}

MRTaskRolloutLayoutC mr_task_rollout_layout(
    const MRTaskRolloutHandle* handle
) {
    MRTaskRolloutLayoutC result{};
    if (!requireTaskRolloutHandle(handle)) {
        return result;
    }
    const metalrobo::MetalWorldContextStats stats =
        handle->context.stats();
    result.environment_count = handle->environmentCount;
    result.nq = static_cast<std::uint32_t>(handle->world.nq());
    result.nv = static_cast<std::uint32_t>(handle->world.nv());
    result.action_count =
        handle->taskProgram.layout().actionCount;
    result.actor_observation_count =
        handle->taskProgram.layout().actorObservationSize;
    result.critic_observation_count =
        handle->taskProgram.layout().criticObservationSize;
    result.scene_body_count =
        static_cast<std::uint32_t>(
            handle->defaultSceneBodies.size()
        );
    result.body_count = static_cast<std::uint32_t>(
        handle->model.bodies.size()
    );
    result.motion_feature_count =
        handle->taskProgram.layout().motionFeatureCount;
    result.maximum_episode_steps =
        handle->taskProgram.header().schedule.x;
    result.world_fingerprint =
        handle->taskProgram.worldFingerprint();
    result.task_fingerprint =
        handle->taskProgram.fingerprint();
    result.observation_fingerprint =
        handle->taskProgram.observationFingerprint();
    result.action_fingerprint =
        handle->taskProgram.actionFingerprint();
    result.run_fingerprint = handle->run.fingerprint();
    result.robot_fingerprint = handle->run.robotFingerprint();
    result.sensor_fingerprint = handle->run.sensorFingerprint();
    result.reality_fingerprint = handle->run.realityFingerprint();
    result.teacher_fingerprint = handle->run.teacherFingerprint();
    result.submitted_control_steps =
        handle->submittedControlSteps;
    result.completed_environment_steps =
        handle->completedEnvironmentSteps;
    result.submission_count = handle->submissionCount;
    result.retained_buffer_bytes = stats.retainedBufferBytes;
    result.immutable_private_bytes =
        stats.memoryPlan.immutablePrivateBytes;
    result.persistent_state_private_bytes =
        stats.memoryPlan.persistentStatePrivateBytes;
    result.transient_private_bytes =
        stats.memoryPlan.transientPrivateBytes;
    result.shared_boundary_bytes =
        stats.memoryPlan.sharedBoundaryBytes;
    result.peak_aliased_bytes =
        stats.memoryPlan.peakAliasedBytes;
    result.total_gpu_milliseconds =
        handle->totalGPUMilliseconds;
    result.total_submission_milliseconds =
        handle->totalSubmissionMilliseconds;
    return result;
}

const char* mr_task_rollout_task_id(
    const MRTaskRolloutHandle* handle
) {
    if (!requireTaskRolloutHandle(handle)) {
        return nullptr;
    }
    gLastError.clear();
    return handle->taskId.c_str();
}

const char* mr_task_rollout_device_name(
    const MRTaskRolloutHandle* handle
) {
    return requireTaskRolloutHandle(handle)
        ? handle->deviceName.c_str()
        : "";
}

uint64_t mr_task_rollout_visual_scene_fingerprint(
    const MRTaskRolloutHandle* handle
) {
    if (!requireTaskRolloutHandle(handle)) {
        return 0u;
    }
    return handle->visualRuntime == nullptr
        ? 0u
        : handle->visualRuntime->sceneFingerprint;
}

int mr_task_rollout_acquire_inspection_frame(
    MRTaskRolloutHandle* handle,
    MRTaskInspectionFrameC* frame
) {
    if (!requireTaskRolloutHandle(handle) || frame == nullptr) {
        return -1;
    }
    if (handle->inspectionVisualRuntime == nullptr ||
        handle->inspectionVisualRuntime->inspector == nullptr) {
        gLastError = "task rollout has no presentation inspector.";
        return -1;
    }
    metalrobo::MetalRunInspectorFrame native;
    if (!handle->inspectionVisualRuntime->inspector->acquireLatestFrame(
            native
        )) {
        gLastError.clear();
        return 0;
    }
    frame->rgb_buffer = native.rgb;
    frame->slot_index = native.slotIndex;
    frame->width = native.width;
    frame->height = native.height;
    frame->frame_index = native.frameIndex;
    frame->submission_index = native.submissionIndex;
    frame->environment_index = native.environmentIndex;
    frame->dropped_frames = native.droppedFrames;
    gLastError.clear();
    return 1;
}

int mr_task_rollout_set_inspection_enabled(
    MRTaskRolloutHandle* handle,
    const uint32_t enabled
) {
    if (!requireTaskRolloutHandle(handle) || enabled > 1u ||
        handle->inspectionVisualRuntime == nullptr ||
        handle->inspectionVisualRuntime->inspector == nullptr) {
        return -1;
    }
    handle->inspectionVisualRuntime->inspector->setEnabled(enabled != 0u);
    gLastError.clear();
    return 0;
}

int mr_task_rollout_release_inspection_frame(
    MRTaskRolloutHandle* handle,
    const uint32_t slot_index
) {
    if (!requireTaskRolloutHandle(handle) ||
        handle->inspectionVisualRuntime == nullptr ||
        handle->inspectionVisualRuntime->inspector == nullptr) {
        return -1;
    }
    handle->inspectionVisualRuntime->inspector->releaseFrame(slot_index);
    gLastError.clear();
    return 0;
}

uint32_t mr_task_rollout_impact_event_count(
    const MRTaskRolloutHandle* handle
) {
    return requireTaskRolloutHandle(handle)
        ? static_cast<uint32_t>(
              handle->taskProgram.impactEvents().size()
          )
        : 0u;
}

const uint32_t* mr_task_rollout_status_codes(
    const MRTaskRolloutHandle* handle
) {
    return requireTaskRolloutHandle(handle) &&
        !handle->statusCodes.empty()
        ? handle->statusCodes.data()
        : nullptr;
}

const uint32_t* mr_task_rollout_active_contacts(
    const MRTaskRolloutHandle* handle
) {
    return requireTaskRolloutHandle(handle) &&
        !handle->activeContacts.empty()
        ? handle->activeContacts.data()
        : nullptr;
}

const float* mr_task_rollout_actor_observations(
    const MRTaskRolloutHandle* handle
) {
    return requireTaskRolloutHandle(handle) &&
        !handle->result.actorObservations.empty()
        ? handle->result.actorObservations.data()
        : nullptr;
}

const float* mr_task_rollout_critic_observations(
    const MRTaskRolloutHandle* handle
) {
    return requireTaskRolloutHandle(handle) &&
        !handle->result.criticObservations.empty()
        ? handle->result.criticObservations.data()
        : nullptr;
}

const float* mr_task_rollout_motion_features(
    const MRTaskRolloutHandle* handle
) {
    return requireTaskRolloutHandle(handle) &&
        !handle->result.motionFeatures.empty()
        ? handle->result.motionFeatures.data()
        : nullptr;
}

const float* mr_task_rollout_teacher_actions(
    const MRTaskRolloutHandle* handle
) {
    return requireTaskRolloutHandle(handle) &&
        ((handle->taskProgram.header().schedule.w &
          MR_TASK_PROGRAM_INTERACTION_REFERENCE) != 0u ||
         handle->stepConfig.birdFlowJourneyTeacher) &&
        !handle->result.teacherActions.empty()
        ? handle->result.teacherActions.data()
        : nullptr;
}

const float* mr_task_rollout_policy_actions(
    const MRTaskRolloutHandle* handle
) {
    return requireTaskRolloutHandle(handle) &&
        !handle->result.policyActions.empty()
        ? handle->result.policyActions.data()
        : nullptr;
}

const MRTaskTransitionC* mr_task_rollout_transitions(
    const MRTaskRolloutHandle* handle
) {
    return requireTaskRolloutHandle(handle) &&
        !handle->result.transitions.empty()
        ? reinterpret_cast<const MRTaskTransitionC*>(
              handle->result.transitions.data()
          )
        : nullptr;
}

uint32_t mr_task_rollout_outcome_count(
    const MRTaskRolloutHandle* handle
) {
    return requireTaskRolloutHandle(handle)
        ? static_cast<uint32_t>(handle->outcomes.size())
        : 0u;
}

const char* mr_task_rollout_outcome_id(
    const MRTaskRolloutHandle* handle,
    const uint32_t outcome_index
) {
    if (!requireTaskRolloutHandle(handle) ||
        outcome_index >= handle->outcomes.size()) {
        gLastError = "task outcome index is out of range.";
        return nullptr;
    }
    gLastError.clear();
    return handle->outcomes[outcome_index].id.c_str();
}

const char* mr_task_rollout_outcome_unit(
    const MRTaskRolloutHandle* handle,
    const uint32_t outcome_index
) {
    if (!requireTaskRolloutHandle(handle) ||
        outcome_index >= handle->outcomes.size()) {
        gLastError = "task outcome index is out of range.";
        return nullptr;
    }
    gLastError.clear();
    return handle->outcomes[outcome_index].unit.c_str();
}

uint32_t mr_task_rollout_outcome_direction(
    const MRTaskRolloutHandle* handle,
    const uint32_t outcome_index
) {
    if (!requireTaskRolloutHandle(handle) ||
        outcome_index >= handle->outcomes.size()) {
        gLastError = "task outcome index is out of range.";
        return MR_TASK_OUTCOME_NEUTRAL;
    }
    gLastError.clear();
    return handle->outcomes[outcome_index].direction;
}

const float* mr_task_rollout_outcome_values(
    const MRTaskRolloutHandle* handle
) {
    return requireTaskRolloutHandle(handle) &&
        !handle->outcomeValues.empty()
        ? handle->outcomeValues.data()
        : nullptr;
}

const float* mr_task_rollout_policy_latents(
    const MRTaskRolloutHandle* handle
) {
    return requireTaskRolloutHandle(handle) &&
        !handle->result.policyLatents.empty()
        ? handle->result.policyLatents.data()
        : nullptr;
}

const float* mr_task_rollout_policy_log_probabilities(
    const MRTaskRolloutHandle* handle
) {
    return requireTaskRolloutHandle(handle) &&
        !handle->result.policyLogProbabilities.empty()
        ? handle->result.policyLogProbabilities.data()
        : nullptr;
}

const float* mr_task_rollout_policy_values(
    const MRTaskRolloutHandle* handle
) {
    return requireTaskRolloutHandle(handle) &&
        !handle->result.policyValues.empty()
        ? handle->result.policyValues.data()
        : nullptr;
}

uint32_t mr_task_rollout_policy_memory_width(const MRTaskRolloutHandle* handle) {
    if (!requireTaskRolloutHandle(handle) || handle->result.policyMemoryResets.empty()) return 0;
    return static_cast<uint32_t>(handle->result.policyMemoryBefore.size()/handle->result.policyMemoryResets.size());
}
uint32_t mr_task_rollout_policy_memory_control_step_count(const MRTaskRolloutHandle* handle) {
    if (!requireTaskRolloutHandle(handle) || !handle->environmentCount || handle->result.policyMemoryResets.empty()) return 0;
    return static_cast<uint32_t>(handle->result.transitions.size()/handle->environmentCount);
}
const float* mr_task_rollout_policy_memory_before(const MRTaskRolloutHandle* handle) {
    return requireTaskRolloutHandle(handle) && !handle->result.policyMemoryBefore.empty()
        ? handle->result.policyMemoryBefore.data() : nullptr;
}
const uint32_t* mr_task_rollout_policy_memory_resets(const MRTaskRolloutHandle* handle) {
    return requireTaskRolloutHandle(handle) && !handle->result.policyMemoryResets.empty()
        ? handle->result.policyMemoryResets.data() : nullptr;
}

const float* mr_task_rollout_bootstrap_policy_values(
    const MRTaskRolloutHandle* handle
) {
    if (!requireTaskRolloutHandle(handle)) {
        return nullptr;
    }
    const std::size_t offset =
        handle->result.transitions.size();
    const std::size_t required =
        offset + handle->environmentCount;
    return handle->result.policyValues.size() >= required
        ? handle->result.policyValues.data() + offset
        : nullptr;
}

const float* mr_task_rollout_final_q(
    const MRTaskRolloutHandle* handle
) {
    return requireTaskRolloutHandle(handle) &&
        !handle->result.finalQ.empty()
        ? handle->result.finalQ.data()
        : nullptr;
}

const float* mr_task_rollout_final_v(
    const MRTaskRolloutHandle* handle
) {
    return requireTaskRolloutHandle(handle) &&
        !handle->result.finalV.empty()
        ? handle->result.finalV.data()
        : nullptr;
}

const char* mr_task_rollout_body_name(
    const MRTaskRolloutHandle* handle,
    const uint32_t body_index
) {
    if (!requireTaskRolloutHandle(handle) ||
        body_index >= handle->model.bodyNames.size()) {
        gLastError = "task-rollout body index is out of range";
        return nullptr;
    }
    return handle->model.bodyNames[body_index].c_str();
}

int mr_task_rollout_copy_final_body_states(
    const MRTaskRolloutHandle* handle,
    float* output,
    const size_t output_count
) {
    if (!requireTaskRolloutHandle(handle)) {
        return -1;
    }
    constexpr std::size_t stride = 13u;
    const std::size_t required =
        static_cast<std::size_t>(handle->environmentCount) *
        handle->model.bodies.size() * stride;
    if (required == 0u || output == nullptr ||
        output_count != required) {
        gLastError = "final composed body-state output has the wrong size";
        return -1;
    }
    std::vector<MRBodyStateGPU> states;
    std::string reason;
    if (!metalrobo::composeVisualBodyStates(
            handle->model,
            handle->environmentCount,
            handle->result.finalQ,
            handle->result.finalV,
            handle->result.finalSceneBodies,
            states,
            &reason
        )) {
        gLastError = "final composed body-state export failed: " + reason;
        return -1;
    }
    std::size_t cursor = 0u;
    for (const MRBodyStateGPU& state : states) {
        for (const float value : {
            state.position.x, state.position.y, state.position.z,
            state.orientation.x, state.orientation.y,
            state.orientation.z, state.orientation.w,
            state.linearVelocityAndInverseMass.x,
            state.linearVelocityAndInverseMass.y,
            state.linearVelocityAndInverseMass.z,
            state.angularVelocity.x, state.angularVelocity.y,
            state.angularVelocity.z,
        }) {
            output[cursor++] = value;
        }
    }
    gLastError.clear();
    return 0;
}

int mr_task_rollout_copy_final_scene_states(
    const MRTaskRolloutHandle* handle,
    float* output,
    const size_t output_count
) {
    if (!requireTaskRolloutHandle(handle)) {
        return -1;
    }
    constexpr std::size_t stride = 13u;
    const std::size_t required =
        handle->result.finalSceneBodies.size() * stride;
    if (required == 0u || output == nullptr ||
        output_count != required) {
        gLastError =
            "final scene-state output has the wrong size";
        return -1;
    }
    std::size_t cursor = 0u;
    for (const MRBodyStateGPU& state :
         handle->result.finalSceneBodies) {
        for (const float value : {
            state.position.x, state.position.y, state.position.z,
            state.orientation.x, state.orientation.y,
            state.orientation.z, state.orientation.w,
            state.linearVelocityAndInverseMass.x,
            state.linearVelocityAndInverseMass.y,
            state.linearVelocityAndInverseMass.z,
            state.angularVelocity.x, state.angularVelocity.y,
            state.angularVelocity.z,
        }) {
            output[cursor++] = value;
        }
    }
    return 0;
}

static int writePolicyRolloutBatchC(
    const MRTaskRolloutHandle* handle,
    const MRPolicyRolloutBatchC* batch,
    const MRPolicyMemoryBatchC* memory,
    const char* batch_id,
    const char* output_path
) {
    if (!requireTaskRolloutHandle(handle)) {
        return -1;
    }
    if (batch == nullptr ||
        batch_id == nullptr || batch_id[0] == '\0' ||
        output_path == nullptr || output_path[0] == '\0') {
        gLastError =
            "policy rollout batch, identity, and output path are required.";
        return -1;
    }
    return translateErrors([&] {
        if (!handle->stepConfig.policyProgram.valid()) {
            throw std::invalid_argument(
                "a compiled policy must be installed before publishing a rollout pack"
            );
        }
        const auto* actorMemory=handle->stepConfig.policyProgram.actorMemory();
        if (actorMemory && !memory)
            throw std::invalid_argument("Recurrent policy rollout publication requires explicit hidden/reset traces; legacy v7 batch is forbidden");
        if (memory && (!actorMemory || memory->abi_version!=1 || memory->struct_size!=sizeof(MRPolicyMemoryBatchC) ||
            memory->hidden_count!=actorMemory->cell.hidden || !memory->hidden_count ||
            (memory->before_count && !memory->before) || (memory->reset_count && !memory->resets)))
            throw std::invalid_argument("Recurrent rollout memory descriptor ABI, shape, pointers or policy mismatch");
        const auto floats = [](
            const float* values,
            const std::size_t count,
            const char* label
        ) {
            if (values == nullptr && count != 0u) {
                throw std::invalid_argument(
                    std::string{label} + " pointer is null"
                );
            }
            return std::span<const float>{values, count};
        };
        if (batch->transition_count != 0u &&
            batch->transitions == nullptr) {
            throw std::invalid_argument(
                "rollout transition pointer is null"
            );
        }
        std::vector<MRLearningTransitionGPU> transitions(
            batch->transition_count
        );
        std::vector<metalrobo::PolicyOutcomeDescriptor> outcomes;
        outcomes.reserve(handle->outcomes.size());
        for (const MRTaskOutcomeDescriptor& outcome : handle->outcomes) {
            outcomes.push_back({
                .id = outcome.id,
                .unit = outcome.unit,
                .direction = outcome.direction,
            });
        }
        std::vector<float> outcomeValues;
        outcomeValues.reserve(
            batch->transition_count * handle->outcomes.size()
        );
        for (std::size_t index = 0u;
             index < batch->transition_count;
             ++index) {
            const MRTaskTransitionC& source = batch->transitions[index];
            MRLearningTransitionGPU& destination = transitions[index];
            destination.rewardAndBootstrap = {
                source.reward,
                source.timeout_bootstrap_value,
                0.0f,
                0.0f,
            };
            destination.termination = {
                source.done,
                source.timeout,
                source.physics_error,
                source.termination_reason,
            };
            destination.context = {
                source.difficulty_band,
                source.terrain_level,
                source.impact_sequence_index,
                source.impact_event_flags,
            };
            destination.policyRevision = source.policy_revision;
            for (const MRTaskOutcomeDescriptor& outcome :
                 handle->outcomes) {
                outcomeValues.push_back(
                    taskOutcomeValue(source, outcome.source)
                );
            }
        }
        const metalrobo::PolicyRolloutPackView authored{
            .id = batch_id,
            .taskFingerprint =
                handle->taskProgram.fingerprint(),
            .policyFingerprint =
                handle->stepConfig.policyProgram.fingerprint(),
            .policyRevision =
                handle->stepConfig.policyProgram.revision(),
            .environmentCount =
                handle->environmentCount,
            .controlStepCount =
                batch->control_step_count,
            .actorObservationCount =
                handle->taskProgram.layout()
                    .actorObservationSize,
            .criticObservationCount =
                handle->taskProgram.layout()
                    .criticObservationSize,
            .actionCount =
                handle->taskProgram.layout().actionCount,
            .motionFeatureCount =
                handle->taskProgram.layout().motionFeatureCount,
            .actorObservations = floats(
                batch->actor_observations,
                batch->actor_observation_count,
                "rollout actor observations"
            ),
            .criticObservations = floats(
                batch->critic_observations,
                batch->critic_observation_count,
                "rollout critic observations"
            ),
            .motionFeatures = floats(
                batch->motion_features,
                batch->motion_feature_count,
                "rollout motion features"
            ),
            .teacherActions = floats(
                batch->teacher_actions,
                batch->teacher_action_count,
                "rollout teacher actions"
            ),
            .latents = floats(
                batch->latents,
                batch->latent_count,
                "rollout latents"
            ),
            .logProbabilities = floats(
                batch->log_probabilities,
                batch->log_probability_count,
                "rollout log probabilities"
            ),
            .values = floats(
                batch->values,
                batch->value_count,
                "rollout values"
            ),
            .bootstrapValues = floats(
                batch->bootstrap_values,
                batch->bootstrap_value_count,
                "rollout bootstrap values"
            ),
            .outcomes = outcomes,
            .outcomeValues = outcomeValues,
            .transitions = transitions,
            .memoryHiddenCount = memory ? memory->hidden_count : 0u,
            .memoryBefore = memory ? floats(memory->before,memory->before_count,"recurrent pre-cell state") : std::span<const float>{},
            .memoryResets = memory ? std::span<const std::uint32_t>{memory->resets,memory->reset_count} : std::span<const std::uint32_t>{},
        };
        const metalrobo::LearningPackResult written =
            metalrobo::writePolicyRolloutPack(
                authored,
                output_path
            );
        if (!written.succeeded()) {
            throw std::runtime_error(
                std::string{
                    "PolicyRolloutPack write failed ["
                } +
                metalrobo::learningPackStatusName(
                    written.status
                ) + "]: " + written.message
            );
        }
    });
}

int mr_task_rollout_write_policy_rollout_pack(const MRTaskRolloutHandle* handle,
    const MRPolicyRolloutBatchC* batch,const char* batch_id,const char* output_path) {
    return writePolicyRolloutBatchC(handle,batch,nullptr,batch_id,output_path);
}
int mr_task_rollout_write_recurrent_policy_rollout_pack(const MRTaskRolloutHandle* handle,
    const MRPolicyRolloutBatchC* batch,const MRPolicyMemoryBatchC* memory,const char* batch_id,const char* output_path) {
    if (!memory) {gLastError="Recurrent rollout memory descriptor is required";return -1;}
    return writePolicyRolloutBatchC(handle,batch,memory,batch_id,output_path);
}

MRWorldFamilyHandle* mr_create_franka_pick_place_world_family(
    const uint32_t capacity,
    const char* metallib_path
) {
    if (capacity == 0u) {
        gLastError = "world-family capacity must be greater than zero.";
        return nullptr;
    }

    MRWorldFamilyHandle* result = nullptr;
    const int status = translateErrors([&] {
        metalrobo::WorldTemplate worldTemplate;
        const metalrobo::WorldCompileResult twin =
            metalrobo::compileEpisodeTwin(
                metalrobo::makeFrankaPickPlaceEpisodeTwin(),
                metalrobo::makeFrankaPickPlaceEngineModel(),
                worldTemplate
            );
        if (!twin.succeeded()) {
            throw std::runtime_error(
                "Franka episode compilation failed: " + twin.message
            );
        }

        metalrobo::WorldFamily family;
        const metalrobo::WorldCompileResult compiled =
            metalrobo::compileWorldFamily(
                worldTemplate,
                metalrobo::makeFrankaPickPlaceWorldProgram(),
                family
            );
        if (!compiled.succeeded()) {
            throw std::runtime_error(
                "Franka world-family compilation failed: " +
                compiled.message
            );
        }

        metalrobo::MetalWorldFamilyConfig config;
        if (metallib_path != nullptr) {
            config.metallibPath = metallib_path;
        }
        auto handle = std::make_unique<MRWorldFamilyHandle>();
        handle->context = metalrobo::MetalWorldFamilyContext{
            std::move(config)
        };
        const metalrobo::MetalWorldFamilyDiagnostics diagnostics =
            handle->context.compile(family, capacity);
        if (!diagnostics.succeeded()) {
            throw worldFamilyError("world-family compile", diagnostics);
        }
        handle->family = std::move(family);
        handle->scenarioSchema =
            metalrobo::compileScenarioSchema(handle->family);
        handle->deviceName = diagnostics.deviceName;
        result = handle.release();
    });
    return status == 0 ? result : nullptr;
}

MRWorldFamilyHandle* mr_load_world_family_pack(
    const char* pack_path,
    const uint32_t capacity,
    const char* metallib_path
) {
    if (pack_path == nullptr || pack_path[0] == '\0') {
        gLastError = "world-pack path must be nonempty.";
        return nullptr;
    }
    if (capacity == 0u) {
        gLastError = "world-family capacity must be greater than zero.";
        return nullptr;
    }

    MRWorldFamilyHandle* result = nullptr;
    const int status = translateErrors([&] {
        metalrobo::MRWorldPack pack;
        const metalrobo::WorldPackResult loaded =
            metalrobo::readWorldPack(pack_path, pack);
        if (!loaded.succeeded()) {
            throw std::runtime_error(
                std::string{"world-pack load failed ["} +
                metalrobo::worldPackStatusName(loaded.status) +
                "]: " + loaded.message
            );
        }
        metalrobo::MetalWorldFamilyConfig config;
        if (metallib_path != nullptr) {
            config.metallibPath = metallib_path;
        }
        auto handle = std::make_unique<MRWorldFamilyHandle>();
        handle->context = metalrobo::MetalWorldFamilyContext{
            std::move(config)
        };
        const metalrobo::MetalWorldFamilyDiagnostics diagnostics =
            handle->context.compile(pack, capacity);
        if (!diagnostics.succeeded()) {
            throw worldFamilyError(
                "packed world-family compile",
                diagnostics
            );
        }
        handle->family = std::move(pack.family);
        handle->scenarioSchema =
            metalrobo::compileScenarioSchema(handle->family);
        handle->authoredPackHash = pack.contentHash;
        handle->deviceName = diagnostics.deviceName;
        result = handle.release();
    });
    return status == 0 ? result : nullptr;
}

void mr_world_family_retain(MRWorldFamilyHandle* handle) {
    if (handle != nullptr) {
        handle->references.fetch_add(1u, std::memory_order_relaxed);
    }
}

void mr_world_family_destroy(MRWorldFamilyHandle* handle) {
    if (handle != nullptr &&
        handle->references.fetch_sub(
            1u,
            std::memory_order_acq_rel
        ) == 1u) {
        delete handle;
    }
}

int mr_world_family_sample(
    MRWorldFamilyHandle* handle,
    const uint32_t instance_count,
    const uint64_t seed
) {
    if (!requireWorldFamilyHandle(handle)) {
        return -1;
    }
    return translateErrors([&] {
        const metalrobo::MetalWorldFamilyDiagnostics diagnostics =
            handle->context.sample(instance_count, seed);
        if (!diagnostics.succeeded()) {
            throw worldFamilyError("world-family sample", diagnostics);
        }
        handle->lastSampleMilliseconds =
            diagnostics.elapsedMilliseconds;
        handle->readback = {};
    });
}

int mr_world_family_sample_ex(
    MRWorldFamilyHandle* handle,
    const uint32_t instance_count,
    const uint64_t seed,
    const uint32_t sampling_mode,
    const uint64_t episode_counter
) {
    if (!requireWorldFamilyHandle(handle)) {
        return -1;
    }
    return translateErrors([&] {
        if (sampling_mode > MR_WORLD_SAMPLING_REPLAY) {
            throw std::invalid_argument(
                "world-family sampling mode is invalid"
            );
        }
        const auto diagnostics = handle->context.sample(
            instance_count,
            seed,
            static_cast<MRWorldSamplingMode>(sampling_mode),
            episode_counter
        );
        if (!diagnostics.succeeded()) {
            throw worldFamilyError(
                "adaptive world-family sample",
                diagnostics
            );
        }
        handle->lastSampleMilliseconds =
            diagnostics.elapsedMilliseconds;
        handle->readback = {};
    });
}

int mr_world_family_configure_sampling(
    MRWorldFamilyHandle* handle,
    const uint64_t alignment_fingerprint,
    const float* particle_quantiles,
    const float* particle_weights,
    const float* particle_residuals,
    const uint32_t particle_count,
    const uint64_t feedback_fingerprint,
    const uint32_t* region_kinds,
    const float* region_weights,
    const float* region_bounds,
    const uint32_t region_count,
    const float broad_weight,
    const float failure_weight,
    const float uncertainty_weight,
    const float alignment_jitter
) {
    if (!requireWorldFamilyHandle(handle)) {
        return -1;
    }
    return translateErrors([&] {
        const std::size_t featureCount =
            handle->scenarioSchema.features.size();
        if (!handle->scenarioSchema.valid() ||
            featureCount == 0u ||
            particle_count > metalrobo::kMaximumAlignmentParticles ||
            region_count > metalrobo::kMaximumFeedbackRegions ||
            (particle_count != 0u &&
             (alignment_fingerprint == 0u ||
              particle_quantiles == nullptr ||
              particle_weights == nullptr)) ||
            (region_count != 0u &&
             (feedback_fingerprint == 0u ||
              region_kinds == nullptr ||
              region_weights == nullptr ||
              region_bounds == nullptr))) {
            throw std::invalid_argument(
                "adaptive sampling arrays or fingerprints are invalid"
            );
        }
        metalrobo::CompiledWorldSamplingProgram program;
        program.schemaFingerprint =
            handle->scenarioSchema.fingerprint;
        program.alignmentFingerprint = alignment_fingerprint;
        program.feedbackFingerprint = feedback_fingerprint;
        program.broadWeight = broad_weight;
        program.failureWeight = failure_weight;
        program.uncertaintyWeight = uncertainty_weight;
        program.alignmentJitter = alignment_jitter;

        double particleTotal = 0.0;
        for (std::uint32_t particle = 0u;
             particle < particle_count;
             ++particle) {
            if (!std::isfinite(particle_weights[particle]) ||
                particle_weights[particle] < 0.0f) {
                throw std::invalid_argument(
                    "alignment particle weight is invalid"
                );
            }
            particleTotal += particle_weights[particle];
        }
        if (particle_count != 0u && !(particleTotal > 0.0)) {
            throw std::invalid_argument(
                "alignment particle weights have no mass"
            );
        }
        double particleCDF = 0.0;
        program.alignmentParticles.reserve(particle_count);
        program.alignmentQuantiles.reserve(
            static_cast<std::size_t>(particle_count) * featureCount
        );
        for (std::uint32_t particle = 0u;
             particle < particle_count;
             ++particle) {
            const double weight =
                particle_weights[particle] / particleTotal;
            particleCDF += weight;
            MRWorldAlignmentParticleGPU record{};
            record.statistics = {
                static_cast<float>(weight),
                static_cast<float>(
                    particle + 1u == particle_count
                    ? 1.0
                    : particleCDF
                ),
                particle_residuals == nullptr
                    ? 0.0f
                    : particle_residuals[particle],
                0.0f,
            };
            record.identity = {particle, 0u, 0u, 0u};
            program.alignmentParticles.push_back(record);
            for (std::size_t feature = 0u;
                 feature < featureCount;
                 ++feature) {
                program.alignmentQuantiles.push_back(
                    particle_quantiles[
                        static_cast<std::size_t>(particle) *
                            featureCount +
                        feature
                    ]
                );
            }
        }

        std::array<double, 2> regionTotals{};
        for (std::uint32_t region = 0u;
             region < region_count;
             ++region) {
            if (region_kinds[region] >
                    MR_FEEDBACK_REGION_UNCERTAINTY ||
                !std::isfinite(region_weights[region]) ||
                region_weights[region] < 0.0f) {
                throw std::invalid_argument(
                    "feedback region kind or weight is invalid"
                );
            }
            regionTotals[region_kinds[region]] +=
                region_weights[region];
        }
        std::array<double, 2> regionCDF{};
        program.feedbackRegions.reserve(region_count);
        program.feedbackBounds.reserve(
            static_cast<std::size_t>(region_count) * featureCount
        );
        for (std::uint32_t region = 0u;
             region < region_count;
             ++region) {
            const std::uint32_t kind = region_kinds[region];
            const double total = regionTotals[kind];
            const double weight =
                total > 0.0 ? region_weights[region] / total : 0.0;
            regionCDF[kind] += weight;
            MRWorldFeedbackRegionGPU record{};
            record.statistics = {
                static_cast<float>(weight),
                static_cast<float>(
                    std::abs(regionCDF[kind] - 1.0) < 1.0e-12
                    ? 1.0
                    : regionCDF[kind]
                ),
                0.0f,
                0.0f,
            };
            record.identity = {kind, region, 0u, 0u};
            program.feedbackRegions.push_back(record);
            for (std::size_t feature = 0u;
                 feature < featureCount;
                 ++feature) {
                const std::size_t offset =
                    (
                        static_cast<std::size_t>(region) *
                            featureCount +
                        feature
                    ) * 2u;
                program.feedbackBounds.push_back({
                    region_bounds[offset],
                    region_bounds[offset + 1u],
                    0.0f,
                    0.0f,
                });
            }
        }
        std::string reason;
        if (!program.valid(handle->scenarioSchema, &reason)) {
            throw std::invalid_argument(reason);
        }
        const auto diagnostics =
            handle->context.configureSamplingProgram(
                handle->scenarioSchema,
                program
            );
        if (!diagnostics.succeeded()) {
            throw worldFamilyError(
                "world-family sampling configuration",
                diagnostics
            );
        }
    });
}

uint64_t mr_world_family_scenario_fingerprint(
    const MRWorldFamilyHandle* handle
) {
    return requireWorldFamilyHandle(handle)
        ? handle->scenarioSchema.fingerprint
        : 0u;
}

uint64_t mr_world_family_authored_pack_hash(
    const MRWorldFamilyHandle* handle
) {
    return requireWorldFamilyHandle(handle)
        ? handle->authoredPackHash
        : 0u;
}

const char* mr_world_family_scenario_id(
    const MRWorldFamilyHandle* handle
) {
    return requireWorldFamilyHandle(handle)
        ? handle->scenarioSchema.id.c_str()
        : "";
}

const char* mr_world_family_scenario_feature_id(
    const MRWorldFamilyHandle* handle,
    const uint32_t feature
) {
    if (!requireWorldFamilyHandle(handle) ||
        feature >= handle->scenarioSchema.features.size()) {
        gLastError = "scenario feature index is invalid.";
        return "";
    }
    return handle->scenarioSchema.features[feature].id.c_str();
}

const char* mr_world_family_scenario_target_id(
    const MRWorldFamilyHandle* handle,
    const uint32_t feature
) {
    if (!requireWorldFamilyHandle(handle) ||
        feature >= handle->scenarioSchema.features.size()) {
        gLastError = "scenario feature index is invalid.";
        return "";
    }
    return handle->scenarioSchema.features[feature].targetId.c_str();
}

MRScenarioFeatureC mr_world_family_scenario_feature(
    const MRWorldFamilyHandle* handle,
    const uint32_t feature
) {
    MRScenarioFeatureC result{};
    if (!requireWorldFamilyHandle(handle) ||
        feature >= handle->scenarioSchema.features.size()) {
        gLastError = "scenario feature index is invalid.";
        return result;
    }
    const auto& source = handle->scenarioSchema.features[feature];
    result.axis = source.axis;
    result.distribution = source.distribution;
    result.target = source.target;
    result.ordinal = source.ordinal;
    result.parameters[0] = source.parameters.x;
    result.parameters[1] = source.parameters.y;
    result.parameters[2] = source.parameters.z;
    result.parameters[3] = source.parameters.w;
    return result;
}

int mr_world_family_readback(MRWorldFamilyHandle* handle) {
    if (!requireWorldFamilyHandle(handle)) {
        return -1;
    }
    return translateErrors([&] {
        metalrobo::WorldInstanceBatch staged;
        const metalrobo::MetalWorldFamilyDiagnostics diagnostics =
            handle->context.readback(staged);
        if (!diagnostics.succeeded()) {
            throw worldFamilyError("world-family readback", diagnostics);
        }
        handle->readback = std::move(staged);
    });
}

MRWorldFamilyLayoutC mr_world_family_layout(
    const MRWorldFamilyHandle* handle
) {
    MRWorldFamilyLayoutC result{};
    if (!requireWorldFamilyHandle(handle)) {
        return result;
    }
    const metalrobo::MetalWorldFamilyLayout layout =
        handle->context.layout();
    result.capacity = layout.capacity;
    result.active_instance_count = layout.activeInstanceCount;
    result.asset_count_per_instance =
        layout.assetCountPerInstance;
    result.sensor_count_per_instance =
        layout.sensorCountPerInstance;
    result.appearance_count_per_instance =
        layout.appearanceCountPerInstance;
    result.variation_count = layout.variationCount;
    result.categorical_value_count =
        layout.categoricalValueCount;
    result.asset_binding_count = layout.assetBindingCount;
    result.binding_index_count = layout.bindingIndexCount;
    result.primary_articulation_index =
        layout.primaryArticulationIndex;
    result.nq = layout.nq;
    result.nv = layout.nv;
    result.body_count = layout.bodyCount;
    result.scene_body_count = layout.sceneBodyCount;
    result.articulation_count = layout.articulationCount;
    result.retained_private_bytes = layout.totalPrivateBytes();
    return result;
}

MRWorldFamilyStatsC mr_world_family_stats(
    const MRWorldFamilyHandle* handle
) {
    MRWorldFamilyStatsC result{};
    if (!requireWorldFamilyHandle(handle)) {
        return result;
    }
    const metalrobo::MetalWorldFamilyStats stats =
        handle->context.stats();
    result.compile_count = stats.compileCount;
    result.sample_count = stats.sampleCount;
    result.readback_count = stats.readbackCount;
    result.last_sample_milliseconds =
        handle->lastSampleMilliseconds;
    return result;
}

const char* mr_world_family_device_name(
    const MRWorldFamilyHandle* handle
) {
    if (!requireWorldFamilyHandle(handle)) {
        return "";
    }
    return handle->deviceName.c_str();
}

void* mr_world_family_native_buffer(
    const MRWorldFamilyHandle* handle,
    const uint32_t buffer_kind
) {
    if (!requireWorldFamilyHandle(handle) || buffer_kind > 12u) {
        if (buffer_kind > 12u) {
            gLastError = "world-family buffer kind is invalid.";
        }
        return nullptr;
    }
    return handle->context.nativeBuffer(
        static_cast<metalrobo::MetalWorldFamilyBuffer>(buffer_kind)
    );
}

const MRWorldInstanceHeaderGPU* mr_world_family_instance_headers(
    const MRWorldFamilyHandle* handle
) {
    if (!requireWorldFamilyHandle(handle) ||
        handle->readback.instances.empty()) {
        return nullptr;
    }
    return handle->readback.instances.data();
}

const MRWorldAssetInstanceGPU* mr_world_family_asset_instances(
    const MRWorldFamilyHandle* handle
) {
    if (!requireWorldFamilyHandle(handle) ||
        handle->readback.assets.empty()) {
        return nullptr;
    }
    return handle->readback.assets.data();
}

const MRWorldSensorInstanceGPU* mr_world_family_sensor_instances(
    const MRWorldFamilyHandle* handle
) {
    if (!requireWorldFamilyHandle(handle) ||
        handle->readback.sensors.empty()) {
        return nullptr;
    }
    return handle->readback.sensors.data();
}

const MRWorldAppearanceInstanceGPU*
mr_world_family_appearance_instances(
    const MRWorldFamilyHandle* handle
) {
    if (!requireWorldFamilyHandle(handle) ||
        handle->readback.appearances.empty()) {
        return nullptr;
    }
    return handle->readback.appearances.data();
}

const MRWorldScenarioHeaderGPU* mr_world_family_scenario_headers(
    const MRWorldFamilyHandle* handle
) {
    if (!requireWorldFamilyHandle(handle) ||
        handle->readback.scenarioHeaders.empty()) {
        return nullptr;
    }
    return handle->readback.scenarioHeaders.data();
}

const MRWorldScenarioValueGPU* mr_world_family_scenario_values(
    const MRWorldFamilyHandle* handle
) {
    if (!requireWorldFamilyHandle(handle) ||
        handle->readback.scenarioValues.empty()) {
        return nullptr;
    }
    return handle->readback.scenarioValues.data();
}

MRHybridRendererHandle* mr_hybrid_renderer_create_v3(
    const MRHybridGaussianC* gaussians,
    const size_t gaussian_count,
    const char* visual_pack_path,
    const char* environment_pack_path,
    const uint32_t asset_count,
    const uint32_t body_count,
    const uint32_t visual_asset_index,
    const uint32_t semantic_id,
    const uint32_t instance_id,
    const char* light_rig,
    const char* renderer_profile,
    const uint32_t capacity,
    const uint32_t width,
    const uint32_t height,
    const uint32_t retain_observation_buffers,
    const char* metallib_path
) {
    const bool hasGaussians = gaussian_count != 0u;
    const bool hasPack =
        visual_pack_path != nullptr &&
        visual_pack_path[0] != '\0';
    const bool hasEnvironmentPack =
        environment_pack_path != nullptr &&
        environment_pack_path[0] != '\0';
    if ((!hasGaussians && !hasPack) ||
        (hasGaussians && gaussians == nullptr) ||
        gaussian_count >
            std::numeric_limits<std::uint32_t>::max() ||
        asset_count == 0u ||
        visual_asset_index >= asset_count ||
        semantic_id == 0u ||
        semantic_id == MR_INVALID_INDEX ||
        instance_id == 0u ||
        instance_id == MR_INVALID_INDEX ||
        capacity == 0u || width == 0u || height == 0u ||
        retain_observation_buffers > 1u) {
        gLastError =
            "V3 visual scene, bindings, dimensions, and capacity "
            "must be valid and nonempty.";
        return nullptr;
    }
    MRHybridRendererHandle* result = nullptr;
    const int status = translateErrors([&] {
        std::vector<MRHybridGaussianGPU> copiedGaussians(
            gaussian_count
        );
        for (std::size_t index = 0u;
             index < gaussian_count;
             ++index) {
            const MRHybridGaussianC& source = gaussians[index];
            MRHybridGaussianGPU& destination =
                copiedGaussians[index];
            std::memcpy(
                &destination.meanAndOpacity,
                source.mean_and_opacity,
                sizeof(source.mean_and_opacity)
            );
            std::memcpy(
                &destination.scaleAndImportance,
                source.scale_and_importance,
                sizeof(source.scale_and_importance)
            );
            std::memcpy(
                &destination.orientation,
                source.orientation,
                sizeof(source.orientation)
            );
            std::memcpy(
                &destination.colorAndEmission,
                source.color_and_emission,
                sizeof(source.color_and_emission)
            );
            std::memcpy(
                &destination.binding,
                source.binding,
                sizeof(source.binding)
            );
        }
        metalrobo::VisualRenderSceneV3 scene;
        scene.id = "c_api_visual_scene_v3";
        scene.assetCount = asset_count;
        scene.bodyCount = body_count;
        scene.gaussians = std::move(copiedGaussians);
        scene.environment =
            metalrobo::makeNeutralStudioEnvironmentV2();
        scene.lightRig =
            metalrobo::makeStudioKeyLightRigV1();
        if (hasPack) {
            metalrobo::VisualAssetPackV2 pack;
            std::string reason;
            if (!metalrobo::readVisualAssetPackIndex(
                    visual_pack_path,
                    pack,
                    &reason
                )) {
                throw std::runtime_error(
                    "could not load V3 visual pack: " + reason
                );
            }
            scene.visualPacks.push_back({
                visual_pack_path,
                pack.contentHash,
                visual_asset_index,
                semantic_id,
                instance_id,
            });
        }
        if (hasEnvironmentPack) {
            metalrobo::VisualEnvironmentPackV2 environmentPack;
            std::string reason;
            if (!metalrobo::readVisualEnvironmentPackIndex(
                    environment_pack_path,
                    environmentPack,
                    &reason
                )) {
                throw std::runtime_error(
                    "could not load V3 environment pack: " + reason
                );
            }
            scene.environment.id = environmentPack.id;
            scene.environment.packPath = environment_pack_path;
            scene.environment.contentHash =
                environmentPack.contentHash;
        }

        const std::string selectedLightRig =
            light_rig == nullptr || light_rig[0] == '\0'
            ? "studio_key"
            : light_rig;
        if (selectedLightRig == "indoor_area") {
            scene.lightRig =
                metalrobo::makeIndoorAreaLightRigV1();
        } else if (selectedLightRig != "studio_key") {
            throw std::runtime_error(
                "unsupported V3 light rig: " + selectedLightRig
            );
        }

        const std::string selectedProfile =
            renderer_profile == nullptr ||
                renderer_profile[0] == '\0'
            ? "sensor_fast"
            : renderer_profile;
        metalrobo::VisualRendererProfileV1 profile;
        if (selectedProfile == "sensor_fast") {
            profile =
                metalrobo::VisualRendererProfileV1::sensorFast();
        } else if (selectedProfile == "sensor_reference") {
            profile =
                metalrobo::VisualRendererProfileV1::
                    sensorReference();
        } else {
            throw std::runtime_error(
                "unsupported V3 renderer profile: " +
                selectedProfile
            );
        }
        if (profile.rayQueryVisibility && body_count == 0u) {
            throw std::runtime_error(
                "sensor_reference requires a nonzero body_count"
            );
        }
        scene.fingerprint =
            metalrobo::computeVisualRenderSceneV3Fingerprint(scene);

        metalrobo::MetalHybridRendererConfig config;
        config.width = width;
        config.height = height;
        config.retainObservationBuffers =
            retain_observation_buffers != 0u;
        if (metallib_path != nullptr) {
            config.metallibPath = metallib_path;
        }
        auto handle = std::make_unique<MRHybridRendererHandle>();
        handle->renderer = metalrobo::MetalHybridRenderer{
            std::move(config)
        };
        const metalrobo::MetalHybridRendererDiagnostics diagnostics =
            handle->renderer.compile(
                std::move(scene),
                profile,
                capacity
            );
        if (!diagnostics.succeeded()) {
            throw std::runtime_error(
                std::string{"V2 visual renderer compile failed ["} +
                metalrobo::metalHybridRendererStatusName(
                    diagnostics.status
                ) + "]: " + diagnostics.message
            );
        }
        handle->deviceName = diagnostics.deviceName;
        result = handle.release();
    });
    return status == 0 ? result : nullptr;
}

void mr_hybrid_renderer_retain(MRHybridRendererHandle* handle) {
    if (handle != nullptr) {
        handle->references.fetch_add(1u, std::memory_order_relaxed);
    }
}

void mr_hybrid_renderer_destroy(MRHybridRendererHandle* handle) {
    if (handle != nullptr &&
        handle->references.fetch_sub(
            1u,
            std::memory_order_acq_rel
        ) == 1u) {
        delete handle;
    }
}

int mr_hybrid_renderer_render(
    MRHybridRendererHandle* handle,
    const MRWorldFamilyHandle* worlds,
    const uint32_t environment_count,
    const uint32_t camera_index
) {
    if (!requireHybridRendererHandle(handle) ||
        !requireWorldFamilyHandle(worlds)) {
        return -1;
    }
    return translateErrors([&] {
        const metalrobo::MetalHybridRendererDiagnostics diagnostics =
            handle->renderer.render(
                worlds->context,
                environment_count,
                camera_index
            );
        if (!diagnostics.succeeded()) {
            throw std::runtime_error(
                std::string{"hybrid render failed ["} +
                metalrobo::metalHybridRendererStatusName(
                    diagnostics.status
                ) + "]: " + diagnostics.message
            );
        }
        handle->activeEnvironmentCount = environment_count;
        handle->lastRenderMilliseconds =
            diagnostics.elapsedMilliseconds;
    });
}

int mr_hybrid_renderer_encode_graph(
    MRHybridRendererHandle* handle,
    const MRWorldFamilyHandle* worlds,
    const void* current_body_states,
    const void* previous_body_states,
    const size_t current_body_offset,
    const size_t previous_body_offset,
    const uint32_t environment_count,
    const uint32_t body_count,
    const uint64_t frame_index,
    const uint32_t sensor_sequence,
    const uint32_t camera_index,
    const MRMetalComputeEncoderCallbacksC* encoder,
    const MRHybridObservationBuffersC* outputs
) {
    if (!requireHybridRendererHandle(handle) ||
        !requireWorldFamilyHandle(worlds) ||
        current_body_states == nullptr ||
        encoder == nullptr ||
        outputs == nullptr) {
        return -1;
    }
    return translateErrors([&] {
        metalrobo::HybridDeviceStateBatch live;
        live.currentBodyStates =
            const_cast<void*>(current_body_states);
        live.previousBodyStates =
            const_cast<void*>(previous_body_states);
        live.currentBodyOffset = current_body_offset;
        live.previousBodyOffset = previous_body_offset;
        live.environmentCount = environment_count;
        live.bodyCount = body_count;
        live.frameIndex = frame_index;
        live.sensorSequence = sensor_sequence;
        live.source = MR_VISUAL_SOURCE_SIMULATION;

        metalrobo::MetalHybridComputeEncoderCallbacks callbacks;
        callbacks.context = encoder->context;
        callbacks.setLabel = encoder->set_label;
        callbacks.useHeap = encoder->use_heap;
        callbacks.useResidencySet =
            encoder->use_residency_set;
        callbacks.setPipeline = encoder->set_pipeline;
        callbacks.setBuffer = encoder->set_buffer;
        callbacks.setBytes = encoder->set_bytes;
        callbacks.dispatchThreads = encoder->dispatch_threads;
        callbacks.dispatchThreadgroups =
            encoder->dispatch_threadgroups;
        callbacks.dispatchThreadgroupsIndirect =
            encoder->dispatch_threadgroups_indirect;

        metalrobo::HybridDeviceObservationBuffers destination;
        destination.rgb = outputs->rgb;
        destination.depth = outputs->depth;
        destination.segmentation = outputs->segmentation;
        destination.identities = outputs->identities;
        destination.normals = outputs->normals;
        destination.motion = outputs->motion;
        destination.validity = outputs->validity;
        destination.outputMask = outputs->output_mask;

        const metalrobo::MetalHybridRendererDiagnostics diagnostics =
            handle->renderer.encodeGraph(
                worlds->context,
                live,
                camera_index,
                callbacks,
                destination
            );
        if (!diagnostics.succeeded()) {
            throw std::runtime_error(
                std::string{"hybrid graph encode failed ["} +
                metalrobo::metalHybridRendererStatusName(
                    diagnostics.status
                ) + "]: " + diagnostics.message
            );
        }
        handle->activeEnvironmentCount = environment_count;
    });
}

int mr_hybrid_renderer_readback(
    MRHybridRendererHandle* handle
) {
    if (!requireHybridRendererHandle(handle)) {
        return -1;
    }
    return translateErrors([&] {
        metalrobo::HybridObservationBatch candidate;
        const metalrobo::MetalHybridRendererDiagnostics diagnostics =
            handle->renderer.readback(candidate);
        if (!diagnostics.succeeded()) {
            throw std::runtime_error(
                std::string{"hybrid readback failed ["} +
                metalrobo::metalHybridRendererStatusName(
                    diagnostics.status
                ) + "]: " + diagnostics.message
            );
        }
        handle->readback = std::move(candidate);
    });
}

MRHybridRendererLayoutC mr_hybrid_renderer_layout(
    const MRHybridRendererHandle* handle
) {
    MRHybridRendererLayoutC result{};
    if (!requireHybridRendererHandle(handle)) {
        return result;
    }
    const metalrobo::MetalHybridRendererLayout layout =
        handle->renderer.layout();
    result.capacity = layout.capacity;
    result.active_environment_count =
        handle->activeEnvironmentCount;
    result.width = layout.width;
    result.height = layout.height;
    result.tile_count_x = layout.tileCountX;
    result.tile_count_y = layout.tileCountY;
    result.gaussian_count = layout.gaussianCount;
    result.maximum_gaussians_per_tile =
        layout.maximumGaussiansPerTile;
    result.maximum_mesh_triangles_per_tile =
        layout.maximumMeshTrianglesPerTile;
    result.mesh_vertex_count = layout.meshVertexCount;
    result.mesh_triangle_count = layout.meshTriangleCount;
    result.mesh_cluster_count = layout.meshClusterCount;
    result.mesh_primitive_count = layout.meshPrimitiveCount;
    result.mesh_instance_count = layout.meshInstanceCount;
    result.mesh_index_count = layout.meshIndexCount;
    result.material_count = layout.materialCount;
    result.texture_count = layout.textureCount;
    result.light_count = layout.lightCount;
    result.body_count = layout.bodyCount;
    result.sensor_binding_count = layout.sensorBindingCount;
    result.shadow_layer_capacity = layout.shadowLayerCapacity;
    result.ray_instance_count = layout.rayInstanceCount;
    result.shadow_workspace_bytes = layout.shadowWorkspaceBytes;
    result.acceleration_structure_bytes =
        layout.accelerationStructureBytes;
    result.retained_private_bytes = layout.retainedPrivateBytes;
    result.last_render_milliseconds =
        handle->lastRenderMilliseconds;
    return result;
}

const char* mr_hybrid_renderer_device_name(
    const MRHybridRendererHandle* handle
) {
    if (!requireHybridRendererHandle(handle)) {
        return "";
    }
    return handle->deviceName.c_str();
}

void* mr_hybrid_renderer_native_buffer(
    const MRHybridRendererHandle* handle,
    const uint32_t buffer_kind
) {
    if (!requireHybridRendererHandle(handle) ||
        buffer_kind >
            static_cast<std::uint32_t>(
                metalrobo::MetalHybridRendererBuffer::
                    validity
            )) {
        if (handle != nullptr) {
            gLastError =
                "hybrid renderer buffer kind is invalid.";
        }
        return nullptr;
    }
    return handle->renderer.nativeBuffer(
        static_cast<metalrobo::MetalHybridRendererBuffer>(
            buffer_kind
        )
    );
}

const float* mr_hybrid_renderer_rgb(
    const MRHybridRendererHandle* handle
) {
    if (!requireHybridRendererHandle(handle) ||
        handle->readback.rgb.empty()) {
        return nullptr;
    }
    return reinterpret_cast<const float*>(
        handle->readback.rgb.data()
    );
}

const float* mr_hybrid_renderer_depth(
    const MRHybridRendererHandle* handle
) {
    if (!requireHybridRendererHandle(handle) ||
        handle->readback.depth.empty()) {
        return nullptr;
    }
    return handle->readback.depth.data();
}

const uint32_t* mr_hybrid_renderer_segmentation(
    const MRHybridRendererHandle* handle
) {
    if (!requireHybridRendererHandle(handle) ||
        handle->readback.segmentation.empty()) {
        return nullptr;
    }
    return handle->readback.segmentation.data();
}

const uint32_t* mr_hybrid_renderer_identities(
    const MRHybridRendererHandle* handle
) {
    if (!requireHybridRendererHandle(handle) ||
        handle->readback.identities.empty()) {
        return nullptr;
    }
    return reinterpret_cast<const uint32_t*>(
        handle->readback.identities.data()
    );
}

const float* mr_hybrid_renderer_normals(
    const MRHybridRendererHandle* handle
) {
    if (!requireHybridRendererHandle(handle) ||
        handle->readback.normals.empty()) {
        return nullptr;
    }
    return reinterpret_cast<const float*>(
        handle->readback.normals.data()
    );
}

const float* mr_hybrid_renderer_motion(
    const MRHybridRendererHandle* handle
) {
    if (!requireHybridRendererHandle(handle) ||
        handle->readback.motion.empty()) {
        return nullptr;
    }
    return reinterpret_cast<const float*>(
        handle->readback.motion.data()
    );
}

const uint32_t* mr_hybrid_renderer_validity(
    const MRHybridRendererHandle* handle
) {
    if (!requireHybridRendererHandle(handle) ||
        handle->readback.validity.empty()) {
        return nullptr;
    }
    return handle->readback.validity.data();
}

MRVisualFrameMetadataC mr_hybrid_renderer_frame_metadata(
    const MRHybridRendererHandle* handle
) {
    MRVisualFrameMetadataC result{};
    if (!requireHybridRendererHandle(handle)) {
        return result;
    }
    std::memcpy(
        &result,
        &handle->readback.metadata,
        sizeof(result)
    );
    return result;
}

MRTactileHandle* mr_tactile_create_world_pack(
    const char* world_pack_path,
    const uint32_t capacity,
    const uint32_t contact_capacity_per_environment,
    const char* metallib_path
) {
    if (world_pack_path == nullptr ||
        world_pack_path[0] == '\0' ||
        capacity == 0u ||
        contact_capacity_per_environment == 0u) {
        gLastError =
            "authored tactile world path and capacities are required.";
        return nullptr;
    }
    MRTactileHandle* result = nullptr;
    const int status = translateErrors([&] {
        metalrobo::MRWorldPack pack;
        const auto loaded = metalrobo::readWorldPack(
            world_pack_path,
            pack
        );
        if (!loaded.succeeded()) {
            throw std::runtime_error(
                std::string{"authored tactile world load failed ["} +
                metalrobo::worldPackStatusName(loaded.status) +
                "]: " + loaded.message
            );
        }
        const metalrobo::WorldTemplate& world =
            pack.family.worldTemplate;
        std::string reason;
        if (!world.valid(&reason)) {
            throw std::runtime_error(
                "authored tactile world is incomplete: " + reason
            );
        }
        if (world.tactileSystem.sensors.empty()) {
            throw std::runtime_error(
                "authored world pack contains no tactile sensors"
            );
        }
        metalrobo::MetalTactileConfig config;
        config.contactCapacityPerEnvironment =
            contact_capacity_per_environment;
        if (metallib_path != nullptr) {
            config.metallibPath = metallib_path;
        }
        auto handle = std::make_unique<MRTactileHandle>();
        handle->context = metalrobo::MetalTactileContext{
            std::move(config)
        };
        const auto diagnostics = handle->context.compile(
            world.tactileSystem,
            world.engineModel,
            capacity
        );
        if (!diagnostics.succeeded()) {
            throw std::runtime_error(
                std::string{"authored tactile Metal compile failed ["} +
                metalrobo::metalTactileStatusName(
                    diagnostics.status
                ) + "]: " + diagnostics.message
            );
        }
        handle->deviceName = diagnostics.deviceName;
        handle->observationMetadataJSON =
            metalrobo::tactileObservationMetadataJSON(
                world.tactileSystem
            );
        result = handle.release();
    });
    return status == 0 ? result : nullptr;
}

void mr_tactile_destroy(MRTactileHandle* handle) {
    delete handle;
}

int mr_tactile_encode(
    MRTactileHandle* handle,
    void* body_states,
    void* contacts,
    void* contact_counts,
    void* reset_mask,
    const uint32_t environment_count,
    const uint32_t body_count,
    const uint32_t contact_capacity_per_environment,
    const float observation_timestep_seconds,
    const float contact_impulse_timestep_seconds,
    const uint64_t frame_index,
    const double timestamp_seconds,
    void* metal_compute_command_encoder
) {
    if (!requireTactileHandle(handle)) {
        return -1;
    }
    return translateErrors([&] {
        metalrobo::MetalTactileDeviceFrame frame;
        frame.bodyStates = body_states;
        frame.contacts = contacts;
        frame.contactCounts = contact_counts;
        frame.resetMask = reset_mask;
        frame.environmentCount = environment_count;
        frame.bodyCount = body_count;
        frame.contactCapacityPerEnvironment =
            contact_capacity_per_environment;
        frame.observationTimestepSeconds =
            observation_timestep_seconds;
        frame.contactImpulseTimestepSeconds =
            contact_impulse_timestep_seconds;
        frame.frameIndex = frame_index;
        frame.timestampSeconds = timestamp_seconds;
        const auto diagnostics = handle->context.encode(
            frame,
            metal_compute_command_encoder
        );
        if (!diagnostics.succeeded()) {
            throw std::runtime_error(
                std::string{"tactile encode failed ["} +
                metalrobo::metalTactileStatusName(
                    diagnostics.status
                ) + "]: " + diagnostics.message
            );
        }
        handle->activeEnvironmentCount = environment_count;
        handle->lastObserveMilliseconds =
            diagnostics.elapsedMilliseconds;
    });
}

int mr_tactile_readback(MRTactileHandle* handle) {
    if (!requireTactileHandle(handle)) {
        return -1;
    }
    return translateErrors([&] {
        metalrobo::TactileObservationBatch candidate;
        const auto diagnostics = handle->context.readback(
            handle->activeEnvironmentCount,
            candidate
        );
        if (!diagnostics.succeeded()) {
            throw std::runtime_error(
                std::string{"tactile readback failed ["} +
                metalrobo::metalTactileStatusName(
                    diagnostics.status
                ) + "]: " + diagnostics.message
            );
        }
        handle->readback = std::move(candidate);
    });
}

MRTactileLayoutC mr_tactile_layout(
    const MRTactileHandle* handle
) {
    MRTactileLayoutC result{};
    if (!requireTactileHandle(handle)) {
        return result;
    }
    const metalrobo::MetalTactileLayout layout =
        handle->context.layout();
    result.capacity = layout.environmentCapacity;
    result.active_environment_count =
        handle->activeEnvironmentCount;
    result.body_count = layout.bodyCount;
    result.shape_count = layout.shapeCount;
    result.sensor_count = layout.sensorCount;
    result.sample_count = layout.sampleCount;
    result.target_count = layout.targetCount;
    result.contact_capacity_per_environment =
        layout.contactCapacityPerEnvironment;
    result.query_backend =
        static_cast<uint32_t>(layout.queryBackend);
    result.hardware_ray_queries_available =
        layout.hardwareRayQueriesAvailable ? 1u : 0u;
    result.retained_bytes = layout.retainedBytes;
    result.bytes_per_environment = layout.bytesPerEnvironment;
    result.last_observe_milliseconds =
        handle->lastObserveMilliseconds;
    return result;
}

const char* mr_tactile_device_name(
    const MRTactileHandle* handle
) {
    return requireTactileHandle(handle)
        ? handle->deviceName.c_str()
        : "";
}

const char* mr_tactile_observation_metadata_json(
    const MRTactileHandle* handle
) {
    return requireTactileHandle(handle)
        ? handle->observationMetadataJSON.c_str()
        : "";
}

void* mr_tactile_native_buffer(
    const MRTactileHandle* handle,
    const uint32_t buffer_kind
) {
    if (!requireTactileHandle(handle) ||
        buffer_kind >
            static_cast<uint32_t>(
                metalrobo::MetalTactileBuffer::tangentialMotion
            )) {
        if (handle != nullptr) {
            gLastError = "tactile buffer kind is invalid.";
        }
        return nullptr;
    }
    return handle->context.nativeBuffer(
        static_cast<metalrobo::MetalTactileBuffer>(buffer_kind)
    );
}

const float* mr_tactile_depth(
    const MRTactileHandle* handle
) {
    return requireTactileHandle(handle) &&
        !handle->readback.penetrationDepthMeters.empty()
        ? handle->readback.penetrationDepthMeters.data()
        : nullptr;
}

const float* mr_tactile_depth_velocity(
    const MRTactileHandle* handle
) {
    return requireTactileHandle(handle) &&
        !handle->readback.depthVelocityMetersPerSecond.empty()
        ? handle->readback.depthVelocityMetersPerSecond.data()
        : nullptr;
}

const float* mr_tactile_tangential_motion(
    const MRTactileHandle* handle
) {
    return requireTactileHandle(handle) &&
        !handle->readback.tangentialMotion.empty()
        ? reinterpret_cast<const float*>(
            handle->readback.tangentialMotion.data()
        )
        : nullptr;
}

const uint32_t* mr_tactile_validity(
    const MRTactileHandle* handle
) {
    return requireTactileHandle(handle) &&
        !handle->readback.validity.empty()
        ? handle->readback.validity.data()
        : nullptr;
}

const uint32_t* mr_tactile_object_shape_ids(
    const MRTactileHandle* handle
) {
    return requireTactileHandle(handle) &&
        !handle->readback.objectShapeIds.empty()
        ? handle->readback.objectShapeIds.data()
        : nullptr;
}

const MRTactileSummaryC* mr_tactile_summaries(
    const MRTactileHandle* handle
) {
    return requireTactileHandle(handle) &&
        !handle->readback.summaries.empty()
        ? reinterpret_cast<const MRTactileSummaryC*>(
            handle->readback.summaries.data()
        )
        : nullptr;
}

} // extern "C"
